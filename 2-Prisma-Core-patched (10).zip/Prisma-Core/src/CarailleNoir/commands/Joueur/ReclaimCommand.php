<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class ReclaimCommand extends BaseCommand
{
 private const COOLDOWN = 86400;

 private const GRADE_REWARDS = [
  "noble"       => ["noble" => 1],
  "heros"       => ["heros" => 1],
  "héros"       => ["heros" => 1],
  "dieu"        => ["dieu"  => 1],
  "influenceur" => ["heros" => 1],
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("reclaim", "Reclamez votre recompense journaliere de grade", [], [], ["prisma.command.reclaim"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  $gradeId = strtolower($sender->getGradeId());
  $rewards = self::GRADE_REWARDS[$gradeId] ?? null;

  if ($rewards === null) {
   $sender->sendMessage("§cVotre grade ne donne pas acces a /reclaim.");
   return;
  }

  $name    = strtolower($sender->getName());
  $now     = time();
  $lastUse = $this->cooldowns[$name] ?? 0;
  $elapsed = $now - $lastUse;

  if ($elapsed < self::COOLDOWN) {
   $remaining = self::COOLDOWN - $elapsed;
   $h = (int)floor($remaining / 3600);
   $m = (int)floor(($remaining % 3600) / 60);
   $s = $remaining % 60;
   $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
   $sender->sendMessage("§cReclaim disponible dans : §f{$fmt}");
   return;
  }

  $this->cooldowns[$name] = $now;

  foreach ($rewards as $boxId => $qty) {
   $item = Manager::BOX()->makeKeyItem($boxId);
   if ($item === null) continue;
   $item->setCount($qty);
   $sender->getInventory()->addItem($item);
  }

  $sender->sendMessage("§aVotre reclaim de grade §f" . $sender->getGradeId() . " §aa ete distribue !");
 }
}
