<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;

class RepairCommand extends BaseCommand
{
 private const REPAIR_COST = 100;

 private const GRADE_COOLDOWNS = [
  "vote"           => 180,
  "noble"          => 120,
  "heros"          => 0,
  "héros"          => 0,
  "dieu"           => 0,
  "influenceur"    => 0,
  "fondateur"      => 0,
  "administrateur" => 0,
  "modérateur"     => 0,
  "guide"          => 120,
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("repair", "Reparer l'item en main", [], [], ["prisma.command.repair"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  $gradeId  = strtolower($sender->getGradeId());
  $cooldown = self::GRADE_COOLDOWNS[$gradeId] ?? 180;
  $name     = strtolower($sender->getName());
  $now      = time();

  if ($cooldown > 0 && isset($this->cooldowns[$name])) {
   $remaining = $cooldown - ($now - $this->cooldowns[$name]);
   if ($remaining > 0) {
    $m = (int)floor($remaining / 60);
    $s = $remaining % 60;
    $fmt = $m > 0 ? "{$m}m {$s}s" : "{$s}s";
    $sender->sendMessage("§cRepair en cooldown : §f{$fmt} §crestant.");
    return;
   }
  }

  $item = $sender->getInventory()->getItemInHand();
  if (!$item instanceof Durable) {
   $sender->sendMessage("§cCet item n'est pas reparable !");
   return;
  }
  if ($item->getDamage() === 0) {
   $sender->sendMessage("§cVotre item n'est pas endommage !");
   return;
  }
  if (!$sender->hasMoney(self::REPAIR_COST)) {
   $sender->sendMessage("§cArgent insuffisant (§f" . number_format(self::REPAIR_COST) . "§6\$§c requis)");
   return;
  }

  $sender->removeMoney(self::REPAIR_COST);
  $item->setDamage(0);
  $sender->getInventory()->setItemInHand($item);
  if ($cooldown > 0) $this->cooldowns[$name] = $now;
  $sender->sendMessage("§aItem repare pour §f" . number_format(self::REPAIR_COST) . "§6\$");
 }
}
