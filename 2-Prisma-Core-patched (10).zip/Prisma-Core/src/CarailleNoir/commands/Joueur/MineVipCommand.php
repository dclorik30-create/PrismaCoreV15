<?php
namespace CarailleNoir\commands\Joueur;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\world\Position;
class MineVipCommand extends BaseCommand {
 public function __construct() { parent::__construct("minevip", "Téléporter à la mine VIP", [], [], ["prisma.command.minevip"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $cfg = Manager::MINE()->getVipMineConfig();
 $worldName = $cfg["world"] ?? "MineVIP";
 $spawn = $cfg["spawn"] ?? ["x" => -1, "y" => 119, "z" => 16];
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 // Essai insensible à la casse si le nom exact échoue
 if (!$wm->isWorldLoaded($worldName)) $wm->loadWorld($worldName);
 $world = $wm->getWorldByName($worldName);
 if ($world === null) {
 foreach ($wm->getWorlds() as $w) {
 if (strtolower($w->getFolderName()) === strtolower($worldName)) {
 $world = $w; break;
 }
 }
 }
 if ($world === null) { $sender->sendMessage("§cMine VIP introuvable !"); return; }
 $pos = isset($spawn["x"]) ? new Position($spawn["x"], $spawn["y"], $spawn["z"], $world) : $world->getSpawnLocation();
 $sender->teleport($pos);
 $sender->sendMessage("§aTéléporté à la mine VIP !");
 }
}
