<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Admin;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\TIGManager;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\world\World;

class MineInitializeCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct(
            "mineinitialize",
            "Initialiser les positions d\'une mine ou de la TIG",
            [], [],
            ["prisma.command.staff", "prisma.command.mineinitialize"]
        );
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("type")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $type = strtolower((string)($args["type"] ?? ""));

        // ── Mines classiques ──────────────────────────────────────────
        if (in_array($type, ["mine", "minevip"], true)) {
            $count = Manager::MINE()->initializeMine($type);
            $sender->sendMessage("§aInitialisation terminee pour §f{$type}§a : §e{$count} §abedrocks enregistrees.");
            $sender->sendMessage("§7Logique: bedrock -> 8s -> minerai, minerai casse -> air -> bedrock -> 8s -> minerai.");
            return;
        }

        // ── TIG : scan de tous les blocs d\'or ───────────────────────
        if ($type === "tig") {
            $sender->sendMessage("§6[TIG] §fScan des blocs d\'or en cours...");

            $worldName = TIGManager::TIG_WORLD;
            $wm        = Server::getInstance()->getWorldManager();

            if (!$wm->isWorldLoaded($worldName) && !$wm->loadWorld($worldName)) {
                $sender->sendMessage("§c[TIG] Impossible de charger le monde §f{$worldName}§c !");
                return;
            }

            $world = null;
            foreach ($wm->getWorlds() as $w) {
                if (strtolower($w->getFolderName()) === strtolower($worldName)) {
                    $world = $w;
                    break;
                }
            }
            if ($world === null) {
                $sender->sendMessage("§c[TIG] Monde §f{$worldName} §cintrouvable !");
                return;
            }

            // Charger tous les chunks de la map TIG (petite map = acceptable)
            $goldId    = VanillaBlocks::GOLD()->getTypeId();
            $positions = [];

            // Recuperer les dimensions du monde pour charger tous ses chunks
            $provider = $world->getProvider();
            $worldData = $provider->getWorldData();
            // Charger les chunks autour du spawn en grand rayon pour couvrir toute la map TIG
            $spawnX = (int)($world->getSpawnLocation()->x >> 4);
            $spawnZ = (int)($world->getSpawnLocation()->z >> 4);
            $radius = 32; // couvre 1024 blocs de rayon — suffisant pour une petite map TIG
            for ($cx2 = $spawnX - $radius; $cx2 <= $spawnX + $radius; $cx2++) {
                for ($cz2 = $spawnZ - $radius; $cz2 <= $spawnZ + $radius; $cz2++) {
                    $world->loadChunk($cx2, $cz2);
                }
            }

            foreach ($world->getLoadedChunks() as $chunkHash => $chunk) {
                World::getXZ($chunkHash, $cx, $cz);
                for ($x = $cx << 4; $x < ($cx << 4) + 16; $x++) {
                    for ($z = $cz << 4; $z < ($cz << 4) + 16; $z++) {
                        for ($y = World::Y_MIN; $y <= World::Y_MAX; $y++) {
                            if ($world->getBlockAt($x, $y, $z)->getTypeId() === $goldId) {
                                $positions[] = ["x" => $x, "y" => $y, "z" => $z];
                            }
                        }
                    }
                }
            }

            Manager::TIGBLOCK()->savePositions($positions);
            $count = count($positions);
            $sender->sendMessage("§6[TIG] §aScan termine : §e{$count} §abloc(s) d\'or enregistre(s).");
            $sender->sendMessage("§7Logique : or casse -> bedrock 30s -> or | Aucun drop | §e+1000$ §7par bloc.");
            return;
        }

        $sender->sendMessage("§cUsage : /mineinitialize <mine|minevip|tig>");
    }
}
