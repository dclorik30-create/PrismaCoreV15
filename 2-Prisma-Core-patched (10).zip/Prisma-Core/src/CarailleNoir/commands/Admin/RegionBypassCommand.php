<?php
namespace CarailleNoir\commands\Admin;

use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\plugin\Plugin;
use pocketmine\plugin\PluginOwned;
use CarailleNoir\Core;

class RegionBypassCommand extends Command implements PluginOwned
{
 public function __construct(private Core $plugin)
 {
  parent::__construct("regionbypass", "Toggle le bypass des regions", null, ["rbypass"]);
  $this->setPermission("prisma.command.regionbypass");
 }

 public function getOwningPlugin(): Plugin { return $this->plugin; }

 public function execute(CommandSender $sender, string $commandLabel, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) {
   $sender->sendMessage("§cCommande reservee aux joueurs.");
   return;
  }
  if (!$sender->hasPermission("prisma.command.regionbypass")) {
   $sender->sendMessage("§cVous n'avez pas la permission.");
   return;
  }

  $new = !$sender->hasRegionBypass();
  $sender->setRegionBypass($new);
  $sender->sendMessage($new
   ? "§a[Region] Bypass §lACTIVE§r§a - vous pouvez poser/casser dans toutes les regions."
   : "§c[Region] Bypass §lDESACTIVE§r§c."
  );
 }
}
