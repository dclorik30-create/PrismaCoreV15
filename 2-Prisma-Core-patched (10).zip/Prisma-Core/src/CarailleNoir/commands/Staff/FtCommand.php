<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class FtCommand extends BaseCommand
{
 private const KEYS = [
 "outpost", "koth", "afkkey", "totem",
 "topkills", "topdeaths", "toppower", "topmoney", "ftop",
 "vote", "discord",
 "topassist", "topkillstreak", "topniveau",
        "box",
        ];

 public function __construct()
 {
 parent::__construct("ft", "Gestion des Floating Texts", [], [], ["prisma.command.staff"]);
 }

 protected function prepare(): array
 {
 return [
 new RawStringArgument("action"),
 new RawStringArgument("key", true),
 ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $action = strtolower($args["action"] ?? "");

 switch ($action) {
 case "list":
 $sender->sendMessage("§e§l--- Floating Texts ---");
 foreach (self::KEYS as $k) {
 $pos = Manager::FLOATINGTEXT()->getPosition($k);
 if ($pos !== null) {
 $sender->sendMessage("§f{$k} §7: §a" .
 $pos["world"] . " " .
 round($pos["x"], 1) . " " .
 round($pos["y"], 1) . " " .
 round($pos["z"], 1));
 } else {
 $sender->sendMessage("§f{$k} §7: §cNon configure");
 }
 }
 break;

 case "setpos":
 if (!$sender instanceof Player) {
 $sender->sendMessage("§cCommande en jeu uniquement.");
 return;
 }
 $key = strtolower($args["key"] ?? "");
 if (!in_array($key, self::KEYS, true)) {
 $sender->sendMessage("§cCle invalide. Cles : " . implode(", ", self::KEYS));
 return;
 }
 $pos = $sender->getPosition();
 Manager::FLOATINGTEXT()->setPosition($key, [
 "world" => $pos->getWorld()->getFolderName(),
 "x" => round($pos->getX(), 2),
 "y" => round($pos->getY() + 1.62, 2), // hauteur des yeux
 "z" => round($pos->getZ(), 2),
 ]);
 $sender->sendMessage("§aPosition du panneau §f{$key} §amise a jour !");
 break;

 case "respawn":
 $key = strtolower($args["key"] ?? "");
 if ($key !== "" && !in_array($key, self::KEYS, true)) {
 $sender->sendMessage("§cCle invalide. Cles : " . implode(", ", self::KEYS));
 return;
 }
 Manager::FLOATINGTEXT()->respawn($key !== "" ? $key : null);
 $sender->sendMessage($key !== ""
 ? "§aPanneau §f{$key} §arespawn !"
 : "§aTous les panneaux ont ete respawn !");
 break;

 case "delete":
 $key = strtolower($args["key"] ?? "");
 if ($key === "all") {
 Manager::FLOATINGTEXT()->deleteAll();
 $sender->sendMessage("§aTous les panneaux ont ete supprimés.");
 } elseif (in_array($key, self::KEYS, true)) {
 Manager::FLOATINGTEXT()->delete($key);
 $sender->sendMessage("§aPanneau §f{$key} §asupprimé.");
 } else {
 $sender->sendMessage("§cCle invalide. Utilisez 'all' ou une cle valide : " . implode(", ", self::KEYS));
 }
 break;

 default:
 $sender->sendMessage("§eUsage :");
 $sender->sendMessage("§f/ft list §7- Liste tous les panneaux");
 $sender->sendMessage("§f/ft setpos <key> §7- Place un panneau a ta position (hauteur des yeux)");
 $sender->sendMessage("§f/ft respawn [key] §7- Respawn un ou tous les panneaux");
 $sender->sendMessage("§f/ft delete <key|all> §7- Supprime un ou tous les panneaux");
 $sender->sendMessage("§7Cles : §f" . implode("§7, §f", self::KEYS));
 break;
 }
 }
}
