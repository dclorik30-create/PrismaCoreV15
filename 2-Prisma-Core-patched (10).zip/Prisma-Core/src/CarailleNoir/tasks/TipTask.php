<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class TipTask extends Task
{
    private const ARCPUNCH_CD = 8;

    public function onRun(): void
    {
        if (empty(PlayerListener::$arcPunchCooldowns)) return;

        $now = time();
        foreach (PlayerListener::$arcPunchCooldowns as $name => $ts) {
            $remaining = self::ARCPUNCH_CD - ($now - $ts);
            $player    = Server::getInstance()->getPlayerExact($name);
            if ($player === null || !$player instanceof PrismaPlayer) {
                unset(PlayerListener::$arcPunchCooldowns[$name]);
                continue;
            }
            if ($remaining > 0) {
                $player->sendTip("§6Arc-Punch §8» §c" . $remaining . "s");
            } else {
                unset(PlayerListener::$arcPunchCooldowns[$name]);
                $player->sendTip("§6Arc-Punch §8» §aPret !");
            }
        }
    }
}
