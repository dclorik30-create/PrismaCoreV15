<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\items\SpecialItems;
use CarailleNoir\managers\Manager;
use CarailleNoir\PrismaItems\blocks\spawner\CreeperSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\SkeletonSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\ZombieSpawner;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\console\ConsoleCommandSender;
use pocketmine\utils\Config;

class LevelRewardManager
{
    /** @var array<int, array{label:string,money:int|null,items:array,command:string|null}> */
    private array $rewards = [];

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . "rewards.yml", Config::YAML);
        foreach ((array)$cfg->get("rewards", []) as $lvl => $data) {
            $data = (array)$data;
            $this->rewards[(int)$lvl] = [
                "label"   => (string)($data["label"]   ?? "Niveau {$lvl}"),
                "money"   => isset($data["money"])   ? (int)$data["money"]   : null,
                "items"   => (array)($data["items"]  ?? []),
                "command" => isset($data["command"])  ? (string)$data["command"] : null,
            ];
        }
    }

    public function getReward(int $level): ?array   { return $this->rewards[$level] ?? null; }
    public function getLabel(int $level): string    { return $this->rewards[$level]["label"] ?? "Récompense Niv. {$level}"; }
    public function getAllRewards(): array           { return $this->rewards; }

    public function isClaimed(string $player, int $level): bool
    {
        return Manager::LEVEL_DATA()->hasClaimed($player, $level);
    }

    /** @return int[] */
    public function getAvailableRewards(string $player): array
    {
        $playerLvl = Manager::LEVEL_DATA()->getLevel($player);
        $available = [];
        foreach (array_keys($this->rewards) as $lvl) {
            if ($lvl <= $playerLvl && !Manager::LEVEL_DATA()->hasClaimed($player, $lvl)) {
                $available[] = $lvl;
            }
        }
        return $available;
    }

    private function makeItem(string $id, int $count): ?Item
    {
        // Items spéciaux avec lore custom
        $item = match ($id) {
            "special:switchball"     => SpecialItems::makeSwitchBall(),
            "special:eggtrap"        => SpecialItems::makeEggTrap(),
            "special:bump"           => SpecialItems::makeBump(),
            "special:freeze_stick"   => SpecialItems::makeFreezeStick(),
            "special:anti_pearl"     => SpecialItems::makeAntiPearlStick(),
            "special:anti_item"      => SpecialItems::makeAntiItemStick(),
            "special:arc_punch"      => SpecialItems::makeArcPunch(),
            "special:pumpkin_stick"  => SpecialItems::makePumpkinStick(),
            "special:teleport_stick" => SpecialItems::makeTeleportStick(),
            "special:elevateur"      => (new \CarailleNoir\PrismaItems\blocks\ElevatorBlock())->asItem(),
            "special:creeper_spawner"=> VanillaBlocks::MONSTER_SPAWNER()->asItem(),
            "special:skeleton_spawner"=>VanillaBlocks::MONSTER_SPAWNER()->asItem(),
            "special:zombie_spawner" => VanillaBlocks::MONSTER_SPAWNER()->asItem(),
            default                  => null,
        };

        // Spawners via PrismaItems
        if ($item === null) {
            $item = match ($id) {
                "special:creeper_spawner"  => (new CreeperSpawner())->asItem(),
                "special:skeleton_spawner" => (new SkeletonSpawner())->asItem(),
                "special:zombie_spawner"   => (new ZombieSpawner())->asItem(),
                default => null,
            };
        }

        if ($item !== null) {
            $item->setCount($count);
            return $item;
        }

        // Fallback : StringToItemParser pour items enregistrés (prisma:*, minecraft:*)
        $parsed = StringToItemParser::getInstance()->parse($id);
        if ($parsed !== null && !$parsed->isNull()) {
            $parsed->setCount($count);
            return $parsed;
        }

        return null;
    }

    public function claimReward(Player $player, int $level): string
    {
        $name      = $player->getName();
        $playerLvl = Manager::LEVEL_DATA()->getLevel($name);

        if ($playerLvl < $level)                                return "locked";
        if (Manager::LEVEL_DATA()->hasClaimed($name, $level))  return "already";

        $reward = $this->rewards[$level] ?? null;
        if ($reward === null)                                   return "no_reward";

        foreach ($reward["items"] as $itemData) {
            $itemData = (array)$itemData;
            $id    = (string)($itemData["id"]    ?? "");
            $count = (int)($itemData["count"] ?? 1);
            $item  = $this->makeItem($id, $count);
            if ($item !== null) {
                $player->getInventory()->addItem($item);
            }
        }

        if ($reward["money"] !== null && $reward["money"] > 0) {
            Manager::COINS()->addCoins($player->getName(), $reward["money"]);
            $player->sendMessage("§8[§6Récompense§8] §fVous recevez §6" . $reward["money"] . " §eCoins§f !");
        }

        if ($reward["command"] !== null) {
            $cmd = str_replace("%player%", $player->getName(), $reward["command"]);
            $player->getServer()->dispatchCommand(new ConsoleCommandSender($player->getServer(), $player->getServer()->getLanguage()), $cmd);
        }

        Manager::LEVEL_DATA()->addClaimed($name, $level);
        Manager::LEVEL_DATA()->save($name);

        $player->sendMessage(
            "§8[§6Récompense§8] §fRécompense du §6niveau {$level}§f récupérée : §e" .
            $reward["label"] . "§f !"
        );
        return "ok";
    }
}
