<?php
namespace CarailleNoir\managers\type;
use CarailleNoir\handlers\DataHandler;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\VanillaItems;

class KitManager extends DataHandler
{
 private const NO_COOLDOWN = ["joueur", "refill"];
 private const KITS = [
 "joueur"      => ["name" => "§7Joueur",      "cooldown" => 86400, "permission" => ""],
 "noble"       => ["name" => "§aNoble",        "cooldown" => 43200, "permission" => "prisma.kit.noble"],
 "heros"       => ["name" => "§bHéros",        "cooldown" => 21600, "permission" => "prisma.kit.heros"],
 "dieu"        => ["name" => "§6Dieu",         "cooldown" => 10800, "permission" => "prisma.kit.dieu"],
 "influenceur" => ["name" => "§dInfluenceur",  "cooldown" => 86400, "permission" => "prisma.kit.influenceur"],
 "vote"        => ["name" => "§eVote",         "cooldown" => 86400, "permission" => "prisma.kit.vote"],
 "refill"      => ["name" => "§fRefill",       "cooldown" => 1800,  "permission" => ""],
 "outils"      => ["name" => "§eOutils",       "cooldown" => 86400, "permission" => ""],
 ];

 public function init(): void { $this->loadData("Kit", "Cooldowns.json"); }
 public function saveData(): void { parent::saveData(); }
 public function kitExists(string $name): bool { return isset(self::KITS[strtolower($name)]); }
 public function getKit(string $name): ?array { return self::KITS[strtolower($name)] ?? null; }
 public function getKits(): array { return self::KITS; }

 public function hasCooldown(string $player, string $kitName): bool
 {
 if (in_array(strtolower($kitName), self::NO_COOLDOWN, true)) return false;
 $ts = (int)($this->data[strtolower($player) . "." . strtolower($kitName)] ?? 0);
 if ($ts === 0) return false;
 return (time() - $ts) < (int)((self::KITS[strtolower($kitName)]["cooldown"] ?? 0));
 }

 public function getCooldownRemaining(string $player, string $kitName): int
 {
 $ts = (int)($this->data[strtolower($player) . "." . strtolower($kitName)] ?? 0);
 if ($ts === 0) return 0;
 return max(0, (int)(self::KITS[strtolower($kitName)]["cooldown"] ?? 0) - (time() - $ts));
 }

 public function formatCooldown(int $seconds): string
 {
 if ($seconds <= 0) return "0s";
 $d = intdiv($seconds, 86400);
 $h = intdiv($seconds % 86400, 3600);
 $m = intdiv($seconds % 3600, 60);
 $s = $seconds % 60;
 $parts = [];
 if ($d > 0) $parts[] = "{$d}j";
 if ($h > 0) $parts[] = "{$h}h";
 if ($m > 0) $parts[] = "{$m}m";
 if ($s > 0 && $d === 0) $parts[] = "{$s}s";
 return implode(" ", $parts);
 }

 public function setCooldown(string $player, string $kitName): void
 {
 if (in_array(strtolower($kitName), self::NO_COOLDOWN, true)) return;
 $this->data[strtolower($player) . "." . strtolower($kitName)] = time();
 }

 private function buildKitItems(string $kitId): array
 {
 return match ($kitId) {
 "joueur" => [
 VanillaItems::IRON_HELMET()->setCount(1), VanillaItems::IRON_CHESTPLATE()->setCount(1),
 VanillaItems::IRON_LEGGINGS()->setCount(1), VanillaItems::IRON_BOOTS()->setCount(1),
 VanillaItems::IRON_SWORD()->setCount(1), SpecialItems::makeSoup(32), VanillaItems::ENDER_PEARL()->setCount(8),
 ],
 "noble" => [
 VanillaItems::IRON_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 2))->setCount(1),
 SpecialItems::makeSoup(48), VanillaItems::ENDER_PEARL()->setCount(12),
 ],
 "heros" => [
 VanillaItems::IRON_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::IRON_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::IRON_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::IRON_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 3))->setCount(1),
 SpecialItems::makeSoup(64), VanillaItems::ENDER_PEARL()->setCount(16),
 ],
 "dieu" => [
 VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->setCount(1),
 VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->setCount(1),
 VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->setCount(1),
 VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 4))->setCount(1),
 VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 5))->setCount(1),
 SpecialItems::makeSoup(64), VanillaItems::ENDER_PEARL()->setCount(16), VanillaItems::GOLDEN_APPLE()->setCount(4),
 ],
 "influenceur" => [
 VanillaItems::DIAMOND_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::DIAMOND_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::DIAMOND_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::DIAMOND_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 3))->setCount(1),
 VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 4))->setCount(1),
 SpecialItems::makeSoup(64), VanillaItems::ENDER_PEARL()->setCount(16), VanillaItems::GOLDEN_APPLE()->setCount(2),
 ],
 "vote" => [
 VanillaItems::IRON_HELMET()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_CHESTPLATE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_LEGGINGS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::IRON_BOOTS()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), 2))->setCount(1),
 VanillaItems::DIAMOND_SWORD()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::SHARPNESS(), 2))->setCount(1),
 SpecialItems::makeSoup(48), VanillaItems::ENDER_PEARL()->setCount(12),
 ],
 "refill" => [SpecialItems::makeSoup(32), VanillaItems::ENDER_PEARL()->setCount(8)],
 "outils" => [
 VanillaItems::DIAMOND_PICKAXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3))->setCount(1),
 VanillaItems::DIAMOND_SHOVEL()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3))->setCount(1),
 VanillaItems::DIAMOND_AXE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3))->setCount(1),
 VanillaItems::DIAMOND_HOE()->addEnchantment(new EnchantmentInstance(VanillaEnchantments::EFFICIENCY(), 5))->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3))->setCount(1),
 ],
 default => [],
 };
 }

 public function giveKit(PrismaPlayer $player, string $kitName): array
 {
 $kitId = strtolower($kitName);
 $kit = self::KITS[$kitId] ?? null;
 if ($kit !== null && ($kit["permission"] ?? "") !== "" && !$player->hasPermission($kit["permission"])) {
 $player->sendMessage("§cVous n'avez pas la permission d'utiliser le kit §f" . ($kit["name"] ?? $kitName) . "§c !");
 return [];
 }
 $items = $this->buildKitItems($kitId);
 $refused = [];
 foreach ($items as $item) {
 $leftover = $player->getInventory()->addItem($item);
 if (!empty($leftover)) $refused[] = $item->getName();
 }
 $this->setCooldown($player->getName(), $kitName);
 return $refused;
 }
}
