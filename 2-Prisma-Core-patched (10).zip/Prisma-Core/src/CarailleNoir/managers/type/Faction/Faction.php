<?php
namespace CarailleNoir\managers\type\Faction;
use CarailleNoir\managers\option\Faction\FactionPermissionEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;
class Faction
{
 public function __construct(
 private readonly string $id, private string $name, private string $owner,
 private string $description = "", private array $subOwner = [], private array $officers = [],
 private array $members = [], private array $recruits = [], private array $allies = [],
 private bool $allyBuildAllowed = false, private bool $allyClaimAllowed = false,
 private bool $everyoneIslandAllowed = true, private array $islandWhitelist = [],
 private ?array $home = null,
 private array $permissions = [
 FactionPermissionEnum::INVITE->value => FactionRoleEnum::OFFICIERS->value,
 FactionPermissionEnum::CLAIM->value => FactionRoleEnum::OWNER->value,
 FactionPermissionEnum::KICK->value => FactionRoleEnum::OFFICIERS->value,
 FactionPermissionEnum::PROMOTE->value => FactionRoleEnum::SUB_OWNER->value,
 FactionPermissionEnum::BUILD_ISLAND->value => FactionRoleEnum::RECRUITS->value,
 ],
 private int $power = 0
 ){}
 public function getId(): string { return $this->id; }
 public function getAllies(): array { return $this->allies; }
 public function isAllyBuildAllowed(): bool { return $this->allyBuildAllowed; }
 public function setAllyBuildAllowed(bool $v): void { $this->allyBuildAllowed = $v; }
 public function isAllyClaimAllowed(): bool { return $this->allyClaimAllowed; }
 public function setAllyClaimAllowed(bool $v): void { $this->allyClaimAllowed = $v; }
 public function isEveryoneIslandAllowed(): bool { return $this->everyoneIslandAllowed; }
 public function setEveryoneIslandAllowed(bool $v): void { $this->everyoneIslandAllowed = $v; }
 public function getIslandWhitelist(): array { return $this->islandWhitelist; }
 public function isWhitelistedForIsland(string $player): bool { return in_array(strtolower($player), array_map("strtolower", $this->islandWhitelist), true); }
 public function addIslandWhitelist(string $player): bool { if ($this->isWhitelistedForIsland($player)) return false; $this->islandWhitelist[] = $player; return true; }
 public function removeIslandWhitelist(string $player): bool { $before = count($this->islandWhitelist); $this->islandWhitelist = array_values(array_filter($this->islandWhitelist, fn($p) => strtolower($p) !== strtolower($player))); return count($this->islandWhitelist) !== $before; }
 public function addAlly(string $factionId): void { if (!in_array($factionId, $this->allies)) $this->allies[] = $factionId; }
 public function removeAlly(string $factionId): void { $this->allies = array_values(array_filter($this->allies, fn($a) => $a !== $factionId)); }
 public function isAlly(string $factionId): bool { return in_array($factionId, $this->allies); }
 public function getName(): string { return $this->name; }
 public function getOwner(): string { return $this->owner; }
 public function getDescription(): string { return $this->description; }
 public function setOwner(string $owner): void { $this->owner = $owner; }
 public function setName(string $name): void { $this->name = $name; }
 public function setDescription(string $description): void { $this->description = $description; }
 // Power
 public function getPower(): int { return $this->power; }
 public function setPower(int $power): void { $this->power = max(0, $power); }
 public function addPower(int $amount): void { $this->power = max(0, $this->power + $amount); }
 public function getHome(): ?array { return $this->home; }
 public function setHome(string $world, float $x, float $y, float $z, float $yaw = 0.0, float $pitch = 0.0): void {
 $this->home = ["world" => $world, "x" => $x, "y" => $y, "z" => $z, "yaw" => $yaw, "pitch" => $pitch];
 }
 public function deleteHome(): void { $this->home = null; }
 public function hasHome(): bool { return $this->home !== null; }
 public function add(string $player, FactionRoleEnum $role): void {
 if ($role === FactionRoleEnum::OWNER) { $this->owner = $player; return; }
 $prop = $role->value;
 if (!is_array($this->$prop)) $this->$prop = [];
 if (!in_array($player, $this->$prop)) { $this->$prop[] = $player; }
 }
 public function remove(string $player, ?FactionRoleEnum $role = null): void {
 foreach ($role ? [$role] : FactionRoleEnum::cases() as $r) {
 if ($r === FactionRoleEnum::OWNER) { if ($this->owner === $player) $this->owner = ""; continue; }
 $this->{$r->value} = array_values(array_filter((array)$this->{$r->value}, fn($p) => $p !== $player));
 }
 }
 public function get(FactionRoleEnum $role): array {
 if ($role === FactionRoleEnum::OWNER) return [$this->owner];
 $prop = $role->value; return is_array($this->$prop) ? $this->$prop : [];
 }
 public function getOnlinePlayers(): ?array {
 return array_filter(array_map(fn (string $player) => Server::getInstance()->getPlayerExact($player), array_merge($this->subOwner, $this->officers, $this->members, $this->recruits, [$this->owner])), fn(mixed $player) => $player instanceof PrismaPlayer);
 }
 public function sendFactionMessage(string $message): void { array_map(fn (PrismaPlayer $player) => $player->sendMessage($message), $this->getOnlinePlayers()); }
 public function getAll(): array { return array_merge($this->subOwner, $this->officers, $this->members, $this->recruits); }
 public function hasPlayer(string $player): bool { return $player === $this->owner || in_array($player, $this->getAll()); }
 public function getPlayerRole(string $player): ?FactionRoleEnum {
 if ($this->owner === $player) return FactionRoleEnum::OWNER;
 foreach (FactionRoleEnum::cases() as $role) { if ($role === FactionRoleEnum::OWNER) continue; if (in_array($player, (array)$this->{$role->value})) return $role; }
 return null;
 }
 public function setPermission(FactionPermissionEnum $permission, FactionRoleEnum $minRole): void { $this->permissions[$permission->value] = $minRole->name; }
 public function getPermission(FactionPermissionEnum $permission): ?FactionRoleEnum {
 $v = $this->permissions[$permission->value] ?? null;
 if($v instanceof FactionRoleEnum) return $v;
 if(is_string($v) && str_starts_with($v, 'E:')) $v = @unserialize($v)?->value ?? 'MEMBERS';
 return $v ? FactionRoleEnum::tryFrom($v) ?? FactionRoleEnum::MEMBERS : null;
 }
 public function hasPermission(FactionPermissionEnum $permission, string $player): bool {
 $playerRole = $this->getPlayerRole($player); if ($playerRole === null) return false;
 $minRole = $this->getPermission($permission); if ($minRole === null) return false;
 return $playerRole->getPriority() >= $minRole->getPriority();
 }
 public static function serialize(self $faction): array {
 return ["id" => $faction->id, "name" => $faction->name, "owner" => $faction->owner, "description" => $faction->description,
 "subOwner" => $faction->subOwner, "officers" => $faction->officers, "members" => $faction->members,
 "recruits" => $faction->recruits, "allies" => $faction->allies, "allyBuildAllowed" => $faction->allyBuildAllowed,
 "allyClaimAllowed" => $faction->allyClaimAllowed, "everyoneIslandAllowed" => $faction->everyoneIslandAllowed,
 "islandWhitelist" => $faction->islandWhitelist, "home" => $faction->home, "permissions" => $faction->permissions, "power" => $faction->power];
 }
 public static function unserialize(array $data): self {
 return new self($data["id"], $data["name"], $data["owner"], $data["description"] ?? "",
 $data["subOwner"] ?? [], $data["officers"] ?? [], $data["members"] ?? [], $data["recruits"] ?? [],
 $data["allies"] ?? [], (bool)($data["allyBuildAllowed"] ?? false), (bool)($data["allyClaimAllowed"] ?? false),
 (bool)($data["everyoneIslandAllowed"] ?? true), $data["islandWhitelist"] ?? [],
 $data["home"] ?? null, $data["permissions"] ?? [], (int)($data["power"] ?? 0));
 }
}
