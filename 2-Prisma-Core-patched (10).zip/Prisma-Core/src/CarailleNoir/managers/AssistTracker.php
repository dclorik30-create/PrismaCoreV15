<?php
declare(strict_types=1);
namespace CarailleNoir\managers;

class AssistTracker
{
    public const DEFAULT_WINDOW = 60;
    private static int $window = self::DEFAULT_WINDOW;

    /**
     * @var array<string, array<string, int>>
     *  victim_lower → [ attacker_lower => timestamp ]
     */
    private static array $hits = [];

    public static function setWindow(int $seconds): void
    {
        self::$window = max(1, $seconds);
    }

    public static function getWindow(): int
    {
        return self::$window;
    }

    public static function recordHit(string $victim, string $attacker): void
    {
        $v = strtolower($victim);
        $a = strtolower($attacker);
        if ($v === $a) return;
        self::$hits[$v][$a] = time();
    }

    /** @return string[] */
    public static function getAssists(string $victim, string $killer): array
    {
        $v = strtolower($victim);
        $k = strtolower($killer);
        $now = time();

        if (!isset(self::$hits[$v])) return [];

        $assists = [];
        foreach (self::$hits[$v] as $attacker => $ts) {
            if ($attacker === $k) continue;
            if (($now - $ts) <= self::$window) {
                $assists[] = $attacker;
            }
        }
        unset(self::$hits[$v]);
        return $assists;
    }

    public static function clear(string $victim): void
    {
        unset(self::$hits[strtolower($victim)]);
    }
}
