<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\managers\AssistTracker;
use CarailleNoir\managers\Manager;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class LevelXpListener implements Listener
{
    /** @var array<string,int> */
    private array $miningXp = [];
    /** @var array<string,int> */
    private array $farmingXp = [];
    private int $killXp = 30;

    private const CUSTOM_ORE_IDS = [
        DiamondOre::class => 'prisma:diamond_ore',
        EmeraldOre::class => 'prisma:emerald_ore',
        RubyOre::class => 'prisma:ruby_ore',
        PrismOre::class => 'prisma:prism_ore',
    ];

    private const CUSTOM_CROP_IDS = [
        \CarailleNoir\PrismaItems\blocks\RubyCrop::class => 'prisma:ruby_crop',
        \CarailleNoir\PrismaItems\blocks\PrismCrop::class => 'prisma:prism_crop',
    ];

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . 'xp_sources.yml', Config::YAML);

        foreach ((array) $cfg->get('mining', []) as $id => $xp) {
            $this->miningXp[strtolower((string) $id)] = (int) $xp;
        }
        foreach ((array) $cfg->get('farming', []) as $id => $xp) {
            $this->farmingXp[strtolower((string) $id)] = (int) $xp;
        }
        $kills = (array) $cfg->get('kills', []);
        $this->killXp = (int) ($kills['player'] ?? 30);
        AssistTracker::setWindow((int) ($kills['assist-window'] ?? AssistTracker::DEFAULT_WINDOW));
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        Manager::LEVEL()->getLevel($event->getPlayer()->getName());
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        Manager::LEVEL()->save($event->getPlayer()->getName());
    }

    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        $block = $event->getBlock();

        foreach (self::CUSTOM_ORE_IDS as $class => $id) {
            if ($block instanceof $class) {
                $xp = (int) ($this->miningXp[strtolower($id)] ?? 0);
                if ($xp > 0) {
                    Manager::LEVEL()->addExp($player, $xp, 'Minage');
                }
                return;
            }
        }

        foreach (self::CUSTOM_CROP_IDS as $class => $id) {
            if ($block instanceof $class) {
                $xp = (int) ($this->farmingXp[strtolower($id)] ?? 0);
                if ($xp > 0 && $this->isMatureCrop($block)) {
                    Manager::LEVEL()->addExp($player, $xp, 'Récolte');
                }
                return;
            }
        }

        $blockId = strtolower($this->getBlockStringId($block));
        if (isset($this->miningXp[$blockId])) {
            Manager::LEVEL()->addExp($player, $this->miningXp[$blockId], 'Minage');
            return;
        }
        if (isset($this->farmingXp[$blockId]) && $this->isMatureCrop($block)) {
            Manager::LEVEL()->addExp($player, $this->farmingXp[$blockId], 'Récolte');
        }
    }

    public function onEntityDamage(EntityDamageByEntityEvent $event): void
    {
        if ($event->isCancelled()) return;

        $victim = $event->getEntity();
        $attacker = $event->getDamager();
        if (!$attacker instanceof Player) return;

        $isFatal = ($victim->getHealth() - $event->getFinalDamage()) <= 0;
        if (!$isFatal) return;

        if ($victim instanceof Player && $attacker->getName() !== $victim->getName() && $this->killXp > 0) {
            Manager::LEVEL()->addExp($attacker, $this->killXp, 'Kill');
        }
    }

    private function getBlockStringId(Block $block): string
    {
        try {
            return \pocketmine\world\format\io\GlobalBlockStateHandlers::getSerializer()
                ->serializeBlock($block)
                ->getName();
        } catch (\Throwable) {
            return 'unknown:' . $block->getTypeId();
        }
    }

    private function isMatureCrop(Block $block): bool
    {
        if ($block instanceof \pocketmine\block\Crops) {
            return $block->getAge() >= $block->getMaxAge();
        }
        return true;
    }
}
