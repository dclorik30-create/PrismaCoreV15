<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;

/**
 * Drops personnalisés des minerais moddés Prisma.
 *
 * DiamondOre → prisma:diamond_ingot   (100%)
 * EmeraldOre → prisma:emerald_ingot   (100%)
 * RubyOre    → prisma:ruby_fragment    (1/25)
 * PrismOre   → prisma:prism_dust      (1/250)
 */
class OreDropListener implements Listener
{
    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();

        [$itemId, $chance] = match (true) {
            $block instanceof DiamondOre => ['prisma:diamond_ingot', 1.0        ],
            $block instanceof EmeraldOre => ['prisma:emerald_ingot', 1.0        ],
            $block instanceof RubyOre    => ['prisma:ruby_fragment', 1 / 25     ],
            $block instanceof PrismOre   => ['prisma:prism_dust',    1 / 250    ],
            default                      => [null, 0.0],
        };

        if ($itemId === null) return;

        // Annuler les drops vanilla
        $event->setDrops([]);

        // Appliquer le taux de drop
        if ($chance >= 1.0 || lcg_value() < $chance) {
            $item = StringToItemParser::getInstance()->parse($itemId);
            if ($item !== null && !$item->isNull()) {
                $item->setCount(1);
                $event->setDrops([$item]);
            }
        }
    }

    /** @deprecated Gardée pour compatibilité LevelXpListener */
    public static function resolveBlockId(object $idInfo): string
    {
        foreach (['getNamespaceId', 'getNamespace', 'getBlockNamespaceId'] as $m) {
            if (method_exists($idInfo, $m)) {
                $v = $idInfo->$m();
                if (is_string($v) && str_contains($v, ':')) return $v;
            }
        }
        try {
            foreach ((new \ReflectionClass($idInfo))->getProperties() as $p) {
                $p->setAccessible(true);
                $v = $p->getValue($idInfo);
                if (is_string($v) && str_contains($v, ':')) return $v;
            }
        } catch (\Throwable) {}
        return 'unknown';
    }
}
