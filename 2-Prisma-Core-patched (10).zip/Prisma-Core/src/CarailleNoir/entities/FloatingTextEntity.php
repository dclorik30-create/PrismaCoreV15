<?php
declare(strict_types=1);
namespace CarailleNoir\entities;

use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;

class FloatingTextEntity extends Entity
{
    protected function getInitialSizeInfo(): EntitySizeInfo { return new EntitySizeInfo(0.0, 0.0); }
    public static function getNetworkTypeId(): string { return EntityIds::ARMOR_STAND; }

    public function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);
        $this->setNameTagAlwaysVisible(true);
        $this->setNameTagVisible(true);
        $this->setScale(0.01);
        $this->setHasGravity(false);
        $this->setCanSaveWithChunk(false);
    }

    protected function getInitialDragMultiplier(): float { return 0.0; }
    protected function getInitialGravity(): float { return 0.0; }
    public function canBeCollidedWith(): bool { return false; }
    public function canCollideWith(Entity $entity): bool { return false; }
    public function attack(EntityDamageEvent $source): void { $source->cancel(); }

    protected function entityBaseTick(int $tickDiff = 1): bool
    {
        // FloatingText statique : aucune physique, aucun mouvement, skip le tick natif
        return false;
    }

    public function updateText(string $text): void
    {
        $this->setNameTag($text);
        $this->sendData($this->getViewers());
    }
}
