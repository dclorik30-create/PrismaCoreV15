<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\manager;

use pocketmine\item\Item;

/**
 * BoxManager (PrismaItems) — version épurée.
 *
 * Rôle unique : identifier le type de clé depuis sa lore.
 * La logique de loot est entièrement déléguée au Core (CarailleNoir\managers\Manager::BOX()).
 */
class BoxManager
{
    private const KEY_NAMES = [
        "vote"      => "§aCLÉ §2Vote",
        "noble"     => "§6CLÉ §eNoble",
        "heros"     => "§bCLÉ §3Héros",
        "dieu"      => "§6CLÉ §eDieu",
        "boutique"  => "§dCLÉ §5Boutique",
    ];

    /** Détecte le type de clé depuis la lore "§8ID:item_key_{type}" */
    public static function getKeyType(Item $item): ?string
    {
        foreach ($item->getLore() as $line) {
            if (str_starts_with($line, "§8ID:item_key_")) {
                $type = mb_substr($line, 14);
                if (isset(self::KEY_NAMES[$type])) return $type;
            }
        }
        return null;
    }

    public static function getKeyDisplayName(string $type): string
    {
        return self::KEY_NAMES[$type] ?? "§fClé §7" . ucfirst($type);
    }
}
