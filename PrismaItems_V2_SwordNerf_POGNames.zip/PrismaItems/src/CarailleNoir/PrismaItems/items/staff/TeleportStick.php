<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\staff;
use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
class TeleportStick extends Item implements ICustomItem {
 public function __construct() {
 parent::__construct(new ItemIdentifier("prisma:teleport_stick", 30057), "§dStick de Téléportation");
 $this->setLore(["§8ID:stick_teleport", "§7Tp vers le dernier attaquant !", "§eDuree : §f15s §8| §eCD : §f180s"]);
 }
 public function getMaxStackSize(): int { return 1; }
 public function getIdentifier(): ItemIdentifier {
 $id = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
 assert($id instanceof ItemIdentifier); return $id;
 }
 public function getItemBuilder(): ItemBuilder {
 return ItemBuilder::create()->setItem($this)->setDefaultMaxStack()->setDefaultName()
 ->setIcon("stick_tp")->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
 }
}
