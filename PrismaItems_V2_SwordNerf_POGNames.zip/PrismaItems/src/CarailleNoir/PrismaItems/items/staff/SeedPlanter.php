<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\staff;

use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;

class SeedPlanter extends Item implements ICustomItem
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:seed_planter", 30200),
            "§aSeed Planter"
        );
        $this->setLore(["§8ID:item_seed_planter", "§7Casse et replante en 3x3 !"]);
    }

    public function getMaxStackSize(): int { return 1; }

    public function getIdentifier(): ItemIdentifier
    {
        $identifier = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
        assert($identifier instanceof ItemIdentifier);
        return $identifier;
    }

    public function getItemBuilder(): ItemBuilder
    {
        return ItemBuilder::create()
            ->setItem($this)
            ->setDefaultMaxStack()
            ->setDefaultName()
            ->setIcon("item_seed_planter")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
    }
}
