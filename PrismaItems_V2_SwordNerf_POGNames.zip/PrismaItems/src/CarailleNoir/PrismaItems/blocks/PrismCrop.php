<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Component\OnInteractComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Component\Sub\MaterialSubComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\PropertyName;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\RenderMethodEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\TargetMaterialEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Permutation\Permutations;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Property\CropsProperty;

use CarailleNoir\PrismaItems\items\fragment\PrismDust;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use pocketmine\block\Block;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\BlockTypeInfo;
use pocketmine\block\utils\BlockEventHelper;
use pocketmine\item\Item;
use pocketmine\math\Facing;
use pocketmine\math\Vector3;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockPermutationBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Crops;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Graine de Prisme — pousse sur le Sable des Âmes (Soul Sand)
 * Pas de lumière nécessaire (comportement Verrue du Nether).
 *
 * canBeSupportedAt() est private dans Crops, donc on override directement
 * les méthodes publiques canBePlacedAt() et onNearbyBlockChange().
 */
class PrismCrop extends Crops
{
    public const MAX_AGE = 3;

    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:prism_crop", 4011),
            "Prism Crop",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    private function isOnSoulSand(): bool
    {
        return $this->getSide(Facing::DOWN)->getTypeId() === BlockTypeIds::SOUL_SAND;
    }

    /** Placement uniquement sur Soul Sand */
    public function canBePlacedAt(Block $blockReplace, Vector3 $clickVector, int $face, bool $isClickedBlock): bool
    {
        return $blockReplace->getSide(Facing::DOWN)->getTypeId() === BlockTypeIds::SOUL_SAND;
    }

    /** Se détruit si le bloc en-dessous n'est plus du Soul Sand */
    public function onNearbyBlockChange(): void
    {
        if (!$this->isOnSoulSand()) {
            $this->position->getWorld()->useBreakOn($this->position);
        }
    }

    /**
     * Pousse sans lumière (override onRandomTick sans CropGrowthHelper).
     */
    public function onRandomTick(): void
    {
        if ($this->age < static::MAX_AGE) {
            $block = clone $this;
            ++$block->age;
            BlockEventHelper::grow($this, $block, null);
        }
    }

    public function getDropsForCompatibleTool(Item $item): array
    {
        if ($this->age >= self::MAX_AGE) {
            $drops = [];
            // Graine de Prisme  : 1/30
            if (mt_rand(1, 30) === 1)  $drops[] = new PrismSeed();
            // Poussière de Prisme : 1/100
            if (mt_rand(1, 100) === 1) $drops[] = new PrismDust();
            return $drops;
        }
        return [];
    }

    /**
     * Override getDrops() pour garantir l'appel peu importe l'outil.
     */
    public function getDrops(Item $item): array
    {
        return $this->getDropsForCompatibleTool($item);
    }

    public function asItem(): Item
    {
        return new PrismSeed();
    }

    public function getBlockBuilder(): BlockPermutationBuilder
    {
        $ages = range(0, static::MAX_AGE);
        $identifier = explode(":", $this->getIdInfo()->getNamespaceId())[1];
        $builder = BlockPermutationBuilder::create()
            ->setBlock($this)
            ->setMaterialInstance(materials: [
                new MaterialSubComponent(TargetMaterialEnum::ALL, $identifier . "_0", RenderMethodEnum::ALPHA_TEST)
            ])
            ->addProperty(new CropsProperty($ages))
            ->setGeometry("geometry.crop.v2")
            ->addComponent(new OnInteractComponent())
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE))
            ->setCollisionBox(new Vector3(-8, 0, -8), new Vector3(16, 16, 16), false);
        foreach ($ages as $age) {
            $builder->addPermutation(Permutations::create()
                ->setCondition("query.block_state('" . PropertyName::CROPS->value . "') == $age")
                ->setMaterialInstance(materials: [
                    new MaterialSubComponent(TargetMaterialEnum::ALL, $identifier . "_$age", RenderMethodEnum::ALPHA_TEST)
                ]));
        }
        return $builder;
    }
}
