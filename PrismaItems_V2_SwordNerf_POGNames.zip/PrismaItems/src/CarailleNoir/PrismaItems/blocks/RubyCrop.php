<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;
use pocketmine\math\Vector3;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Component\OnInteractComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Component\Sub\MaterialSubComponent;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\PropertyName;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\RenderMethodEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Enum\TargetMaterialEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Permutation\Permutations;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Property\CropsProperty;

use CarailleNoir\PrismaItems\items\fragment\RubyFragment;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeInfo;
use pocketmine\item\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockPermutationBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Crops;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class RubyCrop extends Crops
{
    public const MAX_AGE = 3;

    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:ruby_crop", 4010),
            "Ruby Crop",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    public function getDropsForCompatibleTool(Item $item): array
    {
        if ($this->age >= self::MAX_AGE) {
            $drops = [];
            // Graine de Rubis : 1/15
            if (mt_rand(1, 15) === 1) $drops[] = new RubySeed();
            // Fragment de Rubis : 1/30
            if (mt_rand(1, 30) === 1) $drops[] = new RubyFragment();
            return $drops;
        }
        return [];
    }

    /**
     * Override getDrops() pour garantir l'appel peu importe l'outil.
     * PMMP5 saute getDropsForCompatibleTool() pour les blocs instant-break
     * si aucun outil n'est considéré "compatible".
     */
    public function getDrops(Item $item): array
    {
        return $this->getDropsForCompatibleTool($item);
    }

    public function asItem(): Item
    {
        return new RubySeed();
    }

    public function getBlockBuilder(): BlockPermutationBuilder
    {
        $ages = range(0, static::MAX_AGE);
        $identifier = explode(":", $this->getIdInfo()->getNamespaceId())[1];
        $builder = BlockPermutationBuilder::create()
            ->setBlock($this)
            ->setMaterialInstance(materials: [
                new MaterialSubComponent(TargetMaterialEnum::ALL, $identifier . "_0", RenderMethodEnum::ALPHA_TEST)
            ])
            ->addProperty(new CropsProperty($ages))
            ->setGeometry("geometry.crop.v2")
            ->addComponent(new OnInteractComponent())
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE))
            ->setCollisionBox(new Vector3(-8, 0, -8), new Vector3(16, 16, 16), false);
        foreach ($ages as $age) {
            $builder->addPermutation(Permutations::create()
                ->setCondition("query.block_state('" . PropertyName::CROPS->value . "') == $age")
                ->setMaterialInstance(materials: [
                    new MaterialSubComponent(TargetMaterialEnum::ALL, $identifier . "_$age", RenderMethodEnum::ALPHA_TEST)
                ]));
        }
        return $builder;
    }
}
