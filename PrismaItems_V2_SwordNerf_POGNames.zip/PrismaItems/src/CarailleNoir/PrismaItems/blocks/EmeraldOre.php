<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use pocketmine\item\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class EmeraldOre extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:emerald_ore", 4002),
            "§aMinerai d'Émeraude",
            new BlockTypeInfo(new BlockBreakInfo(3.0, BlockToolType::PICKAXE, 1))
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE));
    }

    /** Aucun drop direct — géré par OreDropListener (PrismaCore). */
    public function getDropsForCompatibleTool(Item $item): array { return []; }
    public function getDrops(Item $item): array { return []; }
}
