<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Bloc Élévateur — ID prisma:elevator (4202)
 * Sauter dessus → téléporte au prochain élévateur dans les 7 blocs au-dessus.
 * Sneaker dessus → téléporte au prochain élévateur dans les 7 blocs en-dessous.
 */
class ElevatorBlock extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:elevator", 4203),
            "§bBloc Élévateur",
            new BlockTypeInfo(new BlockBreakInfo(1.5, BlockToolType::PICKAXE, 1))
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::CONSTRUCTION));
    }
}
