<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;

/**
 * Ajoute les drops bonus (fragment + graine) lors du cassage de RubyOre / PrismOre.
 *
 * Taux de drop :
 *   RubyOre  → Fragment de Rubis  : 1/25
 *   RubyOre  → Graine de Rubis    : 1/15
 *   PrismOre → Fragment de Prisme : 1/250
 *   PrismOre → Graine de Prisme   : 1/100
 *
 * @priority NORMAL
 */
class OreDropListener implements Listener
{
    public function onBlockBreak(BlockBreakEvent $event): void
    {
        if ($event->isCancelled()) return;

        $block = $event->getBlock();

        if (!($block instanceof RubyOre) && !($block instanceof PrismOre)) {
            return;
        }

        $bonusDrops = $block->getBonusDrops();
        if ($bonusDrops === []) return;

        $world = $block->getPosition()->getWorld();
        $pos   = $block->getPosition()->add(0.5, 0.5, 0.5);

        foreach ($bonusDrops as $item) {
            $world->dropItem($pos, $item);
        }
    }
}
