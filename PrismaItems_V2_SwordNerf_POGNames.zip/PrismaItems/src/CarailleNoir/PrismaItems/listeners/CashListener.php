<?php
declare(strict_types=1);

namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\items\cash\CashCoins;
use CarailleNoir\PrismaItems\items\cash\CashMoney;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;

class CashListener implements Listener
{
    public function onUse(PlayerItemUseEvent $event): void
    {
        $item = $event->getItem();
        if (!($item instanceof CashMoney) && !($item instanceof CashCoins)) {
            return;
        }
        // handled by PrismaCore via lore/NBT; keep listener as marker/no-op to ensure item classes loaded
    }
}
