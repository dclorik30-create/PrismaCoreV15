<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\PrismaItems\blocks\PrismCrop;
use CarailleNoir\PrismaItems\blocks\RubyCrop;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use ReflectionClass;

/**
 * Gère les crops Prisma au cassage.
 *
 * Crop IMMATURE (age < MAX_AGE) :
 *   - Cancel l'event → PrismaCore NORMAL ne voit rien.
 *   - Retire le bloc manuellement.
 *   - Drop 1 graine correspondante.
 *   - Pas d'XP.
 *
 * Crop MATURE (age == MAX_AGE) :
 *   - Laisse l'event passer.
 *   - Impose les drops via getDropsForCompatibleTool().
 *   - Donne de l'XP (5 pour Ruby, 10 pour Prism).
 *
 * @priority LOWEST
 * @handleCancelled false
 */
class CropBreakListener implements Listener
{
    private function getAge(object $block): int
    {
        // Chercher la propriété 'age' dans la hiérarchie de classes
        $ref = new ReflectionClass($block);
        while ($ref !== false) {
            if ($ref->hasProperty('age')) {
                $prop = $ref->getProperty('age');
                $prop->setAccessible(true);
                return (int) $prop->getValue($block);
            }
            $ref = $ref->getParentClass();
        }
        return 0;
    }

    public function onCropBreak(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();

        $isRuby  = $block instanceof RubyCrop;
        $isPrism = $block instanceof PrismCrop;
        if (!$isRuby && !$isPrism) return;

        $world  = $block->getPosition()->getWorld();
        $pos    = $block->getPosition();
        $player = $event->getPlayer();
        $age    = $this->getAge($block);
        $maxAge = $isRuby ? RubyCrop::MAX_AGE : PrismCrop::MAX_AGE;

        if ($age < $maxAge) {
            // ── Immature : cancel + drop graine ──────────────────────────────
            $event->cancel();
            $world->setBlock($pos, VanillaBlocks::AIR());
            $seed = $isRuby ? new RubySeed() : new PrismSeed();
            $world->dropItem($pos->add(0.5, 0.5, 0.5), $seed);

        } else {
            // ── Mature : imposer drops + XP ──────────────────────────────────
            $drops = $block->getDropsForCompatibleTool($event->getItem());
            $event->setDrops($drops);
            $xp = $isRuby ? 5 : 10;
            Manager::LEVEL()->addExp($player, $xp, "Récolte");
        }
    }
}
