<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\BoxBlock;
use CarailleNoir\PrismaItems\manager\BoxManager;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\sound\PopSound;

class BoxListener implements Listener
{
    public function onInteract(PlayerInteractEvent $event): void
    {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if (!($event->getBlock() instanceof BoxBlock)) return;

        $event->cancel();

        $player  = $event->getPlayer();
        $hand    = $player->getInventory()->getItemInHand();
        $keyType = BoxManager::getKeyType($hand);

        if ($keyType === null) {
            $player->sendMessage("§c✗ Tenez une clé en main pour ouvrir cette Box !");
            return;
        }

        // ── Utiliser le Core BoxManager (boxes.json) ─────────────────────
        $coreBox = \CarailleNoir\managers\Manager::BOX();

        $box = $coreBox->getBox($keyType);
        if ($box === null) {
            $player->sendMessage("§c✗ Aucune récompense configurée pour la box §f{$keyType}§c.");
            return;
        }

        $loot = $coreBox->rollLoot($keyType);
        if ($loot === null) {
            $player->sendMessage("§c✗ Erreur : aucun loot disponible.");
            return;
        }

        $rewardItem = $coreBox->makeLootItem($loot);
        if ($rewardItem === null || $rewardItem->isNull()) {
            $player->sendMessage("§c✗ Erreur : impossible de créer l'item de récompense.");
            return;
        }

        // Consommer 1 clé
        $hand->setCount($hand->getCount() - 1);
        $player->getInventory()->setItemInHand($hand->getCount() > 0 ? $hand : \pocketmine\item\VanillaItems::AIR());

        // Donner la récompense (drop au sol si inventaire plein)
        $leftover = $player->getInventory()->addItem($rewardItem);
        foreach ($leftover as $drop) {
            $player->getWorld()->dropItem($player->getPosition(), $drop);
        }

        // Effets visuels
        $pos = $event->getBlock()->getPosition()->add(0.5, 0.5, 0.5);
        $player->getWorld()->addParticle($pos, new HugeExplodeParticle());
        $player->getWorld()->addSound($pos, new PopSound());

        $display = $loot["display"] ?? ("§f" . $rewardItem->getName() . " x" . $rewardItem->getCount());
        $boxName = $box["name"] ?? $keyType;

        $player->sendMessage("§6» {$boxName} §6- §eRécompense : §f{$display}");
        $player->sendTitle("§6 BOX OUVERTE ", $display, 5, 40, 10);
    }

    public function onBreak(BlockBreakEvent $event): void
    {
        if (!($event->getBlock() instanceof BoxBlock)) return;

        if (!$event->getPlayer()->hasPermission("prismabox.admin")) {
            $event->cancel();
            $event->getPlayer()->sendMessage("§c✗ Permission §fprismabox.admin §crequise pour casser la Box !");
            return;
        }

        $event->setDrops([]);
        $item = StringToItemParser::getInstance()->parse("prisma:box");
        if ($item !== null) {
            $item->setCount(1);
            $event->getBlock()->getPosition()->getWorld()->dropItem(
                $event->getBlock()->getPosition()->add(0.5, 0.5, 0.5), $item
            );
        }
        $event->getPlayer()->sendMessage("§a✓ Box récupérée !");
    }
}
