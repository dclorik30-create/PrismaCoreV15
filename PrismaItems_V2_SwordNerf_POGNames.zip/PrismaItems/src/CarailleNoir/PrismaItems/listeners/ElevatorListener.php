<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\ElevatorBlock;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJumpEvent;
use pocketmine\event\player\PlayerToggleSneakEvent;
use pocketmine\math\Vector3;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\PopSound;
use pocketmine\color\Color;

class ElevatorListener implements Listener
{
    private const MAX_RANGE = 7;

    /**
     * Sauter sur un élévateur → téléporte vers le prochain élévateur AU-DESSUS.
     */
    public function onJump(PlayerJumpEvent $event): void
    {
        $player = $event->getPlayer();
        $world  = $player->getWorld();
        $pos    = $player->getPosition();

        // Bloc sous les pieds du joueur
        $belowPos = $pos->floor()->subtract(0, 1, 0);
        $below    = $world->getBlock($belowPos);

        if (!($below instanceof ElevatorBlock)) return;

        // Chercher un élévateur dans les 7 blocs AU-DESSUS
        for ($i = 1; $i <= self::MAX_RANGE; $i++) {
            $checkPos   = $belowPos->add(0, $i + 1, 0); // +1 pour passer la hauteur du joueur
            $checkBlock = $world->getBlock($checkPos->subtract(0, 1, 0));
            if ($checkBlock instanceof ElevatorBlock) {
                // Téléporter le joueur au-dessus du bloc trouvé
                $dest = new Vector3(
                    $pos->x,
                    $checkPos->y,
                    $pos->z
                );
                $player->teleport($dest);
                $this->effects($player, $dest);
                $player->sendTip("§b▲ Élévateur §f→ §eMonté !");
                return;
            }
        }
    }

    /**
     * Sneaker sur un élévateur → téléporte vers le prochain élévateur EN-DESSOUS.
     */
    public function onSneak(PlayerToggleSneakEvent $event): void
    {
        if (!$event->isSneaking()) return;

        $player = $event->getPlayer();
        $world  = $player->getWorld();
        $pos    = $player->getPosition();

        // Bloc sous les pieds du joueur
        $belowPos = $pos->floor()->subtract(0, 1, 0);
        $below    = $world->getBlock($belowPos);

        if (!($below instanceof ElevatorBlock)) return;

        // Chercher un élévateur dans les 7 blocs EN-DESSOUS
        for ($i = 1; $i <= self::MAX_RANGE; $i++) {
            $checkPos   = $belowPos->subtract(0, $i, 0);
            $checkBlock = $world->getBlock($checkPos);
            if ($checkBlock instanceof ElevatorBlock) {
                // Téléporter le joueur au-dessus du bloc trouvé
                $dest = new Vector3(
                    $pos->x,
                    $checkPos->y + 1,
                    $pos->z
                );
                $player->teleport($dest);
                $this->effects($player, $dest);
                $player->sendTip("§b▼ Élévateur §f→ §eDescendu !");
                return;
            }
        }
    }

    private function effects(\pocketmine\player\Player $player, Vector3 $pos): void
    {
        $world = $player->getWorld();
        $center = $pos->add(0.5, 0.5, 0.5);
        $world->addParticle($center, new DustParticle(new Color(0, 200, 255)));
        $world->addSound($center, new PopSound());
    }
}
