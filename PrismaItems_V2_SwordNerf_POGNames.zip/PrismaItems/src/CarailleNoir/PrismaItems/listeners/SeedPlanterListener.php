<?php
declare(strict_types=1);

namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\items\staff\SeedPlanter;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use CarailleNoir\PrismaItems\blocks\RubyCrop;
use CarailleNoir\PrismaItems\blocks\PrismCrop;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Crops;
use pocketmine\block\Farmland;
use pocketmine\block\VanillaBlocks;
use CarailleNoir\managers\Manager;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\ItemTypeIds;

class SeedPlanterListener implements Listener
{
    /** @var array<string, float> */
    private static array $cooldowns = [];

    public function onBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if (!($player->getInventory()->getItemInHand() instanceof SeedPlanter)) {
            return;
        }

        $name = $player->getName();
        $now = microtime(true) * 1000;
        if (isset(self::$cooldowns[$name]) && ($now - self::$cooldowns[$name]) < 100) {
            return;
        }
        self::$cooldowns[$name] = $now;

        $block = $event->getBlock();
        if (!($block instanceof Crops) && !($block instanceof RubyCrop) && !($block instanceof PrismCrop)) {
            return;
        }

        $event->cancel();

        $center = $block->getPosition();
        $world = $center->getWorld();
        $inv = $player->getInventory();

        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dz = -1; $dz <= 1; $dz++) {
                $pos = $center->add($dx, 0, $dz);
                $crop = $world->getBlock($pos);
                if (!($crop instanceof Crops)) {
                    continue;
                }

                $drops = $crop->getDrops($player->getInventory()->getItemInHand());
                $world->setBlock($pos, VanillaBlocks::AIR());

                foreach ($drops as $drop) {
                    if ($inv->canAddItem($drop)) {
                        $inv->addItem($drop);
                    } else {
                        $world->dropItem($pos->add(0.5, 0.5, 0.5), $drop);
                    }
                }

                // XP uniquement si la pousse était mature
                if ($crop->getAge() >= $crop->getMaxAge()) {
                    Manager::LEVEL()->addExp($player, 5, "Récolte");
                }
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void
    {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            return;
        }

        $player = $event->getPlayer();
        if (!($player->getInventory()->getItemInHand() instanceof SeedPlanter)) {
            return;
        }

        $clicked = $event->getBlock();
        if (!($clicked instanceof Crops) && !($clicked instanceof Farmland)) {
            return;
        }

        $name = $player->getName();
        $now = microtime(true) * 1000;
        if (isset(self::$cooldowns[$name]) && ($now - self::$cooldowns[$name]) < 100) {
            $event->cancel();
            return;
        }
        self::$cooldowns[$name] = $now;

        $event->cancel();

        $world = $clicked->getPosition()->getWorld();
        $inv = $player->getInventory();

        $bestTypeId = null;
        $bestCount = 0;
        // Récupérer les RubySeed/PrismSeed custom directement depuis l'inventaire
        $customSeed = null;
        foreach ($inv->getContents() as $invItem) {
            if ($invItem instanceof RubySeed || $invItem instanceof PrismSeed) {
                $customSeed = $invItem;
                break;
            }
        }

        $validTypeIds = [
            ItemTypeIds::WHEAT_SEEDS,
            ItemTypeIds::CARROT,
            ItemTypeIds::POTATO,
            ItemTypeIds::BEETROOT_SEEDS,
        ];

        foreach ($inv->getContents() as $item) {
            $typeId = $item->getTypeId();
            if (in_array($typeId, $validTypeIds, true) && $item->getCount() > $bestCount) {
                $bestTypeId = $typeId;
                $bestCount = $item->getCount();
            }
        }

        if ($bestTypeId === null && $customSeed === null) {
            $player->sendTip("§cAucune graine dans ton inventaire !");
            return;
        }

        // ── Graines custom (RubySeed / PrismSeed) ──
        if ($customSeed !== null && $bestTypeId === null) {
            $isRuby = $customSeed instanceof RubySeed;
            $centerPos = $clicked instanceof Crops ? $clicked->getPosition() : $clicked->getPosition()->add(0, 1, 0);
            $plantable = [];
            for ($dx = -1; $dx <= 1; $dx++) {
                for ($dz = -1; $dz <= 1; $dz++) {
                    $plantPos = $centerPos->add($dx, 0, $dz);
                    $below = $world->getBlock($plantPos->subtract(0, 1, 0));
                    $at    = $world->getBlock($plantPos);
                    if ($at->getTypeId() !== \pocketmine\block\BlockTypeIds::AIR) continue;
                    if ($isRuby) {
                        // RubyCrop pousse sur Farmland
                        if (!($below instanceof \pocketmine\block\Farmland)) continue;
                    } else {
                        // PrismCrop pousse sur Soul Sand
                        if ($below->getTypeId() !== \pocketmine\block\BlockTypeIds::SOUL_SAND) continue;
                    }
                    $plantable[] = $plantPos;
                }
            }
            if (count($plantable) === 0) {
                $player->sendTip("§cAucune case plantable autour !");
                return;
            }
            $needed = count($plantable);
            $available = $customSeed->getCount();
            $planted = 0;
            foreach ($inv->getContents() as $slot => $slotItem) {
                if ($planted >= $needed || $planted >= $available) break;
                if (!($slotItem instanceof RubySeed) && !($slotItem instanceof PrismSeed)) continue;
                if ($isRuby && !($slotItem instanceof RubySeed)) continue;
                if (!$isRuby && !($slotItem instanceof PrismSeed)) continue;
                $take = min($needed - $planted, $slotItem->getCount());
                $newSlot = clone $slotItem;
                $newSlot->setCount($slotItem->getCount() - $take);
                $inv->setItem($slot, $newSlot);
                $planted += $take;
            }
            $cropBlock = $isRuby ? new RubyCrop() : new PrismCrop();
            $i = 0;
            foreach ($plantable as $plantPos) {
                if ($i >= $planted) break;
                $world->setBlock($plantPos, clone $cropBlock);
                $i++;
            }
            $player->sendTip("§a{$i}/{$needed} plantation(s) posées !");
            return;
        }

        $center = $clicked instanceof Crops ? $clicked->getPosition() : $clicked->getPosition()->add(0, 1, 0);

        $plantable = [];
        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dz = -1; $dz <= 1; $dz++) {
                $plantPos = $center->add($dx, 0, $dz);
                $below = $world->getBlock($plantPos->subtract(0, 1, 0));
                $at = $world->getBlock($plantPos);

                if (!($below instanceof Farmland)) {
                    continue;
                }
                if ($at->getTypeId() !== BlockTypeIds::AIR) {
                    continue;
                }

                $plantable[] = $plantPos;
            }
        }

        if (count($plantable) === 0) {
            $player->sendTip("§cAucune case plantable autour !");
            return;
        }

        $needed = count($plantable);
        $remaining = $needed;

        foreach ($inv->getContents() as $slot => $item) {
            if ($item->getTypeId() !== $bestTypeId) {
                continue;
            }

            $take = min($remaining, $item->getCount());
            if ($take <= 0) {
                break;
            }

            $newItem = clone $item;
            $newItem->setCount($item->getCount() - $take);
            $inv->setItem($slot, $newItem);
            $remaining -= $take;

            if ($remaining <= 0) {
                break;
            }
        }

        $consumed = $needed - $remaining;
        if ($consumed <= 0) {
            $player->sendTip("§cTu n'as pas assez de graines !");
            return;
        }

        $cropBlock = $this->seedToCropFromTypeId($bestTypeId);
        if ($cropBlock === null) {
            return;
        }

        $planted = 0;
        foreach ($plantable as $plantPos) {
            if ($planted >= $consumed) {
                break;
            }
            $world->setBlock($plantPos, clone $cropBlock);
            $planted++;
        }

        $player->sendTip("§a{$planted}/{$needed} plantation(s) posées !");
    }

    private function seedToCropFromTypeId(int $typeId): ?Block
    {
        return match ($typeId) {
            ItemTypeIds::WHEAT_SEEDS => VanillaBlocks::WHEAT(),
            ItemTypeIds::CARROT => VanillaBlocks::CARROTS(),
            ItemTypeIds::POTATO => VanillaBlocks::POTATOES(),
            ItemTypeIds::BEETROOT_SEEDS => VanillaBlocks::BEETROOTS(),
            default => null,
        };
    }
}
