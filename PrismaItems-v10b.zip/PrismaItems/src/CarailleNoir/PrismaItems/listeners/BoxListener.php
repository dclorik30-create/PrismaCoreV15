<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\BoxBlock;
use CarailleNoir\PrismaItems\manager\BoxManager;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\sound\PopSound;

class BoxListener implements Listener
{
    public function onInteract(PlayerInteractEvent $event): void
    {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if (!($event->getBlock() instanceof BoxBlock)) return;

        $event->cancel(); // empêche de placer un bloc avec la clé en main

        $player  = $event->getPlayer();
        $hand    = $player->getInventory()->getItemInHand();
        $keyType = BoxManager::getKeyType($hand);

        if ($keyType === null) {
            $player->sendMessage("§c✗ Tenez une clé en main pour ouvrir cette Box !");
            return;
        }

        // Consommer 1 clé
        $hand->setCount($hand->getCount() - 1);
        $player->getInventory()->setItemInHand($hand);

        $reward = BoxManager::getReward($keyType);
        if ($reward === null) return;

        BoxManager::giveReward($player, $reward);

        // Effets visuels au niveau du bloc
        $pos = $event->getBlock()->getPosition()->add(0.5, 0.5, 0.5);
        $player->getWorld()->addParticle($pos, new HugeExplodeParticle());
        $player->getWorld()->addSound($pos, new PopSound());

        $player->sendMessage("§6» §eBox ouverte avec " . BoxManager::getKeyDisplayName($keyType) . " §e!");
        $player->sendMessage("§6» §eRécompense : §f" . $reward["display"]);
        $player->sendTitle("§6★ BOX OUVERTE ★", $reward["display"], 5, 40, 10);
    }

    public function onBreak(BlockBreakEvent $event): void
    {
        if (!($event->getBlock() instanceof BoxBlock)) return;

        if (!$event->getPlayer()->hasPermission("prismabox.admin")) {
            $event->cancel();
            $event->getPlayer()->sendMessage("§c✗ Permission §fprismabox.admin §crequise pour casser la Box !");
            return;
        }

        $event->setDrops([]);
        $item = StringToItemParser::getInstance()->parse("prisma:box");
        if ($item !== null) {
            $item->setCount(1);
            $event->getBlock()->getPosition()->getWorld()->dropItem(
                $event->getBlock()->getPosition()->add(0.5, 0.5, 0.5), $item
            );
        }
        $event->getPlayer()->sendMessage("§a✓ Box récupérée !");
    }
}
