<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\manager;

use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;

/**
 * Gestion de la Box multi-clés — PrismaItems.
 *
 * Clés reconnues via lore "§8ID:item_key_{type}" :
 *   vote | noble | heros | dieu | boutique
 *
 * Tirage pondéré : 1 récompense aléatoire par ouverture.
 * Enchantements supportés : protection, sharpness, unbreaking.
 *
 * Ordre des armures : Émeraude → Ruby → Prisme
 * Ordre des box     : Vote → Noble → Héros → Dieu → Boutique
 */
class BoxManager
{
    private const KEY_NAMES = [
        "vote"     => "§eCLÉ §6Vote",
        "noble"    => "§aCLÉ §2Noble",
        "heros"    => "§bCLÉ §3Héros",
        "dieu"     => "§6CLÉ §eDieu",
        "boutique" => "§dCLÉ §5Boutique",
    ];

    // ─────────────────────────────────────────────────────────────────────────
    // Raccourcis d'enchantements réutilisables
    // ─────────────────────────────────────────────────────────────────────────
    private const P4          = [["name"=>"protection", "level"=>4]];
    private const P4_U3       = [["name"=>"protection", "level"=>4],["name"=>"unbreaking","level"=>3]];
    private const SHARP5      = [["name"=>"sharpness",  "level"=>5]];
    private const SHARP5_U3   = [["name"=>"sharpness",  "level"=>5],["name"=>"unbreaking","level"=>3]];

    // ─────────────────────────────────────────────────────────────────────────
    // Tables de récompenses  (total weight = 1000 par table)
    // ─────────────────────────────────────────────────────────────────────────
    private const REWARD_TABLES = [

        // ── BOX VOTE (meilleure : spawner zombie ~0.5%, full Émeraude P4, bump/switchball)
        "vote" => [
            // Jackpots
            ["item"=>"prisma:zombie_spawner", "amount"=>1, "weight"=>5,
             "display"=>"§2Spawner §aZombie §fx1"],

            // Full Émeraude P4 + épée Sharp5 (chacun ~2%)
            ["item"=>"prisma:emerald_sword",      "amount"=>1, "weight"=>20, "enchantments"=>self::SHARP5,
             "display"=>"§aÉpée Émeraude §f§oTranchat V §fx1"],
            ["item"=>"prisma:emerald_helmet",     "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§aCasque Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_chestplate", "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§aPlastron Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_leggings",   "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§aPantalon Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_boots",      "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§aBottes Émeraude §f§oProtection IV §fx1"],

            // Items courants
            ["item"=>"prisma:bump",      "amount"=>3, "weight"=>250, "display"=>"§aBump §fx3"],
            ["item"=>"snowball", "amount"=>1, "weight"=>250, "display"=>"§fBoule de neige §fx1"],

            // Ressources / clé
            ["item"=>"prisma:emerald_ingot", "amount"=>4, "weight"=>195, "display"=>"§aLingots Émeraude §fx4"],
            ["item"=>"prisma:key_noble",     "amount"=>1, "weight"=>200, "display"=>"§aCLÉ §2Noble §fx1"],
        ],

        // ── BOX NOBLE (meilleure : full Ruby P4, Émeraude reste accessible)
        "noble" => [
            // Jackpots Ruby (~2.5% chacun)
            ["item"=>"prisma:ruby_sword",      "amount"=>1, "weight"=>25, "enchantments"=>self::SHARP5,
             "display"=>"§cÉpée Ruby §f§oTranchant V §fx1"],
            ["item"=>"prisma:ruby_helmet",     "amount"=>1, "weight"=>25, "enchantments"=>self::P4,
             "display"=>"§cCasque Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_chestplate", "amount"=>1, "weight"=>25, "enchantments"=>self::P4,
             "display"=>"§cPlastron Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_leggings",   "amount"=>1, "weight"=>25, "enchantments"=>self::P4,
             "display"=>"§cPantalon Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_boots",      "amount"=>1, "weight"=>25, "enchantments"=>self::P4,
             "display"=>"§cBottes Ruby §f§oProtection IV §fx1"],
            // Spawner rare
            ["item"=>"prisma:skeleton_spawner","amount"=>1, "weight"=>15,
             "display"=>"§7Spawner §fSquelette §fx1"],

            // Émeraude accessible (~6% chacun)
            ["item"=>"prisma:emerald_sword",      "amount"=>1, "weight"=>60, "enchantments"=>self::SHARP5,
             "display"=>"§aÉpée Émeraude §f§oTranchant V §fx1"],
            ["item"=>"prisma:emerald_helmet",     "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§aCasque Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_chestplate", "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§aPlastron Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_leggings",   "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§aPantalon Émeraude §f§oProtection IV §fx1"],
            ["item"=>"prisma:emerald_boots",      "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§aBottes Émeraude §f§oProtection IV §fx1"],

            // Courants
            ["item"=>"prisma:bump",         "amount"=>3, "weight"=>100, "display"=>"§aBump §fx3"],
            ["item"=>"snowball",    "amount"=>1, "weight"=>100, "display"=>"§fBoule de neige §fx1"],
            ["item"=>"prisma:ruby_ingot",    "amount"=>2, "weight"=>150, "display"=>"§cLingots Ruby §fx2"],
            ["item"=>"prisma:emerald_ingot", "amount"=>4, "weight"=>35,  "display"=>"§aLingots Émeraude §fx4"],
            ["item"=>"prisma:key_heros",     "amount"=>1, "weight"=>175, "display"=>"§bCLÉ §3Héros §fx1"],
        ],

        // ── BOX HÉROS (meilleure : Prisme, Ruby accessible, spawners)
        "heros" => [
            // Jackpots Prisme (~2% chacun)
            ["item"=>"prisma:prism_sword",      "amount"=>1, "weight"=>20, "enchantments"=>self::SHARP5,
             "display"=>"§5Épée Prisme §f§oTranchant V §fx1"],
            ["item"=>"prisma:prism_helmet",     "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§5Casque Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_chestplate", "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§5Plastron Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_leggings",   "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§5Pantalon Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_boots",      "amount"=>1, "weight"=>20, "enchantments"=>self::P4,
             "display"=>"§5Bottes Prisme §f§oProtection IV §fx1"],
            // Spawners rares
            ["item"=>"prisma:creeper_spawner",  "amount"=>1, "weight"=>15,
             "display"=>"§aSpawner §2Creeper §fx1"],
            ["item"=>"prisma:zombie_spawner",   "amount"=>1, "weight"=>25,
             "display"=>"§2Spawner §aZombie §fx1"],

            // Ruby accessible (~6% chacun)
            ["item"=>"prisma:ruby_sword",      "amount"=>1, "weight"=>60, "enchantments"=>self::SHARP5,
             "display"=>"§cÉpée Ruby §f§oTranchant V §fx1"],
            ["item"=>"prisma:ruby_helmet",     "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§cCasque Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_chestplate", "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§cPlastron Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_leggings",   "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§cPantalon Ruby §f§oProtection IV §fx1"],
            ["item"=>"prisma:ruby_boots",      "amount"=>1, "weight"=>60, "enchantments"=>self::P4,
             "display"=>"§cBottes Ruby §f§oProtection IV §fx1"],

            // Courants
            ["item"=>"prisma:prism_ingot",  "amount"=>4, "weight"=>120, "display"=>"§5Lingots Prisme §fx4"],
            ["item"=>"prisma:ruby_ingot",   "amount"=>4, "weight"=>120, "display"=>"§cLingots Ruby §fx4"],
            ["item"=>"prisma:bump",         "amount"=>3, "weight"=>100, "display"=>"§aBump §fx3"],
            ["item"=>"snowball",   "amount"=>1, "weight"=>20,  "display"=>"§fBoule de neige §fx1"],
            ["item"=>"prisma:key_dieu",     "amount"=>1, "weight"=>200, "display"=>"§6CLÉ §eDieu §fx1"],
        ],

        // ── BOX DIEU (meilleure : Prisme P4, spawners, clé Boutique)
        "dieu" => [
            // Jackpots Prisme P4+U3 (~3% chacun)
            ["item"=>"prisma:prism_sword",      "amount"=>1, "weight"=>30, "enchantments"=>self::SHARP5_U3,
             "display"=>"§5Épée Prisme §f§oT.V §oSol.III §fx1"],
            ["item"=>"prisma:prism_helmet",     "amount"=>1, "weight"=>30, "enchantments"=>self::P4_U3,
             "display"=>"§5Casque Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_chestplate", "amount"=>1, "weight"=>30, "enchantments"=>self::P4_U3,
             "display"=>"§5Plastron Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_leggings",   "amount"=>1, "weight"=>30, "enchantments"=>self::P4_U3,
             "display"=>"§5Pantalon Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_boots",      "amount"=>1, "weight"=>30, "enchantments"=>self::P4_U3,
             "display"=>"§5Bottes Prisme §f§oProt.IV §oSol.III §fx1"],

            // Prisme P4 sans Unbreaking (~5% chacun)
            ["item"=>"prisma:prism_sword",      "amount"=>1, "weight"=>50, "enchantments"=>self::SHARP5,
             "display"=>"§5Épée Prisme §f§oTranchant V §fx1"],
            ["item"=>"prisma:prism_helmet",     "amount"=>1, "weight"=>50, "enchantments"=>self::P4,
             "display"=>"§5Casque Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_chestplate", "amount"=>1, "weight"=>50, "enchantments"=>self::P4,
             "display"=>"§5Plastron Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_leggings",   "amount"=>1, "weight"=>50, "enchantments"=>self::P4,
             "display"=>"§5Pantalon Prisme §f§oProtection IV §fx1"],
            ["item"=>"prisma:prism_boots",      "amount"=>1, "weight"=>50, "enchantments"=>self::P4,
             "display"=>"§5Bottes Prisme §f§oProtection IV §fx1"],

            // Spawners
            ["item"=>"prisma:creeper_spawner",  "amount"=>1, "weight"=>30, "display"=>"§aSpawner §2Creeper §fx1"],
            ["item"=>"prisma:skeleton_spawner", "amount"=>1, "weight"=>30, "display"=>"§7Spawner §fSquelette §fx1"],

            // Ressources / clé
            ["item"=>"prisma:prism_ingot", "amount"=>8, "weight"=>100, "display"=>"§5Lingots Prisme §fx8"],
            ["item"=>"prisma:prism_ingot", "amount"=>4, "weight"=>150, "display"=>"§5Lingots Prisme §fx4"],
            ["item"=>"prisma:ruby_ingot",  "amount"=>8, "weight"=>100, "display"=>"§cLingots Ruby §fx8"],
            ["item"=>"prisma:bump",        "amount"=>3, "weight"=>20,  "display"=>"§aBump §fx3"],
            ["item"=>"prisma:key_boutique","amount"=>1, "weight"=>170, "display"=>"§dCLÉ §5Boutique §fx1"],
        ],

        // ── BOX BOUTIQUE (meilleure : Prisme P4+U3, spawners x2, clés)
        "boutique" => [
            // Jackpots Prisme P4+U3 (~5% chacun)
            ["item"=>"prisma:prism_sword",      "amount"=>1, "weight"=>50, "enchantments"=>self::SHARP5_U3,
             "display"=>"§5Épée Prisme §f§oT.V §oSol.III §fx1"],
            ["item"=>"prisma:prism_helmet",     "amount"=>1, "weight"=>50, "enchantments"=>self::P4_U3,
             "display"=>"§5Casque Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_chestplate", "amount"=>1, "weight"=>50, "enchantments"=>self::P4_U3,
             "display"=>"§5Plastron Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_leggings",   "amount"=>1, "weight"=>50, "enchantments"=>self::P4_U3,
             "display"=>"§5Pantalon Prisme §f§oProt.IV §oSol.III §fx1"],
            ["item"=>"prisma:prism_boots",      "amount"=>1, "weight"=>50, "enchantments"=>self::P4_U3,
             "display"=>"§5Bottes Prisme §f§oProt.IV §oSol.III §fx1"],

            // Spawners x2
            ["item"=>"prisma:creeper_spawner",  "amount"=>2, "weight"=>30, "display"=>"§aSpawner §2Creeper §fx2"],
            ["item"=>"prisma:zombie_spawner",   "amount"=>2, "weight"=>30, "display"=>"§2Spawner §aZombie §fx2"],
            ["item"=>"prisma:skeleton_spawner", "amount"=>2, "weight"=>30, "display"=>"§7Spawner §fSquelette §fx2"],

            // Ressources
            ["item"=>"prisma:prism_ingot", "amount"=>8,  "weight"=>150, "display"=>"§5Lingots Prisme §fx8"],
            ["item"=>"prisma:prism_ingot", "amount"=>4,  "weight"=>200, "display"=>"§5Lingots Prisme §fx4"],
            ["item"=>"prisma:ruby_ingot",  "amount"=>8,  "weight"=>130, "display"=>"§cLingots Ruby §fx8"],

            // Clés recyclables
            ["item"=>"prisma:key_dieu",    "amount"=>1,  "weight"=>100, "display"=>"§6CLÉ §eDieu §fx1"],
            ["item"=>"prisma:key_boutique","amount"=>1,  "weight"=>50,  "display"=>"§dCLÉ §5Boutique §fx1"],

            // Bonus
            ["item"=>"prisma:bump",        "amount"=>3,  "weight"=>30,  "display"=>"§aBump §fx3"],
        ],
    ];

    // ─────────────────────────────────────────────────────────────────────────

    /** Détecte le type de clé depuis la lore PrismaItems "§8ID:item_key_{type}" */
    public static function getKeyType(Item $item): ?string
    {
        foreach ($item->getLore() as $line) {
            if (str_starts_with($line, "§8ID:item_key_")) {
                $type = mb_substr($line, 14);
                if (isset(self::REWARD_TABLES[$type])) return $type;
            }
        }
        return null;
    }

    public static function getKeyDisplayName(string $type): string
    {
        return self::KEY_NAMES[$type] ?? "§fClé §7" . ucfirst($type);
    }

    /** Tirage pondéré — 1 récompense aléatoire */
    public static function getReward(string $keyType): ?array
    {
        $table = self::REWARD_TABLES[$keyType] ?? null;
        if ($table === null) return null;
        $total = array_sum(array_column($table, "weight"));
        $roll  = mt_rand(1, $total);
        $cum   = 0;
        foreach ($table as $reward) {
            $cum += $reward["weight"];
            if ($roll <= $cum) return $reward;
        }
        return $table[count($table) - 1];
    }

    /** Construit l'item avec enchantements puis le donne au joueur */
    public static function giveReward(Player $player, array $reward): void
    {
        $item = StringToItemParser::getInstance()->parse($reward["item"]);
        if ($item === null) {
            $player->sendMessage("§c[Box] Item introuvable : " . $reward["item"]);
            return;
        }

        $item->setCount($reward["amount"]);

        // Appliquer les enchantements si présents
        foreach ($reward["enchantments"] ?? [] as $ench) {
            $enchObj = match($ench["name"]) {
                "protection" => VanillaEnchantments::PROTECTION(),
                "sharpness"  => VanillaEnchantments::SHARPNESS(),
                "unbreaking" => VanillaEnchantments::UNBREAKING(),
                default      => null,
            };
            if ($enchObj !== null) {
                $item->addEnchantment(new EnchantmentInstance($enchObj, $ench["level"]));
            }
        }

        if ($player->getInventory()->canAddItem($item)) {
            $player->getInventory()->addItem($item);
        } else {
            $player->getWorld()->dropItem($player->getPosition(), $item);
        }
    }
}
