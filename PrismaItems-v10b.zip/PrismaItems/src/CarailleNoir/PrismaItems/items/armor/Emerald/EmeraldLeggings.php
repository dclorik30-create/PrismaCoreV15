<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Emerald;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class EmeraldLeggings extends Armor implements IPrismaArmor
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:emerald_leggings", 30007),
            "§aEmerald §7Jambières",
            new ArmorTypeInfo(
                maxDurability: 2300,
                defensePoints: 2,
                armorSlot: ArmorInventory::SLOT_LEGS,
                toughness: 0
            )
        );
    }

    public function getPrismaTier(): int { return 1; }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_emerald_leggings");
    }
}
