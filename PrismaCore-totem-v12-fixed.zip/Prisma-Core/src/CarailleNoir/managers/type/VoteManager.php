<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;

use CarailleNoir\Core;
use CarailleNoir\tasks\VoteCheckTask;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;

class VoteManager {

 public const API_KEY = "7Q8zxDPzM69XMmPj7yAQQsww9tGgPjg4lN6";
 public const MAX_VOTES = 50;

 private static int $currentVotes = 0;
 private static string $dataFile;

 public static function init(): void {
 self::$dataFile = Core::getInstance()->getDataFolder() . "vote_data.json";

 if (!file_exists(self::$dataFile)) {
 file_put_contents(self::$dataFile, json_encode(["votes" => 0]));
 }

 $data = json_decode(file_get_contents(self::$dataFile), true);
 self::$currentVotes = $data["votes"] ?? 0;
 }

 public static function save(): void {
 file_put_contents(self::$dataFile, json_encode(["votes" => self::$currentVotes]));
 }

 public static function getCurrentVotes(): int {
 return self::$currentVotes;
 }

 public static function checkVote(Player $player): void {
 Server::getInstance()->getAsyncPool()->submitTask(
 new VoteCheckTask($player->getName(), self::API_KEY)
 );
 }

 public static function onVoteSuccess(Player $player): void {
 $player->sendMessage("§aMerci d'avoir voté ! Voici ta récompense.");
 $player->getInventory()->addItem(VanillaItems::DIAMOND());

 if($player instanceof \CarailleNoir\player\PrismaPlayer){
  if(Manager::GRADE()->existGrade("Vote")){
   Manager::GRADE()->addGrade($player, "Vote", $player->getName());
  }elseif(Manager::GRADE()->existGrade("vote")){
   Manager::GRADE()->addGrade($player, "vote", $player->getName());
  }
 }

 self::$currentVotes++;
 self::save();

 Server::getInstance()->broadcastMessage("§aVoteParty : §f" . self::$currentVotes . "/" . self::MAX_VOTES);

 if (self::$currentVotes >= self::MAX_VOTES) {
 self::triggerVoteParty();
 }
 }

 public static function triggerVoteParty(): void {
 Server::getInstance()->broadcastMessage("§l§aVoteParty atteint ! Récompense pour tous les joueurs !");
 foreach (Server::getInstance()->getOnlinePlayers() as $onlinePlayer) {
 $onlinePlayer->getInventory()->addItem(VanillaItems::EMERALD()->setCount(3));
 }
 self::$currentVotes = 0;
 self::save();
 }
}