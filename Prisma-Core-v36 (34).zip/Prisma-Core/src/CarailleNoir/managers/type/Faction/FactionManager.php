<?php

namespace CarailleNoir\managers\type\Faction;

use CarailleNoir\Core;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;

class FactionManager
{
 use SingletonTrait;
 /** @var Faction[]*/
 private array $factions = [];
 /** @var array<string, array{faction: string, time: int}> */
 private array $invites = [];

 public function register(): void{
 $path = Core::getInstance()->getDataFolder() . "Faction/";
 if (!is_dir($path)) {
 mkdir($path);
 }
 $this->loadClaims();

 $scan = scandir($path);
 foreach ($scan as $file) {
 if (is_file($path. $file)) {
 if ($file === "." or $file === "..") continue;
 $f = substr($file, 0, -4);
 $config = Core::getInstance()->getConfigFile("Faction/" . $f);
 $region = Faction::unserialize($config->getAll());
 $this->factions[$config->get("id")] = $region;
 }
 }
 }

 public function save(): void
 {
 $dataFolder = Core::getInstance()->getDataFolder();
 foreach ($this->factions as $faction) {
 $config = Core::getInstance()->getConfigFile("Faction/{$faction->getId()}");
 $config->setAll($faction->serialize($faction));
 $config->save();
 }
 // Archiver les fichiers orphelins (faction supprimée mais .yml encore présent)
 $path = $dataFolder . "Faction/";
 if (is_dir($path)) {
 foreach (scandir($path) as $file) {
 if (!is_file($path . $file) || !str_ends_with($file, '.yml')) continue;
 $id = substr($file, 0, -4);
 if (!isset($this->factions[$id])) {
 @rename($path . $file, $path . $file . '.bak');
 }
 }
 }
 }
 public function createFaction(string $id, string $name, PrismaPlayer $owner, ?string $description): void
 {
 $this->factions[$id] = new Faction($id, $name, $owner->getName(), $description);
 $owner->setFaction($id);
 $owner->sendMessage(FactionMessageEnum::CREATE_FACTION->value);
 }

 public function deleteFaction(string $id): void
 {
 unset($this->factions[$id]);

 // Supprimer le fichier de sauvegarde de la faction
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "Faction/{$id}.yml";
 if (file_exists($path)) @unlink($path);

 // Supprimer le monde de l'island
 // Supprimer tous les claims de cette faction
 $this->removeAllClaims($id);

 if (isset($this->islands[$id])) {
 $worldName = $this->islands[$id]["world"] ?? null;
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 if ($worldName !== null) {
 if ($wm->isWorldLoaded($worldName)) {
 $world = $wm->getWorldByName($worldName);
 if ($world !== null) $wm->unloadWorld($world, true);
 }
 $worldPath = \pocketmine\Server::getInstance()->getDataPath() . "worlds/" . $worldName;
 if (is_dir($worldPath)) $this->deleteDir($worldPath);
 }
 unset($this->islands[$id]);
 $this->saveIslands();
 }
 }

 private function deleteDir(string $path): void
 {
 if (!is_dir($path)) return;
 $dir = opendir($path);
 while (($file = readdir($dir)) !== false) {
 if ($file === "." || $file === "..") continue;
 $full = "$path/$file";
 is_dir($full) ? $this->deleteDir($full) : @unlink($full);
 }
 closedir($dir);
 @rmdir($path);
 }

 public function getFactions(): array
 {
 return $this->factions;
 }

 public function getFaction(string $id): ?Faction
 {
 return $this->factions[$id] ?? null;
 }

 public function invite(Faction $faction, string $playerName): void {
 $key = strtolower($playerName);

 $this->invites[$key] = [
 "faction" => $faction->getId(),
 "time" => time()
 ];
 }

 public function hasInvite(string $playerName): bool {
 $key = strtolower($playerName);

 if (!isset($this->invites[$key])) {
 return false;
 }

 $invite = $this->invites[$key];

 if (time() - $invite["time"] > 30) {
 unset($this->invites[$key]);
 return false;
 }
 return true;
 }


 public function getLastInvite(string $playerName): ?Faction {
 $key = strtolower($playerName);
 if (!$this->hasInvite($playerName)) return null;

 $factionId = $this->invites[$key]["faction"];
 return $this->getFaction($factionId);
 }

 public function removeInvite(string $playerName): void {
 unset($this->invites[strtolower($playerName)]);
 }

 /** @var array<string, array{world:string, x:float, y:float, z:float}> */
 private array $islands = [];
 /** Compteur monotone pour positions islands — ne recule jamais même si des islands sont supprimées */
 private int $islandCounter = 0;

 public function getIsland(string $factionId): ?array
 {
 return $this->islands[$factionId] ?? null;
 }

 /** Transforme un nom de faction en nom de monde valide (alphanum + underscore, max 32 chars) */
 public function sanitizeWorldName(string $name): string
 {
 $clean = preg_replace('/[^a-zA-Z0-9_]/', '_', $name);
 $clean = preg_replace('/_+/', '_', strtolower($clean));
 $clean = trim($clean, '_');
 return 'island_' . substr($clean, 0, 24); // "island_" (7) + 24 = 31 max
 }

 public function createIsland(string $factionId): bool
 {
 $faction = $this->getFaction($factionId);
 $worldsPath = \pocketmine\Server::getInstance()->getDataPath() . "worlds/";
 $src = $worldsPath . "island_copy";
 $worldName = $this->sanitizeWorldName($faction?->getName() ?? $factionId);
 $dst = $worldsPath . $worldName;

 if (!is_dir($src)) return false;

 // Si le dossier n'existe pas encore, copier island_copy
 if (!is_dir($dst)) {
 $this->copyDir($src, $dst);
 }

 $this->islands[$factionId] = ["world" => $worldName];
 $this->saveIslands();
 return true;
 }

 private function copyDir(string $src, string $dst): void
 {
 @mkdir($dst, 0755, true);
 $dir = opendir($src);
 while (($file = readdir($dir)) !== false) {
 if ($file === "." || $file === "..") continue;
 $s = "$src/$file";
 $d = "$dst/$file";
 is_dir($s) ? $this->copyDir($s, $d) : copy($s, $d);
 }
 closedir($dir);
 }

 public function saveIslands(): void
 {
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "islands.json";
 file_put_contents($path, json_encode([
 "_counter" => $this->islandCounter,
 "islands" => $this->islands
 ], JSON_PRETTY_PRINT));
 }

 public function loadIslands(): void
 {
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "islands.json";
 if (file_exists($path)) {
 $data = json_decode(file_get_contents($path), true) ?? [];
 // Support ancien format (array plat) et nouveau format
 if (isset($data["islands"])) {
 $this->islands = $data["islands"];
 $this->islandCounter = (int)($data["_counter"] ?? count($this->islands));
 } else {
 $this->islands = $data;
 $this->islandCounter = count($data);
 }
 }
 }

 /** @var array<string, string> allyRequestSender[receiverFactionId] = senderFactionId */
 private array $allyRequests = [];

 public function sendAllyRequest(string $senderFactionId, string $receiverFactionId): void
 {
 $this->allyRequests[$receiverFactionId] = $senderFactionId;
 }

 public function hasAllyRequest(string $factionId): bool
 {
 return isset($this->allyRequests[$factionId]);
 }

 public function acceptAllyRequest(string $factionId): ?string
 {
 $sender = $this->allyRequests[$factionId] ?? null;
 unset($this->allyRequests[$factionId]);
 return $sender;
 }


 /** @var array<string, bool> Joueurs OP en mode bypass island */
 private array $bypassPlayers = [];

 public function toggleBypass(string $playerName): bool
 {
 $key = strtolower($playerName);
 if (isset($this->bypassPlayers[$key])) {
 unset($this->bypassPlayers[$key]);
 return false; // bypass désactivé
 }
 $this->bypassPlayers[$key] = true;
 return true; // bypass activé
 }

 public function hasBypass(string $playerName): bool
 {
 return isset($this->bypassPlayers[strtolower($playerName)]);
 }

 public function removeBypass(string $playerName): void
 {
 unset($this->bypassPlayers[strtolower($playerName)]);
 }


 /** @var array<string, list<array{world:string,chunkX:int,chunkZ:int}>> */
 private array $claims = [];

 public function loadClaims(): void
 {
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "claims.json";
 if (file_exists($path)) {
 $this->claims = json_decode(file_get_contents($path), true) ?? [];
 }
 }

 public function saveClaims(): void
 {
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "claims.json";
 file_put_contents($path, json_encode($this->claims, JSON_PRETTY_PRINT));
 }

 public function addClaim(string $factionId, string $world, int $chunkX, int $chunkZ): bool
 {
 // Vérifier si ce chunk est déjà claim par une autre faction
 foreach ($this->claims as $fId => $chunks) {
 foreach ($chunks as $chunk) {
 if ($chunk["world"] === $world && $chunk["chunkX"] === $chunkX && $chunk["chunkZ"] === $chunkZ) {
 return false; // déjà claim
 }
 }
 }
 $this->claims[$factionId][] = ["world" => $world, "chunkX" => $chunkX, "chunkZ" => $chunkZ];
 $this->saveClaims();
 return true;
 }

 public function removeClaim(string $factionId, string $world, int $chunkX, int $chunkZ): void
 {
 if (!isset($this->claims[$factionId])) return;
 $this->claims[$factionId] = array_values(array_filter(
 $this->claims[$factionId],
 fn($c) => !($c["world"] === $world && $c["chunkX"] === $chunkX && $c["chunkZ"] === $chunkZ)
 ));
 if (empty($this->claims[$factionId])) unset($this->claims[$factionId]);
 $this->saveClaims();
 }

 public function removeAllClaims(string $factionId): void
 {
 unset($this->claims[$factionId]);
 $this->saveClaims();
 }

 /** Retourne la faction qui possède le claim à ce chunk, ou null */
 public function getClaimOwner(string $world, int $chunkX, int $chunkZ): ?Faction
 {
 foreach ($this->claims as $factionId => $chunks) {
 foreach ($chunks as $chunk) {
 if ($chunk["world"] === $world && $chunk["chunkX"] === $chunkX && $chunk["chunkZ"] === $chunkZ) {
 return $this->getFaction($factionId);
 }
 }
 }
 return null;
 }

 public function getFactionClaims(string $factionId): array
 {
 return $this->claims[$factionId] ?? [];
 }


 public function getFactionByPlayer(string $playerName): ?Faction
 {
 foreach ($this->factions as $faction) {
 if ($faction->getOwner() === $playerName || in_array($playerName, $faction->getAll(), true)) {
 return $faction;
 }
 }
 return null;
 }

}
