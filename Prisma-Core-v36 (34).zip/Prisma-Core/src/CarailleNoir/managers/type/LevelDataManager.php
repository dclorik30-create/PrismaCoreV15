<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use pocketmine\utils\Config;

/**
 * Gère la persistance des données joueurs.
 * Fichier : players/{name}.yml
 * Structure : { level, exp, claimed_rewards[] }
 */
class LevelDataManager
{
    private string $dataFolder;
    /** @var array<string, array{level:int,exp:int,claimed:int[]}> */
    private array $cache = [];

    public function __construct(string $dataFolder)
    {
        $this->dataFolder = $dataFolder . "players/";
        @mkdir($this->dataFolder, 0777, true);
    }

    /** Compatibilité ManagerHandler — chargement à la demande, pas d'init globale nécessaire */
    public function init(): void {}

    // ── Chargement / Sauvegarde ───────────────────────────────────────────────

    public function load(string $player): void
    {
        $key  = strtolower($player);
        $file = $this->dataFolder . $key . ".yml";
        $cfg  = new Config($file, Config::YAML, [
            "level"   => 1,
            "exp"     => 0,
            "claimed" => [],
        ]);
        $this->cache[$key] = [
            "level"   => max(1, (int)$cfg->get("level", 1)),
            "exp"     => max(0, (int)$cfg->get("exp", 0)),
            "claimed" => (array)$cfg->get("claimed", []),
        ];
    }

    public function save(string $player): void
    {
        $key  = strtolower($player);
        if (!isset($this->cache[$key])) return;
        $file = $this->dataFolder . $key . ".yml";
        $cfg  = new Config($file, Config::YAML);
        $cfg->set("level",   $this->cache[$key]["level"]);
        $cfg->set("exp",     $this->cache[$key]["exp"]);
        $cfg->set("claimed", $this->cache[$key]["claimed"]);
        $cfg->save();
    }

    public function unload(string $player): void
    {
        $this->save($player);
        unset($this->cache[strtolower($player)]);
    }

    // ── Accesseurs ────────────────────────────────────────────────────────────

    private function get(string $player): array
    {
        $key = strtolower($player);
        if (!isset($this->cache[$key])) $this->load($key);
        return $this->cache[$key];
    }

    public function getLevel(string $player): int   { return $this->get($player)["level"]; }
    public function getExp(string $player): int     { return $this->get($player)["exp"]; }
    public function getClaimed(string $player): array { return $this->get($player)["claimed"]; }

    public function setLevel(string $player, int $level): void
    {
        $this->cache[strtolower($player)]["level"] = max(1, min(100, $level));
    }

    public function setExp(string $player, int $exp): void
    {
        $this->cache[strtolower($player)]["exp"] = max(0, $exp);
    }

    public function addClaimed(string $player, int $level): void
    {
        $key = strtolower($player);
        if (!in_array($level, $this->cache[$key]["claimed"], true)) {
            $this->cache[$key]["claimed"][] = $level;
        }
    }

    public function hasClaimed(string $player, int $level): bool
    {
        return in_array($level, $this->get($player)["claimed"], true);
    }

    public function saveAll(): void
    {
        foreach (array_keys($this->cache) as $player) {
            $this->save($player);
        }
    }
}
