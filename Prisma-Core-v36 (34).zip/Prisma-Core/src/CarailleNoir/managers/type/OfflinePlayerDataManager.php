<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;

class OfflinePlayerDataManager extends DataHandler
{
 public function init(): void
 {
 $this->loadData("OfflinePlayerData");
 }

 public function savePlayerData(PrismaPlayer $player): void
 {
 $uid = $player->getUniqueId()->toString();

 $this->data[$uid] = [
 "freeze" => $player->isFreeze(),
 "permissions" => $player->getPermissions()
 ];
 }

 public function loadPlayerData(PrismaPlayer $player): void
 {
 $uid = $player->getUniqueId()->toString();

 if (isset($this->data[$uid])) {
 $player->loadOfflineData($this->data[$uid]);
 }
 $player->setCurrentRegionId(Manager::REGION()->getMainRegionAt($player->getPosition()));
 }
}