<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class LevelRewardManager
{
    /** @var array<int, array{label:string,money:int|null,items:array,command:string|null}> */
    private array $rewards = [];

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . "rewards.yml", Config::YAML);
        foreach ((array)$cfg->get("rewards", []) as $lvl => $data) {
            $data = (array)$data;
            $this->rewards[(int)$lvl] = [
                "label"   => (string)($data["label"]   ?? "Niveau {$lvl}"),
                "money"   => isset($data["money"])   ? (int)$data["money"]   : null,
                "items"   => (array)($data["items"]  ?? []),
                "command" => isset($data["command"])  ? (string)$data["command"] : null,
            ];
        }
    }

    public function getReward(int $level): ?array   { return $this->rewards[$level] ?? null; }
    public function getLabel(int $level): string    { return $this->rewards[$level]["label"] ?? "Récompense Niv. {$level}"; }
    public function getAllRewards(): array           { return $this->rewards; }

    public function isClaimed(string $player, int $level): bool
    {
        return Manager::LEVEL_DATA()->hasClaimed($player, $level);
    }

    /** @return int[] */
    public function getAvailableRewards(string $player): array
    {
        $playerLvl = Manager::LEVEL_DATA()->getLevel($player);
        $available = [];
        foreach (array_keys($this->rewards) as $lvl) {
            if ($lvl <= $playerLvl && !Manager::LEVEL_DATA()->hasClaimed($player, $lvl)) {
                $available[] = $lvl;
            }
        }
        return $available;
    }

    public function claimReward(Player $player, int $level): string
    {
        $name      = $player->getName();
        $playerLvl = Manager::LEVEL_DATA()->getLevel($name);

        if ($playerLvl < $level)                                return "locked";
        if (Manager::LEVEL_DATA()->hasClaimed($name, $level))  return "already";

        $reward = $this->rewards[$level] ?? null;
        if ($reward === null)                                   return "no_reward";

        foreach ($reward["items"] as $itemData) {
            $itemData = (array)$itemData;
            $item = StringToItemParser::getInstance()->parse((string)($itemData["id"] ?? ""));
            if ($item !== null) {
                $item->setCount((int)($itemData["count"] ?? 1));
                $player->getInventory()->addItem($item);
            }
        }

        if ($reward["money"] !== null && $reward["money"] > 0) {
            $player->getServer()->dispatchCommand(
                $player->getServer()->getConsoleSender(),
                "coins add " . $player->getName() . " " . $reward["money"]
            );
        }

        if ($reward["command"] !== null) {
            $cmd = str_replace("%player%", $player->getName(), $reward["command"]);
            $player->getServer()->dispatchCommand($player->getServer()->getConsoleSender(), $cmd);
        }

        Manager::LEVEL_DATA()->addClaimed($name, $level);
        Manager::LEVEL_DATA()->save($name);

        $player->sendMessage(
            "§8[§6Récompense§8] §fRécompense du §6niveau {$level}§f récupérée : §e" .
            $reward["label"] . "§f !"
        );
        return "ok";
    }
}
