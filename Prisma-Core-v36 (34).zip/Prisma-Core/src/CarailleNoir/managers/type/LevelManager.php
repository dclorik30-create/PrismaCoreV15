<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class LevelManager
{
    public const MAX_LEVEL = 100;

    /** @var array<int,int> level => exp_requise */
    private array $levelData = [];

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . "levels.yml", Config::YAML);
        foreach ((array)$cfg->get("levels", []) as $lvl => $xp) {
            $this->levelData[(int)$lvl] = (int)$xp;
        }
    }

    public function getRequiredExp(int $level): int
    {
        return $this->levelData[$level] ?? 999999;
    }

    public function addExp(Player $player, int $amount, string $source = ""): void
    {
        $name  = $player->getName();
        $level = Manager::LEVEL_DATA()->getLevel($name);

        if ($level >= self::MAX_LEVEL) return;

        $player->sendTip("§e+ §6" . $amount . " §eEXP" . ($source !== "" ? " §7(" . $source . ")" : ""));

        $currentExp = Manager::LEVEL_DATA()->getExp($name) + $amount;

        while ($level < self::MAX_LEVEL) {
            $required = $this->getRequiredExp($level);
            if ($currentExp < $required) break;
            $currentExp -= $required;
            $level++;
            Manager::LEVEL_DATA()->setLevel($name, $level);
            $this->onLevelUp($player, $level);
        }

        Manager::LEVEL_DATA()->setExp($name, $currentExp);
    }

    private function onLevelUp(Player $player, int $newLevel): void
    {
        $player->sendTitle("§6§lNIVEAU " . $newLevel, "§eFélicitations ! Niveau {$newLevel} atteint !");
        $player->sendMessage(
            "§8[§6Niveau§8] §fVous avez atteint le §6niveau {$newLevel}§f !" .
            " §7Récupérez votre récompense avec §f/niveau§7."
        );
        if ($newLevel === self::MAX_LEVEL) {
            $player->sendMessage("§6§l★ Félicitations, vous avez atteint le niveau maximum (100) ! ★");
        }
    }

    public function getLevel(string $player): int  { return Manager::LEVEL_DATA()->getLevel($player); }
    public function getExp(string $player): int    { return Manager::LEVEL_DATA()->getExp($player); }

    public function getProgressBar(string $player): string
    {
        $level  = Manager::LEVEL_DATA()->getLevel($player);
        $exp    = Manager::LEVEL_DATA()->getExp($player);
        $req    = $this->getRequiredExp($level);
        $pct    = $req > 0 ? min(1.0, $exp / $req) : 1.0;
        $filled = (int)round($pct * 20);
        $bar    = str_repeat("§a|", $filled) . str_repeat("§7|", 20 - $filled);
        return "§7[{$bar}§7] §f" . number_format($exp) . "§7/§f" . number_format($req) . " §7EXP";
    }

    public function setLevel(string $player, int $level, int $exp = 0): void
    {
        Manager::LEVEL_DATA()->setLevel($player, min(self::MAX_LEVEL, max(1, $level)));
        Manager::LEVEL_DATA()->setExp($player, max(0, $exp));
    }

    public function save(string $player): void    { Manager::LEVEL_DATA()->save($player); }
    public function saveAll(): void               { Manager::LEVEL_DATA()->saveAll(); }
}
