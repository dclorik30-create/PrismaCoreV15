<?php

namespace CarailleNoir\handlers;

use CarailleNoir\managers\Manager;

class ManagerHandler
{
 public static function Load(): void
 {
 // DataHandler-based (init = loadData)
 Manager::BAN()->init();
 Manager::ALIAS()->init();
 Manager::SANCTION()->init();
 Manager::MUTE()->init();
 Manager::WARN()->init();
 Manager::GRADE()->init();
 Manager::OPD()->init();
 Manager::ECONOMY()->init();
 Manager::COINS()->init();
 Manager::STATS()->init();
 Manager::SETTINGS()->init();
 Manager::KIT()->init();
 Manager::ATOUT()->init();
 Manager::TIG()->init();
 Manager::HDV()->init();
 Manager::MARKET()->init();

 // register-based (fichiers JSON/dossiers)
 Manager::REGION()->register();
 Manager::FACTION()->register();
 Manager::BOX()->register();
 Manager::SHOP()->register();
 Manager::MINE()->register();
 Manager::EVENT()->register();
 Manager::PV()->register();

 // Pas de persistance
 // Manager::PEARL() => in-memory
 // Manager::COMBATLOG() => in-memory
 // Manager::SPAWNER() => config statique

 Manager::VOTE()::init();
 Manager::ALERT_WHITELIST()->init();
 Manager::LEVEL_DATA()->init();
 }

 public static function UnLoad(): void
 {
 Manager::BAN()->saveData();
 Manager::ALIAS()->saveData();
 Manager::SANCTION()->saveData();
 Manager::MUTE()->saveData();
 Manager::WARN()->saveData();
 Manager::GRADE()->saveData();
 Manager::OPD()->saveData();
 Manager::ECONOMY()->saveData();
 Manager::COINS()->saveData();
 Manager::STATS()->saveData();
 Manager::SETTINGS()->saveData();
 Manager::KIT()->saveData();
 Manager::ATOUT()->saveData();
 Manager::TIG()->saveData();
 Manager::HDV()->saveData();
 Manager::MARKET()->saveData();

 Manager::REGION()->save();
 Manager::FACTION()->save();
 Manager::BOX()->save();
 Manager::SHOP()->save();
 Manager::PV()->save();

 Manager::VOTE()::save();
 Manager::FACTION()->saveIslands();
 Manager::LEVEL_DATA()->saveAll();
 }
}