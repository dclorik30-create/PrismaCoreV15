<?php
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\inventory\Inventory;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;

class InvseeCommand extends BaseCommand {
 public function __construct() { parent::__construct("invsee", "Voir l'inventaire d'un joueur", [], [], ["prisma.command.staff", "prisma.command.invsee"]); }
 protected function prepare(): array { return [new RawStringArgument("player")]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $targetName = (string)($args["player"] ?? "");
 if ($targetName === "") { $sender->sendMessage("§cUsage : /invsee <joueur>"); return; }

 $online = \pocketmine\Server::getInstance()->getPlayerExact($targetName);
 $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§cInvSee §f{$targetName}");

 if ($online instanceof PrismaPlayer) {
 foreach ($online->getInventory()->getContents() as $slot => $item) $menu->getInventory()->setItem($slot, $item);
 foreach ($online->getArmorInventory()->getContents() as $slot => $item) $menu->getInventory()->setItem(36 + $slot, $item);
 } else {
 $data = Manager::OPD()->getData($targetName);
 foreach (($data["inventory"] ?? []) as $slot => $payload) {
 $item = Manager::PV()->deserializeItem((string)$payload);
 if ($item !== null) $menu->getInventory()->setItem((int)$slot, $item);
 }
 foreach (($data["armorInventory"] ?? []) as $slot => $payload) {
 $item = Manager::PV()->deserializeItem((string)$payload);
 if ($item !== null) $menu->getInventory()->setItem(36 + (int)$slot, $item);
 }
 }

 $menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult {
 return $transaction->continue();
 });

 $menu->setInventoryCloseListener(function(Player $p, Inventory $inv) use ($menu, $targetName, $online): void {
 if ($online instanceof PrismaPlayer) {
 for ($slot = 0; $slot < 36; $slot++) $online->getInventory()->setItem($slot, $menu->getInventory()->getItem($slot));
 for ($slot = 36; $slot < 40; $slot++) $online->getArmorInventory()->setItem($slot - 36, $menu->getInventory()->getItem($slot));
 return;
 }

 $data = Manager::OPD()->getData($targetName);
 $data["inventory"] = [];
 $data["armorInventory"] = [];
 for ($slot = 0; $slot < 36; $slot++) {
 $item = $menu->getInventory()->getItem($slot);
 if (!$item->isNull()) $data["inventory"][$slot] = Manager::PV()->serializeItem($item);
 }
 for ($slot = 36; $slot < 40; $slot++) {
 $item = $menu->getInventory()->getItem($slot);
 if (!$item->isNull()) $data["armorInventory"][$slot - 36] = Manager::PV()->serializeItem($item);
 }
 Manager::OPD()->setData($targetName, $data);
 Manager::OPD()->save();
 });

 $menu->send($sender);
 }
}
