<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Admin;

use CarailleNoir\items\SpecialItems;
use CarailleNoir\managers\Manager;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\player\Player;

/**
 * /cash → Ouvre un menu Money | Coins
 * /cash money X → Vérifie solde, déduit X$, donne un chèque papier
 * /cash coins X → Vérifie solde, déduit X coins, donne un chèque papier
 *
 * Le chèque est UNIQUEMENT obtenu via cette commande.
 * Clic droit sur le chèque → crédite le porteur (géré dans PlayerListener).
 */
class CashCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct(
 "cash",
 "Convertir votre argent/coins en chèque papier échangeable",
 [],
 [],
 ["prisma.command.cash"]
 );
 }

 protected function prepare(): array
 {
 return [
 new RawStringArgument("type", true),
 new RawStringArgument("montant", true),
 ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof Player) {
 $sender->sendMessage("§cCette commande est réservée aux joueurs.");
 return;
 }

 $type = strtolower(trim($args["type"] ?? ""));
 $rawAmt = trim($args["montant"] ?? "");

 // ── Aucun argument → menu de choix ──────────────────────────────────
 if ($type === "") {
 $this->openTypeMenu($sender);
 return;
 }

 // ── Type fourni mais montant absent → menu avec type pré-sélectionné ─
 if (!in_array($type, ["money", "coins"], true)) {
 $sender->sendMessage("§cType invalide. Utilise §f/cash money <montant> §cou §f/cash coins <montant>");
 return;
 }

 if ($rawAmt === "") {
 $this->openAmountMenu($sender, $type);
 return;
 }

 $amount = (float) $rawAmt;
 if ($amount <= 0 || !is_numeric($rawAmt)) {
 $sender->sendMessage("§cLe montant doit être un nombre positif !");
 return;
 }

 $this->processCash($sender, $type, $amount);
 }

 // ── Menu de choix Money / Coins ──────────────────────────────────────────
 private function openTypeMenu(Player $player): void
 {
 $money = Manager::ECONOMY()->getMoney($player->getName());
 $coins = Manager::COINS()->getCoins($player->getName());

 $player->sendForm(new class($money, $coins) implements Form {
 public function __construct(private float $money, private int $coins) {}

 public function jsonSerialize(): mixed {
 return [
 "type" => "form",
 "title" => "§6Cash - Choisir le type",
 "content" => "§fSolde : §e" . number_format($this->money, 0, ",", " ") . "§6$\n§fCoins : §b" . number_format($this->coins, 0, ",", " ") . "§5 Coins",
 "buttons" => [
 ["text" => "§6Money\n§f(" . number_format($this->money, 0, ",", " ") . "$)"],
 ["text" => "§5Coins\n§f(" . number_format($this->coins, 0, ",", " ") . " Coins)"],
 ]
 ];
 }

 public function handleResponse(Player $player, mixed $data): void {
 if ($data === null) return;
 $type = ($data === 0) ? "money" : "coins";
 // Ouvrir le menu montant
 $player->getServer()->dispatchCommand($player, "cash $type");
 }
 });
 }

 // ── Menu de saisie du montant ────────────────────────────────────────────
 private function openAmountMenu(Player $player, string $type): void
 {
 $balance = $type === "money"
 ? number_format(Manager::ECONOMY()->getMoney($player->getName()), 0, ",", " ") . "$"
 : number_format(Manager::COINS()->getCoins($player->getName()), 0, ",", " ") . " Coins";

 $label = $type === "money" ? "§6Money" : "§5Coins";

 $player->sendForm(new class($type, $balance, $label) implements Form {
 public function __construct(private string $type, private string $balance, private string $label) {}

 public function jsonSerialize(): mixed {
 return [
 "type" => "custom_form",
 "title" => "§6Cash - Montant {$this->label}",
 "content" => [
 [
 "type" => "input",
 "text" => "Montant (solde : {$this->balance})",
 "placeholder" => "ex: 500",
 "default" => ""
 ]
 ]
 ];
 }

 public function handleResponse(Player $player, mixed $data): void {
 if ($data === null || !isset($data[0])) return;
 $raw = trim((string)$data[0]);
 if (!is_numeric($raw) || (float)$raw <= 0) {
 $player->sendMessage("§cMontant invalide !");
 return;
 }
 $player->getServer()->dispatchCommand($player, "cash {$this->type} $raw");
 }
 });
 }

 // ── Traitement du cash ───────────────────────────────────────────────────
 private function processCash(Player $player, string $type, float $amount): void
 {
 $name = $player->getName();

 if ($type === "money") {
 $balance = Manager::ECONOMY()->getMoney($name);
 if ($balance < $amount) {
 $player->sendMessage("§cSolde insuffisant ! §fVous avez §e" . number_format($balance, 0, ",", " ") . "§6$ §f(besoin : §e" . number_format($amount, 0, ",", " ") . "§6$§f).");
 return;
 }
 Manager::ECONOMY()->removeMoney($name, $amount);
 Manager::ECONOMY()->saveData();
 $cheque = SpecialItems::makeCashMoney($amount);
 $player->getInventory()->addItem($cheque);
 $player->sendMessage("§6Cash §8» §fChèque §e" . number_format($amount, 0, ",", " ") . "§6$ §fcréé ! §7(-" . number_format($amount, 0, ",", " ") . "$ de votre solde)");
 } else {
 $coins = Manager::COINS()->getCoins($name);
 if ($coins < (int)$amount) {
 $player->sendMessage("§cCoins insuffisants ! §fVous avez §b" . number_format($coins, 0, ",", " ") . "§5 Coins §f(besoin : §b" . number_format((int)$amount, 0, ",", " ") . "§5 Coins§f).");
 return;
 }
 Manager::COINS()->removeCoins($name, (int)$amount);
 Manager::COINS()->saveData();
 $cheque = SpecialItems::makeCashCoins((int)$amount);
 $player->getInventory()->addItem($cheque);
 $player->sendMessage("§5Cash §8» §fChèque §b" . number_format((int)$amount, 0, ",", " ") . "§5 Coins §fcréé ! §7(-" . number_format((int)$amount, 0, ",", " ") . " Coins de votre solde)");
 }
 }
}
