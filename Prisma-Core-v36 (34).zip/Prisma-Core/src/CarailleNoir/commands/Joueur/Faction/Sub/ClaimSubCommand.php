<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class ClaimSubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("claim", "Claim le chunk actuel pour la faction"); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
 if ($faction->getOwner() !== $sender->getName()) {
 $sender->sendMessage("§cSeul le chef peut claim un territoire !"); return;
 }

 $pos = $sender->getPosition();
 $world = $pos->getWorld()->getFolderName();
 $chunkX = $pos->getFloorX() >> 4;
 $chunkZ = $pos->getFloorZ() >> 4;

 // Bloquer dans les mondes island_
 if (str_starts_with($world, "island_")) {
 $sender->sendMessage("§cVous ne pouvez pas claim dans un monde island !"); return;
 }

 // Vérifier qu'il n'y a pas de région existante sur ce chunk
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 $loaded = $wm->getWorldByName($world);
 if ($loaded !== null) {
 $minX = $chunkX * 16; $maxX = $minX + 15;
 $minZ = $chunkZ * 16; $maxZ = $minZ + 15;
 for ($x = $minX; $x <= $maxX; $x += 8) {
 for ($z = $minZ; $z <= $maxZ; $z += 8) {
 $check = new \pocketmine\math\Vector3($x, 64, $z);
 if (Manager::REGION()->getMainRegionAt($check) !== null) {
 $sender->sendMessage("§cImpossible de claim ici : une région admin existe sur ce chunk !");
 return;
 }
 }
 }
 }

 $ok = Manager::FACTION()->addClaim($faction->getId(), $world, $chunkX, $chunkZ);
 if (!$ok) {
 $sender->sendMessage("§cCe chunk est déjà claim par une autre faction !"); return;
 }

 $sender->sendMessage("§a✔ Chunk §f({$chunkX}, {$chunkZ}) §aclaim pour §f" . $faction->getName() . " §a!");
 }
}
