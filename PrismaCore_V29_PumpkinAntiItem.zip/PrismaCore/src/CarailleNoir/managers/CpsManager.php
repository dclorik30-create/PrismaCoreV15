<?php
declare(strict_types=1);
namespace CarailleNoir\managers;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\SettingsManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\player\Player;
use pocketmine\Server;

class CpsManager
{
    private const MAX_CPS              = 20;
    private const TIP_THROTTLE         = 0.1;
    private const ALERT_COOLDOWN       = 5.0;
    private const FLAG_ALERT_COOLDOWN  = 1.5;
    public  const MAX_FLAGS_PER_STAFF  = 3;

    /** @var array<string, float[]> */
    private static array $clicks = [];
    /** @var array<string, float> */
    private static array $lastTip = [];
    /** @var array<string, int> */
    private static array $lastAlertedMax = [];
    /** @var array<string, float> */
    private static array $lastAlertTime = [];
    /** @var array<string, string>  staffLower => targetLower */
    private static array $watchTargets = [];
    /** @var array<string, array<string, int>>  staffLower => [targetLower => threshold] */
    private static array $cpsFlags = [];

    public static function addClick(Player $player): void
    {
        $name  = $player->getName();
        $lower = strtolower($name);
        $now   = microtime(true);

        self::$clicks[$lower][] = $now;
        self::pruneClicks($lower, $now);
        $cps = count(self::$clicks[$lower]);

        // Tip CPS propre si setting actif (sauf si le staff a un watch/flag actif)
        if ($player instanceof PrismaPlayer && $player->isStaffMode()) {
            self::sendStaffTip($player, $lower, $now);
        } elseif (Manager::SETTINGS()->getSetting($name, SettingsManager::SETTING_CPS)) {
            if (!isset(self::$lastTip[$lower]) || ($now - self::$lastTip[$lower]) >= self::TIP_THROTTLE) {
                self::$lastTip[$lower] = $now;
                $player->sendTip("§cCPS : §f" . $cps);
            }
        }

        // Alerte globale via permission prisma.staff.alerts
        if ($cps > self::MAX_CPS && !Manager::ALERT_WHITELIST()->isWhitelisted($name)) {
            $lastMax    = self::$lastAlertedMax[$lower] ?? 0;
            $lastAlert  = self::$lastAlertTime[$lower]  ?? 0.0;
            $cooldownOk = ($now - $lastAlert) >= self::ALERT_COOLDOWN;

            if ($cps > $lastMax || $cooldownOk) {
                self::$lastAlertedMax[$lower] = $cps;
                self::$lastAlertTime[$lower]  = $now;
                $ping = $player->getNetworkSession()->getPing();
                $msg  = "§8[§cAntiCheat§8] §f{$name} §7CPS superieur a "
                      . self::MAX_CPS . " §8| §cCPS Max §f{$cps} §8| §cPing §f{$ping}";
                foreach (Server::getInstance()->getOnlinePlayers() as $receiver) {
                    if (!$receiver instanceof PrismaPlayer || !$receiver->isConnected()) continue;
                    if (strtolower($receiver->getName()) === $lower) continue;
                    if ($receiver->hasPermission('prisma.staff.alerts')) {
                        $receiver->sendMessage($msg);
                    }
                }
            }
        } else {
            unset(self::$lastAlertedMax[$lower], self::$lastAlertTime[$lower]);
        }

        // Mise à jour du tip de tous les staffs qui surveillent ce joueur (watch ou flag)
        foreach (Server::getInstance()->getOnlinePlayers() as $watcher) {
            if (!$watcher instanceof PrismaPlayer || !$watcher->isConnected() || !$watcher->isStaffMode()) continue;
            $wLower = strtolower($watcher->getName());
            $hasWatch = (self::$watchTargets[$wLower] ?? null) === $lower;
            $hasFlag  = isset(self::$cpsFlags[$wLower][$lower]);
            if (!$hasWatch && !$hasFlag) continue;
            self::sendStaffTip($watcher, $wLower, $now);
        }
    }

    /**
     * Construit et envoie le tip unifié pour un staff :
     * [CPS] WatchTarget » X | Flag1 » Y | Flag2 » Z
     */
    public static function sendStaffTipPublic(PrismaPlayer $staff): void
    {
        $sLower = strtolower($staff->getName());
        // Rien à afficher si pas de watch ni de flag
        if (!isset(self::$watchTargets[$sLower]) && empty(self::$cpsFlags[$sLower] ?? [])) return;
        self::sendStaffTip($staff, $sLower, microtime(true));
    }

    private static function sendStaffTip(PrismaPlayer $staff, string $staffLower, float $now): void
    {
        $tipKey = 'staff:' . $staffLower;
        if (isset(self::$lastTip[$tipKey]) && ($now - self::$lastTip[$tipKey]) < self::TIP_THROTTLE) return;
        self::$lastTip[$tipKey] = $now;

        $parts = [];
        $staffName = $staff->getName();

        // Watch target (Random TP)
        $watchLower = self::$watchTargets[$staffLower] ?? null;
        if ($watchLower !== null) {
            $cps = self::getCpsByLower($watchLower);
            $displayName = self::getDisplayName($watchLower);
            $parts[] = "§e" . $displayName . " §8» §c" . $cps;
        }

        // CPS Flags
        foreach (array_keys(self::$cpsFlags[$staffLower] ?? []) as $targetLower) {
            // Ne pas dupliquer si déjà dans le watch
            if ($targetLower === $watchLower) continue;
            $cps = self::getCpsByLower($targetLower);
            $displayName = self::getDisplayName($targetLower);
            $parts[] = "§e" . $displayName . " §8» §c" . $cps;
        }

        if (empty($parts)) return;

        $tip = "§8[§6CPS§8] §f" . implode(" §8| §f", $parts);
        $staff->sendTip($tip);
    }

    public static function getCps(string $name): int
    {
        return self::getCpsByLower(strtolower($name));
    }

    private static function getCpsByLower(string $lower): int
    {
        if (!isset(self::$clicks[$lower])) return 0;
        self::pruneClicks($lower, microtime(true));
        return count(self::$clicks[$lower]);
    }

    private static function getDisplayName(string $lower): string
    {
        foreach (Server::getInstance()->getOnlinePlayers() as $p) {
            if (strtolower($p->getName()) === $lower) return $p->getName();
        }
        return $lower;
    }

    // ─── Watch target ──────────────────────────────────────────────────────

    public static function setWatchTarget(string $staffName, string $targetName): void
    {
        self::$watchTargets[strtolower($staffName)] = strtolower($targetName);
    }

    public static function clearWatchTarget(string $staffName): void
    {
        $sLower = strtolower($staffName);
        unset(self::$watchTargets[$sLower], self::$lastTip['staff:' . $sLower]);
    }

    public static function clearWatchTargetsByTarget(string $targetName): void
    {
        $tLower = strtolower($targetName);
        foreach (self::$watchTargets as $sLower => $watched) {
            if ($watched === $tLower) {
                unset(self::$watchTargets[$sLower], self::$lastTip['staff:' . $sLower]);
            }
        }
    }

    // ─── CPS Flags ────────────────────────────────────────────────────────

    public static function setCpsFlag(string $staffName, string $targetName, int $threshold): void
    {
        self::$cpsFlags[strtolower($staffName)][strtolower($targetName)] = $threshold;
        // Désactiver le tip CPS propre du staff pour éviter la superposition
        Manager::SETTINGS()->setSetting($staffName, SettingsManager::SETTING_CPS, false);
    }

    public static function removeCpsFlag(string $staffName, string $targetName): void
    {
        $sL = strtolower($staffName);
        $tL = strtolower($targetName);
        unset(self::$cpsFlags[$sL][$tL]);
        if (empty(self::$cpsFlags[$sL] ?? [])) {
            unset(self::$cpsFlags[$sL]);
            // Réactiver le tip CPS propre si plus aucun flag ni watch
            if (!isset(self::$watchTargets[$sL])) {
                Manager::SETTINGS()->setSetting($staffName, SettingsManager::SETTING_CPS, true);
            }
        }
    }

    public static function getCpsFlags(string $staffName): array
    {
        return self::$cpsFlags[strtolower($staffName)] ?? [];
    }

    public static function getFlagCount(string $staffName): int
    {
        return count(self::$cpsFlags[strtolower($staffName)] ?? []);
    }

    public static function removeAllFlagsForStaff(string $staffName): void
    {
        $sLower = strtolower($staffName);
        unset(self::$cpsFlags[$sLower], self::$lastTip['staff:' . $sLower]);
    }

    public static function removeTargetFromAllFlags(string $targetName): void
    {
        $tLower = strtolower($targetName);
        foreach (self::$cpsFlags as $sLower => $targets) {
            unset(self::$cpsFlags[$sLower][$tLower]);
            if (empty(self::$cpsFlags[$sLower])) unset(self::$cpsFlags[$sLower]);
        }
    }

    // ─── Cleanup déconnexion ──────────────────────────────────────────────

    public static function remove(string $name): void
    {
        $lower = strtolower($name);
        unset(
            self::$clicks[$lower],
            self::$lastTip[$lower],
            self::$lastTip['staff:' . $lower],
            self::$lastAlertedMax[$lower],
            self::$lastAlertTime[$lower]
        );
        self::clearWatchTarget($name);
        self::clearWatchTargetsByTarget($name);
        self::removeAllFlagsForStaff($name);
        self::removeTargetFromAllFlags($name);
    }

    // ─── Helpers ──────────────────────────────────────────────────────────

    private static function pruneClicks(string $lower, float $now): void
    {
        self::$clicks[$lower] = array_values(array_filter(
            self::$clicks[$lower] ?? [],
            static fn(float $t): bool => ($now - $t) <= 1.0
        ));
    }
}
