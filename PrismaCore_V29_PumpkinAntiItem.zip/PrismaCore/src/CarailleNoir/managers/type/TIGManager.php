<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\handlers\DataHandler;
use CarailleNoir\items\PickaxeOfGodManager;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use pocketmine\Server;
use Symfony\Component\Filesystem\Path;

class TIGManager extends DataHandler
{
    public const TIG_WORLD    = "TIG";
    public const RETURN_WORLD = "Map";

    public function init(): void
    {
        $this->loadData("TIG");
    }

    // ─── Sauvegarde synchrone (données critiques) ─────────────────────────

    private function saveSynchronous(): void
    {
        $path = Path::join(Core::getInstance()->getDataFolder(), "TIG", "Data.json");
        $folder = dirname($path);
        if (!is_dir($folder)) mkdir($folder, 0777, true);
        file_put_contents($path, json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // ─── Ajout TIG ────────────────────────────────────────────────────────

    public function addTIG(string $playerName, int $durationSeconds, string $reason, string $staff): void
    {
        $player  = Server::getInstance()->getPlayerExact($playerName);
        $invData = null;

        if ($player instanceof Player) {
            $invData = $this->serializeInventory($player);
            $player->getInventory()->clearAll();
            $player->getArmorInventory()->clearAll();
        }

        $this->data[strtolower($playerName)] = [
            "reason"       => $reason,
            "staff"        => $staff,
            "expire"       => time() + $durationSeconds,
            "blocks_mined" => 0,
            "prev_world"   => $player?->getWorld()->getFolderName() ?? self::RETURN_WORLD,
            "inventory"    => $invData,
        ];
        $this->saveSynchronous();

        if ($player instanceof Player) $this->teleportToTIG($player, $reason);
    }

    // ─── Suppression TIG ──────────────────────────────────────────────────

    public function removeTIG(string $playerName): void
    {
        $key    = strtolower($playerName);
        $data   = $this->data[$key] ?? null;
        $player = Server::getInstance()->getPlayerExact($playerName);

        unset($this->data[$key]);
        $this->saveSynchronous();

        if ($player instanceof Player) {
            $this->releasePlayer($player, $data);
        }
    }

    // ─── Vérifications ────────────────────────────────────────────────────

    public function isTIG(string $playerName): bool
    {
        $key = strtolower($playerName);
        if (!isset($this->data[$key])) return false;
        if (time() > $this->data[$key]["expire"]) {
            $this->removeTIG($playerName);
            return false;
        }
        return true;
    }

    public function getTIGInfo(string $playerName): ?array
    {
        return $this->data[strtolower($playerName)] ?? null;
    }

    public function getRemainingTime(string $playerName): int
    {
        $key  = strtolower($playerName);
        $info = $this->data[$key] ?? null;
        return $info ? max(0, $info["expire"] - time()) : 0;
    }

    public function addMinedBlock(string $playerName): void
    {
        $key = strtolower($playerName);
        if (isset($this->data[$key])) {
            $this->data[$key]["blocks_mined"]++;
            $this->markDirty();
            $this->saveData();
        }
    }

    // ─── Login check ──────────────────────────────────────────────────────

    public function checkOnLogin(Player $player): void
    {
        $key = strtolower($player->getName());
        if (!isset($this->data[$key])) return;

        // TIG expiré pendant la déco
        if (time() > $this->data[$key]["expire"]) {
            $data = $this->data[$key];
            unset($this->data[$key]);
            $this->saveSynchronous();
            $this->releasePlayer($player, $data);
            return;
        }

        // TIG actif — sauvegarder inventaire si pas encore fait (TIG hors-ligne)
        if (empty($this->data[$key]["inventory"])) {
            $this->data[$key]["inventory"] = $this->serializeInventory($player);
            $this->saveSynchronous();
        }

        $this->teleportToTIG($player, $this->data[$key]["reason"] ?? "");
    }

    // ─── TP vers TIG ──────────────────────────────────────────────────────

    public function teleportToTIG(Player $player, string $reason = ""): void
    {
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded(self::TIG_WORLD)) $wm->loadWorld(self::TIG_WORLD);
        $world = $wm->getWorldByName(self::TIG_WORLD);
        if ($world === null) {
            $player->sendMessage("§cErreur : le monde TIG n'existe pas sur ce serveur !");
            return;
        }
        $player->teleport($world->getSpawnLocation());
        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();

        $pickaxe = PickaxeOfGodManager::makeLevel(1, 0);
        if ($pickaxe !== null) $player->getInventory()->addItem($pickaxe);

        $remaining = $this->getRemainingTime($player->getName());
        $h = intdiv($remaining, 3600);
        $m = intdiv($remaining % 3600, 60);
        $s = $remaining % 60;
        $player->sendMessage("§c━━━━━━━━━━━━━━━━━━━━━━━━");
        $player->sendMessage("§cVous avez été placé en TIG.");
        $player->sendMessage("§fRaison : §e" . ($reason ?: "Non précisée"));
        $player->sendMessage("§fDurée restante : §e{$h}h {$m}min {$s}s");
        $player->sendMessage("§c━━━━━━━━━━━━━━━━━━━━━━━━");
    }

    // ─── Libération joueur ────────────────────────────────────────────────

    private function releasePlayer(Player $player, ?array $data): void
    {
        $player->getInventory()->clearAll();
        $player->getArmorInventory()->clearAll();

        if ($data !== null && !empty($data["inventory"])) {
            $this->restoreInventory($player, $data["inventory"]);
        }

        $wm        = Server::getInstance()->getWorldManager();
        $prevWorld = $data["prev_world"] ?? self::RETURN_WORLD;

        // Si le monde prev_world n'existe pas ou est le monde TIG, on renvoie sur Map
        if ($prevWorld === self::TIG_WORLD || $prevWorld === "world") {
            $prevWorld = self::RETURN_WORLD;
        }

        if (!$wm->isWorldLoaded($prevWorld)) $wm->loadWorld($prevWorld);
        $world = $wm->getWorldByName($prevWorld) ?? $wm->getWorldByName(self::RETURN_WORLD);

        if ($world === null) {
            if (!$wm->isWorldLoaded(self::RETURN_WORLD)) $wm->loadWorld(self::RETURN_WORLD);
            $world = $wm->getWorldByName(self::RETURN_WORLD) ?? $wm->getDefaultWorld();
        }

        if ($world !== null) $player->teleport($world->getSpawnLocation());
        $player->sendMessage("§aVotre TIG est terminé, vous êtes libre !");
    }

    // ─── Sérialisation inventaire ─────────────────────────────────────────

    public function serializeInventory(Player $player): string
    {
        $nbt   = new BigEndianNbtSerializer();
        $items = [];
        foreach ($player->getInventory()->getContents() as $slot => $item) {
            $items[] = ["slot" => $slot, "type" => "main",  "data" => base64_encode($nbt->write(new TreeRoot($item->nbtSerialize())))];
        }
        foreach ($player->getArmorInventory()->getContents() as $slot => $item) {
            $items[] = ["slot" => $slot, "type" => "armor", "data" => base64_encode($nbt->write(new TreeRoot($item->nbtSerialize())))];
        }
        return base64_encode(json_encode($items));
    }

    private function restoreInventory(Player $player, string $encoded): void
    {
        try {
            $nbt   = new BigEndianNbtSerializer();
            $items = json_decode(base64_decode($encoded), true);
            foreach ($items as $entry) {
                $tag  = $nbt->read(base64_decode($entry["data"]))->mustGetCompoundTag();
                $item = Item::nbtDeserialize($tag);
                if ($entry["type"] === "armor") $player->getArmorInventory()->setItem((int)$entry["slot"], $item);
                else $player->getInventory()->setItem((int)$entry["slot"], $item);
            }
        } catch (\Throwable) {}
    }
}
