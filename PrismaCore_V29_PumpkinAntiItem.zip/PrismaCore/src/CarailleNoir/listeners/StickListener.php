<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\Core;
use CarailleNoir\managers\CpsManager;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\scheduler\ClosureTask;

/**
 * Gère les sticks PVP joueurs.
 *
 * FREEZE : 5s | CD 120s — setNoClientPredictions (séparé du freeze staff)
 * ANTI-PEARL : 40s | CD 180s
 * ANTI-ITEM : 40s | CD 180s
 *
 * - Le hit N'EST PAS cancel : les dégâts passent normalement.
 * - Cooldown affiché en bas (sendTip) au moment du hit.
 * - Clic droit : affiche le cooldown ou "Pret a l'emploi".
 */
class StickListener implements Listener
{
 /** key = "playerName:type" value = timestamp d'expiration du cooldown */
 private array $cooldowns = [];

 // ── Hit ───────────────────────────────────────────────────────────────────

 public function onHit(EntityDamageByEntityEvent $event): void
 {
 $attacker = $event->getDamager();
 $victim = $event->getEntity();
 if (!$attacker instanceof PrismaPlayer || !$victim instanceof PrismaPlayer) return;

 $item = $attacker->getInventory()->getItemInHand();
 $now = time();
 $aKey = strtolower($attacker->getName());

 // Bloquer si l'attaquant est sous Anti-Item et tente d'utiliser un stick
 if (SpecialItems::isAntiItemBlockedItem($item) && Manager::ANTIITEM()->hasEffect($aKey)) {
 // Atout 'antiitem' : seul l'arc-punch reste bloqué (l'arc-punch passe par onHit via snowball, donc on bloque tout de même)
 $hasProtection = Manager::ATOUT()->hasAntiItemProtection($aKey);
 if (!$hasProtection || SpecialItems::isArcPunch($item)) {
 $rem = Manager::ANTIITEM()->getRemaining($aKey);
 $attacker->sendTip("§dAnti-Item actif : §f{$rem}s restants");
 return;
 }
 }

 // ── FREEZE ────────────────────────────────────────────────────────────
 if (SpecialItems::isFreezeStick($item)) {
 $cd = $aKey . ':freeze';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§bFreeze §8» §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 120;
 // setNoClientPredictions SANS freeze() — le isFreeze() reste false
 // donc le check admin-freeze dans onAttack ne bloque pas les dégats
 $victim->setNoClientPredictions(true);
 Manager::STICKFREEZE()->freeze($victim->getName(), 5);
 $victim->sendMessage("§b[Freeze] §fVous etes freeze pendant 5s !");
 $attacker->sendTip("§b[Freeze] §fApplique sur §e" . $victim->getName() . " §f(5s).");
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new ClosureTask(function() use ($victim): void {
 if (!$victim->isConnected()) return;
 Manager::STICKFREEZE()->unfreeze($victim->getName());
 // Relacher seulement si pas aussi freeze par un staff
 if (!$victim->isFreeze()) $victim->setNoClientPredictions(false);
 $victim->sendTip("§aVous n'etes plus freeze !");
 }), 20 * 5
 );
 return;
 }

 // ── ANTI-PEARL ────────────────────────────────────────────────────────
 if (SpecialItems::isAntiPearlStick($item)) {
 $cd = $aKey . ':antipearl';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§cAnti-Pearl §8» §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 180;
 Manager::PEARL()->applyAntiPearl($victim->getName(), 40);
 $victim->sendMessage("§c[Anti-Pearl] §fVous ne pouvez pas utiliser de pearl pendant 40s !");
 $attacker->sendTip("§c[Anti-Pearl] §fApplique sur §e" . $victim->getName() . " §f(40s).");
 return;
 }

 // ── ANTI-ITEM ─────────────────────────────────────────────────────────
 if (SpecialItems::isAntiItemStick($item)) {
 $cd = $aKey . ':antiitem';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§dAnti-Item §8» §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 180;
 Manager::ANTIITEM()->apply($victim->getName(), 40);
 $victim->sendMessage("§d[Anti-Item] §fVous ne pouvez pas utiliser vos items pendant 40s !");
 $attacker->sendTip("§d[Anti-Item] §fApplique sur §e" . $victim->getName() . " §f(40s).");
 return;
 }
 }

 // ── Clic droit ────────────────────────────────────────────────────────────

 public function onUse(PlayerItemUseEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $item = $event->getItem();
 $now = time();
 $key = strtolower($player->getName());

 if (SpecialItems::isFreezeStick($item)) {
 $event->cancel();
 $cd = $key . ':freeze';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§bFreeze §8» §f{$rem}s" : "§bFreeze §8» §aPrêt !");
 return;
 }

 if (SpecialItems::isAntiPearlStick($item)) {
 $event->cancel();
 $cd = $key . ':antipearl';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§cAnti-Pearl §8» §f{$rem}s" : "§cAnti-Pearl §8» §aPrêt !");
 return;
 }

 if (SpecialItems::isAntiItemStick($item)) {
 $event->cancel();
 $cd = $key . ':antiitem';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§dAnti-Item §8» §f{$rem}s" : "§dAnti-Item §8» §aPrêt !");
 return;
 }

 }

    /**
     * @priority HIGHEST
     * @handleCancelled true
     */
    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;

        $item = $player->getInventory()->getItemInHand();
        $key  = strtolower($player->getName());

        if (!SpecialItems::isRandomTP($item)) return;

        $event->cancel();

        if (!$player->isStaffMode()) {
            $player->sendMessage('§c[StaffMod] §fCet item est utilisable uniquement en staffmod.');
            return;
        }

        $targets = [];
        foreach (Core::getInstance()->getServer()->getOnlinePlayers() as $target) {
            if (!$target instanceof PrismaPlayer || !$target->isConnected()) continue;
            if (strtolower($target->getName()) === $key) continue;
            if ($target->isStaffMode()) continue;
            $targets[] = $target;
        }

        if (count($targets) === 0) {
            $player->sendMessage('§c[StaffMod] §fAucun joueur disponible pour le Random TP.');
            return;
        }

        /** @var PrismaPlayer $target */
        $target = $targets[array_rand($targets)];
        $player->teleport($target->getPosition());
        CpsManager::setWatchTarget($player->getName(), $target->getName());
        $player->sendMessage('§6[StaffMod] §fTéléporté sur §e' . $target->getName() . '§f. CPS suivis dans le tip.');
    }
    /**
     * @priority HIGHEST
     * @handleCancelled true
     */
    public function onItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $item = $event->getItem();
        $key  = strtolower($player->getName());

        if (!SpecialItems::isRandomTP($item)) return;

        $event->cancel();

        if (!$player->isStaffMode()) {
            $player->sendMessage('§c[StaffMod] §fCet item est utilisable uniquement en staffmod.');
            return;
        }

        $targets = [];
        foreach (Core::getInstance()->getServer()->getOnlinePlayers() as $target) {
            if (!$target instanceof PrismaPlayer || !$target->isConnected()) continue;
            if (strtolower($target->getName()) === $key) continue;
            if ($target->isStaffMode()) continue;
            $targets[] = $target;
        }

        if (count($targets) === 0) {
            $player->sendMessage('§c[StaffMod] §fAucun joueur disponible pour le Random TP.');
            return;
        }

        /** @var PrismaPlayer $target */
        $target = $targets[array_rand($targets)];
        $player->teleport($target->getPosition());
        CpsManager::setWatchTarget($player->getName(), $target->getName());
        $player->sendMessage('§6[StaffMod] §fTéléporté sur §e' . $target->getName() . '§f. CPS suivis dans le tip.');
    }
}
