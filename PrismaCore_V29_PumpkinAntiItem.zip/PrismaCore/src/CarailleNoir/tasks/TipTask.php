<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\managers\CpsManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class TipTask extends Task
{
    private const ARCPUNCH_CD = 8;

    public function onRun(): void
    {
        $now = time();

        // ArcPunch cooldown tip
        foreach (PlayerListener::$arcPunchCooldowns as $name => $ts) {
            $remaining = self::ARCPUNCH_CD - ($now - $ts);
            $player    = Server::getInstance()->getPlayerExact($name);
            if ($player === null || !$player instanceof PrismaPlayer) {
                unset(PlayerListener::$arcPunchCooldowns[$name]);
                continue;
            }
            if ($remaining > 0) {
                $player->sendTip("§6Arc-Punch §8» §c" . $remaining . "s");
            } else {
                unset(PlayerListener::$arcPunchCooldowns[$name]);
                $player->sendTip("§6Arc-Punch §8» §aPret !");
            }
        }

        // Tip CPS unifié pour tout staff avec watch/flags actifs (staffmod ou non)
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if (!$player instanceof PrismaPlayer || !$player->isConnected()) continue;
            CpsManager::sendStaffTipPublic($player);
        }
    }
}
