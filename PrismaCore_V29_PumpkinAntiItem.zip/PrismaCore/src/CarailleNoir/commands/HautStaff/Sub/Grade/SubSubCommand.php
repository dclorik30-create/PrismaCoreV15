<?php
declare(strict_types=1);
namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

/**
 * /grade sub {Player} {gradeId}
 *
 * Attribue un grade secondaire (subRole) qui ajoute uniquement les permissions
 * du grade en question, sans modifier l'affichage (nametag/scoreboard).
 */
class SubSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct(
            'sub',
            'Attribuer/retirer un grade secondaire (permissions only)',
            [], [], DefaultPermissions::ROOT_OPERATOR
        );
    }

    protected function prepare(): array
    {
        return [
            new TargetPlayerArgument(false, 'playerName'),
            new RawStringArgument('identifier', true),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $playerName = $args['playerName'] ?? null;
        $identifier = trim((string)($args['identifier'] ?? ''));

        if ($playerName === null) {
            $sender->sendMessage('§cUsage : §f/grade sub <joueur> [gradeId]');
            return;
        }

        if (!Manager::ALIAS()->hasProfil($playerName)) {
            $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
            return;
        }

        // Sans gradeId : afficher les sub-grades actuels du joueur
        if ($identifier === '') {
            $subs = Manager::GRADE()->getSubGrades($playerName);
            if (empty($subs)) {
                $sender->sendMessage("§e{$playerName} §fn'a aucun grade secondaire.");
            } else {
                $sender->sendMessage("§6Grades secondaires de §e{$playerName}§6 : §f" . implode('§8, §f', $subs));
            }
            return;
        }

        if (!Manager::GRADE()->existGrade($identifier)) {
            $sender->sendMessage("§cLe grade §e{$identifier} §cn'existe pas !");
            return;
        }

        // Toggle : déjà présent → retirer
        if (Manager::GRADE()->hasSubGrade($playerName, $identifier)) {
            Manager::GRADE()->removeSubGrade($playerName, $identifier);
            $sender->sendMessage("§aGrade secondaire §e{$identifier} §aretirable à §e{$playerName}§a.");
        } else {
            Manager::GRADE()->addSubGrade($playerName, $identifier);
            $sender->sendMessage("§aGrade secondaire §e{$identifier} §aajouté à §e{$playerName}§a. (permissions seulement, pas d'affichage)");
        }
    }
}
