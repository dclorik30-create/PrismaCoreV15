<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class UnTIGCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("untig", "Sortir un joueur de TIG", [], [], ["prisma.command.tig", "prisma.command.staff"]);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("player", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $targetName = trim((string)($args["player"] ?? ""));
        if ($targetName === "") {
            $sender->sendMessage("§cUsage : §f/untig <joueur>");
            return;
        }

        // getTIGInfo() = données brutes sans vérif expiration → fonctionne offline
        if (Manager::TIG()->getTIGInfo($targetName) === null) {
            $sender->sendMessage("§e{$targetName} §fn'est pas en TIG.");
            return;
        }

        Manager::TIG()->removeTIG($targetName);

        $online = Server::getInstance()->getPlayerExact($targetName);
        if ($online !== null) {
            $sender->sendMessage("§a{$targetName} §fa été sorti de TIG et téléporté sur §eMap§f.");
        } else {
            $sender->sendMessage("§a{$targetName} §fa été sorti de TIG §7(hors-ligne, sera téléporté à sa reconnexion)§f.");
        }
    }
}
