<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\managers\CpsManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class CpsFlagCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct('cpsflag', "Surveille/arrete de surveiller les CPS d'un joueur", [], [], ['prisma.command.cpsflag']);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(true, 'joueur')];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $target = trim((string)($args['joueur'] ?? ''));

        // Sans argument : liste les flags actifs
        if ($target === '') {
            $active = CpsManager::getCpsFlags($sender->getName());
            if (empty($active)) {
                $sender->sendMessage('§6[CPSFlag] §fAucun joueur surveille.');
                return;
            }
            $lines = [];
            foreach (array_keys($active) as $t) $lines[] = '§e' . $t;
            $sender->sendMessage('§6[CPSFlag] §fSurveillances actives §8(§e' . count($active) . '§8) : ' . implode(' §8| ', $lines));
            return;
        }

        // Verifier que le joueur est bien en ligne
        $onlineTarget = Server::getInstance()->getPlayerByPrefix($target);
        if ($onlineTarget === null) {
            $sender->sendMessage('§c[CPSFlag] §e' . $target . ' §fne semble pas connecte.');
            return;
        }
        $target = $onlineTarget->getName();

        $flags = CpsManager::getCpsFlags($sender->getName());

        // Toggle : deja flagge → retirer
        if (isset($flags[strtolower($target)])) {
            CpsManager::removeCpsFlag($sender->getName(), $target);
            $sender->sendMessage('§6[CPSFlag] §fSurveillance retiree pour §e' . $target . '§f.');
            return;
        }

        // Verifier limite
        if (CpsManager::getFlagCount($sender->getName()) >= CpsManager::MAX_FLAGS_PER_STAFF) {
            $sender->sendMessage('§c[CPSFlag] §fMaximum §e' . CpsManager::MAX_FLAGS_PER_STAFF . ' joueurs §fsimultanement.');
            return;
        }

        CpsManager::setCpsFlag($sender->getName(), $target, 0);
        $sender->sendMessage('§6[CPSFlag] §fSurveillance activee pour §e' . $target . '§f. CPS affiches dans ton tip.');

        $all = CpsManager::getCpsFlags($sender->getName());
        if (count($all) > 1) {
            $lines = [];
            foreach (array_keys($all) as $t) $lines[] = '§e' . $t;
            $sender->sendMessage('§8[CPSFlag] §fActifs : ' . implode(' §8| ', $lines));
        }
    }
}
