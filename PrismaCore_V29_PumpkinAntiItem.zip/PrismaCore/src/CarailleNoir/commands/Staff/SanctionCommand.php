<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\invmenu\SanctionMenu;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class SanctionCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("sanction", "Menu de sanction", [], [], ["prisma.command.sanction", "prisma.command.staff"]);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("player", true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $targetName = trim((string)($args["player"] ?? ""));

        // Sans argument : menu de la liste des joueurs en ligne
        if ($targetName === "") {
            SanctionMenu::getSanctionMenu()->send($sender);
            return;
        }

        // Vérifier que le joueur a un profil (connecté ou non)
        if (!Manager::ALIAS()->hasProfil($targetName)) {
            $sender->sendMessage("§cAucun profil trouve pour §f{$targetName}§c.");
            return;
        }

        // Joueur en ligne → panel complet (TP, freeze, sanctions)
        $online = Server::getInstance()->getPlayerByPrefix($targetName);
        if ($online instanceof PrismaPlayer) {
            SanctionMenu::sendTargetPanel($sender, $online);
            return;
        }

        // Joueur hors-ligne → panel sanctions uniquement (pas de TP/freeze)
        SanctionMenu::sendOfflineTargetPanel($sender, $targetName);
    }
}
