<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class AliasCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("alias", "Alias des joueurs", [], [], ["prisma.command.staff", "prisma.command.alias", DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("playername", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $targetName = $args["playername"];

        if (!Manager::ALIAS()->hasProfil($targetName)) {
            $sender->sendMessage("§cAucun profil trouve pour §f{$targetName}§c.");
            return;
        }

        $alts = Manager::ALIAS()->getAccounts($targetName);

        $msg = "\n§6>> Liste des doubles comptes de §f\"{$targetName}\"§6 :\n";

        if (empty($alts)) {
            $msg .= "§7Aucun double compte trouve.";
        } else {
            foreach ($alts as $alt) {
                $isBanned = Manager::BAN()->isBanned($alt);
                $isMuted  = Manager::MUTE()->isMuted($alt);
                $isTIG    = Manager::TIG()->getTIGInfo($alt) !== null;

                if ($isBanned) {
                    $status = "§cBanni";
                } elseif ($isTIG) {
                    $status = "§6TIG";
                } elseif ($isMuted) {
                    $status = "§eMute";
                } else {
                    $status = "§aAucune sanction";
                }

                $msg .= "§8- §f{$alt} §8: {$status}\n";
            }
            $msg = rtrim($msg);
        }

        $sender->sendMessage($msg);
    }
}
