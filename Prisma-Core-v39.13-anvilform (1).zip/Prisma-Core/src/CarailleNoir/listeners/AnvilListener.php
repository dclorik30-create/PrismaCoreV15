<?php

declare(strict_types=1);

namespace CarailleNoir\listeners;

use CarailleNoir\libs\forms\SimpleForm;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\BlockTypeIds;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\Durable;

class AnvilListener implements Listener
{
    private const REPAIR_PRICE = 100;
    private const REPAIR_ALL_PRICE = 1500;

    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if ($event->getBlock()->getTypeId() !== BlockTypeIds::ANVIL) return;

        $event->cancel();

        $form = new SimpleForm(function(PrismaPlayer $player, $data): void {
            if ($data === null) return;
            switch ($data) {
                case 'repair':
                    $this->repairHand($player);
                    break;
                case 'repair_all':
                    $this->repairAll($player);
                    break;
            }
        });

        $inHand = $player->getInventory()->getItemInHand();
        $handState = $inHand instanceof Durable && $inHand->getDamage() > 0 ? "§aRéparable" : "§cPas réparable";

        $form->setTitle('§8Enclume');
        $form->setContent(
            "§fChoisissez une action :\n\n" .
            "§7Item en main : §e" . $inHand->getName() . "\n" .
            "§7État : " . $handState . "\n\n" .
            "§7Repair : §a100$\n" .
            "§7RepairAll : §a1500$"
        );
        $form->addButton('§aRepair\n§7Répare l\'item en main', -1, '', 'repair');
        $form->addButton('§6RepairAll\n§7Répare inventaire + armure', -1, '', 'repair_all');
        $form->addButton('§cFermer', -1, '', 'close');
        $player->sendForm($form);
    }

    private function repairHand(PrismaPlayer $player): void
    {
        $item = $player->getInventory()->getItemInHand();
        if (!$item instanceof Durable) {
            $player->sendMessage('§cL\'item en main ne peut pas être réparé.');
            return;
        }
        if ($item->getDamage() <= 0) {
            $player->sendMessage('§cVotre item en main est déjà réparé.');
            return;
        }
        if (!$player->hasMoney(self::REPAIR_PRICE)) {
            $player->sendMessage('§cVous n\'avez pas assez d\'argent.');
            return;
        }
        $player->removeMoney(self::REPAIR_PRICE);
        $item->setDamage(0);
        $player->getInventory()->setItemInHand($item);
        $player->sendMessage('§aVotre item en main a été réparé pour 100$.');
    }

    private function repairAll(PrismaPlayer $player): void
    {
        if (!$player->hasMoney(self::REPAIR_ALL_PRICE)) {
            $player->sendMessage('§cVous n\'avez pas assez d\'argent.');
            return;
        }

        $repaired = 0;
        $inv = $player->getInventory();
        for ($i = 0; $i < $inv->getSize(); $i++) {
            $item = $inv->getItem($i);
            if ($item instanceof Durable && $item->getDamage() > 0) {
                $item->setDamage(0);
                $inv->setItem($i, $item);
                $repaired++;
            }
        }

        $armor = $player->getArmorInventory();
        for ($i = 0; $i < $armor->getSize(); $i++) {
            $item = $armor->getItem($i);
            if ($item instanceof Durable && $item->getDamage() > 0) {
                $item->setDamage(0);
                $armor->setItem($i, $item);
                $repaired++;
            }
        }

        if ($repaired <= 0) {
            $player->sendMessage('§cAucun item à réparer dans votre inventaire ou votre armure.');
            return;
        }

        $player->removeMoney(self::REPAIR_ALL_PRICE);
        $player->sendMessage('§aTous vos items ont été réparés pour 1500$.');
    }
}
