<?php
declare(strict_types=1);

namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\items\staff\SeedPlanter;
use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\Crops;
use pocketmine\block\Farmland;
use pocketmine\block\VanillaBlocks;
use CarailleNoir\managers\Manager;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\item\ItemTypeIds;

class SeedPlanterListener implements Listener
{
    /** @var array<string, float> */
    private static array $cooldowns = [];

    public function onBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if (!($player->getInventory()->getItemInHand() instanceof SeedPlanter)) {
            return;
        }

        $name = $player->getName();
        $now = microtime(true) * 1000;
        if (isset(self::$cooldowns[$name]) && ($now - self::$cooldowns[$name]) < 100) {
            return;
        }
        self::$cooldowns[$name] = $now;

        $block = $event->getBlock();
        if (!($block instanceof Crops)) {
            return;
        }

        $event->cancel();

        $center = $block->getPosition();
        $world = $center->getWorld();
        $inv = $player->getInventory();

        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dz = -1; $dz <= 1; $dz++) {
                $pos = $center->add($dx, 0, $dz);
                $crop = $world->getBlock($pos);
                if (!($crop instanceof Crops)) {
                    continue;
                }

                $drops = $crop->getDrops($player->getInventory()->getItemInHand());
                $world->setBlock($pos, VanillaBlocks::AIR());

                foreach ($drops as $drop) {
                    if ($inv->canAddItem($drop)) {
                        $inv->addItem($drop);
                    } else {
                        $world->dropItem($pos->add(0.5, 0.5, 0.5), $drop);
                    }
                }

                // XP uniquement si la pousse était mature
                if ($crop->getAge() >= $crop->getMaxAge()) {
                    Manager::LEVEL()->addExp($player, 5, "Récolte");
                }
            }
        }
    }

    public function onInteract(PlayerInteractEvent $event): void
    {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            return;
        }

        $player = $event->getPlayer();
        if (!($player->getInventory()->getItemInHand() instanceof SeedPlanter)) {
            return;
        }

        $clicked = $event->getBlock();
        if (!($clicked instanceof Crops) && !($clicked instanceof Farmland)) {
            return;
        }

        $name = $player->getName();
        $now = microtime(true) * 1000;
        if (isset(self::$cooldowns[$name]) && ($now - self::$cooldowns[$name]) < 100) {
            $event->cancel();
            return;
        }
        self::$cooldowns[$name] = $now;

        $event->cancel();

        $world = $clicked->getPosition()->getWorld();
        $inv = $player->getInventory();

        $bestTypeId = null;
        $bestCount = 0;
        $validTypeIds = [
            ItemTypeIds::WHEAT_SEEDS,
            ItemTypeIds::CARROT,
            ItemTypeIds::POTATO,
            ItemTypeIds::BEETROOT_SEEDS,
        ];

        foreach ($inv->getContents() as $item) {
            $typeId = $item->getTypeId();
            if (in_array($typeId, $validTypeIds, true) && $item->getCount() > $bestCount) {
                $bestTypeId = $typeId;
                $bestCount = $item->getCount();
            }
        }

        if ($bestTypeId === null) {
            $player->sendTip("§cAucune graine dans ton inventaire !");
            return;
        }

        $center = $clicked instanceof Crops ? $clicked->getPosition() : $clicked->getPosition()->add(0, 1, 0);

        $plantable = [];
        for ($dx = -1; $dx <= 1; $dx++) {
            for ($dz = -1; $dz <= 1; $dz++) {
                $plantPos = $center->add($dx, 0, $dz);
                $below = $world->getBlock($plantPos->subtract(0, 1, 0));
                $at = $world->getBlock($plantPos);

                if (!($below instanceof Farmland)) {
                    continue;
                }
                if ($at->getTypeId() !== BlockTypeIds::AIR) {
                    continue;
                }

                $plantable[] = $plantPos;
            }
        }

        if (count($plantable) === 0) {
            $player->sendTip("§cAucune case plantable autour !");
            return;
        }

        $needed = count($plantable);
        $remaining = $needed;

        foreach ($inv->getContents() as $slot => $item) {
            if ($item->getTypeId() !== $bestTypeId) {
                continue;
            }

            $take = min($remaining, $item->getCount());
            if ($take <= 0) {
                break;
            }

            $newItem = clone $item;
            $newItem->setCount($item->getCount() - $take);
            $inv->setItem($slot, $newItem);
            $remaining -= $take;

            if ($remaining <= 0) {
                break;
            }
        }

        $consumed = $needed - $remaining;
        if ($consumed <= 0) {
            $player->sendTip("§cTu n'as pas assez de graines !");
            return;
        }

        $cropBlock = $this->seedToCropFromTypeId($bestTypeId);
        if ($cropBlock === null) {
            return;
        }

        $planted = 0;
        foreach ($plantable as $plantPos) {
            if ($planted >= $consumed) {
                break;
            }
            $world->setBlock($plantPos, clone $cropBlock);
            $planted++;
        }

        $player->sendTip("§a{$planted}/{$needed} plantation(s) posées !");
    }

    private function seedToCropFromTypeId(int $typeId): ?Block
    {
        return match ($typeId) {
            ItemTypeIds::WHEAT_SEEDS => VanillaBlocks::WHEAT(),
            ItemTypeIds::CARROT => VanillaBlocks::CARROTS(),
            ItemTypeIds::POTATO => VanillaBlocks::POTATOES(),
            ItemTypeIds::BEETROOT_SEEDS => VanillaBlocks::BEETROOTS(),
            default => null,
        };
    }
}
