<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\entities\PrismaItemEntity;
use pocketmine\entity\Location;
use pocketmine\entity\object\ItemEntity;
use pocketmine\event\entity\ItemSpawnEvent;
use pocketmine\event\Listener;
use pocketmine\nbt\tag\CompoundTag;

class ItemClearListener implements Listener
{
    public function onItemSpawn(ItemSpawnEvent $event): void
    {
        $entity = $event->getEntity();

        if ($entity instanceof PrismaItemEntity) {
            return;
        }

        $item       = $entity->getItem();
        $location   = $entity->getLocation();
        $motion     = $entity->getMotion();
        // On recupere le pickup delay de l'entite originale (40 ticks par defaut
        // quand un joueur drop un item, 0 pour les drops de mobs etc.)
        $pickupDelay = $entity->getPickupDelay();

        $entity->flagForDespawn();

        $nbt = CompoundTag::create()
            ->setLong("PrismaExpireAt", time() + 45);

        $custom = new PrismaItemEntity(
            Location::fromObject($location, $location->getWorld(), $location->yaw, $location->pitch),
            $item,
            $nbt
        );
        $custom->setMotion($motion);
        $custom->setPickupDelay($pickupDelay); // conserver le delai original
        $custom->spawnToAll();
    }
}
