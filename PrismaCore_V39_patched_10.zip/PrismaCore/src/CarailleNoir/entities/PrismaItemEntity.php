<?php
declare(strict_types=1);
namespace CarailleNoir\entities;

use pocketmine\entity\object\ItemEntity;
use pocketmine\nbt\tag\CompoundTag;

class PrismaItemEntity extends ItemEntity
{
    private const TTL        = 45;         // secondes
    private const CHECK_FREQ = 20;         // verifier 1x/sec (20 ticks)

    private int $expireAt       = 0;
    private int $nextCheckTick  = 0;

    protected function initEntity(CompoundTag $nbt): void
    {
        parent::initEntity($nbt);
        $this->expireAt = (int) $nbt->getLong("PrismaExpireAt", time() + self::TTL);
    }

    public function saveNBT(): CompoundTag
    {
        $nbt = parent::saveNBT();
        $nbt->setLong("PrismaExpireAt", $this->expireAt);
        return $nbt;
    }

    public function onUpdate(int $currentTick): bool
    {
        if ($this->isClosed()) {
            return false;
        }

        // Verifier l'expiration 1x par seconde au lieu de 20x
        if ($currentTick >= $this->nextCheckTick) {
            $this->nextCheckTick = $currentTick + self::CHECK_FREQ;
            if (time() >= $this->expireAt) {
                $this->flagForDespawn();
                return false;
            }
        }

        $parentResult = parent::onUpdate($currentTick);

        // scheduleUpdate() uniquement si le parent veut arreter de ticker
        // (item immobile au sol) — pas besoin de le rappeler si parent retourne true
        if (!$parentResult) {
            $this->scheduleUpdate();
        }

        return true;
    }
}
