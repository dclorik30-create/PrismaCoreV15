<?php

namespace CarailleNoir\utils\Text;

class TextUtils
{
 const PREFIX = "§8[§d§lPrisma§r§8] §r";
 const NEW_PLAYER = "§8[§6Prisma§8] §fBienvenue à §e{name} §7qui rejoint le serveur pour la première fois !";
 const TARGET_FREEZE = "Un staff vien de vous {freeze_status}";
 const SENDER_FREEZE = "Le joueur {targetname} vient d'être {freeze_status}";
 const ALIAS_NO_EXIST = "§cLe joueur que vous avez choisis ne c'est jamais connecté au serveur !";
}