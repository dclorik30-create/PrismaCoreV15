<?php
namespace CarailleNoir\commands\Joueur\Kit;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;

class KitCommand extends BaseCommand
{
 public function __construct() { parent::__construct("kit", "Récupérer un kit", [], [], ["prisma.command.kit"]); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 if (Manager::COMBATLOG()->isTagged($sender->getName())) {
 $sender->sendMessage("§cVous ne pouvez pas ouvrir le menu kit en combat !");
 return;
 }
 $kits = Manager::KIT()->getKits();
 $kitIds = array_keys($kits);
 if (empty($kits)) { $sender->sendMessage("§cAucun kit disponible."); return; }
 $sender->sendForm(new class($kits, $kitIds, $sender) implements Form {
 public function __construct(private array $kits, private array $kitIds, private PrismaPlayer $player) {}
 public function jsonSerialize(): array
 {
 $btns = [];
 foreach ($this->kits as $id => $kit) {
 $perm    = $kit["permission"] ?? "";
 $hasPerm = ($perm === "") || $this->player->hasPermission($perm);
 $hasCd   = Manager::KIT()->hasCooldown($this->player->getName(), $id);

 if ($hasPerm && !$hasCd) {
 $statusLine = "\n§aDisponible";
 } elseif ($hasCd) {
 $remaining  = Manager::KIT()->getCooldownRemaining($this->player->getName(), $id);
 $statusLine = "\n§cNon Disponible §7(" . Manager::KIT()->formatCooldown($remaining) . ")";
 } else {
 $statusLine = "\n§cNon Disponible";
 }

 $btns[] = ["text" => "§6" . ($kit["name"] ?? $id) . $statusLine];
 }
 return ["type" => "form", "title" => "§6§lKITS", "content" => "§fChoisissez un kit :", "buttons" => $btns];
 }
 public function handleResponse(\pocketmine\player\Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) {
 $player->sendMessage("§cVous ne pouvez pas prendre un kit en combat !");
 return;
 }
 $kitId = (is_int($data) || is_float($data)) ? ($this->kitIds[(int)$data] ?? null) : null;
 if ($kitId === null) return;
 $kit = Manager::KIT()->getKit($kitId);
 if ($kit !== null && ($kit["permission"] ?? "") !== "" && !$player->hasPermission($kit["permission"])) {
 $player->sendMessage("§cVous n'avez pas la permission d'utiliser le kit §f" . ($kit["name"] ?? $kitId) . "§c !");
 return;
 }
 if (Manager::KIT()->hasCooldown($player->getName(), $kitId)) {
 $remaining = Manager::KIT()->getCooldownRemaining($player->getName(), $kitId);
 $player->sendMessage("§cCooldown : §f" . Manager::KIT()->formatCooldown($remaining));
 return;
 }
 $refused = Manager::KIT()->giveKit($player, $kitId);
 $player->sendMessage("§aKit §f" . ($kit["name"] ?? $kitId) . " §areçu !");
 if (!empty($refused)) $player->sendMessage("§7(Limite atteinte pour : §f" . implode(", ", $refused) . "§7)");
 }
 });
 }
}
