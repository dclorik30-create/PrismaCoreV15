<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;

class RepairAllCommand extends BaseCommand
{
 /** Permissions cooldown repairall (en secondes, null = aucun CD) */
 private const PERM_COOLDOWNS = [
  "prisma.repairall.unlimited" => null,
  "prisma.repairall.60"        => 60 * 60, // 1 heure
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("repairall", "Reparer tous les items de l'inventaire", [], [], ["prisma.command.repairall"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  // Trouver la meilleure permission
  $cooldown = 60 * 60; // défaut : 1h
  foreach (self::PERM_COOLDOWNS as $perm => $secs) {
   if ($sender->hasPermission($perm)) {
    if ($secs === null) { $cooldown = null; break; }
    if ($cooldown === null || $secs < $cooldown) $cooldown = $secs;
   }
  }

  $name = strtolower($sender->getName());
  $now  = time();

  if ($cooldown !== null && isset($this->cooldowns[$name])) {
   $remaining = $cooldown - ($now - $this->cooldowns[$name]);
   if ($remaining > 0) {
    $h = (int)floor($remaining / 3600);
    $m = (int)floor(($remaining % 3600) / 60);
    $s = $remaining % 60;
    $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
    $sender->sendMessage("§cRepairAll en cooldown : §f{$fmt} §crestant.");
    return;
   }
  }

  $inv   = $sender->getInventory();
  $armor = $sender->getArmorInventory();
  $repaired = 0;

  foreach ($inv->getContents() as $slot => $item) {
   if ($item instanceof Durable && $item->getDamage() > 0) {
    $item->setDamage(0); $inv->setItem($slot, $item); $repaired++;
   }
  }
  foreach ($armor->getContents() as $slot => $item) {
   if ($item instanceof Durable && $item->getDamage() > 0) {
    $item->setDamage(0); $armor->setItem($slot, $item); $repaired++;
   }
  }

  if ($repaired === 0) { $sender->sendMessage("§7Aucun item a reparer."); return; }
  if ($cooldown !== null) $this->cooldowns[$name] = $now;
  $sender->sendMessage("§a{$repaired} item(s) repare(s) !");
 }
}
