<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;

class RepairCommand extends BaseCommand
{
 /** Permissions cooldown repair (en secondes, null = aucun CD) */
 private const PERM_COOLDOWNS = [
  "prisma.repair.unlimited" => null,
  "prisma.repair.5"         => 5  * 60,  // 5 minutes
  "prisma.repair.30"        => 30 * 60,  // 30 minutes
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("repair", "Reparer l'item en main", [], [], ["prisma.command.repair"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  // Trouver la meilleure permission (CD le plus bas)
  $cooldown = 30 * 60; // défaut : 30 min si aucune perm spécifique
  foreach (self::PERM_COOLDOWNS as $perm => $secs) {
   if ($sender->hasPermission($perm)) {
    if ($secs === null) { $cooldown = null; break; }
    if ($cooldown === null || $secs < $cooldown) $cooldown = $secs;
   }
  }

  $name = strtolower($sender->getName());
  $now  = time();

  if ($cooldown !== null && isset($this->cooldowns[$name])) {
   $remaining = $cooldown - ($now - $this->cooldowns[$name]);
   if ($remaining > 0) {
    $m = (int)floor($remaining / 60);
    $s = $remaining % 60;
    $fmt = $m > 0 ? "{$m}m {$s}s" : "{$s}s";
    $sender->sendMessage("§cRepair en cooldown : §f{$fmt} §crestant.");
    return;
   }
  }

  $item = $sender->getInventory()->getItemInHand();
  if (!$item instanceof Durable) {
   $sender->sendMessage("§cCet item n'est pas reparable !");
   return;
  }
  if ($item->getDamage() === 0) {
   $sender->sendMessage("§cVotre item n'est pas endommage !");
   return;
  }

  $item->setDamage(0);
  $sender->getInventory()->setItemInHand($item);
  if ($cooldown !== null) $this->cooldowns[$name] = $now;
  $sender->sendMessage("§aItem repare !");
 }
}
