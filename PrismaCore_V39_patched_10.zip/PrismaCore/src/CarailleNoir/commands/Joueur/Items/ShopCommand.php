<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\item\VanillaItems;

class ShopCommand extends BaseCommand
{
 public function __construct() { parent::__construct("shop", "Ouvrir le shop", [], [], ["prisma.command.shop"]); }
 protected function prepare(): array { return [new RawStringArgument("action", true), new RawStringArgument("categorie", true)]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $action = strtolower((string)($args['action'] ?? ''));

 if ($action === 'add') {
 if (!\pocketmine\Server::getInstance()->isOp($sender->getName())) {
 $sender->sendMessage("§cCommande réservée aux OP.");
 return;
 }
 $catId = strtolower((string)($args['categorie'] ?? ''));
 if ($catId === '') {
 $sender->sendMessage("§cUtilisation: /shop add <catégorie>");
 return;
 }
 if (Manager::SHOP()->getCategory($catId) === null) {
 $sender->sendMessage("§cCatégorie inconnue.");
 return;
 }
 $item = clone $sender->getInventory()->getItemInHand();
 if ($item->isNull()) {
 $sender->sendMessage("§cVous devez tenir un item en main.");
 return;
 }
 if (!Manager::SHOP()->addItemToCategory($catId, $item, 0, 0)) {
 $sender->sendMessage("§cImpossible d'ajouter l'item.");
 return;
 }
 $sender->sendMessage("§aItem ajouté à §f{$catId}§a. Utilisez §f/shop edit {$catId}§a pour fixer les prix.");
 return;
 }

 if ($action === 'edit') {
 if (!\pocketmine\Server::getInstance()->isOp($sender->getName())) {
 $sender->sendMessage("§cCommande réservée aux OP.");
 return;
 }
 $catId = strtolower((string)($args['categorie'] ?? ''));
 if ($catId === '') {
 $sender->sendMessage("§cUtilisation: /shop edit <catégorie>");
 return;
 }
 if (Manager::SHOP()->getCategory($catId) === null) {
 $sender->sendMessage("§cCatégorie inconnue.");
 return;
 }
 self::openEditCategory($sender, $catId);
 return;
 }

 self::openCategories($sender);
 }

 public static function openCategories(PrismaPlayer $player): void
 {
 $menu = InvMenu::create(InvMenu::TYPE_CHEST);
 $menu->setName("§6Shop §7- §fCatégories");
 $inv = $menu->getInventory();
 $inv->clearAll();

 $cats = [
 10 => ['id' => 'pvp', 'item' => VanillaItems::DIAMOND_SWORD(), 'name' => '§cPVP'],
 12 => ['id' => 'farm', 'item' => VanillaItems::WHEAT(), 'name' => '§aFARM'],
 14 => ['id' => 'block', 'item' => \pocketmine\block\VanillaBlocks::GRASS()->asItem(), 'name' => '§6BLOCK'],
 16 => ['id' => 'mob', 'item' => VanillaItems::BONE(), 'name' => '§5MOB'],
 22 => ['id' => 'minage', 'item' => VanillaItems::IRON_PICKAXE(), 'name' => '§bMINAGE'],
 ];

 foreach ($cats as $slot => $data) {
 $item = clone $data['item'];
 $item->setCustomName($data['name']);
 $item->setLore(["§fOuvrir la catégorie"]);
 $inv->setItem($slot, $item);
 }

 $menu->setListener(function(InvMenuTransaction $tx) use ($cats): InvMenuTransactionResult {
 $player = $tx->getPlayer();
 if (!$player instanceof PrismaPlayer) return $tx->discard();
 $clicked = $tx->getItemClicked();
 foreach ($cats as $data) {
 if ($clicked->getCustomName() === $data['name']) {
 // InvMenu ferme sa fenêtre seul via discard — pas besoin de removeCurrentWindow()
 $player->removeCurrentWindow();
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $data): void {
 self::openCategory($player, $data['id']);
 }), 3);
 break;
 }
 }
 return $tx->discard();
 });
 $menu->send($player);
 }

 public static function openCategory(PrismaPlayer $player, string $catId): void
 {
 $items = Manager::SHOP()->getItemsByCategory($catId);
 $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§6Shop §7- §f" . strtoupper($catId));
 $inv = $menu->getInventory();
 $inv->clearAll();

 $slot = 0;
 $map = [];
 foreach ($items as $key => $entry) {
 if ($slot >= $inv->getSize()) break;
 $item = Manager::SHOP()->makeShopItem($entry['item_id'], $entry['name'], max(1, (int)($entry['amount'] ?? 1)), (string)($entry['item_data'] ?? ''));
 if ($item === null) {
 $item = VanillaItems::BARRIER()->setCustomName("§cItem invalide");
 }
 $lore = $item->getLore();
 $lore[] = "§fAchat : §a" . number_format((float)$entry['buy_price'], 2) . "§6$";
 $lore[] = "§fVente : §c" . number_format((float)$entry['sell_price'], 2) . "§6$";
 $item->setCustomName($entry['name']);
 $item->setLore($lore);
 $inv->setItem($slot, $item);
 $map[$slot] = $key;
 $slot++;
 }

 $menu->setListener(function(InvMenuTransaction $tx) use ($map, $catId): InvMenuTransactionResult {
 $player = $tx->getPlayer();
 if (!$player instanceof PrismaPlayer) return $tx->discard();
 $clicked = $tx->getItemClicked();
 foreach ($map as $shopKey) {
 foreach (Manager::SHOP()->getItemsByCategory($catId) as $key => $entry) {
 if ($key === $shopKey && $clicked->getCustomName() === $entry['name']) {
 // Fermeture naturelle par InvMenu + 3 ticks de délai avant d'envoyer le Form
 $player->removeCurrentWindow();
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $catId, $key): void {
 ShopCommand::openItem($player, $catId, $key);
 }), 3);
 break 2;
 }
 }
 }
 return $tx->discard();
 });
 $menu->send($player);
 }

 public static function openItem(PrismaPlayer $player, string $catId, string $itemId): void
 {
 $item = null;
 foreach (Manager::SHOP()->getItemsByCategory($catId) as $key => $entry) {
 if ($key === $itemId) {
 $item = $entry;
 break;
 }
 }
 if ($item === null) {
 $player->sendMessage("§cItem introuvable dans le shop.");
 self::openCategory($player, $catId);
 return;
 }

 $count = Manager::SHOP()->countItemInInventory($player, $item['item_id']);
 $player->sendForm(new class($catId, $itemId, $item, $count) implements Form {
 public function __construct(private string $catId, private string $itemId, private array $item, private int $count) {}

 public function jsonSerialize(): array {
 return [
 "type" => "custom_form",
 "title" => $this->item['name'],
 "content" => [
 [
 "type" => "label",
 "text" => "§fItem : §e{$this->item['name']}\n§fPrix achat : §a" . number_format((float) $this->item['buy_price'], 2) . "§6$\n§7Prix de vente§8: §c" . number_format((float) $this->item['sell_price'], 2) . "§6$\n§7Nombre d'items dans l'inventaire§8: §e{$this->count}"
 ],
 ["type" => "toggle", "text" => "§aMode achat §f(OFF = vente)", "default" => true],
 ["type" => "input", "text" => "§fNombre d'items", "placeholder" => "Ex: 64", "default" => "1"]
 ]
 ];
 }

 public function handleResponse(\pocketmine\player\Player $player, mixed $data): void {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 $buyMode = (bool) ($data[1] ?? true);
 $amount = max(1, (int) trim((string) ($data[2] ?? '1')));
 $entry = null;
 foreach (Manager::SHOP()->getItemsByCategory($this->catId) as $key => $shopEntry) {
 if ($key === $this->itemId) {
 $entry = $shopEntry;
 break;
 }
 }
 if ($entry === null) {
 $player->sendMessage("§cItem introuvable.");
 ShopCommand::openCategory($player, $this->catId);
 return;
 }

 if ($buyMode) {
 $unitPrice = (float) $entry['buy_price'];
 if ($unitPrice <= 0) {
 $player->sendMessage("§cCet item ne peut pas être acheté.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }

 $baseAmount = max(1, (int) ($entry['amount'] ?? 1));
 $totalPrice = $unitPrice * $amount;
 $give = Manager::SHOP()->makeShopItem($entry['item_id'], $entry['name'], $baseAmount * $amount, (string) ($entry['item_data'] ?? ''));
 if ($give === null) {
 $player->sendMessage("§cItem invalide.");
 ShopCommand::openCategory($player, $this->catId);
 return;
 }
 if (!$player->hasMoney($totalPrice)) {
 $player->sendMessage("§cPas assez d'argent.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 if (!$player->getInventory()->canAddItem($give)) {
 $player->sendMessage("§cPas assez de place dans l'inventaire.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $player->removeMoney($totalPrice);
 $player->getInventory()->addItem($give);
 $player->sendMessage("§aAchat effectué : §f" . $give->getCount() . "x " . $entry['name'] . " §apour §e" . number_format($totalPrice, 2) . "§6$");
 } else {
 $unitPrice = (float) $entry['sell_price'];
 if ($unitPrice <= 0) {
 $player->sendMessage("§cCet item ne peut pas être vendu.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $available = Manager::SHOP()->countItemInInventory($player, $entry['item_id']);
 if ($available < $amount) {
 $player->sendMessage("§cVous n'avez pas assez de cet item.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 if (!Manager::SHOP()->removeItemFromInventory($player, $entry['item_id'], $amount)) {
 $player->sendMessage("§cImpossible de retirer les items.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $totalPrice = $unitPrice * $amount;
 $player->addMoney($totalPrice);
 $player->sendMessage("§aVente effectuée : §f" . $amount . "x " . $entry['name'] . " §apour §e" . number_format($totalPrice, 2) . "§6$");
 }

 ShopCommand::openItem($player, $this->catId, $this->itemId);
 }
 });
 }

 // ─────────────────────────────────────────────────────────
 // EDIT MODE — modifier les prix achat/vente d'un item
 // ─────────────────────────────────────────────────────────

 /**
  * Ouvre un coffre listant tous les items d'une catégorie. Clic = ouvre le form d'edit.
  */
 public static function openEditCategory(PrismaPlayer $player, string $catId): void
 {
 $cat = Manager::SHOP()->getCategory($catId);
 if ($cat === null) {
 $player->sendMessage("§cCatégorie introuvable.");
 return;
 }
 $items = $cat["items"] ?? [];

 $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§6Edit §7- §f" . strtoupper($catId));
 $inv = $menu->getInventory();
 $inv->clearAll();

 // Mapping slot → index dans le tableau "items"
 $slotToIndex = [];
 $slot = 0;
 foreach ($items as $index => $entry) {
 if ($slot >= $inv->getSize()) break;
 $itemId   = (string)($entry["item"] ?? '');
 $itemData = (string)($entry["itemData"] ?? '');
 $name     = (string)($entry["name"] ?? $itemId);
 $amount   = max(1, (int)($entry["amount"] ?? 1));
 $buy      = (float)($entry["buy"] ?? 0);
 $sell     = (float)($entry["sell"] ?? 0);

 $item = Manager::SHOP()->makeShopItem($itemId, $name, $amount, $itemData);
 if ($item === null) $item = VanillaItems::BARRIER()->setCustomName("§cItem invalide");
 $item->setCustomName($name);

 $lore   = $item->getLore();
 $lore[] = "§r§7──────────────";
 $lore[] = "§r§aAchat: §f" . number_format($buy, 2) . "§6$";
 $lore[] = "§r§cVente: §f" . number_format($sell, 2) . "§6$";
 $lore[] = "§r§8Clic pour modifier";
 $item->setLore($lore);

 $inv->setItem($slot, $item);
 $slotToIndex[$slot] = $index;
 $slot++;
 }

 $menu->setListener(function(InvMenuTransaction $tx) use ($catId, $slotToIndex): InvMenuTransactionResult {
 $clicked = $tx->getAction()->getSlot();
 if (!isset($slotToIndex[$clicked])) return $tx->discard();
 $index = $slotToIndex[$clicked];
 $player = $tx->getPlayer();
 if (!$player instanceof PrismaPlayer) return $tx->discard();

 $player->removeCurrentWindow();
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $catId, $index): void {
 if (!$player->isConnected()) return;
 ShopCommand::openEditItem($player, $catId, $index);
 }), 3);
 return $tx->discard();
 });
 $menu->send($player);
 }

 /**
  * Form custom : edit buy/sell prices d'un item donné.
  */
 public static function openEditItem(PrismaPlayer $player, string $catId, int $index): void
 {
 $cat = Manager::SHOP()->getCategory($catId);
 if ($cat === null || !isset($cat["items"][$index])) {
 $player->sendMessage("§cItem introuvable.");
 self::openEditCategory($player, $catId);
 return;
 }
 $entry = $cat["items"][$index];
 $name  = (string)($entry["name"] ?? $entry["item"] ?? 'Item');
 $buy   = (float)($entry["buy"]  ?? 0);
 $sell  = (float)($entry["sell"] ?? 0);

 $player->sendForm(new class($catId, $index, $name, $buy, $sell) implements Form {
 public function __construct(
 private string $catId,
 private int $index,
 private string $name,
 private float $buy,
 private float $sell
 ) {}

 public function jsonSerialize(): array
 {
 $info = "§eItem: §f{$this->name}\n"
 . "§aAchat actuel: §f" . number_format($this->buy, 2) . "§6$\n"
 . "§cVente actuelle: §f" . number_format($this->sell, 2) . "§6$\n"
 . "§7Laisse vide pour ne pas modifier. Coche §fRetour§7 pour annuler.";

 return [
 "type"    => "custom_form",
 "title"   => "§6Edit §7- §f" . strtoupper($this->catId),
 "content" => [
 ["type" => "label", "text" => $info],
 [
 "type"        => "input",
 "text"        => "§aPrix d'achat (§6\$§a)",
 "placeholder" => "ex: 100 ou 12.5",
 "default"     => (string) number_format($this->buy, 2, '.', ''),
 ],
 [
 "type"        => "input",
 "text"        => "§cPrix de vente (§6\$§c)",
 "placeholder" => "ex: 50 ou 6.25",
 "default"     => (string) number_format($this->sell, 2, '.', ''),
 ],
 [
 "type"    => "toggle",
 "text"    => "§7Retour (annuler)",
 "default" => false,
 ],
 [
 "type"    => "toggle",
 "text"    => "§4§lSupprimer cet item de la catégorie",
 "default" => false,
 ],
 ],
 ];
 }

 public function handleResponse(\pocketmine\player\Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;

 $cancel = (bool)($data[3] ?? false);
 $delete = (bool)($data[4] ?? false);

 // Suppression demandée → prioritaire sur les autres actions
 if ($delete) {
 $ok = Manager::SHOP()->removeItem($this->catId, $this->index);
 if ($ok) {
 $player->sendMessage("§c✗ §f{$this->name} §csupprimé de la catégorie §f" . strtoupper($this->catId));
 } else {
 $player->sendMessage("§cImpossible de supprimer cet item.");
 }
 ShopCommand::reopenEditMenu($player, $this->catId);
 return;
 }

 if ($cancel) {
 ShopCommand::reopenEditMenu($player, $this->catId);
 return;
 }

 $rawBuy  = trim((string)($data[1] ?? ""));
 $rawSell = trim((string)($data[2] ?? ""));
 $rawBuy  = str_replace([",", "$", " "], [".", "", ""], $rawBuy);
 $rawSell = str_replace([",", "$", " "], [".", "", ""], $rawSell);

 $newBuy  = ($rawBuy  === "" || !is_numeric($rawBuy))  ? $this->buy  : max(0, (float)$rawBuy);
 $newSell = ($rawSell === "" || !is_numeric($rawSell)) ? $this->sell : max(0, (float)$rawSell);

 $ok = Manager::SHOP()->setItemPrices($this->catId, $this->index, $newBuy, $newSell);
 if (!$ok) {
 $player->sendMessage("§cImpossible de modifier cet item.");
 ShopCommand::reopenEditMenu($player, $this->catId);
 return;
 }

 $player->sendMessage(
 "§a✔ §f{$this->name}§a — §aAchat: §f" . number_format($newBuy, 2) . "§6$"
 . "§a, §cVente: §f" . number_format($newSell, 2) . "§6$"
 );

 ShopCommand::reopenEditMenu($player, $this->catId);
 }
 });
 }

 /**
  * Réouvre le menu d'edit catégorie au tick suivant.
  */
 public static function reopenEditMenu(PrismaPlayer $player, string $catId): void
 {
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $catId): void {
 if (!$player->isConnected()) return;
 ShopCommand::openEditCategory($player, $catId);
 }), 5);
 }
}
