<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\invmenu\DailyMenu;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class DailyCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct('daily', 'Menu daily', [], [], ['prisma.command.daily']);
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument('action', true),
            new RawStringArgument('value1', true),
            new RawStringArgument('value2', true)
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $sub = strtolower((string)($args['action'] ?? ''));

        if ($sub === 'add') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.');
                return;
            }
            $day = (int)($args['value1'] ?? 0);
            if ($day < 1 || $day > Manager::DAILY()->getTotalDays()) {
                $sender->sendMessage('§cJour invalide.');
                return;
            }
            $item = clone $sender->getInventory()->getItemInHand();
            if ($item->isNull()) {
                $sender->sendMessage('§cTenez l\'item à enregistrer en main.');
                return;
            }
            Manager::DAILY()->setReward($day, $item);
            $sender->sendMessage('§aRécompense du jour ' . $day . ' enregistrée : §f' . ($item->getCustomName() !== '' ? $item->getCustomName() : $item->getName()) . ' §7x' . $item->getCount());
            return;
        }

        if ($sub === 'remove') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.');
                return;
            }
            $day = (int)($args['value1'] ?? 0);
            if ($day < 1 || $day > Manager::DAILY()->getTotalDays()) {
                $sender->sendMessage('§cJour invalide.');
                return;
            }
            Manager::DAILY()->removeReward($day);
            $sender->sendMessage('§aRécompense du jour ' . $day . ' supprimée.');
            return;
        }

        if ($sub === 'advance') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.');
                return;
            }
            $targetName = trim((string)($args['value1'] ?? ''));
            $amount = max(1, (int)($args['value2'] ?? 1));
            if ($targetName === '') {
                $sender->sendMessage('§cUsage : /daily advance <player> [amount]');
                return;
            }
            $state = Manager::DAILY()->advanceDay($targetName, $amount);
            $sender->sendMessage('§a' . $targetName . ' avancé au jour ' . (int)$state['day'] . '.');
            return;
        }

        DailyMenu::send($sender);
    }
}
