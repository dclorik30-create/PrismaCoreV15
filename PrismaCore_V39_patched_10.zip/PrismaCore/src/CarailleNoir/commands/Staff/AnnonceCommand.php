<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class AnnonceCommand extends BaseCommand
{
 private const PERM_COOLDOWNS = [
  "prisma.annonce.unlimited" => null,
  "prisma.annonce.1h"        => 3600,
  "prisma.annonce.6h"        => 6 * 3600,
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("annonce", "Envoyer une annonce globale", [], [], ["prisma.command.annonce"]);
 }

 protected function prepare(): array
 {
  return [new TextArgument("message", false)];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $message = trim((string)($args["message"] ?? ""));
  if ($message === "") {
   $sender->sendMessage("§cUsage : §f/annonce <message>");
   return;
  }

  // Trouver la meilleure permission (CD le plus bas)
  $cooldown = 6 * 3600; // défaut : 6h si aucune perm spécifique
  foreach (self::PERM_COOLDOWNS as $perm => $secs) {
   if ($sender->hasPermission($perm)) {
    if ($secs === null) { $cooldown = null; break; }
    if ($cooldown === null || $secs < $cooldown) $cooldown = $secs;
   }
  }

  $name = $sender instanceof Player ? $sender->getName() : "Console";
  $key  = strtolower($name);
  $now  = time();

  if ($cooldown !== null && isset($this->cooldowns[$key])) {
   $remaining = $cooldown - ($now - $this->cooldowns[$key]);
   if ($remaining > 0) {
    $h = (int)floor($remaining / 3600);
    $m = (int)floor(($remaining % 3600) / 60);
    $s = $remaining % 60;
    $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
    $sender->sendMessage("§cAnnonce en cooldown : §f{$fmt} §crestant.");
    return;
   }
  }

  $line = "§8-------------------------------------";
  $body = "§8[§6Prisma§8] §e" . $name . " §f: §6" . $message;

  foreach (Server::getInstance()->getOnlinePlayers() as $player) {
   $player->sendMessage($line);
   $player->sendMessage($body);
   $player->sendMessage($line);
  }

  if ($cooldown !== null) $this->cooldowns[$key] = $now;
 }
}
