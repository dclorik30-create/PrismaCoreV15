<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class MuteCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("mute", "Rendre un joueur muet", [], [], ["prisma.command.mute"]);
 }

 protected function prepare(): array
 {
  return [
   new TargetPlayerArgument(false, "joueur"),
   new RawStringArgument("duree", true),
   new RawStringArgument("raison", true),
  ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  $duree      = $args["duree"]  ?? "permanent";
  $raison     = $args["raison"] ?? "Aucune raison donnee";

  if ($targetName === null) {
   $sender->sendMessage("§cUsage : /mute <joueur> [duree] [raison]");
   return;
  }

  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  if ($target === null) {
   $sender->sendMessage("§cJoueur introuvable ou hors ligne.");
   return;
  }

  $staffName = $sender instanceof PrismaPlayer ? $sender->getName() : "Console";

  // Convertir la durée (ex: 10m, 2h, 1d, permanent) en secondes
  $seconds = null;
  if ($duree !== "permanent" && $duree !== "perm") {
   preg_match('/^(\d+)(s|m|h|d)$/', strtolower($duree), $matches);
   if (!empty($matches)) {
    $mult = ["s" => 1, "m" => 60, "h" => 3600, "d" => 86400][$matches[2]];
    $seconds = (int)$matches[1] * $mult;
   } else {
    $sender->sendMessage("§cDurée invalide. Formats : 10s, 5m, 2h, 1d, permanent");
    return;
   }
  }

  Manager::MUTE()->addMute($target->getName(), $raison, $staffName, $seconds);
  $target->sendMessage("§cVous avez ete mute par §f" . $staffName . "§c pour §f" . $duree . "§c : §e" . $raison);
  $sender->sendMessage("§a" . $target->getName() . " a ete mute (" . $duree . ") : " . $raison);
 }
}
