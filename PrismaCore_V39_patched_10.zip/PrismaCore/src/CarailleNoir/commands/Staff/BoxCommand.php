<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\player\Player;

class BoxCommand extends BaseCommand
{
    private static array $VALID_BOXES = ["vote", "noble", "heros", "dieu", "boutique"];

    public function __construct()
    {
        parent::__construct("box", "Gérer les récompenses des boîtes", [], [], ["prisma.command.box"]);
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument("action", false),
            new RawStringArgument("boxtype", true),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCommande joueur uniquement.");
            return;
        }

        $action  = strtolower($args["action"] ?? "");
        $boxType = strtolower($args["boxtype"] ?? "");

        if (!in_array($action, ["add", "pourc"], true)) {
            $sender->sendMessage("§eUsage : §f/box <add|pourc> <Vote|Noble|Heros|Dieu|Boutique>");
            return;
        }

        if (!in_array($boxType, self::$VALID_BOXES, true)) {
            $sender->sendMessage("§cBoîte invalide ! Valeurs : §f" . implode(", ", self::$VALID_BOXES));
            return;
        }

        $box = Manager::BOX()->getBox($boxType);
        if ($box === null) {
            $sender->sendMessage("§cBoîte '§f{$boxType}§c' introuvable dans boxes.json.");
            return;
        }

        if ($action === "add") {
            $this->openAddMenu($sender, $boxType, $box);
        } else {
            self::openPourcMenu($sender, $boxType);
        }
    }

    /**
     * Mode "add" — édition libre du contenu de la box (déposer/retirer des items).
     */
    private function openAddMenu(Player $sender, string $boxType, array $box): void
    {
        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§6Box §f{$boxType} §8— §7Modifie puis ferme");

        $inv = $menu->getInventory();
        $slot = 0;
        foreach ($box["loots"] as $loot) {
            if ($slot >= 27) break;
            $item = Manager::BOX()->makeLootItem($loot);
            if ($item !== null && !$item->isNull()) {
                $inv->setItem($slot, $item);
                $slot++;
            }
        }

        $menu->setListener(function (InvMenuTransaction $tx): InvMenuTransactionResult {
            return $tx->continue();
        });

        $menu->setInventoryCloseListener(
            function (Player $player, \pocketmine\inventory\Inventory $inv) use ($boxType): void {
                $items = [];
                foreach ($inv->getContents() as $item) {
                    if (!$item->isNull()) $items[] = $item;
                }

                if (count($items) === 0) {
                    $player->sendMessage("§cInventaire vide — la boîte §f{$boxType}§c n'a pas été modifiée.");
                    return;
                }

                Manager::BOX()->setLootsFromItems($boxType, $items);

                $player->sendMessage(
                    "§a✔ Boîte §f{$boxType}§a mise à jour avec §e" . count($items) . " loot(s)§a."
                    . "\n§7Édite §fboxes.json §7ou utilise §f/box pourc {$boxType} §7pour ajuster les chances."
                );
            }
        );

        $menu->send($sender);
    }

    /**
     * Mode "pourc" — clic sur un item ouvre un form pour modifier sa chance %.
     * Public static pour pouvoir être rappelée par BoxChanceForm après modification.
     */
    public static function openPourcMenu(Player $sender, string $boxType): void
    {
        $box = Manager::BOX()->getBox($boxType);
        if ($box === null) {
            $sender->sendMessage("§cBoîte '§f{$boxType}§c' introuvable.");
            return;
        }

        $loots = $box["loots"] ?? [];
        if (empty($loots)) {
            $sender->sendMessage("§cLa boîte §f{$boxType}§c ne contient aucun loot.");
            return;
        }

        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§6Box §f{$boxType} §8— §7Clic = modifier %");

        // Mapping slot → index de loot
        $inv = $menu->getInventory();
        $slotToLootIndex = [];
        $slot = 0;
        $totalChance = 0;
        foreach ($loots as $i => $loot) {
            $totalChance += (int)($loot["chance"] ?? 0);
        }

        foreach ($loots as $i => $loot) {
            if ($slot >= 27) break;
            $item = Manager::BOX()->makeLootItem($loot);
            if ($item === null || $item->isNull()) continue;

            // Ajouter le pourcentage actuel dans le lore pour visibilité
            $chance  = (int)($loot["chance"] ?? 0);
            $percent = $chance / 100; // 4000 = 40.00%
            $lore    = $item->getLore();
            $lore[]  = "§r§7──────────────";
            $lore[]  = "§r§eChance actuelle: §f" . number_format($percent, 2) . "%";
            $lore[]  = "§r§7Brut: §f{$chance}§7/10000";
            $lore[]  = "§r§8Clic pour modifier";
            $item->setLore($lore);

            $inv->setItem($slot, $item);
            $slotToLootIndex[$slot] = $i;
            $slot++;
        }

        $menu->setListener(function (InvMenuTransaction $tx) use ($boxType, $slotToLootIndex, $totalChance): InvMenuTransactionResult {
            $clickedSlot = $tx->getAction()->getSlot();
            if (!isset($slotToLootIndex[$clickedSlot])) return $tx->discard();

            $lootIndex = $slotToLootIndex[$clickedSlot];
            $box       = Manager::BOX()->getBox($boxType);
            if ($box === null) return $tx->discard();
            $loot = $box["loots"][$lootIndex] ?? null;
            if ($loot === null) return $tx->discard();

            $player = $tx->getPlayer();
            $player->removeCurrentWindow();

            // Différer l'envoi du form au tick suivant pour laisser le client fermer la fenêtre proprement
            $sched = \CarailleNoir\Core::getInstance()->getScheduler();
            $sched->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(
                function () use ($player, $boxType, $lootIndex, $loot, $totalChance): void {
                    if (!$player->isConnected()) return;
                    $player->sendForm(new BoxChanceForm($boxType, $lootIndex, $loot, $totalChance));
                }
            ), 2);

            return $tx->discard();
        });

        $menu->send($sender);
    }
}

/**
 * Form custom pour modifier la chance d'un loot.
 */
class BoxChanceForm implements Form
{
    public function __construct(
        private string $boxType,
        private int $lootIndex,
        private array $loot,
        private int $totalChance
    ) {}

    public function jsonSerialize(): array
    {
        $name        = $this->loot["display"] ?? ($this->loot["item"] ?? "Loot #{$this->lootIndex}");
        $chance      = (int)($this->loot["chance"] ?? 0);
        $percent     = $chance / 100;
        $totalPct    = $this->totalChance / 100;
        $infoLines = "§eLoot: §f{$name}\n"
            . "§eChance actuelle: §f" . number_format($percent, 2) . "% §7({$chance}/10000)\n"
            . "§eTotal box: §f" . number_format($totalPct, 2) . "% §7({$this->totalChance}/10000)\n"
            . "§7Entre une nouvelle valeur en pourcentage (0-100), ou coche §fRetour§7 pour annuler.";

        return [
            "type"    => "custom_form",
            "title"   => "§6Box §f{$this->boxType} §8— §7Loot #{$this->lootIndex}",
            "content" => [
                ["type" => "label", "text" => $infoLines],
                [
                    "type"        => "input",
                    "text"        => "§eNouveau pourcentage (%)",
                    "placeholder" => "ex: 40 ou 12.5",
                    "default"     => (string) number_format($percent, 2),
                ],
                [
                    "type"    => "toggle",
                    "text"    => "§7Retour (annuler la modification)",
                    "default" => false,
                ],
            ],
        ];
    }

    public function handleResponse(\pocketmine\player\Player $player, mixed $data): void
    {
        // X / fermeture sans soumettre → ne rien faire (pas de réouverture)
        if ($data === null) return;

        $cancel = (bool)($data[2] ?? false);
        if ($cancel) {
            // Toggle Retour coché → réouvrir le menu sans modifier
            self::reopenMenu($player, $this->boxType);
            return;
        }

        $raw = trim((string)($data[1] ?? ""));
        $raw = str_replace([",", "%", " "], [".", "", ""], $raw);

        if ($raw === "" || !is_numeric($raw)) {
            $player->sendMessage("§cValeur invalide : §f{$raw}");
            self::reopenMenu($player, $this->boxType);
            return;
        }

        $pct = (float)$raw;
        if ($pct < 0)   $pct = 0;
        if ($pct > 100) $pct = 100;

        $newChance = (int) round($pct * 100); // % → /10000
        $ok = Manager::BOX()->setLootChance($this->boxType, $this->lootIndex, $newChance);
        if (!$ok) {
            $player->sendMessage("§cImpossible de modifier ce loot (introuvable).");
            return;
        }

        $name = $this->loot["display"] ?? ($this->loot["item"] ?? "Loot");
        $player->sendMessage(
            "§a✔ Box §f{$this->boxType}§a — §f{$name} §a→ §e" . number_format($pct, 2) . "% §7({$newChance}/10000)"
        );

        // Réouvrir le menu
        self::reopenMenu($player, $this->boxType);
    }

    /**
     * Réouvre le menu pourc au prochain tick (pour laisser le client traiter le form).
     */
    private static function reopenMenu(\pocketmine\player\Player $player, string $boxType): void
    {
        $sched = \CarailleNoir\Core::getInstance()->getScheduler();
        $sched->scheduleDelayedTask(new \pocketmine\scheduler\ClosureTask(
            function () use ($player, $boxType): void {
                if (!$player->isConnected()) return;
                BoxCommand::openPourcMenu($player, $boxType);
            }
        ), 5);
    }
}
