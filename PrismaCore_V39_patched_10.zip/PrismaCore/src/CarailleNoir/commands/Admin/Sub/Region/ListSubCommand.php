<?php

namespace CarailleNoir\commands\Admin\Sub\Region;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class ListSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("list", "Liste des regions", [], ["prisma.command.region"]);
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 $list = Manager::REGION()->getRegions();
 $msg = "- Liste des régions -\n";
 foreach ($list as $id) {
 $msg .= " - $id\n";
 }
 $sender->sendMessage($msg);
 }
}