<?php

namespace CarailleNoir\commands\Admin\Sub\Region;

use CarailleNoir\form\RegionForm;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class EditSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("edit", "Edit une regions", [], ["prisma.command.region"]);
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 $sender->sendForm(RegionForm::listMenu());
 }
}