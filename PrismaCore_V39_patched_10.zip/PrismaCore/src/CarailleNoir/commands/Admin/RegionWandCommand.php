<?php

namespace CarailleNoir\commands\Admin;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;

class RegionWandCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("regionwand", "", [

 ]);
  $this->setPermission("prisma.command.regionwand");
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $sender->getInventory()->addItem(
 VanillaItems::WOODEN_AXE()
 ->setCustomName("§bRegion Wand")
 ->setLore(["§7Clique gauche = Pos1", "§7Clique droit = Pos2"])
 );
 }

}
