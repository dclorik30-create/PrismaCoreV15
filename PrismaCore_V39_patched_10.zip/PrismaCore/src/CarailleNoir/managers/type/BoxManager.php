<?php

declare(strict_types=1);

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\PrismaItems\items\key\DieuKey;
use CarailleNoir\PrismaItems\items\key\BoutiqueKey;
use CarailleNoir\PrismaItems\items\key\HerosKey;
use CarailleNoir\PrismaItems\items\key\NobleKey;
use CarailleNoir\PrismaItems\items\key\VoteKey;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;

class BoxManager
{
    /** @var array<string, array> */
    private array $boxes = [];

    /**
     * Clés en attente pour les joueurs hors-ligne au moment de la victoire.
     * Structure : ['playerNameLower' => ['noble', 'dieu', ...]]
     * @var array<string, list<string>>
     */
    private array $pendingKeys = [];
    private string $pendingKeysFile = '';

    private static array $defaultBoxes = [
        "vote" => ["name" => "§aBoîte Vote", "color" => "§a", "loots" => [
            ["item" => "gold_ingot", "amount" => 16, "chance" => 4000, "display" => "§6Lingot d'Or x16"],
            ["item" => "diamond", "amount" => 4, "chance" => 2500, "display" => "§bDiamant x4"],
            ["item" => "emerald", "amount" => 8, "chance" => 2000, "display" => "§2Emeraude x8"],
            ["item" => "iron_ingot", "amount" => 32, "chance" => 1500, "display" => "§7Lingot de Fer x32"]
        ]],
        "noble" => ["name" => "§9Boîte Noble", "color" => "§9", "loots" => [
            ["item" => "diamond", "amount" => 8, "chance" => 3500, "display" => "§bDiamant x8"],
            ["item" => "gold_ingot", "amount" => 32, "chance" => 3000, "display" => "§6Lingot d'Or x32"],
            ["item" => "emerald", "amount" => 16, "chance" => 2500, "display" => "§2Emeraude x16"],
            ["item" => "iron_block", "amount" => 4, "chance" => 1000, "display" => "§7Bloc de Fer x4"]
        ]],
        "heros" => ["name" => "§cBoîte Héros", "color" => "§c", "loots" => [
            ["item" => "diamond_block", "amount" => 2, "chance" => 3000, "display" => "§bBloc de Diamant x2"],
            ["item" => "diamond", "amount" => 16, "chance" => 3000, "display" => "§bDiamant x16"],
            ["item" => "emerald", "amount" => 32, "chance" => 2500, "display" => "§2Emeraude x32"],
            ["item" => "gold_block", "amount" => 4, "chance" => 1500, "display" => "§6Bloc d'Or x4"]
        ]],
        "dieu" => ["name" => "§6Boîte Dieu", "color" => "§6", "loots" => [
            ["item" => "diamond_block", "amount" => 4, "chance" => 3000, "display" => "§bBloc de Diamant x4"],
            ["item" => "netherite_ingot","amount" => 2, "chance" => 2500, "display" => "§8Netherite x2"],
            ["item" => "emerald_block", "amount" => 4, "chance" => 2500, "display" => "§2Bloc d'Emeraude x4"],
            ["item" => "gold_block", "amount" => 8, "chance" => 2000, "display" => "§6Bloc d'Or x8"]
        ]],
        "boutique" => ["name" => "§5Boîte Boutique", "color" => "§5", "loots" => [
            ["item" => "diamond_block", "amount" => 2, "chance" => 3000, "display" => "§bBloc de Diamant x2"],
            ["item" => "emerald_block", "amount" => 2, "chance" => 3000, "display" => "§2Bloc d'Emeraude x2"],
            ["item" => "gold_block",    "amount" => 4, "chance" => 2500, "display" => "§6Bloc d'Or x4"],
            ["item" => "netherite_ingot","amount" => 1, "chance" => 1500, "display" => "§8Netherite x1"]
        ]]
    ];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "boxes.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode(self::$defaultBoxes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
        $content = file_get_contents($path);
        $this->boxes = json_decode($content, true) ?? self::$defaultBoxes;

        $this->pendingKeysFile = Core::getInstance()->getDataFolder() . "pending_keys.json";
        if (file_exists($this->pendingKeysFile)) {
            $this->pendingKeys = json_decode(file_get_contents($this->pendingKeysFile), true) ?? [];
        }
    }

    /**
     * Enregistre une clé à donner au joueur lors de sa prochaine connexion.
     * Appelé quand le joueur est hors-ligne au moment de la victoire.
     */
    public function addPendingKey(string $playerName, string $boxId): void
    {
        $key = strtolower($playerName);
        $this->pendingKeys[$key][] = $boxId;
        file_put_contents($this->pendingKeysFile, json_encode($this->pendingKeys, JSON_PRETTY_PRINT));
        Core::getInstance()->getLogger()->info("[BoxManager] Clé '{$boxId}' mise en attente pour '{$playerName}' (hors-ligne au moment de la victoire).");
    }

    /**
     * Distribue les clés en attente au joueur qui vient de se connecter.
     * Appeler depuis PlayerListener::onJoin().
     */
    public function deliverPendingKeys(Player $player): void
    {
        $key = strtolower($player->getName());
        if (empty($this->pendingKeys[$key])) return;

        foreach ($this->pendingKeys[$key] as $boxId) {
            $item = $this->makeKeyItem($boxId);
            if ($item !== null) {
                $player->getInventory()->addItem($item);
                $player->sendMessage("\u00a76[Event] \u00a7fTu avais remporté le TOTEM alors que tu étais hors-ligne. Ta clé \u00a7e" . strtoupper($boxId) . "\u00a7f t'a été remise !");
                Core::getInstance()->getLogger()->info("[BoxManager] Clé '{$boxId}' remise à '{$player->getName()}' au login.");
            }
        }

        unset($this->pendingKeys[$key]);
        file_put_contents($this->pendingKeysFile, json_encode($this->pendingKeys, JSON_PRETTY_PRINT));
    }

    public function save(): void
    {
        $path = Core::getInstance()->getDataFolder() . "boxes.json";
        file_put_contents($path, json_encode($this->boxes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    public function getBox(string $id): ?array
    {
        return $this->boxes[strtolower($id)] ?? null;
    }

    public function getBoxes(): array
    {
        return $this->boxes;
    }

    public function rollLoot(string $boxId): ?array
    {
        $box = $this->getBox($boxId);
        if ($box === null) return null;

        $rand = mt_rand(1, 10000);
        $cumul = 0;
        foreach ($box["loots"] as $loot) {
            $cumul += $loot["chance"];
            if ($rand <= $cumul) return $loot;
        }
        return $box["loots"][array_key_last($box["loots"])] ?? null;
    }

    public function makeKeyItem(string $boxId): ?Item
    {
        $boxId = strtolower($boxId);
        return match ($boxId) {
            'vote' => new VoteKey(),
            'noble' => new NobleKey(),
            'heros' => new HerosKey(),
            'dieu' => new DieuKey(),
            'boutique' => new BoutiqueKey(),
            default => null,
        };
    }

    public function isKey(Item $item, string $boxId): bool
    {
        $id = $this->getKeyBoxId($item);
        return $id !== null && strtolower($id) === strtolower($boxId);
    }

    public function getKeyBoxId(Item $item): ?string
    {
        foreach ($item->getLore() as $line) {
            if (str_contains($line, 'item_key_boutique')) return 'boutique'; // avant vote/noble pour éviter faux positifs
            if (str_contains($line, 'item_key_vote'))     return 'vote';
            if (str_contains($line, 'item_key_noble'))    return 'noble';
            if (str_contains($line, 'item_key_heros'))    return 'heros';
            if (str_contains($line, 'item_key_dieu'))     return 'dieu';
        }
        return null;
    }

    // ── Sérialisation NBT complète ─────────────────────────

    public function itemToNbt(Item $item): string
    {
        try {
            return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())));
        } catch (\Throwable) {
            return "";
        }
    }

    public function itemFromNbt(string $data): ?Item
    {
        try {
            $raw = base64_decode($data, true);
            if ($raw === false || $raw === "") return null;
            $tag = (new BigEndianNbtSerializer())->read($raw)->mustGetCompoundTag();
            return Item::nbtDeserialize($tag);
        } catch (\Throwable) {
            return null;
        }
    }

    public function makeLootItem(array $loot): ?Item
    {
        if (!empty($loot["nbt"])) {
            $item = $this->itemFromNbt($loot["nbt"]);
            if ($item !== null) {
                $item->setCount(max(1, (int)($loot["amount"] ?? 1)));
                return $item;
            }
        }
        $parsed = StringToItemParser::getInstance()->parse($loot["item"] ?? "");
        if ($parsed === null) return null;
        $parsed->setCount(max(1, (int)($loot["amount"] ?? 1)));
        return $parsed;
    }

    public function addLootsFromItems(string $boxId, array $items): void
    {
        $boxId = strtolower($boxId);
        if (!isset($this->boxes[$boxId])) return;
        foreach ($items as $item) {
            if ($item->isNull()) continue;
            $nbt  = $this->itemToNbt($item);
            $name = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
            $this->boxes[$boxId]["loots"][] = [
                "item"    => "air",
                "nbt"     => $nbt,
                "amount"  => $item->getCount(),
                "chance"  => 0,
                "display" => "§f{$name} x" . $item->getCount(),
            ];
        }
        $this->save();
    }

    /**
     * Remplace TOUS les loots d'une box par les items fournis.
     * Conserve les chance des anciens loots par index (pour ne pas perdre le paramétrage).
     * Les nouveaux loots au-delà de l'ancienne liste auront chance = 0.
     */
    public function setLootsFromItems(string $boxId, array $items): void
    {
        $boxId = strtolower($boxId);
        if (!isset($this->boxes[$boxId])) return;

        $oldLoots = $this->boxes[$boxId]["loots"] ?? [];
        $newLoots = [];
        $idx      = 0;

        foreach ($items as $item) {
            if ($item->isNull()) continue;
            $nbt      = $this->itemToNbt($item);
            $name     = $item->hasCustomName() ? $item->getCustomName() : $item->getName();
            // Conserver la chance de l'ancien loot au même index si elle existe
            $oldChance = (int)($oldLoots[$idx]["chance"] ?? 0);
            $newLoots[] = [
                "item"    => "air",
                "nbt"     => $nbt,
                "amount"  => $item->getCount(),
                "chance"  => $oldChance,
                "display" => "§f{$name} x" . $item->getCount(),
            ];
            $idx++;
        }

        // Auto-distribuer les chances équitablement si elles sont toutes à 0
        $totalChance = array_sum(array_column($newLoots, 'chance'));
        if ($totalChance === 0 && count($newLoots) > 0) {
            $base  = intdiv(10000, count($newLoots));
            $resto = 10000 - ($base * count($newLoots));
            foreach ($newLoots as $i => $l) {
                $newLoots[$i]['chance'] = $base + ($i === 0 ? $resto : 0);
            }
        }

        $this->boxes[$boxId]["loots"] = $newLoots;
        $this->save();
    }

    /**
     * Modifie la chance d'un loot unique dans une box.
     * @param int $newChance valeur sur 10000 (ex: 4000 = 40%)
     * @return bool true si modification appliquée, false sinon
     */
    public function setLootChance(string $boxId, int $lootIndex, int $newChance): bool
    {
        $boxId = strtolower($boxId);
        if (!isset($this->boxes[$boxId]["loots"][$lootIndex])) return false;
        if ($newChance < 0) $newChance = 0;
        if ($newChance > 10000) $newChance = 10000;
        $this->boxes[$boxId]["loots"][$lootIndex]["chance"] = $newChance;
        $this->save();
        return true;
    }

}
