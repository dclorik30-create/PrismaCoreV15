<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use CarailleNoir\Core;
use CarailleNoir\PrismaItems\items\key\VoteKey;
use CarailleNoir\tasks\VoteCheckTask;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;

class VoteManager
{
    public const API_KEY   = "7Q8zxDPzM69XMmPj7yAQQsww9tGgPjg4lN6";
    public const MAX_VOTES = 50;
    public const GRADE_DURATION = 86400; // 24 heures en secondes

    private static int    $currentVotes = 0;
    private static string $dataFile;
    private static string $gradeFile;

    /**
     * Map playerNameLower => timestamp d'expiration du grade Vote
     * @var array<string, int>
     */
    private static array $gradeExpiry = [];

    /**
     * Map playerNameLower => timestamp du dernier vote réussi
     * @var array<string, int>
     */
    private static array $lastVote = [];

    public static function init(): void
    {
        self::$dataFile  = Core::getInstance()->getDataFolder() . "vote_data.json";
        self::$gradeFile = Core::getInstance()->getDataFolder() . "vote_grade_expiry.json";

        if (!file_exists(self::$dataFile)) {
            file_put_contents(self::$dataFile, json_encode(["votes" => 0]));
        }
        $data = json_decode(file_get_contents(self::$dataFile), true);
        self::$currentVotes = $data["votes"] ?? 0;

        // Charger les expirations de grade
        if (file_exists(self::$gradeFile)) {
            $gradeData = json_decode(file_get_contents(self::$gradeFile), true) ?? [];
            self::$gradeExpiry = $gradeData["expiry"] ?? $gradeData;
            self::$lastVote    = $gradeData["lastVote"] ?? [];
        }
    }

    public static function save(): void
    {
        file_put_contents(self::$dataFile, json_encode(["votes" => self::$currentVotes]));
    }

    private static function saveGradeExpiry(): void
    {
        file_put_contents(self::$gradeFile, json_encode([
            "expiry"   => self::$gradeExpiry,
            "lastVote" => self::$lastVote,
        ], JSON_PRETTY_PRINT));
    }

    public static function getCurrentVotes(): int
    {
        return self::$currentVotes;
    }

    public static function checkVote(Player $player): void
    {
        Server::getInstance()->getAsyncPool()->submitTask(
            new VoteCheckTask($player->getName(), self::API_KEY)
        );
    }

    public static function hasVotedToday(string $playerName): bool
    {
        $key = strtolower($playerName);
        if (!isset(self::$lastVote[$key])) return false;
        $last = self::$lastVote[$key];
        // Même jour calendaire (minuit reset)
        return date("Y-m-d", $last) === date("Y-m-d", time());
    }

    public static function onVoteSuccess(Player $player): void
    {
        $key = strtolower($player->getName());

        // Bloquer si déjà voté aujourd'hui
        if (self::hasVotedToday($player->getName())) {
            $next = strtotime("tomorrow midnight");
            $diff = $next - time();
            $h    = floor($diff / 3600);
            $m    = floor(($diff % 3600) / 60);
            $player->sendMessage("§c[Vote] §fTu as déjà voté aujourd'hui ! Reviens dans §e{$h}h{$m}m§f.");
            return;
        }

        // Enregistrer le vote
        self::$lastVote[$key] = time();
        self::saveGradeExpiry();
        // ── Donner la clé Vote (instanciation directe, fiable) ────────────────
        self::giveVoteKey($player, 1);

        $player->sendMessage("§a[Vote] Merci d'avoir voté ! Tu reçois une §6Clé Vote§a.");

        // ── Grade Vote : uniquement si le joueur a le grade Joueur ────────────
        if ($player instanceof \CarailleNoir\player\PrismaPlayer) {
            $gradeId = null;
            if (Manager::GRADE()->existGrade("Vote")) {
                $gradeId = "Vote";
            } elseif (Manager::GRADE()->existGrade("vote")) {
                $gradeId = "vote";
            }

            if ($gradeId !== null) {
                $key           = strtolower($player->getName());
                $alreadyHas    = isset(self::$gradeExpiry[$key]) && self::$gradeExpiry[$key] > time();
                $gradeData     = Manager::GRADE()->getPlayerGradeData($player->getName());
                $currentGrade  = strtolower($gradeData["id"] ?? "joueur");
                $isJoueur      = ($currentGrade === "joueur" || $currentGrade === "");

                // Renouveler le timer 24h dans tous les cas
                self::$gradeExpiry[$key] = time() + self::GRADE_DURATION;
                self::saveGradeExpiry();

                if ($isJoueur) {
                    if (!$alreadyHas) {
                        // Grade Joueur → donner le grade Vote pour 24h
                        Manager::GRADE()->addGrade($player, $gradeId, $player->getName());
                        $player->sendMessage("§6[Vote] §fTu as reçu le grade §6Vote §fpour §e24 heures §f!");
                    } else {
                        // Déjà grade Vote → renouveler
                        $player->sendMessage("§6[Vote] §fTon grade Vote a été renouvelé pour §e24 heures §f!");
                    }
                } else {
                    // Grade supérieur à Joueur → pas de changement de grade
                    $player->sendMessage("§6[Vote] §fTu as déjà un grade (§e{$currentGrade}§f), ton grade est conservé.");
                }
            }
        }

        self::$currentVotes++;
        self::save();
        Server::getInstance()->broadcastMessage("§6[VoteParty] §f" . self::$currentVotes . "/" . self::MAX_VOTES . " votes !");

        if (self::$currentVotes >= self::MAX_VOTES) {
            self::triggerVoteParty();
        }
    }

    /**
     * Vérifie et expire les grades Vote périmés.
     * Appelé depuis PlaytimeTask (toutes les 60s).
     */
    public static function tickGradeExpiry(): void
    {
        $now     = time();
        $changed = false;

        foreach (self::$gradeExpiry as $playerName => $expiresAt) {
            if ($now < $expiresAt) continue;

            unset(self::$gradeExpiry[$playerName]);
            $changed = true;

            $gradeManager = Manager::GRADE();
            $online = Server::getInstance()->getPlayerExact($playerName);

            if ($online instanceof \CarailleNoir\player\PrismaPlayer) {
                // Joueur en ligne
                $gradeManager->removeGradeOffline($playerName);
                $online->sendMessage("§c[Vote] §fTon grade Vote a expiré. Tu es redevenu Joueur.");
                $online->invalidateGradeCache();
            } else {
                // Hors-ligne : modifier les données brutes
                $gradeManager->removeGradeOffline($playerName);
            }
        }

        if ($changed) self::saveGradeExpiry();
    }

    public static function triggerVoteParty(): void
    {
        Server::getInstance()->broadcastMessage("§l§a[VoteParty] §fObjectif atteint ! Une §6Clé Vote §fest distribuée à tous les joueurs en ligne !");
        foreach (Server::getInstance()->getOnlinePlayers() as $onlinePlayer) {
            self::giveVoteKey($onlinePlayer, 1);
            $onlinePlayer->sendMessage("§6[VoteParty] §fTu as reçu une §6Clé Vote §f!");
        }
        self::$currentVotes = 0;
        self::save();
    }

    /**
     * Donne une Clé Vote au joueur. Si l'inventaire est plein, drop au sol.
     */
    private static function giveVoteKey(Player $player, int $count = 1): void
    {
        $voteKey = (new VoteKey())->setCount($count);
        if ($player->getInventory()->canAddItem($voteKey)) {
            $player->getInventory()->addItem($voteKey);
        } else {
            $player->getWorld()->dropItem($player->getPosition(), $voteKey);
        }
    }
}
