<?php

declare(strict_types=1);

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\Position;

class EventManager
{
    public const TYPE_KOTH = "koth";
    public const TYPE_OUTPOST = "outpost";
    public const TYPE_TOTEM = "totem";
    public const TYPE_NEXUS = "nexus";
    public const TYPE_AFKKEY = "afkkey";

    private ?string $activeEvent = null;
    private ?string $capturePlayer = null;
    private int $captureProgress = 0;
    private int $captureRequired = 120;
    private int $lastKothStart = 0;
    private int $kothExpireAt = 0;
    public const KOTH_MAX_DURATION = 1800; // 30 min expiration

    /** @var array<string, mixed> */
    private array $config = [];

    /** @var array<string, true> */
    private array $playersInKoth = [];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "events.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode([
                "koth" => [
                    "world" => "world",
                    "pos1" => ["x" => -3, "y" => 62, "z" => -3],
                    "pos2" => ["x" => 3, "y" => 68, "z" => 3],
                    "capture_time" => 60,
                    "reward_box" => "dieu"
                ],
                "outpost" => [
                    "world" => "world",
                    "pos1" => ["x" => -10, "y" => 60, "z" => -10],
                    "pos2" => ["x" => 10, "y" => 80, "z" => 10],
                    "capture_time" => 180,
                    "reward_box" => "noble"
                ],
                "totem" => ["world" => "Map", "x" => -8, "y" => 64, "z" => 185, "capture_time" => 120, "reward_box" => "heros"],
                "nexus" => ["world" => "world", "x" => 0, "y" => 65, "z" => -200, "capture_time" => 240, "reward_box" => "dieu"]
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
        $this->config = json_decode((string) file_get_contents($path), true) ?? [];
        $changed = false;
        foreach ([self::TYPE_KOTH, self::TYPE_OUTPOST] as $type) {
            if (!isset($this->config[$type])) continue;
            if (!isset($this->config[$type]['pos1'], $this->config[$type]['pos2'])) {
                $x = (int) ($this->config[$type]['x'] ?? 0);
                $y = (int) ($this->config[$type]['y'] ?? 64);
                $z = (int) ($this->config[$type]['z'] ?? 0);
                $radius = $type === self::TYPE_KOTH ? 3 : 10;
                $y2 = $type === self::TYPE_KOTH ? $y + 6 : $y + 20;
                $this->config[$type]['pos1'] = ["x" => $x - $radius, "y" => $y - 2, "z" => $z - $radius];
                $this->config[$type]['pos2'] = ["x" => $x + $radius, "y" => $y2, "z" => $z + $radius];
                $changed = true;
            }
        }

        if (isset($this->config['totem'])) {
            if (!isset($this->config['totem']['pos1'], $this->config['totem']['pos2'])) {
                $x = (int) ($this->config['totem']['x'] ?? -8);
                $y = (int) ($this->config['totem']['y'] ?? 64);
                $z = (int) ($this->config['totem']['z'] ?? 185);
                $this->config['totem']['pos1'] = ['x' => $x - 6, 'y' => $y - 2, 'z' => $z - 6];
                $this->config['totem']['pos2'] = ['x' => $x + 6, 'y' => $y + 8, 'z' => $z + 6];
                $this->config['totem']['world'] = (string)($this->config['totem']['world'] ?? 'Map');
                $this->config['totem']['reward_box'] = (string)($this->config['totem']['reward_box'] ?? 'heros');
                $changed = true;
            }
        }
        if (isset($this->config['koth'])) {
            $this->config['koth']['capture_time'] = (int) ($this->config['koth']['capture_time'] ?? 60);
            $this->config['koth']['reward_box'] = (string) ($this->config['koth']['reward_box'] ?? 'dieu');
        }
        if ($this->lastKothStart <= 0) {
            $this->lastKothStart = time();
        }
        if (!isset($this->config['afkkey'])) {
            $this->config['afkkey'] = ['world' => 'Map', 'pos1' => ['x' => -5, 'y' => 54, 'z' => -171], 'pos2' => ['x' => 5, 'y' => 60, 'z' => -161], 'capture_time' => 180];
            $changed = true;
        }
        if ($changed) $this->save();
    }

    public function save(): void
    {
        $path = Core::getInstance()->getDataFolder() . "events.json";
        file_put_contents($path, json_encode($this->config, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    public function isEventActive(): bool { return $this->activeEvent !== null; }
    public function isRunning(): bool { return $this->activeEvent !== null; }
    public function getActiveEvent(): ?string { return $this->activeEvent; }
    public function getType(): ?string { return $this->activeEvent; }
    public function getKothCapturingPlayer(): ?string { return $this->capturePlayer; }
    public function getCaptureProgress(): int { return $this->captureProgress; }
    public function getCaptureRequired(): int { return $this->captureRequired; }

    public function getEventConfig(string $type): ?array { return $this->config[$type] ?? null; }
    public function getAvailableTypes(): array { return [self::TYPE_KOTH, self::TYPE_OUTPOST, self::TYPE_TOTEM, self::TYPE_NEXUS, self::TYPE_AFKKEY]; }

    public function getRewardBoxId(string $type): string
    {
        return (string) ($this->config[$type]['reward_box'] ?? 'vote');
    }

    public function getCaptureTime(string $type): int
    {
        return (int) ($this->config[$type]['capture_time'] ?? 120);
    }

    public function canStartKothNow(): bool
    {
        return (time() - $this->lastKothStart) >= 10800;
    }

    public function markKothStarted(): void
    {
        $this->lastKothStart = time();
    }

    public function setEventZone(string $type, string $world, array $pos1, array $pos2): void
    {
        if (!isset($this->config[$type])) $this->config[$type] = [];
        $this->config[$type]['world'] = $world;
        $this->config[$type]['pos1'] = [
            'x' => (int) $pos1['x'], 'y' => (int) $pos1['y'], 'z' => (int) $pos1['z']
        ];
        $this->config[$type]['pos2'] = [
            'x' => (int) $pos2['x'], 'y' => (int) $pos2['y'], 'z' => (int) $pos2['z']
        ];
        $this->save();
    }

    public function getZone(string $type): ?array
    {
        $cfg = $this->config[$type] ?? null;
        if ($cfg === null || !isset($cfg['pos1'], $cfg['pos2'])) return null;
        return [
            'world' => (string) ($cfg['world'] ?? 'world'),
            'pos1' => $cfg['pos1'],
            'pos2' => $cfg['pos2']
        ];
    }

    public function isInEventZone(string $type, Position $pos): bool
    {
        $zone = $this->getZone($type);
        if ($zone === null) return false;
        if ($pos->getWorld()->getFolderName() !== $zone['world']) return false;
        $x = (int) floor($pos->getX());
        $y = (int) floor($pos->getY());
        $z = (int) floor($pos->getZ());
        $x1 = (int) $zone['pos1']['x']; $y1 = (int) $zone['pos1']['y']; $z1 = (int) $zone['pos1']['z'];
        $x2 = (int) $zone['pos2']['x']; $y2 = (int) $zone['pos2']['y']; $z2 = (int) $zone['pos2']['z'];
        return $x >= min($x1, $x2) && $x <= max($x1, $x2)
            && $y >= min($y1, $y2) && $y <= max($y1, $y2)
            && $z >= min($z1, $z2) && $z <= max($z1, $z2);
    }

    public function isInKothZone(Position $pos): bool
    {
        return $this->isInEventZone(self::TYPE_KOTH, $pos);
    }

    public function getEventPosition(string $type): ?Vector3
    {
        $zone = $this->getZone($type);
        if ($zone !== null) {
            $x1 = (int) $zone['pos1']['x']; $y1 = (int) $zone['pos1']['y']; $z1 = (int) $zone['pos1']['z'];
            $x2 = (int) $zone['pos2']['x']; $y2 = (int) $zone['pos2']['y']; $z2 = (int) $zone['pos2']['z'];
            return new Vector3((min($x1, $x2) + max($x1, $x2)) / 2, (min($y1, $y2) + max($y1, $y2)) / 2, (min($z1, $z2) + max($z1, $z2)) / 2);
        }
        $cfg = $this->getEventConfig($type);
        if ($cfg === null) return null;
        return new Vector3((float) ($cfg['x'] ?? 0), (float) ($cfg['y'] ?? 64), (float) ($cfg['z'] ?? 0));
    }

    public function startEvent(string $type): void
    {
        if ($this->isEventActive()) return;
        $this->activeEvent = $type;
        $this->capturePlayer = null;
        $this->captureProgress = 0;
        $this->playersInKoth = [];
        $this->captureRequired = $this->getCaptureTime($type);
        if ($type === self::TYPE_KOTH) {
            $this->markKothStarted();
            $this->kothExpireAt = time() + self::KOTH_MAX_DURATION;
        }
        if ($type === self::TYPE_TOTEM) {
            Manager::TOTEM()->start();
        }
        Server::getInstance()->broadcastMessage("§6[Event] §eLe §f" . strtoupper($type) . " §ecommence.");
    }

    public function stopEvent(): void
    {
        $wasTotem = $this->activeEvent === self::TYPE_TOTEM;
        $this->activeEvent = null;
        $this->capturePlayer = null;
        $this->captureProgress = 0;
        $this->playersInKoth = [];
        $this->kothExpireAt = 0;
        if ($wasTotem || Manager::TOTEM()->isActive()) {
            Manager::TOTEM()->stop();
        }
    }

    public function getKothExpireAt(): int { return $this->kothExpireAt; }

    public function tickCapture(string $player): bool
    {
        if (!$this->isEventActive()) return false;
        if ($this->activeEvent === self::TYPE_KOTH) {
            if ($this->capturePlayer !== $player) return false;
        } else {
            $this->capturePlayer = $player;
        }
        $this->captureProgress++;
        return $this->captureProgress >= $this->captureRequired;
    }

    public function onKothEnter(PrismaPlayer $player): void
    {
        if (!$this->isRunning() || $this->getType() !== self::TYPE_KOTH) return;
        $name = $player->getName();
        $this->playersInKoth[$name] = true;
        if ($this->capturePlayer === null) {
            $this->capturePlayer = $name;
            $this->captureProgress = 0;
            $player->sendTip("§6[Event] §eCapture du KOTH commencée.");
        }
    }

    public function onKothLeave(string $playerName): void
    {
        unset($this->playersInKoth[$playerName]);
        if ($this->capturePlayer !== $playerName) return;
        $this->capturePlayer = null;
        $this->captureProgress = 0;
        foreach (array_keys($this->playersInKoth) as $next) {
            $this->capturePlayer = $next;
            break;
        }
    }

    public function onEventWon(string $playerName): void
    {
        if ($this->activeEvent === null) return;
        $type = $this->activeEvent;
        $boxId = $this->getRewardBoxId($type);
        $key = Manager::BOX()->makeKeyItem($boxId);
        $player = Server::getInstance()->getPlayerExact($playerName);
        Server::getInstance()->broadcastMessage("§6[Event] §a$playerName §ea remporté le §f" . strtoupper($type) . " §eet reçoit une clé §6" . strtoupper($boxId) . "§e.");
        if ($player !== null && $key !== null) $player->getInventory()->addItem($key);
        $this->stopEvent();
    }
}
