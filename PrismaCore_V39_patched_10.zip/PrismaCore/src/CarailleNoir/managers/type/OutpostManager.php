<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;
use pocketmine\world\Position;

class OutpostManager
{
 public const DECAPTURE_TIME = 60;
 public const REWARD_MONEY = 2500;
 public const REWARD_POWER = 5;
 public const REWARD_INTERVAL = 300;
 public const STATE_NEUTRAL = "neutral";
 public const STATE_CAPTURING = "capturing";
 public const STATE_CAPTURED = "captured";
 public const STATE_CONTESTED = "contested";
 public const STATE_DECAPTURING = "decapturing";

 private string $state = self::STATE_NEUTRAL;
 private ?string $capturingFaction = null;
 private ?string $lastCapturer = null;
 private ?string $capturedFaction = null;
 private ?string $decapturingFaction = null;
 private int $captureProgress = 0;
 private int $decaptureProgress = 0;
 private int $rewardTimer = 0;
 private array $playersInZone = [];

 public function hasZone(): bool { return Manager::EVENT()->getZone('outpost') !== null; }
 public function getState(): string { return $this->state; }
 public function getCapturedFaction(): ?string { return $this->capturedFaction; }
 public function getCapturingFaction(): ?string { return $this->capturingFaction; }
 public function getDecapturingFaction(): ?string { return $this->decapturingFaction; }
 public function getCaptureProgress(): int { return $this->captureProgress; }
 public function getDecaptureProgress(): int { return $this->decaptureProgress; }
 public function getRewardTimer(): int { return $this->rewardTimer; }
 public function getCaptureTime(): int { return Manager::EVENT()->getCaptureTime('outpost'); }

 public function isInZone(Position $pos): bool { return Manager::EVENT()->isInEventZone('outpost', $pos); }
 public function setZone(string $world, array $pos1, array $pos2): void { Manager::EVENT()->setEventZone('outpost', $world, $pos1, $pos2); }

 public function enterZone(string $player, string $factionId): void{
  if (!isset($this->playersInZone[$factionId])) $this->playersInZone[$factionId] = [];
  if (!in_array($player, $this->playersInZone[$factionId], true)) $this->playersInZone[$factionId][] = $player;
 }
 public function leaveZone(string $player): void{
  foreach ($this->playersInZone as $fid => &$players) {
   $players = array_values(array_filter($players, fn($p) => $p !== $player));
   if (empty($players)) unset($this->playersInZone[$fid]);
  }
 }
 public function getFactionsInZone(): array { return array_keys(array_filter($this->playersInZone, fn($p) => count($p) > 0)); }
 private function factionName(?string $id): string{
  if ($id === null) return "Aucune";
  $f = Manager::FACTION()->getFaction($id);
  return $f !== null ? $f->getName() : $id;
 }
 public function tick(): void{
  $factions = $this->getFactionsInZone();
  $count = count($factions);
  if ($this->state === self::STATE_CAPTURED && $this->capturedFaction !== null) {
   $this->rewardTimer++;
   if ($this->rewardTimer >= self::REWARD_INTERVAL) {
    $this->rewardTimer = 0;
    $this->giveRewards($this->capturedFaction);
   }
  }
  switch ($this->state) {
   case self::STATE_NEUTRAL:
    if ($count === 1) {
     $this->state = self::STATE_CAPTURING; $this->capturingFaction = $factions[0]; $this->captureProgress = 0;
     $this->broadcast("§e§l[Outpost] §fLa faction §a{$this->factionName($factions[0])} §fcommence la capture !");
    } break;
   case self::STATE_CAPTURING:
    if ($count === 0) { $this->state = self::STATE_NEUTRAL; $this->capturingFaction = null; $this->captureProgress = 0; }
    elseif ($count >= 2) { $this->state = self::STATE_CONTESTED; }
    elseif ($factions[0] === $this->capturingFaction) {
      $this->captureProgress++;
      if ($this->captureProgress >= $this->getCaptureTime()) {
       $playerInZone = $this->playersInZone[$this->capturingFaction][0] ?? null;
       $this->lastCapturer = $playerInZone;
       $this->capturedFaction = $this->capturingFaction; $this->capturingFaction = null; $this->captureProgress = 0; $this->state = self::STATE_CAPTURED;
       $this->broadcast("§e§l[Outpost] §a✔ La faction §f{$this->factionName($this->capturedFaction)} §aa capturé l'Outpost !");
       $this->giveRewards($this->capturedFaction);
      }
    } else { $this->state = self::STATE_CONTESTED; }
    break;
   case self::STATE_CONTESTED:
    if ($count === 0) { $this->state = self::STATE_NEUTRAL; $this->capturingFaction = null; $this->captureProgress = 0; }
    elseif ($count === 1) { $this->state = self::STATE_CAPTURING; $this->capturingFaction = $factions[0]; }
    break;
   case self::STATE_CAPTURED:
    if ($count === 0) break;
    if ($count >= 2) { $this->state = self::STATE_CONTESTED; break; }
    if ($factions[0] !== $this->capturedFaction) {
     $this->state = self::STATE_DECAPTURING; $this->decapturingFaction = $factions[0]; $this->decaptureProgress = 0;
     $this->broadcast("§e§l[Outpost] §c⚠ §f{$this->factionName($factions[0])} §ctente de décapturer l'Outpost de §f{$this->factionName($this->capturedFaction)} §c(60s)");
    } break;
   case self::STATE_DECAPTURING:
    if ($count === 0) { $this->state = self::STATE_CAPTURED; $this->decapturingFaction = null; $this->decaptureProgress = 0; }
    elseif ($count >= 2) { $this->state = self::STATE_CONTESTED; }
    elseif ($factions[0] === $this->decapturingFaction) {
      $this->decaptureProgress++;
      if ($this->decaptureProgress >= self::DECAPTURE_TIME) {
       $this->broadcast("§e§l[Outpost] §cL'Outpost a été décapturé ! §f{$this->factionName($this->decapturingFaction)} §ccommence la capture ({$this->getCaptureTime()}s).");
       $this->capturingFaction = $this->decapturingFaction; $this->capturedFaction = null; $this->decapturingFaction = null; $this->decaptureProgress = 0; $this->captureProgress = 0; $this->state = self::STATE_CAPTURING;
      }
    } else { $this->state = self::STATE_CONTESTED; }
    break;
  }
 }
 private function giveRewards(string $factionId): void{
  $faction = Manager::FACTION()->getFaction($factionId); if ($faction === null) return;
  $online = $faction->getOnlinePlayers();

  // 1. Chercher le chef en ligne
  $recipient = null;
  $leaderId = $faction->getOwner();
  if ($leaderId !== null) {
   foreach ($online as $op) {
    if (strtolower($op->getName()) === strtolower($leaderId) && $op instanceof PrismaPlayer) {
     $recipient = $op; break;
    }
   }
  }

  // 2. Sinon le dernier capteur si en ligne
  if ($recipient === null && $this->lastCapturer !== null) {
   foreach ($online as $op) {
    if (strtolower($op->getName()) === strtolower($this->lastCapturer) && $op instanceof PrismaPlayer) {
     $recipient = $op; break;
    }
   }
  }

  // 3. Sinon joueur aléatoire de la faction en ligne
  if ($recipient === null && !empty($online)) {
   $candidates = array_values(array_filter($online, fn($p) => $p instanceof PrismaPlayer));
   if (!empty($candidates)) $recipient = $candidates[array_rand($candidates)];
  }

  if ($recipient === null) return;
  $recipient->addMoney((float)self::REWARD_MONEY);
  Manager::STATS()->addPower($recipient->getName(), self::REWARD_POWER);
  $recipient->sendMessage("§e§l[Outpost] §a+§f" . self::REWARD_MONEY . "§a$ §7& §a+" . self::REWARD_POWER . " §7power reçus !");
  $this->broadcast("§e§l[Outpost] §f" . $recipient->getName() . " §8(§f{$faction->getName()}§8) §freçoit les récompenses de l'Outpost !");
 }
 public function broadcast(string $msg): void{ foreach (Server::getInstance()->getOnlinePlayers() as $p) { $p->sendMessage($msg); } }
 public function getStatusBar(): string{
  return match ($this->state) {
   self::STATE_NEUTRAL => "§7[Outpost] §fNeutre",
   self::STATE_CAPTURING => "§7[Outpost] §aCapture §f" . $this->factionName($this->capturingFaction) . " §7(" . $this->captureProgress . "/" . $this->getCaptureTime() . "s)",
   self::STATE_CAPTURED => "§7[Outpost] §a" . $this->factionName($this->capturedFaction),
   self::STATE_CONTESTED => "§7[Outpost] §c Contesté",
   self::STATE_DECAPTURING => "§7[Outpost] §cDécapture §f" . $this->factionName($this->decapturingFaction) . " §7(" . $this->decaptureProgress . "/" . self::DECAPTURE_TIME . "s)",
   default => ""
  };
 }
}
