<?php
declare(strict_types=1);
namespace CarailleNoir\entities\vanilla;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;

/**
 * Piglin Event — spawn toutes les 5 minutes au spawn.
 * Drops une clé PrismaItems aléatoire (prisma:key_XXX) selon % de chance.
 *
 * Chance | Clé
 * -------+--------------------
 * 55% | key_vote (Vote)
 * 25% | key_boutique (Boutique)
 * 12% | key_noble (Noble)
 * 6% | key_heros (Heros)
 * 2% | key_dieu (Dieu)
 */
class Piglin extends Living
{
 // Probabilités : Vote 55% | Noble 25% | Héros 15% | Dieu 5% (total = 100%)
 private const KEY_POOL = [
 ["id" => "prisma:key_vote",  "chance" => 55],
 ["id" => "prisma:key_noble", "chance" => 25],
 ["id" => "prisma:key_heros", "chance" => 15],
 ["id" => "prisma:key_dieu",  "chance" => 5],
 ];

 protected function initEntity(CompoundTag $nbt): void
 {
 $this->setMaxHealth(40);
 $this->setHealth(40);
 $this->setNameTagAlwaysVisible(true);
 parent::initEntity($nbt);
 }

 public static function getNetworkTypeId(): string { return EntityIds::PIGLIN; }

 protected function getInitialSizeInfo(): EntitySizeInfo { return new EntitySizeInfo(1.9, 0.6); }

 public function getName(): string { return "Piglin"; }

 public function getXpHunter(): int { return 0; }

 public function knockBack(float $x, float $z, float $force = 0, ?float $verticalLimit = 0.4): void
 {
 $this->setMotion(new Vector3(0.0, $this->motion->y, 0.0));
 }

 protected function onDeath(): void
 {
 $key = $this->rollKey();
 if ($key !== null) {
 // Donner au joueur le plus proche dans un rayon de 20 blocs
 $closest = null;
 $minDist = PHP_FLOAT_MAX;
 foreach ($this->getWorld()->getPlayers() as $p) {
 $d = $p->getPosition()->distanceSquared($this->getPosition());
 if ($d < $minDist) { $minDist = $d; $closest = $p; }
 }
 if ($closest !== null && $minDist <= 400) {
 if ($closest->getInventory()->canAddItem($key)) {
 $closest->getInventory()->addItem($key);
 } else {
 $this->getWorld()->dropItem($this->getPosition(), $key);
 }
 $closest->sendMessage("§6[Event] §eVous avez obtenu : §r" . $key->getName());
 } else {
 $this->getWorld()->dropItem($this->getPosition(), $key);
 }
 }
 parent::onDeath();
 }

 private function rollKey(): ?Item
 {
 $roll = mt_rand(1, 100);
 $cum = 0;
 foreach (self::KEY_POOL as $entry) {
 $cum += $entry["chance"];
 if ($roll <= $cum) {
 $item = StringToItemParser::getInstance()->parse($entry["id"]);
 if ($item !== null) {
 $item->setCount(1);
 return $item;
 }
 }
 }
 return null;
 }

 public function getDrops(): array { return []; }
}
