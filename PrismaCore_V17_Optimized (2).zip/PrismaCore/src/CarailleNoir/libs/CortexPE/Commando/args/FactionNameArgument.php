<?php
declare(strict_types=1);
namespace CarailleNoir\libs\CortexPE\Commando\args;

use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\types\command\CommandHardEnum;
use pocketmine\Server;

/**
 * Argument qui autocomplète les noms de factions.
 *
 * Fonctionnement :
 *  - Étend ArrayEnumArgument SANS override de getEnumValues()
 *    → le PacketHooker de Commando peut lire $param->enum->getValues() correctement
 *  - refreshEnum() met à jour le CommandHardEnum dans parameterData
 *    puis appelle syncAvailableCommands() pour chaque joueur connecté
 *  - Le PacketHooker intercepte ces paquets et relit nos valeurs → mise à jour live
 *  - Le 1-tick delayed task dans Core.php peuple l'enum après le chargement complet
 *
 * Appelé depuis : Core.php (delayed 1 tick), FactionManager (create/delete), NameSubCommand (rename)
 */
class FactionNameArgument extends ArrayEnumArgument
{
    public const ENUM_NAME = "FactionNames";
    private static ?self $instance = null;
    /** Timestamp du dernier refreshEnum() pour le cooldown anti-spam */
    private static int $lastRefreshTime = 0;
    private const REFRESH_COOLDOWN = 10; // secondes

    public function __construct(bool $optional = false, ?string $name = null)
    {
        parent::__construct($name ?? "factionName", self::ENUM_NAME, ["aucune"], $optional);
        self::$instance = $this;
    }

    /**
     * Met à jour l'enum et resynchronise l'autocomplétion pour tous les joueurs connectés.
     * Le PacketHooker intercepte les AvailableCommandsPacket envoyés par syncAvailableCommands()
     * et relit automatiquement les valeurs de notre CommandHardEnum mis à jour.
     */
    public static function refreshEnum(): void
    {
        // Anti-spam : au maximum 1 refresh toutes les 10 secondes
        $now = time();
        if (($now - self::$lastRefreshTime) < self::REFRESH_COOLDOWN) return;
        self::$lastRefreshTime = $now;

        $self = self::$instance;
        if ($self === null) return;

        $names = self::buildNames();
        if (empty($names)) return;

        // 1. Mettre à jour le tableau interne d'ArrayEnumArgument
        $self->value = [];
        foreach ($names as $name) {
            $self->addValue($name, $name);
        }

        // 2. Mettre à jour le CommandHardEnum dans parameterData
        //    Le PacketHooker lit $param->enum->getValues() → ces valeurs
        $self->getNetworkParameterData()->enum = new CommandHardEnum(
            self::ENUM_NAME,
            $self->getEnumValues() // array_keys($value) — standard ArrayEnumArgument
        );

        // 3. Resynchroniser pour les joueurs déjà connectés
        //    PacketHooker::generateOverloadList() intercepte et relit nos valeurs
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            try {
                $player->getNetworkSession()->syncAvailableCommands();
            } catch (\Throwable) {
                // Silencieux si indisponible dans cette build
            }
        }
    }

    private static function buildNames(): array
    {
        $names = [];
        foreach (Manager::FACTION()->getFactions() as $faction) {
            $names[] = $faction->getName();
        }
        return $names;
    }

    public function getTypeName(): string { return "faction"; }

    /** Accepte toute saisie non vide côté serveur */
    public function canParse(string $testString, CommandSender $sender): bool
    {
        return strlen(trim($testString)) >= 1;
    }

    public function parse(string $argument, CommandSender $sender): string
    {
        return $argument;
    }
}
