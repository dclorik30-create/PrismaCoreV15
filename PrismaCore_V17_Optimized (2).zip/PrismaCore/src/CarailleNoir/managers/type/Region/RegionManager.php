<?php

namespace CarailleNoir\managers\type\Region;

use CarailleNoir\Core;
use CarailleNoir\managers\option\RegionOption;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\math\AxisAlignedBB;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\utils\SingletonTrait;
use Symfony\Component\Filesystem\Path;
use function reset;

class RegionManager
{
 use SingletonTrait;
 private array $playerPositions = [];
 /** @var Region[]*/
 private array $regions = [];

 public function register(): void{
 $path = Core::getInstance()->getDataFolder() . "Region/";
 if (!is_dir($path)) {
 @mkdir($path, 0777, true);
 }
 $scan = scandir($path);
 foreach ($scan as $file) {
 if ($file === "." || $file === "..") continue;
 if (is_file($path . $file)) {
 $f = substr($file, 0, -4);
 $config = Core::getInstance()->getConfigFile("Region/" . $f);
 $data = $config->getAll();

 // Migration auto: anciennes regions stockees avec displayName au lieu du folderName
 $worldName = (string) ($data["world"] ?? '');
 if ($worldName !== '') {
 foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
 if ($world->getDisplayName() === $worldName) {
 $data["world"] = $world->getFolderName();
 $config->set("world", $data["world"]);
 $config->save();
 break;
 }
 }
 }

 $region = Region::unserialize($data);
 $this->regions[$config->get("id")] = $region;
 }
 }
 }

 public function save(): void
 {
 foreach ($this->regions as $region) {
 $config = Core::getInstance()->getConfigFile("Region/{$region->getId()}");
 $config->setAll($region->serialize($region));
 $config->save();
 }
 }

 public function getRegionById(string $id): ?Region {
 return $this->regions[$id] ?? null;
 }

 public function createRegion(PrismaPlayer $player, string $id, string $name, AxisAlignedBB $zone, string $world, ?int $priority): void
 {
 if (isset($this->regions[$id])) {
 $player->sendMessage("Une région avec cette id existe déja");
 return;
 }

 $priority ??= 0;
 $priorities = array_map(fn($region) => $region->getPriority(), $this->regions);

 while (in_array($priority, $priorities, true)) {
 $priority++;
 }

 $this->regions[$id] = new Region($id, $name, $zone, $world, $priority, [
 RegionOption::PARAM_PVP->getType() => true,
 RegionOption::PARAM_BUILD->getType() => false,
 RegionOption::PARAM_INTERACT->getType() => false,
 RegionOption::PARAM_GROW->getType() => false,
 RegionOption::PARAM_DECAY->getType() => false,
 RegionOption::PARAM_DROP->getType() => true,
 RegionOption::PARAM_PICKUP->getType() => true,
 RegionOption::PARAM_EXPLOSION->getType() => false,
 RegionOption::PARAM_HUNGER->getType() => false,
 RegionOption::PARAM_ENDERPEARL->getType() => true,
 RegionOption::PARAM_CHAT->getType() => true,
 RegionOption::PARAM_FIRE_DAMAGE->getType() => false,
 RegionOption::PARAM_FALL_DAMAGE->getType() => false,
         RegionOption::PARAM_USE->getType() => false
        ]);
 }

 public function deleteRegion(PrismaPlayer $player, string $id): void
 {
 if (!isset($this->regions[$id])) {
 $player->sendMessage("§cAucune région trouvé avec l'id $id.");
 return;
 }

 unset($this->regions[$id]);
 $player->sendMessage("§ARégion supprimé avec succes.");
 }

 public function editRegion(PrismaPlayer $player, string $id, Region $newRegion): void{
 $region = $this->getRegionById($id);

 if($region === null){
 $player->sendMessage("Région non trouvée");
 return;
 }

 $this->regions[$id] = $newRegion;
 }

 public function setPosition1(string $playerName, Vector3 $pos): void {
 $this->playerPositions[$playerName]['pos1'] = $pos;
 }

 public function setPosition2(string $playerName, Vector3 $pos): void {
 $this->playerPositions[$playerName]['pos2'] = $pos;
 }

 public function getPositions(string $playerName): ?array {
 return $this->playerPositions[$playerName] ?? null;
 }

 /** @return Region[] */
 public function getRegionsAt(Vector3 $pos, string $worldName = ''): array {
 return array_filter($this->regions, function(Region $region) use ($pos, $worldName): bool {
 if ($worldName !== '' && $region->getWorldName() !== $worldName) return false;
 $zone = $region->getZone();
 return $pos->x >= $zone->minX && $pos->x <= $zone->maxX
 && $pos->y >= $zone->minY && $pos->y <= $zone->maxY
 && $pos->z >= $zone->minZ && $pos->z <= $zone->maxZ;
 });
 }


 public function getMainRegionAt(Vector3 $pos, string $worldName = ''): ?Region {
 $regions = $this->getRegionsAt($pos, $worldName);
 if (empty($regions)) return null;

 uasort($regions, fn(Region $region, Region $region2) => $region->getPriority() <=> $region2->getPriority());

 return reset($regions);
 }

 public function getRegions(): array {
 return array_keys($this->regions);
 }
}