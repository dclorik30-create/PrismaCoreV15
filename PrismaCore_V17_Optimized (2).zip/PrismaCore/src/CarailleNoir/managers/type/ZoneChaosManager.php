<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\particle\RedstoneParticle;
use pocketmine\world\particle\FlameParticle;

/**
 * ZoneChaosManager
 *
 * - /zonechaos <id>        : enregistre pos1 puis pos2 de la zone <id>
 * - Tous les jours à 21h (Europe/Paris) : zone aléatoire choisie, annoncée,
 *   entourée de particules (bords uniquement, 1x/s), kill = +10 000$ +5 power.
 * - /event start zonechaos : démarre manuellement.
 * - Durée : 20 minutes.
 */
class ZoneChaosManager
{
    // ── Constantes ──────────────────────────────────────────────────────────
    private const DURATION_SECONDS = 20 * 60;   // 1200 secondes = 20 minutes
    private const DAILY_HOUR       = 21;
    private const KILL_MONEY       = 10_000;
    private const KILL_POWER       = 5;
    private const DATA_FILE        = "zone_chaos.json";

    // ── Zones ────────────────────────────────────────────────────────────────
    /** @var array<int, array{world:string, pos1:array{x:float,y:float,z:float}, pos2:array{x:float,y:float,z:float}}> */
    private array $zones = [];

    /** @var array<int, int> étape setup (0 = attend pos1, 1 = attend pos2) */
    private array $setupStep = [];

    /** @var array<int, array{world:string,x:float,y:float,z:float}> */
    private array $pendingPos1 = [];

    // ── État de l'event ──────────────────────────────────────────────────────
    private bool $active       = false;
    private int  $activeTick   = 0;
    private int  $currentZone  = -1;
    private int  $particleTick = 0;

    // ── Vérification quotidienne ─────────────────────────────────────────────
    private int  $dailyCheckTick  = 0;
    private bool $triggeredToday  = false;
    private int  $lastDay         = -1;

    // ── Init ─────────────────────────────────────────────────────────────────

    public function init(): void
    {
        $path = Core::getInstance()->getDataFolder() . self::DATA_FILE;
        if (!file_exists($path)) return;
        $data = json_decode((string) file_get_contents($path), true) ?? [];
        foreach ($data as $id => $zone) {
            $this->zones[(int)$id] = $zone;
        }
    }

    private function save(): void
    {
        file_put_contents(
            Core::getInstance()->getDataFolder() . self::DATA_FILE,
            json_encode($this->zones, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    // ── Commande /zonechaos <id> ─────────────────────────────────────────────

    public function handleSetup(int $id, string $worldName, float $x, float $y, float $z): string
    {
        $step = $this->setupStep[$id] ?? 0;

        if ($step === 0) {
            $this->pendingPos1[$id] = ["world" => $worldName, "x" => $x, "y" => $y, "z" => $z];
            $this->setupStep[$id]   = 1;
            return "§6[Zone Chaos #$id] §aPos1 enregistrée : §f{$x}, {$y}, {$z} §a(§f{$worldName}§a) — Refais /zonechaos {$id} pour la Pos2.";
        }

        $p1 = $this->pendingPos1[$id] ?? null;
        if ($p1 === null || $p1["world"] !== $worldName) {
            $this->setupStep[$id] = 0;
            unset($this->pendingPos1[$id]);
            return "§c[Zone Chaos #$id] Monde différent ou pos1 manquante. Recommence.";
        }

        $this->zones[$id] = [
            "world" => $worldName,
            "pos1"  => ["x" => min((float)$p1["x"], $x), "y" => min((float)$p1["y"], $y), "z" => min((float)$p1["z"], $z)],
            "pos2"  => ["x" => max((float)$p1["x"], $x), "y" => max((float)$p1["y"], $y), "z" => max((float)$p1["z"], $z)],
        ];
        unset($this->setupStep[$id], $this->pendingPos1[$id]);
        $this->save();

        $z1 = $this->zones[$id];
        return "§6[Zone Chaos #$id] §aZone enregistrée ! " .
               "§fPos1: {$z1['pos1']['x']},{$z1['pos1']['y']},{$z1['pos1']['z']} " .
               "§7→ §fPos2: {$z1['pos2']['x']},{$z1['pos2']['y']},{$z1['pos2']['z']}";
    }

    // ── Start / Stop ─────────────────────────────────────────────────────────

    public function start(int $zoneId = -1): bool
    {
        if ($this->active) return false;
        if (empty($this->zones)) return false;

        if ($zoneId === -1 || !isset($this->zones[$zoneId])) {
            $ids    = array_keys($this->zones);
            $zoneId = $ids[array_rand($ids)];
        }

        $this->active      = true;
        $this->currentZone = $zoneId;
        $this->activeTick  = 0;
        $this->particleTick = 0;

        $zone = $this->zones[$zoneId];
        $cx   = (int) round(($zone["pos1"]["x"] + $zone["pos2"]["x"]) / 2);
        $cz   = (int) round(($zone["pos1"]["z"] + $zone["pos2"]["z"]) / 2);
        $cy   = (int) $zone["pos1"]["y"];

        Server::getInstance()->broadcastMessage(
            "\n§4§l━━━━ ZONE DE CHAOS ━━━━\n" .
            "§cUne zone de combat s'embrase !\n" .
            "§7Coordonnées : §f{$cx}, {$cy}, {$cz}\n" .
            "§7Chaque kill : §6+10 000$ §7et §b+5 Power\n" .
            "§7Durée : §f20 minutes\n" .
            "§4§l━━━━━━━━━━━━━━━━━━━━━━\n"
        );

        return true;
    }

    public function stop(): void
    {
        if (!$this->active) return;
        $this->active      = false;
        $this->currentZone = -1;
        Server::getInstance()->broadcastMessage("§4§l[Zone de Chaos] §cL'event est terminé !");
    }

    // ── Tick (appelé 1x/seconde par ZoneChaosTask) ───────────────────────────

    public function tick(): void
    {
        // Vérifier heure quotidienne toutes les 60s
        $this->dailyCheckTick++;
        if ($this->dailyCheckTick >= 60) {
            $this->dailyCheckTick = 0;
            $this->checkDailyTrigger();
        }

        if (!$this->active) return;

        $this->activeTick++;
        $this->particleTick++;

        if ($this->activeTick >= self::DURATION_SECONDS) {
            $this->stop();
            return;
        }

        $this->spawnParticles();
    }

    // ── Déclencheur quotidien ────────────────────────────────────────────────

    private function checkDailyTrigger(): void
    {
        $tz   = new \DateTimeZone("Europe/Paris");
        $now  = new \DateTime("now", $tz);
        $hour = (int) $now->format("H");
        $day  = (int) $now->format("z");

        if ($day !== $this->lastDay) {
            $this->lastDay        = $day;
            $this->triggeredToday = false;
        }

        if (!$this->triggeredToday && $hour >= self::DAILY_HOUR) {
            $this->triggeredToday = true;
            if (!$this->active) {
                $this->start();
            }
        }
    }

    // ── Kill dans la zone ─────────────────────────────────────────────────────

    public function isActive(): bool { return $this->active; }

    public function isInZone(string $worldName, float $x, float $y, float $z): bool
    {
        if (!$this->active || $this->currentZone === -1) return false;
        $zone = $this->zones[$this->currentZone] ?? null;
        if ($zone === null) return false;
        if (strtolower($zone["world"]) !== strtolower($worldName)) return false;

        return $x >= $zone["pos1"]["x"] && $x <= $zone["pos2"]["x"]
            && $y >= $zone["pos1"]["y"] && $y <= $zone["pos2"]["y"]
            && $z >= $zone["pos1"]["z"] && $z <= $zone["pos2"]["z"];
    }

    public function onKill(string $killerName): void
    {
        Manager::ECONOMY()->addMoney($killerName, (float) self::KILL_MONEY);
        Manager::STATS()->addPower($killerName, self::KILL_POWER);
        $killer = Server::getInstance()->getPlayerExact($killerName);
        if ($killer !== null) {
            $killer->sendMessage("§4§l[Zone de Chaos] §6+10 000$ §7& §b+5 Power §7pour ton kill !");
        }
    }

    // ── Particules (périmètre complet, chaque Y, step horizontal = 2) ─────────

    private function spawnParticles(): void
    {
        if ($this->currentZone === -1) return;
        $zone = $this->zones[$this->currentZone] ?? null;
        if ($zone === null) return;

        $wm    = Server::getInstance()->getWorldManager();
        $world = $wm->getWorldByName($zone["world"]);
        if ($world === null) return;

        $x1 = (int) $zone["pos1"]["x"];
        $y1 = (int) $zone["pos1"]["y"];
        $z1 = (int) $zone["pos1"]["z"];
        $x2 = (int) $zone["pos2"]["x"];
        $y2 = (int) $zone["pos2"]["y"];
        $z2 = (int) $zone["pos2"]["z"];

        $flame    = new FlameParticle();
        $redstone = new RedstoneParticle();

        // Horizontal step = 2 pour limiter le nombre de particules
        // tout en couvrant les 4 murs à chaque niveau de hauteur.
        $hStep = 2;

        for ($y = $y1; $y <= $y2; $y++) {
            // Alterner flamme (niveaux pairs) / redstone (niveaux impairs)
            $particle = ($y % 2 === 0) ? $flame : $redstone;

            // Faces Nord (z=z1) et Sud (z=z2)
            for ($x = $x1; $x <= $x2; $x += $hStep) {
                $world->addParticle(new Vector3($x + 0.5, $y + 0.5, $z1 + 0.5), $particle);
                $world->addParticle(new Vector3($x + 0.5, $y + 0.5, $z2 + 0.5), $particle);
            }
            // Faces Ouest (x=x1) et Est (x=x2) — coins déjà couverts ci-dessus
            for ($z = $z1 + $hStep; $z < $z2; $z += $hStep) {
                $world->addParticle(new Vector3($x1 + 0.5, $y + 0.5, $z + 0.5), $particle);
                $world->addParticle(new Vector3($x2 + 0.5, $y + 0.5, $z + 0.5), $particle);
            }
        }
    }


    // ── Getters ──────────────────────────────────────────────────────────────

    public function getZoneCount(): int     { return count($this->zones); }
    public function getZones(): array       { return $this->zones; }
    public function getRemainingSeconds(): int
    {
        if (!$this->active) return 0;
        return max(0, self::DURATION_SECONDS - $this->activeTick);
    }
}
