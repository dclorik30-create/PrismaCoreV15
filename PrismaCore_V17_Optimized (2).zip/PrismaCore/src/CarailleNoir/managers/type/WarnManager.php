<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\WarnOption;
use pocketmine\Server;

class WarnManager extends DataHandler
{
 public function init(): void { $this->loadData("Warn");
        $this->markDirty(); }

 private function ensure(string $name): void
 {
 $key = strtolower($name);
 if (!isset($this->data[$key])) {
 $this->data[$key] = ["warn" => 0, "mute" => 0, "kick" => 0];
 }
 }

 public function incrementWarn(string $playerName): void
 {
 $this->ensure($playerName);
 $this->data[strtolower($playerName)]["warn"]++;
 $this->markDirty();
 $this->checkSanction($playerName);
 }

 public function incrementMute(string $playerName): void
 {
 $this->ensure($playerName);
 $this->data[strtolower($playerName)]["mute"]++;
 $this->markDirty();
 $this->checkSanction($playerName);
 }

 public function incrementKick(string $playerName): void
 {
 $this->ensure($playerName);
 $this->data[strtolower($playerName)]["kick"]++;
 $this->markDirty();
 $this->checkSanction($playerName);
 }

 public function getTotal(string $playerName): int
 {
 $d = $this->data[strtolower($playerName)] ?? ["warn" => 0, "mute" => 0, "kick" => 0];
 return ($d["warn"] ?? 0) + ($d["mute"] ?? 0) + ($d["kick"] ?? 0);
 }

 public function getWarnData(string $playerName): array
 {
 return $this->data[strtolower($playerName)] ?? ["warn" => 0, "mute" => 0, "kick" => 0];
 }

 private function checkSanction(string $playerName): void
 {
 $total = $this->getTotal($playerName);
 $player = Server::getInstance()->getPlayerExact($playerName);
 if ($total >= WarnOption::THRESHOLD_BLACKLIST) {
 Manager::BAN()->addBan($playerName, WarnOption::SANCTION_MESSAGE, "System", null);
 } elseif ($total >= WarnOption::THRESHOLD_BAN) {
 Manager::BAN()->addBan($playerName, WarnOption::SANCTION_MESSAGE, "System", 3 * 86400);
 } elseif ($total >= WarnOption::THRESHOLD_MESSAGE) {
 $player?->sendMessage(WarnOption::ALERT_MESSAGE);
 }
 $player?->sendMessage(WarnOption::BASE_MESSAGE);
 }
}
