<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\WarnOption;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;

class BanManager extends DataHandler
{
 public function init(): void
 {
 $this->loadData("Ban");
        $this->markDirty();
 }

 public function addBan(string $playerName, string $reason, ?string $staff = "Console", ?int $duration = null): void
 {
 $expire = is_null($duration) ? null : (time() + $duration);

 $this->data[strtolower($playerName)] = [
 "reason" => $reason,
 "staff" => $staff,
 "expire" => $expire
 ];
 $this->markDirty();

 Manager::WARN()->incrementWarn($playerName); // BAN enregistré dans WarnManager
 }

 public function removeBan(string $playerName, string $reason): void
 {
 if (isset($this->data[strtolower($playerName)])) {
 unset($this->data[strtolower($playerName)]);
 $this->markDirty();
 Server::getInstance()->broadcastMessage("le joueur $playerName vient d'être unban pour la raison -> $reason");
 }
 }

 public function isBanned(PrismaPlayer|string $player): bool
 {
 if ($player instanceof PrismaPlayer) {
 $name = strtolower($player->getName());
 }else {
 $name = strtolower($player);
 }

 if ($this->checkActiveBan($name)) {
 return true;
 }

 $alts = Manager::ALIAS()->getAccounts($player);
 foreach ($alts as $alt) {
 if ($this->checkActiveBan($alt)) {
 return true;
 }
 }

 return false;
 }

 private function checkActiveBan(string $name): bool
 {
 if (!isset($this->data[strtolower($name)])) {
 return false;
 }

 $ban = $this->data[strtolower($name)];

 if ($ban["expire"] === null) {
 return true;
 }


 if ($ban["expire"] < time()) {
 unset($this->data[strtolower($name)]);
 return false;
 }
 return true;
 }

 public function getBanInfo(PrismaPlayer $player): ?array
 {
 $name = strtolower($player->getName());

 if ($this->checkActiveBan($name)) {
 return $this->data[$name];
 }

 $alts = Manager::ALIAS()->getAccounts($player);
 foreach ($alts as $alt) {
 $alt = strtolower($alt);
 if ($this->checkActiveBan($alt)) {
 return $this->data[$alt];
 }
 }

 return [
 "reason" => "Aucune raison trouvée",
 "staff" => "Console",
 "expire" => null
 ];
 }
}