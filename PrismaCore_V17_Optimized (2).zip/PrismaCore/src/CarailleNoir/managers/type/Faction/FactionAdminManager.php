<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type\Faction;

/**
 * Mode admin faction pour les OPs.
 * Permet de bypasser les vérifications d'appartenance.
 */
class FactionAdminManager
{
    /** @var array<string, bool> */
    private static array $admins = [];

    public static function toggle(string $playerName): bool
    {
        $key = strtolower($playerName);
        if (isset(self::$admins[$key])) {
            unset(self::$admins[$key]);
            return false;
        }
        self::$admins[$key] = true;
        return true;
    }

    public static function isAdmin(string $playerName): bool
    {
        return isset(self::$admins[strtolower($playerName)]);
    }

    public static function remove(string $playerName): void
    {
        unset(self::$admins[strtolower($playerName)]);
    }
}
