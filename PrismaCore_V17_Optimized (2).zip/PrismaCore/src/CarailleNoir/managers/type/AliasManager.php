<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;

class AliasManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("Alias");
        $this->markDirty();
        $this->migrateOldFormat();
    }

    // ─────────────────────────────────────────────────────────
    // Migration automatique : ancien format scalaire → tableaux
    // ─────────────────────────────────────────────────────────
    private function migrateOldFormat(): void
    {
        $dirty = false;
        foreach ($this->data as $name => $profile) {
            if (!isset($profile['username'])) continue;
            if (!is_array($profile['username'])) {
                $this->data[$name] = [
                    'username' => array_values(array_filter([$profile['username'] ?? $name])),
                    'ip'       => array_values(array_filter([($profile['ip']  ?? null)])),
                    'did'      => array_values(array_filter([($profile['did'] ?? null)])),
                    'ssid'     => [],
                ];
                $dirty = true;
            }
        }
        if ($dirty) $this->saveData("Alias");
    }

    // ─────────────────────────────────────────────────────────
    // Créer un profil (première connexion)
    // ─────────────────────────────────────────────────────────
    public function createProfil(PrismaPlayer $player): void
    {
        $this->data[$player->getName()] = [
            'username' => [$player->getName()],
            'ip'       => [$player->getNetworkSession()->getIp()],
            'did'      => [$player->getPlayerInfo()->getExtraData()['DeviceId'] ?? ''],
            'ssid'     => [],
        ];
        Manager::GRADE()->setDefaultGrade($player->getName());
        $this->saveData("Alias");
    }

    public function hasProfil(string $playerName): bool
    {
        return isset($this->data[$playerName]);
    }

    // ─────────────────────────────────────────────────────────
    // Mise à jour à chaque connexion :
    //   - Si au moins 1 info commune avec un profil existant → merge
    //   - Sinon → juste mettre à jour son propre profil
    // ─────────────────────────────────────────────────────────
    public function updateProfil(PrismaPlayer $player): void
    {
        $name = $player->getName();
        $ip   = $player->getNetworkSession()->getIp();
        $did  = $player->getPlayerInfo()->getExtraData()['DeviceId'] ?? '';
        $ssid = $player->getPlayerInfo()->getExtraData()['SelfSignedId'] ?? '';

        // Données du joueur lui-même
        if (!isset($this->data[$name])) {
            $this->createProfil($player);
            return;
        }

        // Merge dans son propre profil
        $this->mergeValues($this->data[$name], $name, $ip, $did, $ssid);

        // Chercher si une info commune existe avec d'autres profils
        foreach ($this->data as $otherName => $profile) {
            if ($otherName === $name) continue;

            $sharedIp   = !empty($ip)   && in_array($ip,   $profile['ip']   ?? [], true);
            $sharedDid  = !empty($did)  && in_array($did,  $profile['did']  ?? [], true);
            $sharedSsid = !empty($ssid) && in_array($ssid, $profile['ssid'] ?? [], true);
            $sharedUser = in_array($name, $profile['username'] ?? [], true);

            if ($sharedIp || $sharedDid || $sharedSsid || $sharedUser) {
                // Au moins 1 info commune → propager toutes les nouvelles infos
                $this->mergeValues($this->data[$otherName], $name, $ip, $did, $ssid);
                // Et récupérer les infos de l'autre vers le joueur
                foreach ($this->data[$otherName]['ip']   ?? [] as $v) $this->addIfMissing($this->data[$name]['ip'], $v);
                foreach ($this->data[$otherName]['did']  ?? [] as $v) $this->addIfMissing($this->data[$name]['did'], $v);
                foreach ($this->data[$otherName]['ssid'] ?? [] as $v) $this->addIfMissing($this->data[$name]['ssid'], $v);
                if (!in_array($otherName, $this->data[$name]['username'], true)) {
                    $this->data[$name]['username'][] = $otherName;
                }
            }
        }

        $this->saveData("Alias");
    }

    private function mergeValues(array &$profile, string $name, string $ip, string $did, string $ssid): void
    {
        if (!in_array($name, $profile['username'] ?? [], true)) $profile['username'][] = $name;
        if (!empty($ip)   && !in_array($ip,   $profile['ip']   ?? [], true)) $profile['ip'][]   = $ip;
        if (!empty($did)  && !in_array($did,  $profile['did']  ?? [], true)) $profile['did'][]  = $did;
        if (!empty($ssid) && !in_array($ssid, $profile['ssid'] ?? [], true)) $profile['ssid'][] = $ssid;
    }

    private function addIfMissing(array &$arr, string $val): void
    {
        if (!empty($val) && !in_array($val, $arr, true)) $arr[] = $val;
    }

    // ─────────────────────────────────────────────────────────
    // Récupère les données brutes d'un profil
    // ─────────────────────────────────────────────────────────
    public function getProfileData(PrismaPlayer|string $player): ?array
    {
        if ($player instanceof PrismaPlayer) return $this->data[$player->getName()] ?? null;
        return $this->data[$player] ?? null;
    }

    // ─────────────────────────────────────────────────────────
    // Retourne tous les comptes liés (autres noms dans le même profil
    // OU partageant au moins une IP/DID/SSID)
    // ─────────────────────────────────────────────────────────
    public function getAccounts(PrismaPlayer|string $player): array
    {
        $name    = $player instanceof PrismaPlayer ? $player->getName() : $player;
        $profile = $this->data[$name] ?? null;
        if ($profile === null) return [];

        $ips   = $profile['ip']   ?? [];
        $dids  = $profile['did']  ?? [];
        $ssids = $profile['ssid'] ?? [];
        $alts  = [];

        foreach ($this->data as $otherName => $info) {
            if (strtolower($otherName) === strtolower($name)) continue;

            // Déjà listé dans les username du profil
            if (in_array($otherName, $profile['username'] ?? [], true)) {
                $alts[] = $otherName;
                continue;
            }

            $sharedIp   = !empty(array_intersect($ips,   $info['ip']   ?? []));
            $sharedDid  = !empty(array_intersect($dids,  $info['did']  ?? []));
            $sharedSsid = !empty(array_intersect($ssids, $info['ssid'] ?? []));

            if ($sharedIp || $sharedDid || $sharedSsid) {
                $alts[] = $otherName;
            }
        }

        return array_unique($alts);
    }
}
