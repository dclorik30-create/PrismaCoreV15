<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use pocketmine\inventory\Inventory;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;

class ReclaimManager
{
    private const VALID_GRADES = ["noble", "heros", "dieu", "influenceur", "boutique"];

    private string $dataPath;

    /** @var array<string, list<array{nbt:string,amount:int,display:string}>> */
    private array $data = [];

    public function __construct()
    {
        $this->dataPath = \CarailleNoir\Core::getInstance()->getDataFolder() . "reclaim.json";
        $this->load();
    }

    // ─────────────────────────────── Persistance ──────────────────────────

    private function load(): void
    {
        if (!file_exists($this->dataPath)) {
            $this->data = [];
            return;
        }
        $this->data = json_decode(file_get_contents($this->dataPath), true) ?? [];
    }

    private function save(): void
    {
        file_put_contents($this->dataPath, json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    // ─────────────────────────────── Accesseurs ───────────────────────────

    public static function getValidGrades(): array
    {
        return self::VALID_GRADES;
    }

    /** Retourne les loots configurés pour un grade */
    public function getItems(string $grade): array
    {
        return $this->data[strtolower($grade)] ?? [];
    }

    // ─────────────────────────────── Sérialisation ────────────────────────

    private function itemToNbt(Item $item): string
    {
        $nbt  = new BigEndianNbtSerializer();
        $tree = new TreeRoot($item->nbtSerialize());
        return base64_encode($nbt->write($tree));
    }

    private function nbtToItem(string $nbt64): ?Item
    {
        try {
            $serializer = new BigEndianNbtSerializer();
            $tree       = $serializer->read(base64_decode($nbt64));
            return Item::nbtDeserialize($tree->mustGetCompoundTag());
        } catch (\Throwable) {
            return null;
        }
    }

    // ─────────────────────────────── Éditeur InvMenu ─────────────────────

    public function openEditorMenu(Player $player, string $grade): void
    {
        $grade = strtolower($grade);
        $menu  = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§6Reclaim §f{$grade} §8— §7Modifie puis ferme");

        // Pré-remplir avec les items actuels
        $inv  = $menu->getInventory();
        $slot = 0;
        foreach ($this->getItems($grade) as $loot) {
            if ($slot >= 54) break;
            $item = $this->nbtToItem($loot["nbt"]);
            if ($item !== null && !$item->isNull()) {
                $inv->setItem($slot, $item);
                $slot++;
            }
        }

        // Toutes les modifications autorisées
        $menu->setListener(function (InvMenuTransaction $tx): InvMenuTransactionResult {
            return $tx->continue();
        });

        // À la fermeture : sauvegarder
        $menu->setInventoryCloseListener(
            function (Player $p, Inventory $inv) use ($grade): void {
                $loots = [];
                foreach ($inv->getContents() as $item) {
                    if ($item->isNull()) continue;
                    $loots[] = [
                        "nbt"     => $this->itemToNbt($item),
                        "amount"  => $item->getCount(),
                        "display" => "§f" . $item->getName() . " x" . $item->getCount(),
                    ];
                }

                if (empty($loots)) {
                    $p->sendMessage("§cInventaire vide — reclaim §f{$grade}§c non modifié.");
                    return;
                }

                $this->data[$grade] = $loots;
                $this->save();
                $p->sendMessage("§a✔ Reclaim §f{$grade}§a mis à jour avec §e" . count($loots) . " item(s)§a.");
            }
        );

        $menu->send($player);
    }

    // ─────────────────────────────── Distribution ────────────────────────

    /**
     * Donne TOUS les items du reclaim d'un grade au joueur.
     * Retourne false si aucun item n'est configuré pour ce grade.
     */
    public function giveReclaim(Player $player, string $grade): bool
    {
        $grade = strtolower($grade);
        $loots = $this->getItems($grade);

        if (empty($loots)) {
            return false;
        }

        foreach ($loots as $loot) {
            $item = $this->nbtToItem($loot["nbt"]);
            if ($item === null || $item->isNull()) continue;

            $leftover = $player->getInventory()->addItem($item);
            foreach ($leftover as $drop) {
                $player->getWorld()->dropItem($player->getPosition(), $drop);
            }
        }

        return true;
    }
}
