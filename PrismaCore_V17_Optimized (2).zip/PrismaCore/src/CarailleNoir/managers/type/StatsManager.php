<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class StatsManager extends DataHandler
{
    /** Cache des tops — invalidé à chaque modification de stat */
    private array $topCache = [];

    public function init(): void
    {
        $this->loadData("Stats");
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = [
                "kills"          => 0,
                "deaths"         => 0,
                "power"          => 0,
                "assists"        => 0,
                "killstreak"     => 0,
                "bestkillstreak" => 0,
            ];
            $this->markDirty();
        } else {
            $this->data[$key] += [
                "assists"        => 0,
                "killstreak"     => 0,
                "bestkillstreak" => 0,
            ];
        }
    }

    public function addKill(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["kills"]++;
        $this->markDirty();
        $this->topCache = [];
    }

    public function getKills(string $player): int
    {
        return (int)($this->data[strtolower($player)]["kills"] ?? 0);
    }

    public function addDeath(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["deaths"]++;
        $this->markDirty();
        $this->topCache = [];
    }

    public function getDeaths(string $player): int
    {
        return (int)($this->data[strtolower($player)]["deaths"] ?? 0);
    }

    public function addPower(string $player, int $amount): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["power"] += $amount;
        $this->markDirty();
        $this->topCache = [];
    }

    public function removePower(string $player, int $amount): void
    {
        $this->ensurePlayer($player);
        $key = strtolower($player);
        $this->data[$key]["power"] = max(0, ($this->data[$key]["power"] ?? 0) - $amount);
        $this->markDirty();
        $this->topCache = [];
    }

    public function getPower(string $player): int
    {
        return (int)($this->data[strtolower($player)]["power"] ?? 0);
    }

    public function addAssist(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["assists"]++;
        $this->markDirty();
        $this->topCache = [];
    }

    public function getAssists(string $player): int
    {
        return (int)($this->data[strtolower($player)]["assists"] ?? 0);
    }

    public function incrementKillStreak(string $player): int
    {
        $this->ensurePlayer($player);
        $key    = strtolower($player);
        $streak = ++$this->data[$key]["killstreak"];
        if ($streak > (int)$this->data[$key]["bestkillstreak"]) {
            $this->data[$key]["bestkillstreak"] = $streak;
        }
        $this->markDirty();
        $this->topCache = [];
        return $streak;
    }

    public function resetKillStreak(string $player): void
    {
        $key = strtolower($player);
        if (isset($this->data[$key])) {
            $this->data[$key]["killstreak"] = 0;
            $this->markDirty();
        }
    }

    public function getKillStreak(string $player): int
    {
        return (int)($this->data[strtolower($player)]["killstreak"] ?? 0);
    }

    public function getBestKillStreak(string $player): int
    {
        return (int)($this->data[strtolower($player)]["bestkillstreak"] ?? 0);
    }

    public function getKDR(string $player): string
    {
        $k = $this->getKills($player);
        $d = $this->getDeaths($player);
        return $d === 0 ? (string)$k : number_format($k / $d, 2);
    }

    // ── Tops avec cache ────────────────────────────────────────────────────

    public function getTopKills(int $limit = 10): array
    {
        $key = "kills_{$limit}";
        if (!isset($this->topCache[$key])) {
            $sorted = $this->data;
            uasort($sorted, fn($a, $b) => ($b["kills"] ?? 0) <=> ($a["kills"] ?? 0));
            $this->topCache[$key] = array_slice($sorted, 0, $limit, true);
        }
        return $this->topCache[$key];
    }

    public function getTopDeaths(int $limit = 10): array
    {
        $key = "deaths_{$limit}";
        if (!isset($this->topCache[$key])) {
            $sorted = $this->data;
            uasort($sorted, fn($a, $b) => ($b["deaths"] ?? 0) <=> ($a["deaths"] ?? 0));
            $this->topCache[$key] = array_slice($sorted, 0, $limit, true);
        }
        return $this->topCache[$key];
    }

    public function getTopPower(int $limit = 10): array
    {
        $key = "power_{$limit}";
        if (!isset($this->topCache[$key])) {
            $sorted = $this->data;
            uasort($sorted, fn($a, $b) => ($b["power"] ?? 0) <=> ($a["power"] ?? 0));
            $this->topCache[$key] = array_slice($sorted, 0, $limit, true);
        }
        return $this->topCache[$key];
    }

    public function getTopAssists(int $limit = 10): array
    {
        $key = "assists_{$limit}";
        if (!isset($this->topCache[$key])) {
            $sorted = $this->data;
            uasort($sorted, fn($a, $b) => ($b["assists"] ?? 0) <=> ($a["assists"] ?? 0));
            $this->topCache[$key] = array_slice($sorted, 0, $limit, true);
        }
        return $this->topCache[$key];
    }

    public function getTopKillStreak(int $limit = 10): array
    {
        $key = "ks_{$limit}";
        if (!isset($this->topCache[$key])) {
            $sorted = $this->data;
            uasort($sorted, fn($a, $b) => ($b["bestkillstreak"] ?? 0) <=> ($a["bestkillstreak"] ?? 0));
            $this->topCache[$key] = array_slice($sorted, 0, $limit, true);
        }
        return $this->topCache[$key];
    }
}
