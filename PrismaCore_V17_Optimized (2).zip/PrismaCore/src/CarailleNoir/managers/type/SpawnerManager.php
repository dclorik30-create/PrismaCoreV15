<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use pocketmine\entity\Living;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\plugin\Plugin;
use pocketmine\world\Position;
use pocketmine\world\World;

class SpawnerManager
{
    private const SAVE_FILE    = "spawners.json";
    private const CLUSTER_RADIUS = 12.0;

    private static array $loots = [
        "zombie"   => [["item" => "rotten_flesh", "min" => 1, "max" => 2, "chance" => 100]],
        "skeleton" => [["item" => "bone",          "min" => 1, "max" => 2, "chance" => 100]],
        "creeper"  => [["item" => "gunpowder",     "min" => 1, "max" => 2, "chance" => 100]],
    ];
    private static array $prices = ["zombie" => 200, "skeleton" => 200, "creeper" => 300];

    /** @var array<string, array{type:string,world:string,x:int,y:int,z:int}> */
    private array $spawners = [];

    // ── Reverse index : entityId → type ──────────────────────
    /** @var array<int, string> */
    private array $entityTypeIndex = [];
    // ── Reverse index : "type:worldFolder:entityId" → Living ─
    /** @var array<string, Living> */
    private array $livingIndex = [];

    // ── Cluster cache ─────────────────────────────────────────
    /** @var array<string, array{clusterId:string,keys:string[]}> */
    private array $clusterCache = [];
    private bool $clusterDirty  = true;

    // ── Dirty flag pour save ──────────────────────────────────
    private bool $dirty = false;

    // ─────────────────────────────────────────────────────────
    private static function key(Position $pos): string
    {
        return $pos->getFloorX() . ':' . $pos->getFloorY() . ':' . $pos->getFloorZ() . ':' . $pos->getWorld()->getFolderName();
    }

    public function register(Position $pos, string $type): void
    {
        $this->spawners[self::key($pos)] = [
            'type'  => strtolower($type),
            'world' => $pos->getWorld()->getFolderName(),
            'x'     => $pos->getFloorX(),
            'y'     => $pos->getFloorY(),
            'z'     => $pos->getFloorZ(),
        ];
        $this->clusterDirty = true;
        $this->dirty        = true;
    }

    public function unregister(Position $pos): void
    {
        unset($this->spawners[self::key($pos)]);
        $this->clusterDirty = true;
        $this->dirty        = true;
    }

    public function isSpawner(Position $pos): bool  { return isset($this->spawners[self::key($pos)]); }
    public function getType(Position $pos): ?string  { return $this->spawners[self::key($pos)]['type'] ?? null; }
    public function getAllSpawners(): array           { return $this->spawners; }

    // ─────────────────────────────────────────────────────────
    // Cluster cache — recalculé seulement si un spawner a bougé
    // ─────────────────────────────────────────────────────────
    public function rebuildClusterCacheIfNeeded(): void
    {
        if (!$this->clusterDirty) return;

        $this->clusterCache = [];
        $r2 = self::CLUSTER_RADIUS * self::CLUSTER_RADIUS;

        foreach ($this->spawners as $key => $data) {
            if (isset($this->clusterCache[$key])) continue;

            // Trouver tous les spawners du même type/monde dans le rayon
            $near = [];
            foreach ($this->spawners as $k2 => $d2) {
                if ($d2['world'] !== $data['world'] || $d2['type'] !== $data['type']) continue;
                $dx = $d2['x'] - $data['x'];
                $dy = $d2['y'] - $data['y'];
                $dz = $d2['z'] - $data['z'];
                if (($dx*$dx + $dy*$dy + $dz*$dz) <= $r2) $near[] = $k2;
            }
            sort($near);
            $cid = $data['type'] . '|' . $data['world'] . '|' . implode('|', $near);

            foreach ($near as $k2) {
                $this->clusterCache[$k2] = ['clusterId' => $cid, 'keys' => $near];
            }
        }

        $this->clusterDirty = false;
    }

    /** Retourne les spawners du cluster (depuis le cache) */
    public function getCluster(string $spawnerKey): array
    {
        if (!isset($this->clusterCache[$spawnerKey])) return [$spawnerKey];
        return $this->clusterCache[$spawnerKey]['keys'];
    }

    public function getClusterId(string $spawnerKey): string
    {
        return $this->clusterCache[$spawnerKey]['clusterId'] ?? $spawnerKey;
    }

    // ─────────────────────────────────────────────────────────
    // Recherche d'entité stackable via reverse index — O(k) mobs du bon type
    // ─────────────────────────────────────────────────────────
    public function findStackableEntity(World $world, string $type, Position $center, float $radius = self::CLUSTER_RADIUS): ?Living
    {
        $r2     = $radius * $radius;
        $prefix = strtolower($type) . ':' . $world->getFolderName() . ':';

        foreach ($this->livingIndex as $k => $entity) {
            if (!str_starts_with($k, $prefix)) continue;

            // Nettoyage auto si mort/despawn
            if (!$entity->isAlive() || $entity->isFlaggedForDespawn()) {
                unset($this->livingIndex[$k]);
                continue;
            }

            $p  = $entity->getPosition();
            $dx = $p->x - $center->x;
            $dy = $p->y - $center->y;
            $dz = $p->z - $center->z;
            if (($dx*$dx + $dy*$dy + $dz*$dz) <= $r2) return $entity;
        }
        return null;
    }

    public function markEntityType(Living $entity, string $type): void
    {
        $type = strtolower($type);
        $eid  = $entity->getId();
        $this->entityTypeIndex[$eid] = $type;
        $lkey = $type . ':' . $entity->getWorld()->getFolderName() . ':' . $eid;
        $this->livingIndex[$lkey] = $entity;
    }

    public function getSpawnerTypeByEntity(int $eid): ?string
    {
        return $this->entityTypeIndex[$eid] ?? null;
    }

    public function onEntityDeath(int $eid): void
    {
        $type = $this->entityTypeIndex[$eid] ?? null;
        if ($type !== null) {
            // Nettoyer le reverse living index
            foreach ($this->livingIndex as $k => $_) {
                if (str_ends_with($k, ':' . $eid)) {
                    unset($this->livingIndex[$k]);
                    break;
                }
            }
        }
        unset($this->entityTypeIndex[$eid]);
    }

    public function isSpawnerMobOfType(Living $entity, string $type): bool
    {
        return match (strtolower($type)) {
            'zombie'   => $entity instanceof Zombie,
            'skeleton' => $entity instanceof Skeleton,
            'creeper'  => $entity instanceof Creeper,
            default    => false,
        };
    }

    // ─────────────────────────────────────────────────────────
    public function rollLoots(string $type, int $stack = 1): array
    {
        $r = [];
        foreach ((self::$loots[strtolower($type)] ?? []) as $l) {
            if (mt_rand(1, 100) <= $l['chance']) {
                $r[] = ['item' => $l['item'], 'amount' => min(mt_rand($l['min'], $l['max']) * $stack, 64)];
            }
        }
        return $r;
    }

    public function getPrice(string $type): int        { return self::$prices[strtolower($type)] ?? 200; }
    public function getAvailableTypes(): array          { return array_keys(self::$loots); }
    public function getLootsFor(string $type): array   { return self::$loots[strtolower($type)] ?? []; }

    public function makeSpawnerItem(string $type): Item
    {
        $item = StringToItemParser::getInstance()->parse("prisma:{$type}_spawner") ?? VanillaItems::BONE_MEAL();
        $item->setCount(1);
        return $item;
    }

    public function getSpawnerTypeFromItem(Item $item): ?string
    {
        foreach ($item->getLore() as $l) {
            if (str_starts_with($l, '§8ID:spawner_')) return mb_substr($l, 13);
        }
        return null;
    }

    public function buildNametag(string $type, int $stack): string
    {
        return match (strtolower($type)) {
            'zombie'   => "§2§lZombie §f§lx{$stack}",
            'skeleton' => "§7§lSquelette §f§lx{$stack}",
            'creeper'  => "§a§lCreeper §f§lx{$stack}",
            default    => '§f§l' . ucfirst($type) . " §f§lx{$stack}",
        };
    }

    // ─────────────────────────────────────────────────────────
    // Save : dirty flag — I/O seulement si nécessaire
    // ─────────────────────────────────────────────────────────
    public function saveIfDirty(Plugin $plugin): void
    {
        if (!$this->dirty) return;
        file_put_contents(
            $plugin->getDataFolder() . self::SAVE_FILE,
            json_encode(array_values($this->spawners), JSON_PRETTY_PRINT)
        );
        $this->dirty = false;
    }

    /** Force save (ex: onDisable) */
    public function save(Plugin $plugin): void
    {
        file_put_contents(
            $plugin->getDataFolder() . self::SAVE_FILE,
            json_encode(array_values($this->spawners), JSON_PRETTY_PRINT)
        );
        $this->dirty = false;
    }

    public function load(Plugin $plugin): void
    {
        $path = $plugin->getDataFolder() . self::SAVE_FILE;
        if (!file_exists($path)) return;
        foreach (json_decode(file_get_contents($path), true) ?? [] as $e) {
            if (!isset($e['world'], $e['type'], $e['x'], $e['y'], $e['z'])) continue;
            $type = strtolower((string)$e['type']);
            // Migration legacy "crééper" → "creeper"
            if ($type === 'crééper') $type = 'creeper';
            $key = $e['x'] . ':' . $e['y'] . ':' . $e['z'] . ':' . $e['world'];
            $this->spawners[$key] = [
                'type'  => $type,
                'world' => (string)$e['world'],
                'x'     => (int)$e['x'],
                'y'     => (int)$e['y'],
                'z'     => (int)$e['z'],
            ];
        }
        $this->clusterDirty = true;
    }
}
