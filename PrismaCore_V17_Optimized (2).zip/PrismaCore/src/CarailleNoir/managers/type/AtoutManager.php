<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class AtoutManager extends DataHandler
{
 // Atouts : speed, force, resis, antiitem
 public function init(): void
 {
 $this->loadData("Atout");
        $this->markDirty();
 }

 public function hasAtout(string $player, string $atout): bool
 {
 return in_array($atout, $this->data[strtolower($player)]["owned"] ?? $this->data[strtolower($player)] ?? [], true);
 }

 public function addAtout(string $player, string $atout): void
 {
 $key = strtolower($player);
 $this->migratePlayer($key);
 if (!in_array($atout, $this->data[$key]["owned"], true)) {
 $this->data[$key]["owned"][] = $atout;
        $this->markDirty();
 }
 // Activer par défaut à l'achat
 $this->data[$key]["disabled"] = array_values(array_filter($this->data[$key]["disabled"], fn($a) => $a !== $atout));
 }

 public function removeAtout(string $player, string $atout): void
 {
 $key = strtolower($player);
 $this->migratePlayer($key);
 $this->data[$key]["owned"] = array_values(array_filter($this->data[$key]["owned"], fn($a) => $a !== $atout));
        $this->markDirty();
 $this->data[$key]["disabled"] = array_values(array_filter($this->data[$key]["disabled"], fn($a) => $a !== $atout));
 }

 public function isAtoutActive(string $player, string $atout): bool
 {
 $key = strtolower($player);
 $this->migratePlayer($key);
 return in_array($atout, $this->data[$key]["owned"], true)
 && !in_array($atout, $this->data[$key]["disabled"], true);
 }

 public function setAtoutActive(string $player, string $atout, bool $active): void
 {
 $key = strtolower($player);
 $this->migratePlayer($key);
 if ($active) {
 $this->data[$key]["disabled"] = array_values(array_filter($this->data[$key]["disabled"], fn($a) => $a !== $atout));
 } else {
 if (!in_array($atout, $this->data[$key]["disabled"], true)) {
 $this->data[$key]["disabled"][] = $atout;
        $this->markDirty();
 }
 }
 }

 public function getAtouts(string $player): array
 {
 $key = strtolower($player);
 $this->migratePlayer($key);
 return $this->data[$key]["owned"] ?? [];
 }

 public function hasAntiItemProtection(string $player): bool
 {
 return $this->isAtoutActive($player, "antiitem");
 }

 private function migratePlayer(string $key): void
 {
 // Migration depuis ancien format (array de strings)
 if (!isset($this->data[$key])) {
 $this->data[$key] = ["owned" => [], "disabled" => []];
 } elseif (is_array($this->data[$key]) && !isset($this->data[$key]["owned"])) {
 $this->data[$key] = ["owned" => array_values($this->data[$key]), "disabled" => []];
 }
 }
}
