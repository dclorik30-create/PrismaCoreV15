<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\libs\forms\CustomForm;
use pocketmine\scheduler\ClosureTask;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\player\Player;
use pocketmine\Server;

class SanctionManager extends DataHandler
{

 public function init(): void { $this->loadData("Sanction");
        $this->markDirty(); }

 public function releaseAction(string $type, string $target, string $staffName): void
 {
 $server = Server::getInstance();
 $staffPlayer = $server->getPlayerExact($staffName);
 $targetPlayer = $server->getPlayerExact($target);
 if (!$staffPlayer instanceof PrismaPlayer) return;

 switch ($type) {
 case "warn":
 Manager::WARN()->incrementWarn($target);
 $staffPlayer->sendMessage("§e+1 avertissement §fajouté à §6$target");
 $targetPlayer?->sendMessage("§cVous avez reçu un avertissement d'un staff.");
 break;

 case "kick":
 if (!$targetPlayer instanceof PrismaPlayer) {
 $staffPlayer->sendMessage("§c$target n'est plus en ligne.");
 return;
 }
 Manager::WARN()->incrementKick($target);
 $targetPlayer->kick("§cTu as été expulsé par §6$staffName.");
 $staffPlayer->sendMessage("§a$target §fa été expulsé.");
 break;

 case "mute":
 $this->openMuteForm($staffPlayer, $target);
 break;

 case "unmute":
 if (!Manager::MUTE()->isMuted($target)) {
 $staffPlayer->sendMessage("§f$target §an'est pas mute.");
 return;
 }
 Manager::MUTE()->removeMute($target, "Démute via menu sanction", $staffName);
 $staffPlayer->sendMessage("§a$target §fa été démute.");
 break;

 case "tig":
 $this->openTIGForm($staffPlayer, $target);
 break;

 case "untig":
 if (!Manager::TIG()->isTIG($target)) {
 $staffPlayer->sendMessage("§f$target §an'est pas en TIG.");
 return;
 }
 Manager::TIG()->removeTIG($target);
 $staffPlayer->sendMessage("§a$target §fa été libéré de la TIG.");
 break;
 }
 }


 // ── Parser de durée : "1d", "2h30m", "1d12h30m", "90s", "0" (permanent) ──

 private function parseDuration(string $s): ?int
 {
 $s = strtolower(trim($s));
 if ($s === "0" || str_starts_with($s, "perm")) return null;
 $total = 0;
 preg_match_all('/(\d+)(d|h|m|s)/', $s, $m, PREG_SET_ORDER);
 foreach ($m as $x) {
 $total += match($x[2]) {
 'd' => (int)$x[1] * 86400,
 'h' => (int)$x[1] * 3600,
 'm' => (int)$x[1] * 60,
 's' => (int)$x[1],
 };
 }
 return $total > 0 ? $total : null;
 }

 public function openMuteForm(PrismaPlayer $staff, string $target): void
 {
 $mgr = $this;
 \CarailleNoir\Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new ClosureTask(function() use ($staff, $target, $mgr): void {
 $form = new CustomForm(function(PrismaPlayer $player, ?array $data) use ($target, $mgr): void {
 if ($data === null) return;
 $raw = trim((string)($data["duree"] ?? "1h"));
 $raison = trim((string)($data["raison"] ?? "Mute via staff"));
 if ($raison === "") $raison = "Mute via staff";
 $dur = $mgr->parseDuration($raw);
 Manager::MUTE()->addMute($target, $raison, $player->getName(), $dur);
 $player->sendMessage("§b$target §fmuté §e" . ($dur !== null ? $raw : "permanent") . " §f— §7$raison");
 });
 $form->setTitle("§c[MUTE] §f" . $target);
 $form->addLabel("§fDurée : §e1d§7, §e2h30m§7, §e90s §7— §c0 §f= permanent");
 $form->addInput("Durée", "ex: 1d, 2h30m, 0", "1h", "duree");
 $form->addInput("Raison", "ex: spam, insultes...", "Mute via staff", "raison");
 $staff->sendForm($form);
 }),
 2
 );
 }

 private function openTIGForm(PrismaPlayer $staff, string $target): void
 {
 $mgr = $this;
 \CarailleNoir\Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new ClosureTask(function() use ($staff, $target, $mgr): void {
 $form = new CustomForm(function(PrismaPlayer $player, ?array $data) use ($target, $mgr): void {
 if ($data === null) return;
 $raw = trim((string)($data["duree"] ?? "1d"));
 $raison = trim((string)($data["raison"] ?? "TIG via staff"));
 if ($raison === "") $raison = "TIG via staff";
 $dur = $mgr->parseDuration($raw);
 $durSec = $dur ?? (86400 * 365 * 10);
 Manager::TIG()->addTIG($target, $durSec, $raison, $player->getName());
 $player->sendMessage("§6$target §fplacé en TIG §e" . ($dur !== null ? $raw : "permanent") . " §f— §7$raison");
 });
 $form->setTitle("§6[TIG] §f" . $target);
 $form->addLabel("§fDurée : §e1d§7, §e2h30m§7, §e90s §7— §c0 §f= permanent");
 $form->addInput("Durée", "ex: 1d, 2h30m, 0", "1d", "duree");
 $form->addInput("Raison", "ex: grief, insultes...", "TIG via staff", "raison");
 $staff->sendForm($form);
 }),
 2
 );
 }
}
