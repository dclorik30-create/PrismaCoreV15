<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\tasks\NameTagTask;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\world\particle\HugeExplodeParticle;
use pocketmine\world\particle\DustParticle;
use pocketmine\world\sound\XpCollectSound;
use pocketmine\world\sound\TotemUseSound;
use pocketmine\color\Color;

class LevelManager
{
    public const MAX_LEVEL = 100;

    /** @var array<int,int> level => exp_requise */
    private array $levelData = [];

    /** Cache de xp_sources.yml — chargé une seule fois au démarrage */
    private array $xpSources = [];

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . "levels.yml", Config::YAML);
        foreach ((array)$cfg->get("levels", []) as $lvl => $xp) {
            $this->levelData[(int)$lvl] = (int)$xp;
        }
        // Cache xp_sources une seule fois — évite new Config() à chaque kill
        $src = new Config($dataFolder . "xp_sources.yml", Config::YAML);
        $this->xpSources = (array)$src->getAll();
    }

    public function getXpSource(string $category, string $key, int $default = 0): int
    {
        return (int)((($this->xpSources[$category] ?? [])[$key]) ?? $default);
    }

    public function getRequiredExp(int $level): int
    {
        return $this->levelData[$level] ?? 999999;
    }

    public function addExp(Player $player, int $amount, string $source = ""): void
    {
        $name  = $player->getName();
        $level = Manager::LEVEL_DATA()->getLevel($name);

        if ($level >= self::MAX_LEVEL) return;

        $player->sendTip("§e+ §6" . $amount . " §eEXP" . ($source !== "" ? " §7(" . $source . ")" : ""));

        $currentExp = Manager::LEVEL_DATA()->getExp($name) + $amount;

        while ($level < self::MAX_LEVEL) {
            $required = $this->getRequiredExp($level);
            if ($currentExp < $required) break;
            $currentExp -= $required;
            $level++;
            Manager::LEVEL_DATA()->setLevel($name, $level);
            $this->onLevelUp($player, $level);
        }

        Manager::LEVEL_DATA()->setExp($name, $currentExp);
    }

    private function onLevelUp(Player $player, int $newLevel): void
    {
        $player->sendTitle("§6§l✦ NIVEAU " . $newLevel . " ✦", "§e§lFélicitations ! Vous montez en puissance !", 10, 70, 20);
        $player->sendMessage(
            "§8[§6Niveau§8] §fVous avez atteint le §6niveau {$newLevel}§f !" .
            " §7Récupérez votre récompense avec §f/niveau§7."
        );
        $player->sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");
        $player->sendMessage("§e§lBravo ! §fVous venez de passer au §6niveau {$newLevel}§f !");
        $player->sendMessage("§7Continuez à miner, farmer et combattre pour progresser.");
        $player->sendMessage("§6§l▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬▬");

        $world = $player->getWorld();
        $center = $player->getPosition()->add(0, 1, 0);
        $world->addParticle($center, new HugeExplodeParticle());
        for ($i = 0; $i < 16; $i++) {
            $world->addParticle($center->add(lcg_value() * 2 - 1, lcg_value() * 2, lcg_value() * 2 - 1), new DustParticle(new Color(255, 215, 0)));
        }
        $world->addSound($center, new TotemUseSound());
        $world->addSound($center, new XpCollectSound());

        if ($newLevel === self::MAX_LEVEL) {
            $player->sendMessage("§6§l★ Félicitations, vous avez atteint le niveau maximum (100) ! ★");
        }
        if ($player instanceof PrismaPlayer) {
            $player->setNameTag(NameTagTask::buildTag($player));
            $player->setNameTagAlwaysVisible(true);
        }
    }

    public function getLevel(string $player): int  { return Manager::LEVEL_DATA()->getLevel($player); }
    public function getExp(string $player): int    { return Manager::LEVEL_DATA()->getExp($player); }

    public function getProgressBar(string $player): string
    {
        $level  = Manager::LEVEL_DATA()->getLevel($player);
        $exp    = Manager::LEVEL_DATA()->getExp($player);
        $req    = $this->getRequiredExp($level);
        $pct    = $req > 0 ? min(1.0, $exp / $req) : 1.0;
        $filled = (int)round($pct * 20);
        $bar    = str_repeat("§a|", $filled) . str_repeat("§7|", 20 - $filled);
        return "§7[{$bar}§7] §f" . number_format($exp) . "§7/§f" . number_format($req) . " §7EXP";
    }

    public function setLevel(string $player, int $level, int $exp = 0): void
    {
        Manager::LEVEL_DATA()->setLevel($player, min(self::MAX_LEVEL, max(1, $level)));
        Manager::LEVEL_DATA()->setExp($player, max(0, $exp));
    }

    public function save(string $player): void    { Manager::LEVEL_DATA()->save($player); }
    public function saveAll(): void               { Manager::LEVEL_DATA()->saveAll(); }
}
