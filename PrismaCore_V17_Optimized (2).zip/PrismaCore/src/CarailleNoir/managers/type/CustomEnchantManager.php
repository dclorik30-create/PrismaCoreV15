<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Armor;
use pocketmine\item\Axe;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\items\PickaxeOfGodManager;
use pocketmine\item\Bow;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Hoe;
use pocketmine\item\Item;
use pocketmine\item\Pickaxe;
use pocketmine\item\Shovel;
use pocketmine\item\Sword;

class CustomEnchantManager
{
 /** type => "custom" (NBT+effet) ou "vanilla" (addEnchantment) */
 private const ENCHANTS = [
 // prices[] = [niv1, niv2, niv3, ...] — prix fixe par niveau (pas multiplicatif)
 // ── Custom (potion effects) ───────────────────────────────────────
 "speed"      => ["label" => "§bSpeed",       "prices" => [1000, 500000],           "maxLevel" => 2, "type" => "custom"],
 "force"      => ["label" => "§cForce",       "prices" => [250000, 750000],          "maxLevel" => 2, "type" => "custom"],
 "resistance" => ["label" => "§aRésistance",  "prices" => [100000, 500000],          "maxLevel" => 2, "type" => "custom"],
 "haste"      => ["label" => "§eHaste",       "prices" => [1000, 10000, 100000],     "maxLevel" => 3, "type" => "custom"],
 // ── Vanilla ──────────────────────────────────────────────────────
 "protection" => ["label" => "§9Protection",  "prices" => [600, 1200, 1800, 2400],   "maxLevel" => 4, "type" => "vanilla"],
 "solidite"   => ["label" => "§6Solidité",    "prices" => [700, 1400, 2100],         "maxLevel" => 3, "type" => "vanilla"],
 "tranchant"  => ["label" => "§cTranchant",   "prices" => [650, 1300, 1950, 2600, 3250], "maxLevel" => 5, "type" => "vanilla"],
 "punch"      => ["label" => "§dPunch",       "prices" => [1200, 2400],              "maxLevel" => 2, "type" => "vanilla"],
 "efficacite" => ["label" => "§eEfficacité",  "prices" => [550, 1100, 1650, 2200, 2750], "maxLevel" => 5, "type" => "vanilla"],
 ];
 private const NBT_KEY = "CustomEnchants";

 public function getAll(): array { return self::ENCHANTS; }
 public function getEnchant(string $id): ?array { return self::ENCHANTS[strtolower($id)] ?? null; }
 public function getPrice(string $id, int $level = 1): int
 {
 $e = self::ENCHANTS[strtolower($id)] ?? null;
 if ($e === null) return 0;
 // Nouveau système : prix fixe par niveau via prices[]
 return (int)($e["prices"][$level - 1] ?? 0);
 }
 public function getMaxLevel(string $id): int { return self::ENCHANTS[strtolower($id)]["maxLevel"] ?? 1; }
 public function isVanilla(string $id): bool { return (self::ENCHANTS[strtolower($id)]["type"] ?? "") === "vanilla"; }

 // ── Méthodes NBT (custom enchants) ──────────────────────────────────
 public function getItemEnchants(Item $item): array
 {
 $raw = $item->getNamedTag()->getString(self::NBT_KEY, "");
 return $raw === "" ? [] : (json_decode($raw, true) ?? []);
 }

 // ── Lecture vanilla ──────────────────────────────────────────────────
 private function getVanillaEnchantment(string $id): ?\pocketmine\item\enchantment\Enchantment
 {
 return match (strtolower($id)) {
 "protection" => VanillaEnchantments::PROTECTION(),
 "solidite" => VanillaEnchantments::UNBREAKING(),
 "tranchant" => VanillaEnchantments::SHARPNESS(),
 "punch" => VanillaEnchantments::PUNCH(),
 "efficacite" => VanillaEnchantments::EFFICIENCY(),
 default => null,
 };
 }

 public function getLevel(Item $item, string $id): int
 {
 $id = strtolower($id);
 if ($this->isVanilla($id)) {
 $enc = $this->getVanillaEnchantment($id);
 if ($enc === null) return 0;
 return $item->getEnchantment($enc)?->getLevel() ?? 0;
 }
 return (int)($this->getItemEnchants($item)[$id] ?? 0);
 }

 public function hasEnchant(Item $item, string $id): bool { return $this->getLevel($item, $id) > 0; }

 public function isEnchantAllowedOnItem(Item $item, string $id): bool
 {
 $id = strtolower($id);
 if (PickaxeOfGodManager::isPog($item)) {
 return false;
 }
 if (SpecialItems::isArcPunch($item)) {
 return $id === "punch"; // L'arc-punch custom n'a pas Solidité (pas de durabilité)
 }
 if ($item instanceof Bow) {
 return in_array($id, ["punch", "solidite"], true); // arcs vanilla
 }
 if ($item instanceof Armor) {
 return match ($id) {
 "speed" => $item->getArmorSlot() === ArmorInventory::SLOT_FEET,
 "resistance" => $item->getArmorSlot() === ArmorInventory::SLOT_CHEST,
 "force" => $item->getArmorSlot() === ArmorInventory::SLOT_LEGS,
 "haste" => $item->getArmorSlot() === ArmorInventory::SLOT_HEAD,
 "protection", "solidite" => true,
 default => false,
 };
 }
 if ($item instanceof Sword) {
 return in_array($id, ["tranchant", "solidite"], true);
 }
 if ($item instanceof Pickaxe || $item instanceof Shovel || $item instanceof Hoe || $item instanceof Axe) {
 return in_array($id, ["efficacite", "solidite"], true);
 }
 return false;
 }

 public function setItemEnchant(Item $item, string $id, int $level): Item
 {
 $id = strtolower($id);
 if (!$this->isEnchantAllowedOnItem($item, $id)) return $item;
 $level = max(1, min($level, $this->getMaxLevel($id)));

 if ($this->isVanilla($id)) {
 $enc = $this->getVanillaEnchantment($id);
 if ($enc === null) return $item;
 $item->addEnchantment(new EnchantmentInstance($enc, $level));
 } else {
 $enchants = $this->getItemEnchants($item);
 $enchants[$id] = $level;
 $item->getNamedTag()->setString(self::NBT_KEY, json_encode($enchants));
 $this->refreshCustomLore($item, $enchants);
 }
 return $item;
 }

 public function removeItemEnchant(Item $item, string $id): Item
 {
 $id = strtolower($id);
 if ($this->isVanilla($id)) {
 $enc = $this->getVanillaEnchantment($id);
 if ($enc !== null) $item->removeEnchantment($enc);
 } else {
 $enchants = $this->getItemEnchants($item);
 unset($enchants[$id]);
 $item->getNamedTag()->setString(self::NBT_KEY, json_encode($enchants));
 $this->refreshCustomLore($item, $enchants);
 }
 return $item;
 }

 private function refreshCustomLore(Item $item, array $customEnchants): void
 {
 $lore = array_values(array_filter($item->getLore(), fn($l) => str_contains($l, "§8tier:")));
 foreach ($customEnchants as $id => $lvl) {
 $e = self::ENCHANTS[$id] ?? null;
 if ($e !== null && $e["type"] === "custom") $lore[] = $e["label"] . " §7Niv." . $lvl;
 }
 $item->setLore($lore);
 }

 public function buildFormButtons(Item $item): array
 {
 $buttons = [];
 foreach (self::ENCHANTS as $id => $e) {
 if (!$this->isEnchantAllowedOnItem($item, $id)) continue;
 $current = $this->getLevel($item, $id);
 $max = $e["maxLevel"];
 $priceNL = $this->getPrice($id, $current + 1);
 $status = $current > 0 ? "§aNiv." . $current : "§7Non appliqué";
 $label = $e["label"] . " — " . $status;
 $label .= $current < $max ? "\n§7Prochain niveau : §e{$priceNL}§6$" : "\n§cNiveau max atteint";
 $buttons[] = ["id" => $id, "text" => $label, "current" => $current, "max" => $max, "price" => $priceNL];
 }
 return $buttons;
 }
}
