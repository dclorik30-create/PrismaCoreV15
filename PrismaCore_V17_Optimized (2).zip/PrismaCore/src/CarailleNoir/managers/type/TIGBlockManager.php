<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use pocketmine\block\VanillaBlocks;
use pocketmine\scheduler\ClosureTask;
use pocketmine\Server;
use pocketmine\world\World;

class TIGBlockManager
{
    // TIGBlockTask tourne toutes les 20 ticks = ~1 appel/seconde => 30 appels = 30s
    private const BEDROCK_TO_GOLD_CALLS = 30;
    private const MONEY_REWARD          = 10;

    /** @var array<string,true> cles "x,y,z" des positions de blocs d'or enregistrees */
    private array $trackedPositions = [];

    /** @var array<string,int> "x,y,z" => callCount cible pour passer bedrock -> bloc d'or */
    private array $pendingRespawns = [];

    private int $callCount = 0;

    // -----------------------------------------------------------------
    public function init(): void
    {
        $path = Core::getInstance()->getDataFolder() . "TIGBlocks.json";
        if (!file_exists($path)) {
            Core::getInstance()->saveResource("TIGBlocks.json");
        }
        $raw = json_decode(file_get_contents($path), true) ?? [];
        $this->trackedPositions = [];
        foreach ($raw["coordinates"] ?? [] as $coord) {
            $this->trackedPositions[$this->key((int)$coord["x"], (int)$coord["y"], (int)$coord["z"])] = true;
        }
    }

    public function getMoneyReward(): int { return self::MONEY_REWARD; }

    /** Appele par /mineinitialize tig */
    public function savePositions(array $positions): void
    {
        $this->trackedPositions = [];
        $this->pendingRespawns  = [];
        foreach ($positions as $coord) {
            $this->trackedPositions[$this->key((int)$coord["x"], (int)$coord["y"], (int)$coord["z"])] = true;
        }
        file_put_contents(
            Core::getInstance()->getDataFolder() . "TIGBlocks.json",
            json_encode(["coordinates" => $positions], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    public function isTracked(int $x, int $y, int $z): bool
    {
        return isset($this->trackedPositions[$this->key($x, $y, $z)]);
    }

    // -----------------------------------------------------------------
    /**
     * Appele depuis PlayerListener apres qu'un joueur TIG a casse un bloc d'or.
     * On schedule la pose de bedrock au tick suivant (apres que PM5 ait fini
     * de traiter le BlockBreakEvent et remis le bloc en AIR cote serveur).
     * Puis on planifie le retour du bloc d'or 30 secondes plus tard.
     */
    public function notifyBroken(int $x, int $y, int $z): void
    {
        $key = $this->key($x, $y, $z);

        // Poser la bedrock au tick suivant pour eviter le conflit avec PM5
        Core::getInstance()->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function() use ($x, $y, $z, $key): void {
                $world = $this->getTIGWorld();
                if ($world === null) return;
                $world->setBlockAt($x, $y, $z, VanillaBlocks::BEDROCK());
                $this->pendingRespawns[$key] = $this->callCount + self::BEDROCK_TO_GOLD_CALLS;
            }),
            1 // 1 tick de delai
        );
    }

    // -----------------------------------------------------------------
    /** Appele par TIGBlockTask toutes les 20 ticks (~1 seconde) */
    public function tick(): void
    {
        $this->callCount++;
        if (empty($this->pendingRespawns)) return;

        $world = $this->getTIGWorld();
        if ($world === null) return;

        foreach ($this->pendingRespawns as $key => $readyAt) {
            if ($this->callCount < $readyAt) continue;

            [$x, $y, $z] = explode(',', $key, 3);
            $ix = (int)$x; $iy = (int)$y; $iz = (int)$z;

            if (!isset($this->trackedPositions[$key])) {
                unset($this->pendingRespawns[$key]);
                continue;
            }

            $world->setBlockAt($ix, $iy, $iz, VanillaBlocks::GOLD());
            unset($this->pendingRespawns[$key]);
        }
    }

    // -----------------------------------------------------------------
    private function key(int $x, int $y, int $z): string { return "$x,$y,$z"; }

    private function getTIGWorld(): ?World
    {
        $wm      = Server::getInstance()->getWorldManager();
        $tigName = TIGManager::TIG_WORLD;
        if (!$wm->isWorldLoaded($tigName)) {
            $wm->loadWorld($tigName);
        }
        $world = $wm->getWorldByName($tigName);
        if ($world !== null) return $world;
        // Fallback insensible a la casse (Linux)
        foreach ($wm->getWorlds() as $w) {
            if (strtolower($w->getFolderName()) === strtolower($tigName)) return $w;
        }
        return null;
    }
}
