<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\Item;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class HdvManager extends DataHandler
{
 /** Slots max selon le grade (grade ID => slots) */
 private const SLOTS_BY_GRADE = [
  "joueur"          => 3,
  "vote"            => 3,
  "noble"           => 5,
  "heros"           => 8,
  "héros"           => 8,
  "dieu"            => 15,
  "influenceur"     => 8,
  "guide"           => 5,
  "modérateur"      => 15,
  "administrateur"  => 15,
  "fondateur"       => 15,
  "default"         => 3,
 ];

 /** Taxe (%) selon le grade */
 private const TAX_BY_GRADE = [
 "default" => 10,
 "vip" => 8,
 "vip+" => 6,
 "youtuber" => 5,
 "staff" => 0,
 "modo" => 0,
 "admin" => 0,
 ];

 public function init(): void
 {
 $this->loadData("HDV");
        $this->markDirty();
 }

 // ── Accès aux slots ───────────────────────────────────────

 public function getSlots(string $gradeId, ?\pocketmine\player\Player $player = null): int
 {
  // Vérifier d'abord les permissions prisma.hdv.slots.X
  if ($player !== null) {
   foreach ([15, 8, 5, 3] as $slots) {
    if ($player->hasPermission("prisma.hdv.slots.{$slots}")) {
     return $slots;
    }
   }
  }
  $key = strtolower($gradeId);
  return self::SLOTS_BY_GRADE[$key] ?? self::SLOTS_BY_GRADE["default"];
 }

 public function getUsedSlots(string $playerName): int
 {
 return count(array_filter($this->data, fn($l) => strtolower($l["seller"]) === strtolower($playerName)));
 }

 // ── CRUD annonces ─────────────────────────────────────────

 public function addListing(PrismaPlayer $seller, Item $item, float $price): bool
 {
 $gradeId = $seller->getGradeId();
 if ($this->getUsedSlots($seller->getName()) >= $this->getSlots($gradeId, $seller)) {
 return false;
 }

 $encoded = self::itemToNbt($item);
 if ($encoded === "") return false;

 $id = $this->nextId();
 $this->data[$id] = [
 "id" => $id,
 "seller" => $seller->getName(),
 "itemData" => $encoded,
 "itemCount" => $item->getCount(),
 "item_name" => $item->getName(),
 "price" => $price,
 "created" => time(),
 ];
 $this->saveData();
 return true;
 }

 public function getListing(int $id): ?array
 {
 return $this->data[$id] ?? null;
 }

 public function getListings(): array
 {
 return $this->data;
 }

 public function withdrawListing(PrismaPlayer $player, int $id): bool
 {
 $listing = $this->getListing($id);
 if ($listing === null) return false;
 if (strtolower($listing["seller"]) !== strtolower($player->getName())) return false;

 try {
 $item = self::itemFromNbt($listing["itemData"]);
 if ($item instanceof Item) { $player->getInventory()->addItem($item); }
 } catch (\Throwable) {}

 unset($this->data[$id]);
 $this->saveData();
 return true;
 }

 public function buyListing(PrismaPlayer $buyer, int $id): bool
 {
 $listing = $this->getListing($id);
 if ($listing === null) return false;

 $price = (float)$listing["price"];
 if (!$buyer->hasMoney($price)) return false;

 $tax = self::TAX_BY_GRADE[strtolower($buyer->getGradeId())] ?? self::TAX_BY_GRADE["default"];
 $net = $price * (1 - $tax / 100);

 $buyer->removeMoney($price);

 // Créditer le vendeur s'il est en ligne, sinon via EconomyManager
 $sellerName = $listing["seller"];
 $onlineSeller = \pocketmine\Server::getInstance()->getPlayerExact($sellerName);
 if ($onlineSeller instanceof PrismaPlayer) {
 $onlineSeller->addMoney($net);
 } else {
 \CarailleNoir\managers\Manager::ECONOMY()->addMoney($sellerName, $net);
 }

 try {
 $item = self::itemFromNbt($listing["itemData"]);
 if ($item instanceof Item) { $buyer->getInventory()->addItem($item); }
 } catch (\Throwable) {}

 unset($this->data[$id]);
 $this->saveData();
 return true;
 }

 // ── Sérialisation NBT (PM5 compatible — serialize() interdit sur enchantements) ─

 private static function itemToNbt(Item $item): string
 {
 try {
 return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())));
 } catch (\Throwable) {
 return "";
 }
 }

 public static function decodeItemData(string $data): ?Item
 {
 return self::itemFromNbt($data);
 }

 private static function itemFromNbt(string $data): ?Item
 {
 try {
 $raw = base64_decode($data, true);
 if ($raw === false || $raw === "") return null;
 $tag = (new BigEndianNbtSerializer())->read($raw)->mustGetCompoundTag();
 return Item::nbtDeserialize($tag);
 } catch (\Throwable) {
 return null;
 }
 }

 // ── Helpers ───────────────────────────────────────────────

 private function nextId(): int
 {
 return empty($this->data) ? 1 : max(array_keys($this->data)) + 1;
 }
}
