<?php

namespace CarailleNoir\managers\option;

enum RegionOption: string
{
 case PARAM_PVP = "pvp" ;
 case PARAM_BUILD = "build";
 case PARAM_INTERACT = "interact";
 case PARAM_GROW = "grow";
 case PARAM_DROP = "drop";
 case PARAM_PICKUP = "pickup";
 case PARAM_EXPLOSION = "explosion";
 case PARAM_HUNGER = "hunger";
 case PARAM_ENDERPEARL = "enderpearl";
 case PARAM_CHAT = "chat";
 case PARAM_DECAY = "decay";
 case PARAM_USE = "use";


 case PARAM_FIRE_DAMAGE = "fire_damage";
 case PARAM_FALL_DAMAGE = "fall_damage";


 public function getType(): string {
 return "region.setting." . $this->value;
 }
}