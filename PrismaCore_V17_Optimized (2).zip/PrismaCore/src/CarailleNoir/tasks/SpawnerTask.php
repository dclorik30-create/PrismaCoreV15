<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\Core;
use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\managers\Manager;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\Position;

class SpawnerTask extends Task
{
    private const MAX_STACK        = 20000;
    private const MOBS_PER_SPAWNER = 3;
    private const SPAWN_RANGE_SQ   = 32 * 32;  // rayon joueur = 32 blocs

    /** @var array<string, bool> clusters déjà traités ce tick */
    private array $processed = [];

    public function onRun(): void
    {
        $this->processed = [];
        $spawnerMgr = Manager::SPAWNER();
        $wm         = Server::getInstance()->getWorldManager();

        // Rebuild cluster cache si un spawner a été posé/cassé depuis le dernier tick
        $spawnerMgr->rebuildClusterCacheIfNeeded();

        foreach ($spawnerMgr->getAllSpawners() as $key => $data) {
            $worldName = $data['world'];
            if (!$wm->isWorldLoaded($worldName)) continue;
            $world = $wm->getWorldByName($worldName);
            if ($world === null) continue;

            $pos = new Position((int)$data['x'], (int)$data['y'], (int)$data['z'], $world);

            // Skip si chunk non chargé
            if (!$world->isChunkLoaded($pos->getFloorX() >> 4, $pos->getFloorZ() >> 4)) continue;

            // Skip si aucun joueur dans un rayon de 32 blocs
            $hasPlayer = false;
            foreach ($world->getPlayers() as $p) {
                $pp  = $p->getPosition();
                $ddx = $pp->x - $pos->x;
                $ddz = $pp->z - $pos->z;
                if (($ddx * $ddx + $ddz * $ddz) <= self::SPAWN_RANGE_SQ) {
                    $hasPlayer = true;
                    break;
                }
            }
            if (!$hasPlayer) continue;

            // Cluster (depuis le cache — O(1))
            $type      = $data['type'];
            $clusterId = $spawnerMgr->getClusterId($key);

            if (isset($this->processed[$clusterId])) continue;
            $this->processed[$clusterId] = true;

            $clusterKeys  = $spawnerMgr->getCluster($key);
            $spawnAmount  = max(1, count($clusterKeys) * self::MOBS_PER_SPAWNER);

            // Chercher une entité existante à stacker (via reverse index — O(k))
            $entity = $spawnerMgr->findStackableEntity($world, $type, $pos, 12.0);

            if ($entity !== null) {
                $entity->stack = min(self::MAX_STACK, $entity->stack + $spawnAmount);
                $newMax = max(20, 20 * $entity->stack);
                $entity->setMaxHealth($newMax);
                $entity->setHealth($newMax);
                $entity->setNameTag($spawnerMgr->buildNametag($type, $entity->stack));
                $spawnerMgr->markEntityType($entity, $type);
                continue;
            }

            // Spawner une nouvelle entité
            do { $dx = mt_rand(-3, 3); $dz = mt_rand(-3, 3); } while ($dx === 0 && $dz === 0);
            $loc = Location::fromObject(
                new Vector3($pos->getX() + $dx + 0.5, $pos->getY() + 1, $pos->getZ() + $dz + 0.5),
                $world
            );

            $newEntity = match ($type) {
                'skeleton' => new Skeleton($loc, CompoundTag::create()),
                'creeper'  => new Creeper($loc, CompoundTag::create()),
                default    => new Zombie($loc, CompoundTag::create()),
            };

            $newEntity->stack = min(self::MAX_STACK, $spawnAmount);
            $newEntity->setNameTag($spawnerMgr->buildNametag($type, $newEntity->stack));
            $newEntity->setNameTagAlwaysVisible(true);
            $newEntity->setMaxHealth(max(20, 20 * $newEntity->stack));
            $newEntity->setHealth(max(20, 20 * $newEntity->stack));
            $newEntity->spawnToAll();
            $spawnerMgr->markEntityType($newEntity, $type);
        }

        // Sauvegarde différée : seulement si dirty (pose/casse depuis le dernier tick)
        $spawnerMgr->saveIfDirty(Core::getInstance());
    }
}
