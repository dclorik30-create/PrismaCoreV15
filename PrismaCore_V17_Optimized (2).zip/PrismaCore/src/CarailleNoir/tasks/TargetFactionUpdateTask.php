<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use pocketmine\scheduler\Task;

/**
 * Rafraîchit l'autocomplétion des noms de factions toutes les 10 secondes (200 ticks).
 * Remplace les appels immédiats depuis create/disband/name qui pouvaient être spammés
 * par un joueur malintentionné et provoquer un crash.
 *
 * FactionNameArgument::refreshEnum() possède son propre cooldown interne de 10s,
 * donc même si d'autres appels parasites arrivent, ils sont ignorés.
 */
class TargetFactionUpdateTask extends Task
{
    public function onRun(): void
    {
        FactionNameArgument::refreshEnum();
    }
}
