<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

/**
 * Tourne toutes les secondes (20 ticks).
 * Appelle ZoneChaosManager::tick() pour :
 *   - Vérifier le trigger quotidien 21h
 *   - Gérer les particules
 *   - Gérer la fin de l'event
 */
class ZoneChaosTask extends Task
{
    public function onRun(): void
    {
        Manager::ZONECHAOS()->tick();
    }
}
