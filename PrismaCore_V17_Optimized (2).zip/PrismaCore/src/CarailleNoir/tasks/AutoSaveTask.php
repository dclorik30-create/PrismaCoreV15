<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class AutoSaveTask extends Task
{
    private int $count = 0;

    public function onRun(): void
    {
        $this->count++;
        $start = microtime(true);

        // saveData() est async + dirty-flag : ne bloque plus le TPS
        Manager::BAN()->saveData();
        Manager::ALIAS()->saveData();
        Manager::SANCTION()->saveData();
        Manager::MUTE()->saveData();
        Manager::WARN()->saveData();
        Manager::GRADE()->saveData();
        Manager::OPD()->saveData();
        Manager::ECONOMY()->saveData();
        Manager::COINS()->saveData();
        Manager::STATS()->saveData();
        Manager::SETTINGS()->saveData();
        Manager::KIT()->saveData();
        Manager::ATOUT()->saveData();
        Manager::TIG()->saveData();
        Manager::HDV()->saveData();
        Manager::DAILY()->saveData();
        Manager::PLAYTIME()->saveData();
        Manager::LEVEL_DATA()->saveAll();
        Manager::REGION()->save();

        $elapsed = round((microtime(true) - $start) * 1000, 1);
        Core::getInstance()->getLogger()->info(
            "§a[AutoSave] §f#{$this->count} — §e{$elapsed}ms §7(async, dirty-flag)"
        );
    }
}
