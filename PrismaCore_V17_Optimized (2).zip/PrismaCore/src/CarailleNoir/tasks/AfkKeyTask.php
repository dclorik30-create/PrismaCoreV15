<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\AfkKeyManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class AfkKeyTask extends Task
{
    private string $lastHash = '';

    public function onRun(): void
    {
        $manager = Manager::AFKKEY();
        $winners = $manager->tick();

        foreach ($winners as $playerName) {
            $player = Server::getInstance()->getPlayerExact($playerName);
            if (!$player instanceof PrismaPlayer) {
                $manager->leaveZone($playerName);
                continue;
            }
            $rewardId = $manager->rollReward();
            $key      = Manager::BOX()->makeKeyItem($rewardId);
            if ($key !== null) {
                $player->getInventory()->addItem($key);
            }
            $player->sendMessage("§6[AfkKey] §fBravo ! Tu as obtenu une clé §e" . strtoupper($rewardId) . "§f !");
            Server::getInstance()->broadcastMessage("§6[AfkKey] §e" . $playerName . " §fa obtenu une clé §e" . strtoupper($rewardId) . " §fen restant 3 min dans la zone !");
            // Réinitialiser la zone après victoire pour mettre à jour le floating text
            $manager->leaveZone($playerName);
        }

        $this->updateFloating($manager);
    }

    private function updateFloating(AfkKeyManager $manager): void
    {
        $player = $manager->getCapturingPlayer();
        $time   = $manager->getCaptureTime();
        $hash   = $player !== null ? "{$player}|{$time}" : 'idle';

        if ($hash === $this->lastHash) return;
        $this->lastHash = $hash;

        Manager::FLOATINGTEXT()->updateAfkKey(
            $player !== null ? 'active' : 'idle',
            $player,
            $time,
            AfkKeyManager::REQUIRED_TIME
        );
    }
}
