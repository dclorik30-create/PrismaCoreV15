<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use pocketmine\scheduler\AsyncTask;

/**
 * Écrit un fichier JSON sur un worker thread (hors main thread).
 * Seuls des types PHP primitifs transitent — aucun objet PM5.
 * Écriture atomique via fichier .tmp + rename().
 */
class SaveDataAsyncTask extends AsyncTask
{
    public function __construct(
        private readonly string $filePath,
        private readonly string $jsonData
    ) {}

    public function onRun(): void
    {
        $dir = dirname($this->filePath);
        if (!is_dir($dir)) {
            mkdir($dir, 0777, true);
        }
        $tmp = $this->filePath . '.tmp';
        file_put_contents($tmp, $this->jsonData, LOCK_EX);
        rename($tmp, $this->filePath);
    }
}
