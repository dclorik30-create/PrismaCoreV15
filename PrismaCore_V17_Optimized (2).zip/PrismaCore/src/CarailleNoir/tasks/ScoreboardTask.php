<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\scheduler\Task;
use pocketmine\Server;

/**
 * Scoreboard 100% événementiel + re-sync périodique (toutes les 5s).
 *
 * FIXES :
 * - onRun() fait un refreshAll() périodique → corrige le bug scoreboard
 *   invisible 1 redémarrage sur 2 (re-sync si objectif perdu côté client).
 * - RemoveObjectivePacket envoyé quand /settings scoreboard désactive.
 * - $initialised reset au masquage (évite séquence REMOVE avant CREATE).
 *
 * OPTIMISATIONS :
 * - Cache $lastLines : paquets envoyés seulement si les données changent.
 * - buildLines() centralisé.
 */
class ScoreboardTask extends Task
{
    private const OBJECTIVE = "prisma_sb";
    private const LINES     = 7;

    private static ?self $instance = null;

    /** @var array<string, bool> true = objectif envoyé et visible */
    private array $initialised = [];

    /** @var array<string, string[]> cache du dernier contenu envoyé */
    private array $lastLines = [];

    public function __construct()
    {
        self::$instance = $this;
    }

    // ── Re-sync périodique (toutes les 5s via Loader) ─────────────────────
    public function onRun(): void
    {
        self::refreshAll();
    }

    // ── API statique ───────────────────────────────────────────────────────

    public static function refresh(PrismaPlayer $player): void
    {
        if (self::$instance !== null && $player->isConnected()) {
            self::$instance->sendScoreboard($player);
        }
    }

    public static function refreshAll(): void
    {
        if (self::$instance === null) return;
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if ($player instanceof PrismaPlayer && $player->isConnected()) {
                self::$instance->sendScoreboard($player);
            }
        }
    }

    // ── Construction du contenu ────────────────────────────────────────────

    private function buildLines(PrismaPlayer $player): array
    {
        $faction = $player->getFaction();
        return [
            "§8" . str_repeat("-", 18),
            "§7Grade : "     . $player->getGradeColor() . $player->getGradeName(),
            "§7Faction : §f" . ($faction?->getName() ?? "Aucune"),
            "§7Money : §6"   . self::fmt($player->getMoney()),
            "§7Coins : §b"   . self::fmt((float)$player->getCoins()),
            "§6prismamc.fr",
            "§8" . str_repeat("-", 18),
        ];
    }

    // ── Envoi / masquage ───────────────────────────────────────────────────

    public function sendScoreboard(PrismaPlayer $player): void
    {
        if (!$player->isConnected()) return;

        $name    = $player->getName();
        $enabled = Manager::SETTINGS()->getSetting($name, Manager::SETTINGS()::SETTING_SCOREBOARD);

        // ── Masquer si désactivé ───────────────────────────────────────────
        if (!$enabled) {
            if (isset($this->initialised[$name])) {
                $player->getNetworkSession()->sendDataPacket(
                    RemoveObjectivePacket::create(self::OBJECTIVE)
                );
                unset($this->initialised[$name], $this->lastLines[$name]);
            }
            return;
        }

        $lines = $this->buildLines($player);

        // ── Optimisation : skip si contenu identique ET déjà initialisé ───
        if (isset($this->initialised[$name], $this->lastLines[$name])
            && $this->lastLines[$name] === $lines) {
            return;
        }
        $this->lastLines[$name] = $lines;

        // ── Créer l'objectif si pas encore visible ────────────────────────
        if (!isset($this->initialised[$name])) {
            $player->getNetworkSession()->sendDataPacket(
                SetDisplayObjectivePacket::create(
                    SetDisplayObjectivePacket::DISPLAY_SLOT_SIDEBAR,
                    self::OBJECTIVE,
                    "§6§lPrisma",
                    "dummy",
                    SetDisplayObjectivePacket::SORT_ORDER_ASCENDING
                )
            );
            $this->initialised[$name] = true;
        } else {
            // Retirer les anciennes lignes
            $removes = [];
            for ($i = 0; $i < self::LINES; $i++) {
                $e = new ScorePacketEntry();
                $e->objectiveName = self::OBJECTIVE;
                $e->scoreboardId  = $i + 1;
                $e->score         = $i;
                $removes[] = $e;
            }
            $player->getNetworkSession()->sendDataPacket(
                SetScorePacket::create(SetScorePacket::TYPE_REMOVE, $removes)
            );
        }

        // ── Envoyer les nouvelles lignes ───────────────────────────────────
        $entries = [];
        foreach ($lines as $score => $text) {
            $e = new ScorePacketEntry();
            $e->objectiveName = self::OBJECTIVE;
            $e->type          = ScorePacketEntry::TYPE_FAKE_PLAYER;
            $e->customName    = $text;
            $e->score         = $score;
            $e->scoreboardId  = $score + 1;
            $entries[] = $e;
        }
        $player->getNetworkSession()->sendDataPacket(
            SetScorePacket::create(SetScorePacket::TYPE_CHANGE, $entries)
        );
    }

    private static function fmt(float $v): string
    {
        if ($v >= 1_000_000) return number_format($v / 1_000_000, 1, '.', '') . 'M';
        if ($v >= 1_000)     return number_format($v / 1_000, 1, '.', '') . 'k';
        return (string)(int)$v;
    }

    public function removePlayer(string $name): void
    {
        unset($this->initialised[$name], $this->lastLines[$name]);
    }

    /** Appelé au quit pour que la reconnexion recrée l'objectif proprement */
    public static function forgetPlayer(string $name): void
    {
        if (self::$instance !== null) {
            self::$instance->removePlayer($name);
        }
    }
}
