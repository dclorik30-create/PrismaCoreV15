<?php
namespace CarailleNoir\commands\Admin;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\FloatArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class AddMoneyCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("addmoney", "Ajouter de l'argent à un joueur", [], [], ["prisma.command.addmoney"]);
 }

 protected function prepare(): array
 {
  return [
   new TargetPlayerArgument(false, "joueur"),
   new FloatArgument("montant"),
  ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  $amount = (float)($args["montant"] ?? 0);

  if ($targetName === null) { $sender->sendMessage("§cUsage : §f/addmoney <joueur> <montant>"); return; }
  if ($amount <= 0) { $sender->sendMessage("§cLe montant doit être positif !"); return; }

  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  $name = $target !== null ? $target->getName() : $targetName;

  if (!Manager::ECONOMY()->playerExists($name)) {
   $sender->sendMessage("§cJoueur §f{$name} §cinconnu ! Il doit s'être connecté au moins une fois.");
   return;
  }

  Manager::ECONOMY()->addMoney($name, $amount);
  $current = Manager::ECONOMY()->getMoney($name);

  $sender->sendMessage("§a+§f" . number_format($amount, 2) . "§6\$ §aajouté à §f{$name}§a. (Nouveau solde : §f" . number_format($current, 2) . "§6\$§a)");
  if ($target !== null) $target->sendMessage("§a+§f" . number_format($amount, 2) . "§6\$ §avous ont été ajoutés par §f" . $sender->getName() . "§a !");
 }
}
