<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\utils\trait\Time;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\Server;

class BanCommand extends BaseCommand
{
    use Time;

    public function __construct()
    {
        parent::__construct("ban", "Bannir un joueur", [], [], ["prisma.command.staff", "prisma.command.ban", DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [
            new TargetPlayerArgument(false, "name"),
            new RawStringArgument("time"),
            new TextArgument("reason"),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $targetName = $args["name"];
        $timeStr    = $args["time"];
        $reason     = $args["reason"];

        if (!Manager::ALIAS()->hasProfil($targetName)) {
            $sender->sendMessage("§cLe joueur §f{$targetName} §cn'a jamais rejoint le serveur.");
            return;
        }

        $duration = $this->parseTime($timeStr);
        $expire   = $duration ? date("d/m/Y H:i:s", time() + $duration) : "Permanent";

        Manager::BAN()->addBan($targetName, $reason, $sender->getName(), $duration);
        $sender->sendMessage("§eLe joueur §f{$targetName} §ea été banni. §7(§f{$expire}§7)");

        $kickMsg = "§cBanni pour : §f{$reason}\n§7Par : §f{$sender->getName()}\n§7Expire : §f{$expire}";

        // Kick le joueur ciblé
        $target = Server::getInstance()->getPlayerByPrefix($targetName);
        $target?->kick($kickMsg);

        // Kick tous les alts connectés
        $alts = Manager::ALIAS()->getAccounts($targetName);
        $kickedAlts = [];
        foreach ($alts as $alt) {
            $altPlayer = Server::getInstance()->getPlayerByPrefix($alt);
            if ($altPlayer !== null && $altPlayer->isConnected()) {
                $altPlayer->kick("§cBanni (compte lié à §f{$targetName}§c)\n§7Raison : §f{$reason}\n§7Expire : §f{$expire}");
                $kickedAlts[] = $alt;
            }
        }

        if (!empty($kickedAlts)) {
            $sender->sendMessage("§eAlts kickés : §f" . implode("§7, §f", $kickedAlts));
        }
    }
}
