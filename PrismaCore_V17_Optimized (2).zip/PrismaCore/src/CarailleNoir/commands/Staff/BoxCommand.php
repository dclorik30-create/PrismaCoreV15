<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class BoxCommand extends BaseCommand
{
    private static array $VALID_BOXES = ["vote", "noble", "heros", "dieu", "boutique"];

    public function __construct()
    {
        parent::__construct("box", "Gérer les récompenses des boîtes", [], [], ["prisma.command.box"]);
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument("action", false),
            new RawStringArgument("boxtype", true),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCommande joueur uniquement.");
            return;
        }

        $action  = strtolower($args["action"] ?? "");
        $boxType = strtolower($args["boxtype"] ?? "");

        if ($action !== "add") {
            $sender->sendMessage("§eUsage : §f/box add <Vote|Noble|Heros|Dieu|Boutique>");
            return;
        }

        if (!in_array($boxType, self::$VALID_BOXES, true)) {
            $sender->sendMessage("§cBoîte invalide ! Valeurs : §f" . implode(", ", self::$VALID_BOXES));
            return;
        }

        $box = Manager::BOX()->getBox($boxType);
        if ($box === null) {
            $sender->sendMessage("§cBoîte '§f{$boxType}§c' introuvable dans boxes.json.");
            return;
        }

        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§6Box §f{$boxType} §8— §7Modifie puis ferme");

        // Pré-remplir avec les loots actuels de la box
        $inv = $menu->getInventory();
        $slot = 0;
        foreach ($box["loots"] as $loot) {
            if ($slot >= 27) break;
            $item = Manager::BOX()->makeLootItem($loot);
            if ($item !== null && !$item->isNull()) {
                $inv->setItem($slot, $item);
                $slot++;
            }
        }

        // Autoriser toutes les modifications (déposer, retirer, déplacer)
        $menu->setListener(function (InvMenuTransaction $tx): InvMenuTransactionResult {
            return $tx->continue();
        });

        // À la fermeture : remplacer TOUS les loots par le contenu de l'inventaire
        $menu->setInventoryCloseListener(
            function (Player $player, \pocketmine\inventory\Inventory $inv) use ($boxType): void {
                $items = [];
                foreach ($inv->getContents() as $item) {
                    if (!$item->isNull()) {
                        $items[] = $item;
                    }
                }

                if (count($items) === 0) {
                    $player->sendMessage("§cInventaire vide — la boîte §f{$boxType}§c n'a pas été modifiée.");
                    return;
                }

                // Remplacer les loots (en conservant les chance existantes par index si possible)
                Manager::BOX()->setLootsFromItems($boxType, $items);

                $player->sendMessage(
                    "§a✔ Boîte §f{$boxType}§a mise à jour avec §e" . count($items) . " loot(s)§a."
                    . "\n§7Édite §fboxes.json §7pour ajuster les §echance §7(total = §e10 000§7)."
                );
            }
        );

        $menu->send($sender);
    }
}
