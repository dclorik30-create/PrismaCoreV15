<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class KickCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("kick", "Expulser un joueur du serveur", [], [], ["prisma.command.kick"]);
 }

 protected function prepare(): array
 {
  return [
   new TargetPlayerArgument(false, "joueur"),
   new RawStringArgument("raison", true),
  ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  $raison     = $args["raison"] ?? "Aucune raison donnee";

  if ($targetName === null) {
   $sender->sendMessage("§cUsage : /kick <joueur> [raison]");
   return;
  }

  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  if ($target === null) {
   $sender->sendMessage("§cJoueur introuvable.");
   return;
  }

  $staffName = $sender instanceof PrismaPlayer ? $sender->getName() : "Console";
  $target->kick("§cVous avez ete expulse.\n§fRaison : §e" . $raison);
  Server::getInstance()->broadcastMessage(
   "§8[§cKick§8] §f" . $target->getName() . " §7a ete expulse par §f" . $staffName . " §7: §e" . $raison
  );
 }
}
