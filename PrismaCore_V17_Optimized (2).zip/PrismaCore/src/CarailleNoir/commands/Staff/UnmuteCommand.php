<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class UnmuteCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("unmute", "Retirer le mute d'un joueur", [], [], ["prisma.command.unmute"]);
 }

 protected function prepare(): array
 {
  return [new TargetPlayerArgument(false, "joueur")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  if ($targetName === null) {
   $sender->sendMessage("§cUsage : /unmute <joueur>");
   return;
  }

  Manager::SANCTION()->unmute($targetName);
  $sender->sendMessage("§a" . $targetName . " n'est plus mute.");
  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  if ($target !== null) $target->sendMessage("§aVotre mute a ete leve.");
 }
}
