<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class KitNbtCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("kitnbt", "Configurer les items d'un kit via InvMenu", [], [], ["prisma.command.box"]);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("kitname", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCommande joueur uniquement.");
            return;
        }

        $kitName = strtolower($args["kitname"] ?? "");

        if ($kitName === "" || !Manager::KIT()->kitExists($kitName)) {
            $kits = array_keys(Manager::KIT()->getKits());
            $sender->sendMessage("§cKit invalide ! Kits disponibles : §f" . implode(", ", $kits));
            return;
        }

        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§6Kit §f{$kitName} §8— §7Modifie puis ferme");

        // Pré-remplir avec les items actuels du kit
        $inv = $menu->getInventory();
        $slot = 0;
        foreach (Manager::KIT()->getKitItems($kitName) as $item) {
            if ($slot >= 54) break;
            if (!$item->isNull()) {
                $inv->setItem($slot, $item);
                $slot++;
            }
        }

        $menu->setListener(function (InvMenuTransaction $tx): InvMenuTransactionResult {
            return $tx->continue();
        });

        $menu->setInventoryCloseListener(
            function (Player $player, \pocketmine\inventory\Inventory $inv) use ($kitName): void {
                $items = [];
                foreach ($inv->getContents() as $item) {
                    if (!$item->isNull()) $items[] = $item;
                }

                if (empty($items)) {
                    $player->sendMessage("§cInventaire vide — kit §f{$kitName}§c non modifié.");
                    return;
                }

                Manager::KIT()->setKitItems($kitName, $items);
                $player->sendMessage(
                    "§a✔ Kit §f{$kitName}§a mis à jour avec §e" . count($items) . " item(s)§a (NBT complet sauvegardé)."
                );
            }
        );

        $menu->send($sender);
    }
}
