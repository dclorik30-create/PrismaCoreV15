<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class AliasCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("alias", "Alias des joueurs", [], [], ["prisma.command.staff", "prisma.command.alias", DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "playername")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $targetName = $args["playername"];

        if (!Manager::ALIAS()->hasProfil($targetName)) {
            $sender->sendMessage("§cAucun profil trouvé pour §f{$targetName}§c.");
            return;
        }

        $profile = Manager::ALIAS()->getProfileData($targetName);
        $alts    = Manager::ALIAS()->getAccounts($targetName);

        $usernames = implode("§7, §f", $profile['username'] ?? [$targetName]);

        // Statut ban des alts
        $altLines = [];
        foreach ($alts as $alt) {
            $banned = Manager::BAN()->isBanned($alt);
            $altLines[] = ($banned ? "§c" : "§a") . $alt . ($banned ? " §7(§cBanni§7)" : "");
        }
        $altsStr = empty($altLines) ? "§8Aucun" : implode("§7, ", $altLines);

        $msg  = "\n§6§l──── Alias : §f{$targetName} §6§l────\n";
        $msg .= "§7Usernames §8: §f{$usernames}\n";
        $msg .= "§7Alts      §8: {$altsStr}\n";
        $msg .= "§6§l" . str_repeat("─", 28);

        $sender->sendMessage($msg);
    }
}
