<?php
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

class EcSeeCommand extends BaseCommand {
 public function __construct() { parent::__construct("ecsee", "Voir/ouvrir l'ender chest d'un joueur", [], [], ["prisma.command.staff", "prisma.command.ecsee"]); }
 protected function prepare(): array { return [new TargetPlayerArgument(false, "player")]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $targetName = (string)($args["player"] ?? "");
 if ($targetName === "") { $sender->sendMessage("§cUsage : /ecsee <joueur>"); return; }

 $online = \pocketmine\Server::getInstance()->getPlayerExact($targetName);
 $menu = InvMenu::create(InvMenu::TYPE_CHEST);
 $menu->setName("§5EC §f{$targetName}");

 if ($online instanceof PrismaPlayer) {
 foreach ($online->getEnderInventory()->getContents() as $slot => $item) $menu->getInventory()->setItem($slot, $item);
 } else {
 $data = Manager::OPD()->getPlayerData($targetName);
 foreach (($data["enderInventory"] ?? []) as $slot => $payload) {
 $item = Manager::PV()->deserializeItem((string)$payload);
 if ($item !== null) $menu->getInventory()->setItem((int)$slot, $item);
 }
 }

 $menu->setListener(function(InvMenuTransaction $transaction) : InvMenuTransactionResult {
 return $transaction->continue();
 });

 $menu->setInventoryCloseListener(function(Player $p, Inventory $inv) use ($menu, $targetName, $online): void {
 if ($online instanceof PrismaPlayer) {
 foreach ($menu->getInventory()->getContents() as $slot => $item) $online->getEnderInventory()->setItem($slot, $item);
 return;
 }
 $data = Manager::OPD()->getPlayerData($targetName);
 $data["enderInventory"] = [];
 foreach ($menu->getInventory()->getContents() as $slot => $item) {
 if (!$item->isNull()) $data["enderInventory"][$slot] = Manager::PV()->serializeItem($item);
 }
 Manager::OPD()->setPlayerData($targetName, $data);
 Manager::OPD()->save();
 });

 $menu->send($sender);
 }
}
