<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class ZoneChaosCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct(
            "zonechaos",
            "Enregistrer une Zone de Chaos",
            [], [],
            ["prisma.command.staff", "prisma.command.zonechaos"]
        );
    }

    protected function prepare(): array
    {
        return [new IntegerArgument("id", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) {
            $sender->sendMessage("§cCommande réservée aux joueurs en jeu.");
            return;
        }

        $id = (int)($args["id"] ?? 0);
        if ($id <= 0) {
            $sender->sendMessage("§cUsage : §f/zonechaos <id> §7(id >= 1)");
            return;
        }

        $pos = $sender->getPosition();
        $msg = Manager::ZONECHAOS()->handleSetup(
            $id,
            $sender->getWorld()->getFolderName(),
            round($pos->x, 1),
            round($pos->y, 1),
            round($pos->z, 1)
        );
        $sender->sendMessage($msg);
    }
}
