<?php
declare(strict_types=1);

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\forms\SimpleForm;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\world\Position;

class EventCommand extends BaseCommand {

    private const WORLD = 'Map';
    private const TELEPORTS = [
        'outpost' => [self::WORLD, -171, 57, 0],
        'koth' => [self::WORLD, 184, 64, 20],
        'afkkey' => [self::WORLD, 0, 56, -166],
        'totem' => [self::WORLD, -8, 64, 185],
    ];

    public function __construct() {
        parent::__construct('event', 'Gérer les events', [], [], ['prisma.command.staff', 'prisma.command.event']);
    }

    protected function prepare(): array {
        return [new RawStringArgument('action', true), new RawStringArgument('type', true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if ($sender instanceof PrismaPlayer && !isset($args['action'])) {
            $this->sendPlayerMenu($sender);
            return;
        }

        $action = strtolower((string)($args['action'] ?? ''));
        $types = Manager::EVENT()->getAvailableTypes();
        $type = strtolower((string)($args['type'] ?? ''));

        switch ($action) {
            case 'start':
                if ($type === 'zonechaos') {
                    if (Manager::ZONECHAOS()->getZoneCount() === 0) {
                        $sender->sendMessage('§c[Zone de Chaos] Aucune zone enregistrée ! Utilise §f/zonechaos <id>');
                        return;
                    }
                    if (Manager::ZONECHAOS()->isActive()) {
                        $sender->sendMessage('§c[Zone de Chaos] Une Zone de Chaos est déjà active !');
                        return;
                    }
                    Manager::ZONECHAOS()->start();
                    $sender->sendMessage('§a[Zone de Chaos] Event démarré manuellement !');
                    return;
                }
                if (Manager::EVENT()->isEventActive()) {
                    $sender->sendMessage('§cUn event est déjà en cours : §e' . Manager::EVENT()->getActiveEvent());
                    return;
                }
                if (!in_array($type, $types, true)) {
                    $sender->sendMessage('§cType invalide. Types : ' . implode(', ', $types) . ', zonechaos');
                    return;
                }
                Manager::EVENT()->startEvent($type);
                $sender->sendMessage('§aEvent §f' . strtoupper($type) . ' §adémarré !');
                break;
            case 'stop':
                if ($type === 'zonechaos') {
                    if (!Manager::ZONECHAOS()->isActive()) {
                        $sender->sendMessage('§c[Zone de Chaos] Aucune Zone de Chaos active !');
                        return;
                    }
                    Manager::ZONECHAOS()->stop();
                    $sender->sendMessage('§a[Zone de Chaos] Event arrêté manuellement.');
                    return;
                }
                if (!Manager::EVENT()->isEventActive()) {
                    $sender->sendMessage('§cAucun event actif !');
                    return;
                }
                Manager::EVENT()->stopEvent();
                $sender->sendMessage('§aEvent arrêté.');
                break;
            case 'status':
                if (!Manager::EVENT()->isEventActive()) {
                    $sender->sendMessage('§eAucun event en cours.');
                    return;
                }
                $ev = Manager::EVENT()->getActiveEvent();
                $cap = method_exists(Manager::EVENT(), 'getCapturePlayer') ? (Manager::EVENT()->getCapturePlayer() ?? 'Personne') : 'Personne';
                $prg = method_exists(Manager::EVENT(), 'getCaptureProgress') ? Manager::EVENT()->getCaptureProgress() : 0;
                $req = method_exists(Manager::EVENT(), 'getCaptureRequired') ? Manager::EVENT()->getCaptureRequired() : 0;
                $pct = $req > 0 ? round($prg / $req * 100) : 0;
                $sender->sendMessage("§6Event §e{$ev} §f- Capture : §a{$cap} §f({$pct}% - {$prg}/{$req}s)");
                break;
            default:
                $sender->sendMessage('§cUsage : /event <start|stop|status> [type]');
                break;
        }
    }

    private function sendPlayerMenu(PrismaPlayer $player): void {
        $form = new SimpleForm(function (PrismaPlayer $player, $data): void {
            if ($data === null) {
                return;
            }
            $type = (string) $data;
            $this->teleportToEvent($player, $type);
        });
        $form->setTitle('Event');
        $form->setContent('Choisis un lieu');
        $form->addButton('Outpost', -1, '', 'outpost');
        $form->addButton('Koth', -1, '', 'koth');
        $form->addButton('Afk Key', -1, '', 'afkkey');
        $form->addButton('Totem', -1, '', 'totem');
        $form->sendToPlayer($player);
    }

    private function teleportToEvent(PrismaPlayer $player, string $type): void {
        $data = self::TELEPORTS[$type] ?? null;
        if ($data === null) {
            $player->sendMessage('§cLieu invalide.');
            return;
        }
        [$worldName, $x, $y, $z] = $data;
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($worldName)) {
            $wm->loadWorld($worldName);
        }
        $world = $wm->getWorldByName($worldName);
        if ($world === null) {
            $player->sendMessage('§cMonde introuvable.');
            return;
        }
        $player->teleport(new Position((float) $x, (float) $y, (float) $z, $world));
    }
}
