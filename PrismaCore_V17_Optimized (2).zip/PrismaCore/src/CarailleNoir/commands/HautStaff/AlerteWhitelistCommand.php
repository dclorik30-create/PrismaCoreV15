<?php
declare(strict_types=1);
namespace CarailleNoir\commands\HautStaff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class AlerteWhitelistCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct(
            "alertewhitelist",
            "Gérer la whitelist des alertes CPS",
            [],
            [],
            [DefaultPermissions::ROOT_OPERATOR]
        );
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(true, "joueur")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $wl = Manager::ALERT_WHITELIST();

        // Sans argument : afficher la liste
        if (empty($args["joueur"])) {
            $list = $wl->getAll();
            if (empty($list)) {
                $sender->sendMessage("§6[AlerteWhitelist] §fAucun joueur en whitelist.");
                return;
            }
            $sender->sendMessage("§6[AlerteWhitelist] §fJoueurs exemptés (§e" . count($list) . "§f) :");
            foreach ($list as $name) {
                $sender->sendMessage("  §7- §f" . $name);
            }
            return;
        }

        $target = $args["joueur"];

        if ($wl->isWhitelisted($target)) {
            $wl->remove($target);
            $sender->sendMessage("§6[AlerteWhitelist] §f{$target} §cretirée §fde la whitelist.");
        } else {
            $wl->add($target);
            $sender->sendMessage("§6[AlerteWhitelist] §f{$target} §aajouté §fà la whitelist.");
        }
    }
}
