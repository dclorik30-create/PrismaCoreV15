<?php
declare(strict_types=1);

namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class IslandWhitelistSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("iswl", "Gérer la whitelist de l'île", [], []);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "target", false, ["list"])];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $faction = $sender->getFaction();
        if (!$faction instanceof Faction) {
            $sender->sendMessage("§cVous n'avez pas de faction.");
            return;
        }

        if ($faction->getOwner() !== $sender->getName()) {
            $sender->sendMessage("§cSeul le chef peut gérer la whitelist de l'île.");
            return;
        }

        $target = trim((string)($args["target"] ?? ""));
        if ($target === "") {
            $sender->sendMessage("§cUsage : §f/f iswl <joueur>");
            $sender->sendMessage("§f        §f/f iswl list");
            return;
        }

        if (strtolower($target) === "list") {
            $list = $faction->getIslandWhitelist();
            if ($list === []) {
                $sender->sendMessage("§eAucun joueur n'est whitelist sur votre île.");
                return;
            }
            $sender->sendMessage("§6Whitelist île §8(§f" . count($list) . "§8) §7: §f" . implode("§7, §f", $list));
            return;
        }

        $real = Server::getInstance()->getPlayerExact($target)?->getName() ?? $target;
        if ($faction->addIslandWhitelist($real)) {
            Manager::FACTION()->save();
            $sender->sendMessage("§a" . $real . " §fest maintenant whitelist pour votre île.");
        } else {
            $sender->sendMessage("§e" . $real . " §fest déjà whitelist pour votre île.");
        }
    }
}
