<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use CarailleNoir\player\PrismaPlayer;

class BuyIslandSubCommand extends BaseSubCommand {
 private const ISLAND_COST = 5000;
 public function __construct() { parent::__construct("isbuy", "Acheter une île pour sa faction", [], []); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
 if ($faction->getOwner() !== $sender->getName()) {
 $sender->sendMessage("§cSeul le chef de faction peut acheter une île !"); return;
 }
 if (Manager::FACTION()->getIsland($faction->getId()) !== null) {
 $sender->sendMessage("§cVotre faction possède déjà une île !"); return;
 }
 if (!$sender->hasMoney(self::ISLAND_COST)) {
 $sender->sendMessage("§cIl vous faut §f" . number_format(self::ISLAND_COST, 2) . "§6$ §cpour acheter une île !"); return;
 }
 $sender->removeMoney(self::ISLAND_COST);
 $ok = Manager::FACTION()->createIsland($faction->getId());
 if (!$ok) {
 $sender->removeMoney(-self::ISLAND_COST); // remboursement
 $sender->sendMessage("§cErreur : le monde §fisland_copy §cest introuvable sur le serveur. Contactez un admin.");
 return;
 }
 $sender->sendMessage("§aÎle créée ! Utilisez §f/f is §apour vous téléporter.");
 foreach ($faction->getAll() as $member) {
 $p = \pocketmine\Server::getInstance()->getPlayerExact($member);
 $p?->sendMessage("§6[Faction] §e{$sender->getName()} §fa acheté une île pour §f" . $faction->getName() . " §a!");
 }
 }
}
