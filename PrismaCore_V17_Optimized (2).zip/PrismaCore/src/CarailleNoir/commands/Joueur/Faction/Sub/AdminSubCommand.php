<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\type\Faction\FactionAdminManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class AdminSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("admin", "Active/désactive le mode admin faction (OP uniquement)");
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        if (!Server::getInstance()->isOp($sender->getName())) {
            $sender->sendMessage("§cVous n'avez pas la permission.");
            return;
        }

        $enabled = FactionAdminManager::toggle($sender->getName());
        if ($enabled) {
            $sender->sendMessage("§a✔ Mode admin faction §lACTIVÉ§r§a. Vous pouvez rejoindre/gérer n'importe quelle faction.");
        } else {
            $sender->sendMessage("§c✘ Mode admin faction §lDÉSACTIVÉ§r§c.");
        }
    }
}
