<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Manage;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\managers\type\Faction\FactionAdminManager;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class DisbandSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("disband", "Permet de supprimer sa faction", ["del"]);
 }

 protected function prepare(): array
 {
 return [new RawStringArgument("factionName", true)];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;
 $fManager = Manager::FACTION();
 $isAdmin  = FactionAdminManager::isAdmin($sender->getName());

 // Mode admin : /f disband <nomFaction>
 if ($isAdmin && isset($args["factionName"])) {
 $fName = $args["factionName"];
 $faction = null;
 foreach ($fManager->getFactions() as $f) {
 if (strcasecmp($f->getName(), $fName) === 0) { $faction = $f; break; }
 }
 if ($faction === null) {
 $sender->sendMessage("§cFaction §f{$fName}§c introuvable.");
 return;
 }
 $this->disbandFaction($faction, $sender);
 return;
 }

 $faction = $sender->getFaction();

 if (!$faction instanceof Faction) {
 FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []);
 return;
 }

 if (!$isAdmin && $faction->getOwner() !== $sender->getName()) {
 FactionMessageEnum::NOT_OWNER->sendToPlayer($sender, []);
 return;
 }
 $this->disbandFaction($faction, $sender);
 }

 private function disbandFaction(Faction $faction, PrismaPlayer $admin): void
 {
 $server  = Server::getInstance();
 $fManager = Manager::FACTION();

 foreach ($faction->getAll() as $member) {
 $player = $server->getPlayerExact($member);
 if ($player instanceof PrismaPlayer && $player->isOnline()) {
 $player->setFaction("Aucune");
 FactionMessageEnum::KICK_FACTION->sendToPlayer($player, []);
 } else {
 $data = $server->getOfflinePlayerData($member);
 $data?->setString("factionId", "Aucune");
 $server?->saveOfflinePlayerData($member, $data);
 }
 }

 $o = $server->getPlayerExact($faction->getOwner());
 if ($o instanceof PrismaPlayer) {
 $o->sendMessage(FactionMessageEnum::DISBAND_FACTION->value);
 }
 if ($admin->isConnected()) {
 $admin->setFaction("Aucune");
 $admin->sendMessage("§aFaction §f" . $faction->getName() . "§a dissoute.");
 }
 $fManager->deleteFaction($faction->getId());
 }
}