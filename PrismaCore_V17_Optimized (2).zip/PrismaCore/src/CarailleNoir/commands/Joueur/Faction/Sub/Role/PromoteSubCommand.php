<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Role;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionPermissionEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\managers\type\Faction\FactionAdminManager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class PromoteSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("promote", "Augmenter le grade d'un joueur dans sa faction", ["uprank"]);
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(false, "playerName")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;
 $senderName = $sender->getName();

 $isAdmin = FactionAdminManager::isAdmin($sender->getName());
 $faction = $sender->getFaction();
 if (!$faction instanceof Faction && !$isAdmin) {
 $sender->sendMessage(FactionMessageEnum::NOT_IN_FACTION->value);
 return;
 }

 if (!$isAdmin && !FactionPermissionEnum::PROMOTE->has($faction, $senderName)) {
 FactionMessageEnum::NOT_PERMISSION_PROMOTE->sendToPlayer($sender, []);
 return;
 }

 $targetName = $args["playerName"];
 if (!Manager::ALIAS()->hasProfil($targetName)) {
 $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
 return;
 }

 $target = Server::getInstance()->getPlayerExact($targetName);
 if (!$target instanceof PrismaPlayer) {
 $sender->sendMessage("§cImpossible de récupérer le joueur !");
 return;
 }

 $factionT = $target->getFaction();
 if (!$factionT instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::TARGET_NOT_IN_FACTION->value);
 return;
 }

 // Mode admin sans faction : utilise la faction du target
 if ($isAdmin && !($faction instanceof Faction)) {
 $faction = $factionT;
 }

 if ($faction->getId() !== $factionT->getId()) {
 FactionMessageEnum::NOT_SAME_FACTION->sendToPlayer($sender, []);
 return;
 }

 $rank = $isAdmin ? \CarailleNoir\managers\option\Faction\FactionRoleEnum::OWNER : $faction->getPlayerRole($senderName);
 $rankT = $faction->getPlayerRole($targetName);

 if ($rankT === FactionRoleEnum::OWNER) {
 FactionMessageEnum::NOT_PERMISSION_PROMOTE_PLAYER->sendToPlayer($sender, []);
 return;
 }

 // Bloquer promotion SUB_OWNER → OWNER, rediriger vers /f leader
 if ($rankT === FactionRoleEnum::SUB_OWNER) {
 $sender->sendMessage("§cFaites §f/f leader §csi vous souhaitez transférer le lead de la faction.");
 return;
 }

 if ($rank->getPriority() < $rankT->getPriority()) {
 FactionMessageEnum::NOT_PERMISSION_PROMOTE_PLAYER->sendToPlayer($sender, []);
 return;
 }

 $faction->remove($targetName, $rankT);
 $faction->add($targetName, $rankT->getBetterRank());
 FactionMessageEnum::PROMOTE_PLAYER->sendToFaction($faction, ["{playername}" => $targetName, "{rankname}" => $rankT->getBetterRank()->value]);
 }
}