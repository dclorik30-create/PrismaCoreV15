<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class AddAllySubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("addally", "Envoyer une demande d'alliance", [], []); }
 protected function prepare(): array { return [new FactionNameArgument(false, "factionName")]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []); return; }

 $role = $faction->getPlayerRole($sender->getName());
 if ($role === null || $role->getPriority() < FactionRoleEnum::SUB_OWNER->getPriority()) {
 FactionMessageEnum::NOT_OWNER_OR_SUB->sendToPlayer($sender, []); return;
 }

 if (count($faction->getAllies()) >= 2) {
 $sender->sendMessage("§cVotre faction a déjà atteint le maximum de §e2 alliances§c."); return;
 }

 $targetFactionName = trim($args["factionName"] ?? "");
 $targetFaction = null;
 foreach (Manager::FACTION()->getFactions() as $f) {
 if (strtolower($f->getName()) === strtolower($targetFactionName)) { $targetFaction = $f; break; }
 }
 if ($targetFaction === null) { FactionMessageEnum::FACTION_NOT_FOUND->sendToPlayer($sender, []); return; }
 if ($targetFaction->getId() === $faction->getId()) { $sender->sendMessage("§cVous ne pouvez pas vous allier avec vous-même !"); return; }
 if ($faction->isAlly($targetFaction->getId())) { FactionMessageEnum::ALLY_ALREADY->sendToPlayer($sender, []); return; }

 if (count($targetFaction->getAllies()) >= 2) {
 $sender->sendMessage("§cLa faction §f" . $targetFaction->getName() . "§c a déjà atteint le maximum de §e2 alliances§c."); return;
 }

 Manager::FACTION()->sendAllyRequest($faction->getId(), $targetFaction->getId());
 FactionMessageEnum::ALLY_REQUEST_SENT->sendToPlayer($sender, ["{faction}" => $targetFaction->getName()]);
 foreach ($targetFaction->getOnlinePlayers() as $p) {
 FactionMessageEnum::ALLY_REQUEST_RECEIVED->sendToPlayer($p, ["{faction}" => $faction->getName()]);
 }
 }
}
