<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class UnallySubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("unally", "Retirer une faction de vos alliés"); }
 protected function prepare(): array { return [new FactionNameArgument(false, "factionName")]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []); return; }

 $role = $faction->getPlayerRole($sender->getName());
 if ($role === null || $role->getPriority() < FactionRoleEnum::SUB_OWNER->getPriority()) {
 FactionMessageEnum::NOT_OWNER_OR_SUB->sendToPlayer($sender, []); return;
 }

 $targetName = trim($args["factionName"] ?? "");
 $targetFaction = null;
 foreach (Manager::FACTION()->getFactions() as $f) {
 if (strtolower($f->getName()) === strtolower($targetName)) { $targetFaction = $f; break; }
 }
 if ($targetFaction === null) { FactionMessageEnum::FACTION_NOT_FOUND->sendToPlayer($sender, []); return; }
 if (!$faction->isAlly($targetFaction->getId())) {
 $sender->sendMessage("§cCette faction n'est pas votre alliée !"); return;
 }

 $faction->removeAlly($targetFaction->getId());
 $targetFaction->removeAlly($faction->getId());
 Manager::FACTION()->save();

 $sender->sendMessage("§aVous avez retiré §f" . $targetFaction->getName() . " §ade vos alliés.");
 foreach ($targetFaction->getOnlinePlayers() as $p) {
 $p->sendMessage("§c[Alliance] §fLa faction §e" . $faction->getName() . " §fa mis fin à l'alliance.");
 }
 }
}
