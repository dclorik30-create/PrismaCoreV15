<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class InfoSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("info", "Permet de voir les info de la faction");
 }

 protected function prepare(): array
 {
 return [new FactionNameArgument(true, "factionName")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $facName = $args["factionName"] ?? null;
 $fManager = Manager::FACTION();

 if ($facName !== null) {
 $faction = null;
 foreach ($fManager->getFactions() as $f) {
 if (strtolower($f->getName()) === strtolower($facName)) {
 $faction = $f;
 break;
 }
 }
 if (!$faction instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::FACTION_NOT_FOUND->value);
 return;
 }
 } else {
 $faction = $sender->getFaction();
 if (!$faction instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::NOT_IN_FACTION->value);
 return;
 }
 }

 FactionMessageEnum::FACTION_INFO->sendToPlayer($sender, [
 "{NAME}" => $faction->getName(),
 "{DESCRIPTION}" => $faction->getDescription(),
 "{OWNER}" => $faction->getOwner(),
 "{SUBOWNER}" => implode(", ", $faction->get(FactionRoleEnum::SUB_OWNER)),
 "{OFFICERS}" => implode(", ", $faction->get(FactionRoleEnum::OFFICIERS)),
 "{MEMBERS}" => implode(", ", $faction->get(FactionRoleEnum::MEMBERS)),
 "{RECRUITS}" => implode(", ", $faction->get(FactionRoleEnum::RECRUITS)),
 "{POWER}" => (function() use ($faction): string {
 $total = 0;
 $all = array_merge([$faction->getOwner()], $faction->get(\CarailleNoir\managers\option\Faction\FactionRoleEnum::SUB_OWNER), $faction->get(\CarailleNoir\managers\option\Faction\FactionRoleEnum::OFFICIERS), $faction->get(\CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS), $faction->get(\CarailleNoir\managers\option\Faction\FactionRoleEnum::RECRUITS));
 $all = array_filter($all, fn($m) => $m !== "");
 foreach ($all as $member) { $total += Manager::STATS()->getPower($member); }
 return (string)$total;
 })(),
 "{ALLIES}" => (function() use ($faction, $fManager): string {
 $names = [];
 foreach ($faction->getAllies() as $allyId) {
 $ally = $fManager->getFaction($allyId);
 if ($ally !== null) $names[] = $ally->getName();
 }
 return empty($names) ? "Aucune" : implode(", ", $names);
 })(),
 ]);
 }
}