<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\FactionAdminManager;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class JoinSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("join", "Rejoindre une faction (admin : sans invitation)");
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("factionName")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        if (!FactionAdminManager::isAdmin($sender->getName())) {
            $sender->sendMessage("§cCette commande est réservée au mode admin. Faites §f/f admin §cpour l'activer.");
            return;
        }

        $fName = trim($args["factionName"] ?? "");
        if ($fName === "") {
            $sender->sendMessage("§eUsage : §f/f join <nomFaction>");
            return;
        }

        $fManager = Manager::FACTION();
        $senderName = $sender->getName();

        // Chercher la faction cible
        $target = null;
        foreach ($fManager->getFactions() as $f) {
            if (strcasecmp($f->getName(), $fName) === 0) {
                $target = $f;
                break;
            }
        }

        if ($target === null) {
            $sender->sendMessage("§cFaction §f{$fName}§c introuvable.");
            return;
        }

        // Quitter l'ancienne faction si nécessaire
        $old = $sender->getFaction();
        if ($old instanceof Faction) {
            if ($old->getId() === $target->getId()) {
                $sender->sendMessage("§cVous êtes déjà dans cette faction.");
                return;
            }
            // Peu importe le rôle (même owner) : on retire juste le joueur
            // La faction reste telle quelle, sans leader si c'était le owner
            $old->remove($senderName);
            // broadcast uniquement si la faction a encore des membres (évite crash owner vide)
            if (count($old->getAll()) > 0 || $old->getOwner() !== "" && $old->getOwner() !== $senderName) {
                $old->sendFactionMessage("§6[Admin] §e{$senderName} §7a quitté la faction.");
            }
            $sender->setFaction("Aucune");
        }

        // Rejoindre en RECRUITS
        $target->add($senderName, FactionRoleEnum::RECRUITS);
        $sender->setFaction($target->getId());
        $sender->sendMessage("§a✔ Vous avez rejoint §f" . $target->getName() . "§a (mode admin).");
        $target->sendFactionMessage("§6[Admin] §e{$senderName} §fa rejoint la faction.");
    }
}
