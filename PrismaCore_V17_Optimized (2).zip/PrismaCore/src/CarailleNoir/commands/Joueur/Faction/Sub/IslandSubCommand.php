<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class IslandSubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("is", "Téléporter à l'île de faction", [], []); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
 $island = Manager::FACTION()->getIsland($faction->getId());
 if ($island === null) {
 $sender->sendMessage("§cVotre faction n'a pas d'île ! Achetez-en une avec §f/f isbuy"); return;
 }
 $worldName = $island["world"] ?? ("island_" . strtolower($faction->getId()));
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($worldName)) $wm->loadWorld($worldName);
 $world = $wm->getWorldByName($worldName);
 if ($world === null) { $sender->sendMessage("§cMonde de l'île introuvable !"); return; }
 $sender->teleport($world->getSpawnLocation());
 $sender->sendMessage("§aTéléporté sur l'île de §f" . $faction->getName());
 }
}
