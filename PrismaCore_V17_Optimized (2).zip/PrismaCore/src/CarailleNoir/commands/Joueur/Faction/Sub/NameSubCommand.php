<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class NameSubCommand extends BaseSubCommand
{
    public function __construct() { parent::__construct("name", "Modifier le nom de la faction"); }

    protected function prepare(): array { return [new RawStringArgument("name", false)]; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $faction = $sender->getFaction();
        if (!$faction instanceof Faction) {
            $sender->sendMessage("§cVous n'avez pas de faction.");
            return;
        }

        $name = $sender->getName();
        $isLeader = $faction->getOwner() === $name || in_array($name, $faction->get(FactionRoleEnum::SUB_OWNER), true);
        if (!$isLeader) {
            $sender->sendMessage("§cSeul le chef ou un sous-chef peut modifier le nom.");
            return;
        }

        $newName = trim((string)($args["name"] ?? ""));

        // Retirer les codes couleur §x pour les validations
        $cleanNew = strtolower(preg_replace('/§[0-9a-fk-or]/i', '', $newName));

        // Bloquer les caractères spéciaux — lettres, chiffres, tirets et underscores uniquement
        if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $cleanNew)) {
            $sender->sendMessage("§cLe nom ne peut contenir que des §elettres§c, §echiffres§c, §e-§c et §e_§c.");
            return;
        }

        if ($cleanNew === '' || mb_strlen($cleanNew) < 3) {
            $sender->sendMessage("§cLe nom doit contenir au moins §e3 caractères§c.");
            return;
        }

        if (mb_strlen($cleanNew) > 12) {
            $sender->sendMessage("§cLe nom ne peut pas dépasser §e12 caractères§c.");
            return;
        }

        foreach (Manager::FACTION()->getFactions() as $existing) {
            if ($existing->getId() === $faction->getId()) continue;
            $cleanExisting = strtolower(preg_replace('/§[0-9a-fk-or]/i', '', $existing->getName()));
            if ($cleanExisting === $cleanNew) {
                $sender->sendMessage("§cUne faction avec ce nom existe déjà.");
                return;
            }
        }

        $oldName = $faction->getName();
        $faction->setName($newName);
        Manager::FACTION()->renameIslandWorld($faction->getId(), $newName);
        Manager::FACTION()->save();
        FactionNameArgument::refreshEnum();
        foreach ($faction->getOnlinePlayers() ?? [] as $p) {
            $p->setFaction($faction->getId());
        }
        $sender->sendMessage("§aNom de faction mis à jour." . ($oldName !== $newName ? " §7(Island synchronisée si elle existait.)" : ""));
    }
}
