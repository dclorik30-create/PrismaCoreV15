<?php

namespace CarailleNoir\commands\Joueur\Faction;

use CarailleNoir\commands\Joueur\Faction\Sub\AcceptSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\AddAllySubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\AdminSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\BypassSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\JoinSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\FlySubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\ClaimSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\UnallySubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\TopSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\DescSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\DelHomeSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\HomeSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\SetHomeSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\UnclaimSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\AllyAcceptSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\BuyIslandSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\PermissionSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\InfoSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\NameSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\IslandSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\IslandVisitSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\IslandWhitelistSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\IslandUnWhitelistSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\LeaveSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Manage\CreateSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Manage\DisbandSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Manage\InviteSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Manage\KickSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Manage\LeaderSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Role\DemoteSubCommand;
use CarailleNoir\commands\Joueur\Faction\Sub\Role\PromoteSubCommand;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;

class FactionCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("faction", "Commande de faction", [
 new LeaveSubCommand(),
 new InfoSubCommand(),
 new AcceptSubCommand(),
 new CreateSubCommand(),
 new DisbandSubCommand(),
 new InviteSubCommand(),
 new KickSubCommand(),
 new LeaderSubCommand(),
 new PromoteSubCommand(),
 new DemoteSubCommand(),
 new IslandSubCommand(),
 new BuyIslandSubCommand(),
 new AddAllySubCommand(),
 new AllyAcceptSubCommand(),
 new PermissionSubCommand(),
 new AdminSubCommand(),
 new JoinSubCommand(),
 new BypassSubCommand(),
  new FlySubCommand(),
 new IslandVisitSubCommand(),
 new IslandWhitelistSubCommand(),
 new IslandUnWhitelistSubCommand(),
 new ClaimSubCommand(),
 new UnclaimSubCommand(),
 new UnallySubCommand(),
 new TopSubCommand(),
 new DescSubCommand(),
 new NameSubCommand(),
 new SetHomeSubCommand(),
 new HomeSubCommand(),
 new DelHomeSubCommand()
 ], ["f"]
 );
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $sender->sendMessage("§6Commandes faction : §f/f <create|invite|accept|leave|info|kick|leader|promote|demote|is|isbuy|disband|addally|allyaccept|perm|bypass|isvisit|iswl|isunwl|claim|unclaim|name|desc|sethome|home|delhome>");
 }
}
