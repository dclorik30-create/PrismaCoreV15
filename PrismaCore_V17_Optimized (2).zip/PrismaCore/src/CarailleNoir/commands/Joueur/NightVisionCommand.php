<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;

class NightVisionCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("nightvision", "Active/désactive le Night Vision", [], ["nv"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;
  $effects = $sender->getEffects();

  if ($effects->has(VanillaEffects::NIGHT_VISION())) {
   $effects->remove(VanillaEffects::NIGHT_VISION());
   $sender->sendMessage("§c[NV] Night Vision désactivé.");
  } else {
   // 999999999 ticks ≈ 578 jours — quasi-permanent
   $effects->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999999, 0, false, false));
   $sender->sendMessage("§a[NV] Night Vision activé.");
  }
 }
}
