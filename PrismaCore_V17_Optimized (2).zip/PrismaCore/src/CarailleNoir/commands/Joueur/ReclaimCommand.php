<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\ReclaimManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class ReclaimCommand extends BaseCommand
{
    private const COOLDOWN = 86400; // 24 h en secondes

    private array $cooldowns = [];

    public function __construct()
    {
        parent::__construct(
            "reclaim",
            "Reclamez votre recompense de grade (ou configurez-la avec add)",
            [], [], ["prisma.command.reclaim"]
        );
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument("action", true),   // "add" ou vide
            new RawStringArgument("grade",  true),   // grade cible si add
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCommande joueur uniquement.");
            return;
        }

        $action = strtolower($args["action"] ?? "");

        // ── /reclaim add <grade> — réservé aux OP ─────────────────────────
        if ($action === "add") {
            if (!\pocketmine\Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage("§cVous n'avez pas la permission.");
                return;
            }

            $grade = strtolower($args["grade"] ?? "");
            if ($grade === "" || !in_array($grade, ReclaimManager::getValidGrades(), true)) {
                $sender->sendMessage(
                    "§eUsage : §f/reclaim add <grade>\n§7Grades valides : §f"
                    . implode(", ", ReclaimManager::getValidGrades())
                );
                return;
            }

            Manager::RECLAIM()->openEditorMenu($sender, $grade);
            return;
        }

        // ── /reclaim — usage joueur ────────────────────────────────────────
        if (!$sender instanceof PrismaPlayer) return;

        $gradeId = strtolower($sender->getGradeId());

        // Vérifier que le grade a un reclaim configuré
        if (empty(Manager::RECLAIM()->getItems($gradeId))) {
            $sender->sendMessage("§cVotre grade ne donne pas accès au /reclaim ou n'a pas encore été configuré.");
            return;
        }

        // Cooldown 24 h
        $name    = strtolower($sender->getName());
        $now     = time();
        $lastUse = $this->cooldowns[$name] ?? 0;
        $elapsed = $now - $lastUse;

        if ($elapsed < self::COOLDOWN) {
            $remaining = self::COOLDOWN - $elapsed;
            $h   = (int) floor($remaining / 3600);
            $m   = (int) floor(($remaining % 3600) / 60);
            $s   = $remaining % 60;
            $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
            $sender->sendMessage("§cReclaim disponible dans : §f{$fmt}");
            return;
        }

        $this->cooldowns[$name] = $now;

        $given = Manager::RECLAIM()->giveReclaim($sender, $gradeId);
        if ($given) {
            $sender->sendMessage("§aVotre reclaim de grade §f" . $sender->getGradeId() . "§a a été distribué !");
        } else {
            $sender->sendMessage("§cErreur lors de la distribution du reclaim.");
        }
    }
}
