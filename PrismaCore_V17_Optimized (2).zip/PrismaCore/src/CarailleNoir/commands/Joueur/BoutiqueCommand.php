<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\player\Player;

class BoutiqueCommand extends BaseCommand
{
 public function __construct() { parent::__construct("boutique", "Ouvrir la boutique", [], [], ["prisma.command.boutique"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $sender->sendForm(new BoutiqueMainForm());
 }
}

// ── Menu principal ────────────────────────────────────────────────────────────
class BoutiqueMainForm implements Form
{
 public function jsonSerialize(): array
 {
 return [
 "type" => "form",
 "title" => "§6§lBoutique §r§f(Coins)",
 "content" => "§fChoisissez une catégorie :",
 "buttons" => [
 ["text" => "§2 Spawneur\n§fZombie, Squelette, Creeper"],
 ["text" => "§6 Grade\n§fNoble, Héros, Dieu"],
 ["text" => "§5 Atout\n§fProtection, Power par Kill"],
 ["text" => "§e Clé\n§fBoutique, Dieu, Héros, Noble, Vote"],
 ["text" => "§b MineVIP\n§fAccès à la mine VIP"],
 ],
 ];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) {
 $player->sendMessage("§cVous ne pouvez pas ouvrir la boutique en combat !");
 return;
 }
 $player->sendForm(match ((int)$data) {
 0 => new BoutiqueSpawnerForm(),
 1 => new BoutiqueGradeForm(),
 2 => new BoutiqueAtoutForm(),
 3 => new BoutiqueKeyForm(),
 4 => new BoutiqueMineVipForm(),
 default => new BoutiqueMainForm(),
 });
 }
}

// ── Spawneur ──────────────────────────────────────────────────────────────────
class BoutiqueSpawnerForm implements Form
{
 private const ITEMS = [
 "zombie"   => ["§2Zombie",    200],
 "skeleton" => ["§fSquelette", 200],
 "creeper"  => ["§aCreeper",   300],
 ];
 public function jsonSerialize(): array
 {
 $btns = [];
 foreach (self::ITEMS as [$lbl, $price]) $btns[] = ["text" => "$lbl\n§fPrix : §e{$price} §6Coins"];
 return ["type" => "form", "title" => "§2 Spawneur", "content" => "", "buttons" => $btns];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) { $player->sendMessage("§cAction impossible en combat !"); return; }
 $ids = array_keys(self::ITEMS);
 $id = $ids[$data] ?? null; if ($id === null) return;
 [$lbl, $price] = self::ITEMS[$id];
 if (!Manager::COINS()->hasCoins($player->getName(), $price)) { $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)"); return; }
 Manager::COINS()->removeCoins($player->getName(), $price);
 $player->getInventory()->addItem(Manager::SPAWNER()->makeSpawnerItem($id));
 $player->sendMessage("§aAchat de §f$lbl §apour §e{$price} §6Coins §a!");
 }
}

// ── Grade ─────────────────────────────────────────────────────────────────────
class BoutiqueGradeForm implements Form
{
 private const GRADES = [
 "Noble"  => ["§dNoble",   2000],
 "Héros"  => ["§bHéros",   5000],
 "Dieu"   => ["§6§lDieu", 10000],
 ];
 public function jsonSerialize(): array
 {
 $btns = [];
 foreach (self::GRADES as [$lbl, $price]) $btns[] = ["text" => "$lbl\n§fPrix : §e{$price} §6Coins"];
 return ["type" => "form", "title" => "§6 Grade", "content" => "§fL'achat remplace votre grade actuel.", "buttons" => $btns];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) { $player->sendMessage("§cAction impossible en combat !"); return; }
 $ids = array_keys(self::GRADES); $id = $ids[$data] ?? null; if ($id === null) return;
 [$lbl, $price] = self::GRADES[$id];
 $mgr = Manager::GRADE();
 if (!$mgr->existGrade($id)) { $player->sendMessage("§cErreur : le grade §f{$id} §cn'existe pas sur le serveur. Contactez un administrateur."); return; }
 if (!Manager::COINS()->hasCoins($player->getName(), $price)) { $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)"); return; }
 Manager::COINS()->removeCoins($player->getName(), $price);
 $mgr->addGrade($player, $id, $player->getName());
 $player->sendMessage("§aGrade §r$lbl §aacheté pour §e{$price} §6Coins §a!");
 }
}

// ── Atout ─────────────────────────────────────────────────────────────────────
class BoutiqueAtoutForm implements Form
{
 private const ATOUTS = [
 "antiitem"  => ["§dProtection Anti-Item", 3000],
 "powerkill" => ["§6+1 Power par Kill",    350],
 "force1"    => ["§cForce 1",              500],
 ];
 public function jsonSerialize(): array
 {
 // Récupérer le joueur courant via Server (form appelé sur le joueur)
 $btns = [];
 foreach (self::ATOUTS as $id => [$lbl, $price]) {
 $owned = false; // sera évalué côté handleResponse
 $btns[] = ["text" => "$lbl\n§fPrix : §e{$price} §6Coins"];
 }
 return ["type" => "form", "title" => "§5 Atout", "content" => "§fReappuyez pour activer/désactiver un atout déjà acheté.", "buttons" => $btns];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) { $player->sendMessage("§cAction impossible en combat !"); return; }
 $ids = array_keys(self::ATOUTS); $id = $ids[$data] ?? null; if ($id === null) return;
 [$lbl, $price] = self::ATOUTS[$id];
 // Toggle si déjà acheté
 if (Manager::ATOUT()->hasAtout($player->getName(), $id)) {
 $active = Manager::ATOUT()->isAtoutActive($player->getName(), $id);
 Manager::ATOUT()->setAtoutActive($player->getName(), $id, !$active);
 $state = !$active ? "§aactivé" : "§cdésactivé";
 $player->sendMessage("§5Atout §r$lbl $state §5!");
 // Appliquer / Retirer l'effet immédiatement pour l'atout Force 1
 if ($id === "force1") {
  if (!$active) {
   // Activation → donner STRENGTH pour 9 999 999 999 ticks
   $player->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(
    \pocketmine\entity\effect\VanillaEffects::STRENGTH(), 2147483647, 0, false, false
   ));
  } else {
   // Désactivation → retirer STRENGTH
   $player->getEffects()->remove(\pocketmine\entity\effect\VanillaEffects::STRENGTH());
  }
 }
 return;
 }
 if (!Manager::COINS()->hasCoins($player->getName(), $price)) { $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)"); return; }
 Manager::COINS()->removeCoins($player->getName(), $price);
 Manager::ATOUT()->addAtout($player->getName(), $id);
 $player->sendMessage("§aAtout §r$lbl §aacheté pour §e{$price} §6Coins §a!");
 // Appliquer l'effet immédiatement si c'est Force 1
 if ($id === "force1") {
  $player->getEffects()->add(new \pocketmine\entity\effect\EffectInstance(
   \pocketmine\entity\effect\VanillaEffects::STRENGTH(), 2147483647, 0, false, false
  ));
 }
 }
}

// ── Clé ───────────────────────────────────────────────────────────────────────
class BoutiqueKeyForm implements Form
{
 private const KEYS = [
 "boutique" => ["§eClé Boutique", 500],
 "dieu"     => ["§5Clé Dieu",    400],
 "heros"    => ["§cClé Héros",   250],
 "noble"    => ["§6Clé Noble",   150],
 "vote"     => ["§aClé Vote",     75],
 ];
 public function jsonSerialize(): array
 {
 $btns = [];
 foreach (self::KEYS as [$lbl, $price]) $btns[] = ["text" => "$lbl\n§fPrix : §e{$price} §6Coins"];
 return ["type" => "form", "title" => "§e Clé", "content" => "§fAchetez une clé de caisse :", "buttons" => $btns];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) { $player->sendMessage("§cAction impossible en combat !"); return; }
 $ids = array_keys(self::KEYS); $id = $ids[$data] ?? null; if ($id === null) return;
 [$lbl, $price] = self::KEYS[$id];
 if (!Manager::COINS()->hasCoins($player->getName(), $price)) { $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)"); return; }
 $item = Manager::BOX()->makeKeyItem($id);
 if ($item === null) { $player->sendMessage("§cErreur : clé introuvable."); return; }
 Manager::COINS()->removeCoins($player->getName(), $price);
 $player->getInventory()->addItem($item);
 $player->sendMessage("§aAchat de §f$lbl §apour §e{$price} §6Coins §a!");
 }
}

// ── MineVIP ───────────────────────────────────────────────────────────────────
class BoutiqueMineVipForm implements Form
{
 private const PRICE = 500;
 public function jsonSerialize(): array
 {
 return [
 "type" => "form",
 "title" => "§b MineVIP",
 "content" => "§fAccès permanent à la mine VIP.\n§fPrix : §e" . self::PRICE . " §6Coins",
 "buttons" => [
 ["text" => "§aAcheter l'accès MineVIP\n§e" . self::PRICE . " §6Coins"],
 ["text" => "§cRetour"],
 ],
 ];
 }
 public function handleResponse(Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null || (int)$data !== 0) return;
 if (Manager::COMBATLOG()->isTagged($player->getName())) { $player->sendMessage("§cAction impossible en combat !"); return; }
 if ($player->hasPermission("prisma.command.minevip")) { $player->sendMessage("§cVous avez déjà accès à la MineVIP !"); return; }
 if (!Manager::COINS()->hasCoins($player->getName(), self::PRICE)) { $player->sendMessage("§cPas assez de Coins ! (§e" . self::PRICE . " §6Coins §crequis)"); return; }
 Manager::COINS()->removeCoins($player->getName(), self::PRICE);
 $player->addPermission("prisma.command.minevip");
 $player->sendMessage("§aAccès §bMineVIP §aacheté ! Utilisez §f/minevip §apour vous téléporter.");
 }
}
