<?php
namespace CarailleNoir\commands\Joueur\Coins;
use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
class SetCoinsCommand extends BaseCommand {
 public function __construct() { parent::__construct("setcoins", "Définir les coins d'un joueur", [], [], [DefaultPermissions::ROOT_OPERATOR]); }
 protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new IntegerArgument("amount")]; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  $name = $args["player"];
  $amount = (int)$args["amount"];
  if (!Manager::COINS()->playerExists($name)) {
   $sender->sendMessage("§cJoueur §f{$name} §cinconnu ! Il doit s'être connecté au moins une fois.");
   return;
  }
  Manager::COINS()->setCoins($name, $amount);
  $sender->sendMessage("§aCoins définis à §f{$amount} §apour §f{$name}");
  $online = \pocketmine\Server::getInstance()->getPlayerExact($name);
  if ($online !== null) $online->sendMessage("§8[§6Coins§8] §aVos coins ont été définis à §f{$amount} §6Coins §ade la part du staff !");
 }
}
