<?php

namespace CarailleNoir\handlers;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\tasks\ZoneChaosTask;

class ManagerHandler
{
 public static function Load(): void
 {
 // DataHandler-based (init = loadData)
 Manager::BAN()->init();
 Manager::ALIAS()->init();
 Manager::SANCTION()->init();
 Manager::MUTE()->init();
 Manager::WARN()->init();
 Manager::GRADE()->init();
 Manager::OPD()->init();
 Manager::ECONOMY()->init();
 Manager::COINS()->init();
 Manager::STATS()->init();
 Manager::SETTINGS()->init();
 Manager::KIT()->init();
 Manager::ATOUT()->init();
 Manager::TIG()->init();
 Manager::TIGBLOCK()->init();
 Manager::ZONECHAOS()->init();
 Manager::HDV()->init();
 Manager::DAILY()->init();
 Manager::PLAYTIME()->init();

 // register-based (fichiers JSON/dossiers)
 Manager::REGION()->register();
 Manager::FACTION()->register();
 Manager::BOX()->register();
 Manager::SHOP()->register();
 Manager::MINE()->register();
 Manager::EVENT()->register();
 Manager::PV()->register();

 // Pas de persistance
 // Manager::PEARL() => in-memory
 // Manager::COMBATLOG() => in-memory
 // Manager::SPAWNER() — chargé depuis spawners.json
        Manager::SPAWNER()->load(\CarailleNoir\Core::getInstance());

 Manager::VOTE()::init();

 // ZoneChaos — tick toutes les 20 ticks (1s)
 Core::getInstance()->getScheduler()->scheduleRepeatingTask(new ZoneChaosTask(), 20);
 Manager::ALERT_WHITELIST()->init();
 Manager::LEVEL_DATA()->init();
 }

 public static function UnLoad(): void
 {
 Manager::BAN()->saveData();
 Manager::ALIAS()->saveData();
 Manager::SANCTION()->saveData();
 Manager::MUTE()->saveData();
 Manager::WARN()->saveData();
 Manager::GRADE()->saveData();
 Manager::OPD()->saveData();
 Manager::ECONOMY()->saveData();
 Manager::COINS()->saveData();
 Manager::STATS()->saveData();
 Manager::SETTINGS()->saveData();
 Manager::KIT()->saveData();
 Manager::ATOUT()->saveData();
 Manager::TIG()->saveData();
 Manager::HDV()->saveData();
 Manager::DAILY()->saveData();
 Manager::PLAYTIME()->saveData();

 Manager::REGION()->save();
 Manager::FACTION()->save();
 Manager::BOX()->save();
 Manager::SHOP()->save();
 Manager::PV()->save();

 Manager::VOTE()::save();
 Manager::FACTION()->saveIslands();
 Manager::LEVEL_DATA()->saveAll();
 }
}