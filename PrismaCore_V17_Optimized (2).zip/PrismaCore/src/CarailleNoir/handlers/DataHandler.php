<?php
declare(strict_types=1);
namespace CarailleNoir\handlers;

use CarailleNoir\Core;
use CarailleNoir\tasks\SaveDataAsyncTask;
use pocketmine\Server;
use Symfony\Component\Filesystem\Path;

class DataHandler
{
    protected array  $data       = [];
    protected string $folderName = "";
    protected string $fileName   = "Data.json";

    /** true dès qu'une donnée est modifiée depuis le dernier save */
    private bool $dirty = false;

    protected function getFilePath(): string
    {
        return Path::join(Core::getInstance()->getDataFolder(), $this->folderName, $this->fileName);
    }

    public function loadData(string $folderName, string $fileName = "Data.json"): void
    {
        $this->folderName = $folderName;
        $this->fileName   = $fileName;

        $file = $this->getFilePath();
        if (file_exists($file)) {
            $this->data = json_decode(file_get_contents($file), true) ?? [];
        } else {
            $this->data = [];
        }
        $this->dirty = false;
    }

    /** Marque ce manager comme modifié. À appeler dans chaque setter. */
    public function markDirty(): void
    {
        $this->dirty = true;
    }

    public function isDirty(): bool
    {
        return $this->dirty;
    }

    /**
     * Sauvegarde asynchrone :
     * - json_encode() sur le main thread (quelques ms)
     * - écriture disque sur un worker thread (non-bloquant)
     * - skip total si rien n'a changé (dirty flag)
     */
    public function saveData(): void
    {
        if (!$this->dirty) {
            return;
        }

        $json = json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $path = $this->getFilePath();

        $folder = dirname($path);
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }

        Server::getInstance()->getAsyncPool()->submitTask(
            new SaveDataAsyncTask($path, $json)
        );

        $this->dirty = false;
    }

    public function getData(): array
    {
        return $this->data;
    }

    public function setData(array $data): void
    {
        $this->data = $data;
        $this->markDirty();
    }

    public function playerExists(string $player): bool
    {
        return isset($this->data[strtolower($player)]);
    }
}
