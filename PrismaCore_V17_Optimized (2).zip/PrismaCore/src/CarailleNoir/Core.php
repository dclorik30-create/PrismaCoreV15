<?php

namespace CarailleNoir;

use CarailleNoir\libs\CortexPE\Commando\args\FactionNameArgument;
use CarailleNoir\tasks\TargetFactionUpdateTask;
use CarailleNoir\managers\Manager;

use CarailleNoir\handlers\ManagerHandler;
use CarailleNoir\libs\CortexPE\Commando\PacketHooker;
use CarailleNoir\libs\muqsit\invmenu\InvMenuHandler;
use CarailleNoir\utils\Loader;
use pocketmine\plugin\PluginBase;
use pocketmine\scheduler\ClosureTask;
use pocketmine\utils\Config;

class Core extends PluginBase
{
    private static self $self;

    public function onLoad(): void
    {
        self::$self = $this;
    }

    public static function getInstance(): self
    {
        return self::$self;
    }

    public function onEnable(): void
    {
        @mkdir($this->getDataFolder(), 0777, true);
        date_default_timezone_set("Europe/Paris");

        // ─────────────────────────────────────────────────────────────────
        // OPTIMISATION GC — désactive le ramasse-miettes automatique de PHP.
        //
        // Par défaut, PHP déclenche le GC dès que 10 000 objets cycliques
        // s'accumulent, en plein tick, bloquant le thread principal.
        // Sur ce serveur les timings montraient des pauses de 27 à 41 SECONDES
        // dues au GC cyclique (Cyclic GC avg 27 721 ms, pic 41 764 ms).
        //
        // Solution : on désactive le déclenchement automatique et on le
        // lance manuellement toutes les 5 minutes, seulement si la mémoire
        // utilisée dépasse 256 MB, et de manière contrôlée entre deux ticks.
        // ─────────────────────────────────────────────────────────────────
        gc_disable();

        $this->getScheduler()->scheduleRepeatingTask(
            new ClosureTask(function(): void {
                $usedMb = memory_get_usage(true) / 1024 / 1024;
                if ($usedMb > 256) {
                    gc_collect_cycles();
                    $this->getLogger()->debug(
                        sprintf("[GC] Cycles collectés (mémoire était %.1f MB).", $usedMb)
                    );
                }
            }),
            6000 // toutes les 5 minutes (6000 ticks)
        );

        // Configs système de niveaux — copie si absentes
        foreach (["levels.yml", "rewards.yml", "xp_sources.yml"] as $cfg) {
            if (!file_exists($this->getDataFolder() . $cfg)) {
                $this->saveResource($cfg);
            }
        }

        if (!PacketHooker::isRegistered()) {
            PacketHooker::register($this);
        }

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        ManagerHandler::Load();
        $this->getLogger()->info("§ePrisma Core§f activé avec §asuccès§f.");

        new Loader($this);

        // Delayed 1 tick : factions chargées avant de peupler l'enum /f info
        $this->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function(): void {
                FactionNameArgument::refreshEnum();
            }),
            1
        );

        // Rafraîchit l'autocomplétion des factions toutes les 10s (200 ticks)
        // pour éviter le spam de create/disband/rename qui crashait le serveur.
        $this->getScheduler()->scheduleRepeatingTask(
            new TargetFactionUpdateTask(),
            200
        );
    }

    public function onDisable(): void
    {
        $this->getLogger()->info("§cSAUVEGARDE des données du serveur... Merci de ne pas kill le process !");
        Manager::LEVEL()->saveAll();
        ManagerHandler::UnLoad();
        $this->getLogger()->info("§aSAUVEGARDE des données du serveur terminée !");
    }

    public function getConfigFile(string $file): Config
    {
        return new Config($this->getDataFolder() . $file . ".yml", Config::YAML);
    }
}
