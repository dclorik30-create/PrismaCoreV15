<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use CarailleNoir\PrismaItems\items\fragment\PrismDust;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeInfo;
use pocketmine\item\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockPermutationBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Crops;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class PrismCrop extends Crops
{
    public const MAX_AGE = 2;

    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:prism_crop", 4011),
            "Prism Crop",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    public function getDropsForCompatibleTool(Item $item): array
    {
        if ($this->age >= self::MAX_AGE) {
            $drops = [new PrismSeed()];
            if (mt_rand(1, 100) === 1) {
                $drops[] = new PrismDust();
            }
            return $drops;
        }
        return [new PrismSeed()];
    }

    public function asItem(): Item
    {
        return new PrismSeed();
    }

    public function getBlockBuilder(): BlockPermutationBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE))
            ->setGeometry("geometry.crop.v2");
    }
}
