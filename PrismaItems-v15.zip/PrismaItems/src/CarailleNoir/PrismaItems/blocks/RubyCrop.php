<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use CarailleNoir\PrismaItems\items\fragment\RubyFragment;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeInfo;
use pocketmine\item\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockPermutationBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Crops;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class RubyCrop extends Crops
{
    public const MAX_AGE = 2;

    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:ruby_crop", 4010),
            "Ruby Crop",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    public function getDropsForCompatibleTool(Item $item): array
    {
        if ($this->age >= self::MAX_AGE) {
            $drops = [new RubySeed()];
            if (mt_rand(1, 50) === 1) {
                $drops[] = new RubyFragment();
            }
            return $drops;
        }
        return [new RubySeed()];
    }

    public function asItem(): Item
    {
        return new RubySeed();
    }

    public function getBlockBuilder(): BlockPermutationBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE))
            ->setGeometry("geometry.crop.v2");
    }
}
