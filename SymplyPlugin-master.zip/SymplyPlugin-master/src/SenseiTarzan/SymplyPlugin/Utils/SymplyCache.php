<?php

/*
 *
 *            _____ _____         _      ______          _____  _   _ _____ _   _  _____
 *      /\   |_   _|  __ \       | |    |  ____|   /\   |  __ \| \ | |_   _| \ | |/ ____|
 *     /  \    | | | |  | |______| |    | |__     /  \  | |__) |  \| | | | |  \| | |  __
 *    / /\ \   | | | |  | |______| |    |  __|   / /\ \ |  _  /| . ` | | | | . ` | | |_ |
 *   / ____ \ _| |_| |__| |      | |____| |____ / ____ \| | \ \| |\  |_| |_| |\  | |__| |
 *  /_/    \_\_____|_____/       |______|______/_/    \_\_|  \_\_| \_|_____|_| \_|\_____|
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU Lesser General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * @author AID-LEARNING
 * @link https://github.com/AID-LEARNING
 *
 */

declare(strict_types=1);

namespace SenseiTarzan\SymplyPlugin\Utils;

use pocketmine\network\mcpe\protocol\types\BlockPaletteEntry;
use pocketmine\network\mcpe\protocol\types\ItemComponentPacketEntry;
use pocketmine\utils\SingletonTrait;

final class SymplyCache
{
	use SingletonTrait;
	public const BLOCK_ID_NEXT = 10000;
	public const ITEM_ID_NEXT = 9950;
	public static int $itemIdNext = self::ITEM_ID_NEXT;
	public static int $blockIdNext = self::BLOCK_ID_NEXT;

	/** @var BlockPaletteEntry[] */
	private array $blockPaletteEntries;

	/** @var ItemComponentPacketEntry[] */
	private array $itemsComponentPacketEntries;

	private array $transmitterBlockCustom;
	private array $transmitterItemCustom;
	private array $transmitterBlockOverwrite;
	private array $transmitterItemOverwrite;
	private array $transmitterBlockVanilla;
	private array $transmitterItemVanilla;

	public bool	$blockNetworkIdsAreHashes = false;

	public function __construct(private bool $asyncMode = false)
	{
		$this->blockPaletteEntries = [];
		$this->itemsComponentPacketEntries = [];
		if (!$this->asyncMode){
			$this->transmitterBlockCustom = [];
			$this->transmitterItemCustom = [];
			$this->transmitterBlockOverwrite = [];
			$this->transmitterItemOverwrite = [];
			$this->transmitterBlockVanilla = [];
			$this->transmitterItemVanilla = [];
		}
	}

	private static function make(bool $asyncMode = false) : self{
		return new self($asyncMode);
	}

	public static function getInstance(bool $asyncMode = false) : self{
		if(self::$instance === null){
			self::$instance = self::make($asyncMode);
		}
		return self::$instance;
	}

	public function setBlockPaletteEntries(array $blockPaletteEntries) : void
	{
		$this->blockPaletteEntries = $blockPaletteEntries;
	}

	public function addBlockPaletteEntry(BlockPaletteEntry $blockPaletteEntry) : void
	{
		$this->blockPaletteEntries[] = $blockPaletteEntry;
	}

	public function addTransmitterBlockCustom(array $arrayClosure) : void
	{
		$this->transmitterBlockCustom[] = $arrayClosure;
	}

	public function addTransmitterItemCustom(array $arrayClosure) : void
	{
		$this->transmitterItemCustom[] = $arrayClosure;
	}

	public function addTransmitterBlockOverwrite(array $arrayClosure) : void
	{
		$this->transmitterBlockOverwrite[] = $arrayClosure;
	}

	public function addTransmitterItemOverwrite(array $arrayClosure) : void
	{
		$this->transmitterItemOverwrite[] = $arrayClosure;
	}

	public function addTransmitterBlockVanilla(array $arrayClosure) : void
	{
		$this->transmitterBlockVanilla[] = $arrayClosure;
	}

	public function addTransmitterItemVanilla(array $arrayClosure) : void
	{
		$this->transmitterItemVanilla[] = $arrayClosure;
	}

	/**
	 * Gives custom blocks to load into threads
	 */
	public function getTransmitterBlockCustom() : array
	{
		return $this->transmitterBlockCustom;
	}

	/**
	 * Gives custom items to load into threads
	 */
	public function getTransmitterItemCustom() : array
	{
		return $this->transmitterItemCustom;
	}

	/**
	 * Overload vanilla blocks in threads
	 */
	public function getTransmitterBlockOverwrite() : array
	{
		return $this->transmitterBlockOverwrite;
	}

	/**
	 * Give vanilla items to overload in threads
	 */
	public function getTransmitterItemOverwrite() : array
	{
		return $this->transmitterItemOverwrite;
	}

	/**
	 * Gives vanilla blocks to load into threads
	 */
	public function getTransmitterBlockVanilla() : array
	{
		return $this->transmitterBlockVanilla;
	}

	/**
	 * Gives vanilla items to load into threads
	 */
	public function getTransmitterItemVanilla() : array
	{
		return $this->transmitterItemVanilla;
	}

	public function isBlockNetworkIdsAreHashes() : bool
	{
		return $this->blockNetworkIdsAreHashes;
	}

	public function setBlockNetworkIdsAreHashes(bool $blockNetworkIdsAreHashes) : void
	{
		$this->blockNetworkIdsAreHashes = $blockNetworkIdsAreHashes;
	}

	/**
	 * @return BlockPaletteEntry[]
	 */
	public function getBlockPaletteEntries() : array
	{
		return $this->blockPaletteEntries;
	}
}
