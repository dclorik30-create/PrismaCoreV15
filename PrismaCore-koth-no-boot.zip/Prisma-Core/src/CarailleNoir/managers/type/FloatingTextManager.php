<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\entities\FloatingTextEntity;
use CarailleNoir\managers\Manager;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\ClosureTask;
use pocketmine\world\ChunkLoader;
use pocketmine\Server;

/**
 * Gere tous les panneaux FloatingText.
 * Positions sauvegardees dans plugins/Prisma-Core/floating_texts.json
 * En jeu : /ft setpos <key>
 */
class FloatingTextManager
{
 private const DEFAULT_POS = [
 "outpost" => ["world" => "world", "x" => 0.5, "y" => 67.0, "z" => 0.5],
 "koth" => ["world" => "world", "x" => 10.5, "y" => 67.0, "z" => 0.5],
 "nexus" => ["world" => "world", "x" => 20.5, "y" => 67.0, "z" => 0.5],
 "totem" => ["world" => "world", "x" => 30.5, "y" => 67.0, "z" => 0.5],
 "topkills" => ["world" => "world", "x" => -10.5, "y" => 67.0, "z" => 0.5],
 "topdeaths" => ["world" => "world", "x" => -20.5, "y" => 67.0, "z" => 0.5],
 "toppower" => ["world" => "world", "x" => -30.5, "y" => 67.0, "z" => 0.5],
 "topmoney" => ["world" => "world", "x" => -40.5, "y" => 67.0, "z" => 0.5],
 "ftop" => ["world" => "world", "x" => -50.5, "y" => 67.0, "z" => 0.5],
 "vote" => ["world" => "world", "x" => 50.5, "y" => 67.0, "z" => 0.5],
 "discord"       => ["world" => "world", "x" => 60.5, "y" => 67.0, "z" => 0.5],
  "topassist"     => ["world" => "world", "x" => 70.5, "y" => 67.0, "z" => 0.5],
  "topkillstreak" => ["world" => "world", "x" => 80.5, "y" => 67.0, "z" => 0.5],
  "topniveau"     => ["world" => "world", "x" => 90.5, "y" => 67.0, "z" => 0.5],
 ];

 /** @var array<string, FloatingTextEntity> */
 private array $entities = [];

 /** @var array<string, ChunkLoader> : maintient les chunks chargés */
 private array $chunkLoaders = [];

 /** @var array<string, array> */
 private array $positions = [];

 private string $dataFile;

 public function __construct()
 {
 $this->dataFile = \CarailleNoir\Core::getInstance()->getDataFolder() . "floating_texts.json";
 $this->loadPositions();

 \CarailleNoir\Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new ClosureTask(function (): void { $this->spawnAll(); }),
 60
 );
 }

 // ── Persistance ────────────────────────────────────────────────────────

 private function loadPositions(): void
 {
 if (file_exists($this->dataFile)) {
 $data = json_decode(file_get_contents($this->dataFile), true);
 $this->positions = is_array($data) ? $data : [];
 }
 foreach (self::DEFAULT_POS as $key => $pos) {
 if (!isset($this->positions[$key])) {
 $this->positions[$key] = $pos;
 }
 }
 }

 private function savePositions(): void
 {
 file_put_contents($this->dataFile, json_encode($this->positions, JSON_PRETTY_PRINT));
 }

 public function getPosition(string $key): ?array
 {
 return $this->positions[$key] ?? null;
 }

 public function setPosition(string $key, array $pos): void
 {
 $this->positions[$key] = $pos;
 $this->savePositions();
 $this->respawn($key);
 }

 // ── Spawn / Despawn ────────────────────────────────────────────────────

 private function spawnAll(): void
 {
 foreach (array_keys(self::DEFAULT_POS) as $key) {
 $this->spawnAt($key, $this->buildText($key));
 }
 }

 private function spawnAt(string $key, string $text): void
 {
 // Detruire l'entite existante avant d'en creer une nouvelle
 if (isset($this->entities[$key])) {
 if (!$this->entities[$key]->isClosed()) {
 $this->entities[$key]->flagForDespawn();
 }
 unset($this->entities[$key]);
 }

 $pos = $this->positions[$key] ?? null;
 if ($pos === null) return;

 $srv = Server::getInstance();
 $world = $srv->getWorldManager()->getWorldByName($pos["world"]);
 if ($world === null) {
 if ($srv->getWorldManager()->loadWorld($pos["world"])) {
 $world = $srv->getWorldManager()->getWorldByName($pos["world"]);
 }
 if ($world === null) return;
 }

 // Garder le chunk charge en permanence
 if (isset($this->chunkLoaders[$key])) {
  $world->unregisterChunkLoader($this->chunkLoaders[$key], (int)$pos["x"] >> 4, (int)$pos["z"] >> 4);
 }
 $loader = new class implements ChunkLoader {};
 $this->chunkLoaders[$key] = $loader;
 $world->registerChunkLoader($loader, (int)$pos["x"] >> 4, (int)$pos["z"] >> 4, true);

 $loc = new Location((float)$pos["x"], (float)$pos["y"], (float)$pos["z"], $world, 0.0, 0.0);
 $entity = new FloatingTextEntity($loc, new CompoundTag());
 $entity->updateText($text);
 $entity->spawnToAll();
 $this->entities[$key] = $entity;
 }

 private function update(string $key, string $text): void
 {
 if (isset($this->entities[$key]) && !$this->entities[$key]->isClosed()) {
 $this->entities[$key]->updateText($text);
 } else {
 // Entite fermee (chunk dechargee etc.) — on respawn
 $this->spawnAt($key, $text);
 }
 }

 public function respawn(?string $key = null): void
 {
 if ($key !== null) {
 $this->spawnAt($key, $this->buildText($key));
 } else {
 foreach (array_keys(self::DEFAULT_POS) as $k) {
 $this->spawnAt($k, $this->buildText($k));
 }
 }
 }

 // ── Refresh periodique (FloatingTextTask) ──────────────────────────────

 public function refreshTops(): void
 {
 $this->update("topkills", $this->buildTopKills());
 $this->update("topdeaths", $this->buildTopDeaths());
 $this->update("toppower", $this->buildTopPower());
 $this->update("topmoney", $this->buildTopMoney());
 $this->update("ftop", $this->buildFTop());
 $this->update("vote", $this->buildVote());
  $this->update("topassist",     $this->buildTopAssist());
  $this->update("topkillstreak", $this->buildTopKillStreak());
  $this->update("topniveau",     $this->buildTopNiveau());
 }

 // ── Mise a jour Outpost (appele par OutpostTask chaque seconde) ────────

 private function factionName(?string $id): string
 {
 if ($id === null) return "Aucune";
 $f = Manager::FACTION()->getFaction($id);
 return $f !== null ? $f->getName() : $id;
 }

 public function updateOutpost(
 string $state,
 ?string $capturingFaction,
 ?string $capturedFaction,
 ?string $decapturingFaction,
 int $captureProgress,
 int $decaptureProgress,
 int $rewardTimer = 0
 ): void {
 $capName = $this->factionName($capturingFaction);
 $capOwn = $this->factionName($capturedFaction);
 $decapName = $this->factionName($decapturingFaction);
 $rewardLeft = OutpostManager::REWARD_INTERVAL - $rewardTimer;

 $text = match ($state) {
 OutpostManager::STATE_CAPTURING =>
 "§e§l-= Outpost =-\n" .
 "§7En capture par : §a{$capName}\n" .
 "§7Progression : " . $this->bar($captureProgress, Manager::OUTPOST()->getCaptureTime()) .
 " §f({$captureProgress}/" . Manager::OUTPOST()->getCaptureTime() . "s)",
 OutpostManager::STATE_CAPTURED =>
 "§e§l-= Outpost =-\n" .
 "§7Capture par : §a{$capOwn}\n" .
 "§7Recompense dans §f{$rewardLeft}§7s " . $this->bar($rewardTimer, OutpostManager::REWARD_INTERVAL, "§a"),
 OutpostManager::STATE_CONTESTED =>
 "§e§l-= Outpost =-\n" .
 "§c§l CONTESTE \n" .
 "§7Proprietaire : §f{$capOwn}",
 OutpostManager::STATE_DECAPTURING =>
 "§e§l-= Outpost =-\n" .
 "§7Proprietaire : §a{$capOwn}\n" .
 "§7Décapture par : §c{$decapName}\n" .
 "§7Dans : §c" . (OutpostManager::DECAPTURE_TIME - $decaptureProgress) . "s " .
 $this->bar($decaptureProgress, OutpostManager::DECAPTURE_TIME, "§c"),
 default =>
 "§e§l-= Outpost =-\n" .
 "§7Aucune faction dans la zone.\n" .
 "§7Entrez pour commencer la capture !",
 };
 $this->update("outpost", $text);
 }


 public function updateKoth(string $state, ?string $capturingFaction, ?string $capturedFaction, int $timeLeft): void
 {
 $text = match ($state) {
 "capturing" =>
 "§c§l-= KOTH =-\n" .
 "§7En capture par : §a{$capturingFaction}\n" .
 "§7Temps restant : §f{$timeLeft}s",
 "captured" =>
 "§c§l-= KOTH =-\n" .
 "§7Capture par : §a{$capturedFaction}\n" .
 "§7Temps restant : §f{$timeLeft}s",
 "ended" =>
 "§c§l-= KOTH =-\n" .
 "§7Gagne par : §6{$capturedFaction}\n" .
 "§7Prochain event bientot...",
 default =>
 "§c§l-= KOTH =-\n" .
 "§7Etat : §fInactif\n" .
 "§7En attente du prochain event.",
 };
 $this->update("koth", $text);
 }

 public function updateNexus(string $state, ?string $faction, int $hp, int $maxHp): void
 {
 $text = match ($state) {
 "active" =>
 "§5§l-= Nexus =-\n" .
 "§7En jeu !\n" .
 "§7Faction en tete : §d{$faction}\n" .
 "§7HP Nexus : §a{$hp}§7/§a{$maxHp}",
 "ended" =>
 "§5§l-= Nexus =-\n" .
 "§7Gagne par : §6{$faction}\n" .
 "§7Prochain event bientot...",
 default =>
 "§5§l-= Nexus =-\n" .
 "§7Etat : §fInactif\n" .
 "§7En attente du prochain event.",
 };
 $this->update("nexus", $text);
 }

 public function updateTotem(string $state, ?string $faction, int $timeLeft): void
 {
 $text = match ($state) {
 "active" =>
 "§2§l-= Totem =-\n" .
 "§7En jeu !\n" .
 "§7Faction en tete : §a{$faction}\n" .
 "§7Temps restant : §f{$timeLeft}s",
 "ended" =>
 "§2§l-= Totem =-\n" .
 "§7Gagne par : §6{$faction}\n" .
 "§7Prochain event bientot...",
 default =>
 "§2§l-= Totem =-\n" .
 "§7Etat : §fInactif\n" .
 "§7En attente du prochain event.",
 };
 $this->update("totem", $text);
 }

 // ── Dispatcher texte initial par cle ───────────────────────────────────

 private function buildText(string $key): string
 {
 return match ($key) {
 "outpost" => "§e§l-= Outpost =-\n§7Aucune faction dans la zone.\n§7Entrez pour commencer la capture !",
 "topkills" => $this->buildTopKills(),
 "topdeaths" => $this->buildTopDeaths(),
 "toppower" => $this->buildTopPower(),
 "topmoney" => $this->buildTopMoney(),
 "ftop" => $this->buildFTop(),
 "vote" => $this->buildVote(),
 "discord"       => $this->buildDiscord(),
   "topassist"     => $this->buildTopAssist(),
   "topkillstreak" => $this->buildTopKillStreak(),
   "topniveau"     => $this->buildTopNiveau(),
   default => $this->buildEventNeutral($key),
 };
 }

 // ── Builders Tops ──────────────────────────────────────────────────────

 private function buildTopKills(): string
 {
 $top = Manager::STATS()->getTopKills(10);
 $text = "§c§l--- Top Kills ---\n";
 $i = 1;
 foreach ($top as $name => $data) {
 $kills = (int)($data["kills"] ?? 0);
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $text .= "{$medal} §f{$name} §7- §c{$kills} kills\n";
 $i++;
 }
 return rtrim($text);
 }

 private function buildTopDeaths(): string
 {
 $top = Manager::STATS()->getTopDeaths(10);
 $text = "§8§l--- Top Morts ---\n";
 $i = 1;
 foreach ($top as $name => $data) {
 $deaths = (int)($data["deaths"] ?? 0);
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $text .= "{$medal} §f{$name} §7- §8{$deaths} morts\n";
 $i++;
 }
 return rtrim($text);
 }

 private function buildTopPower(): string
 {
 $top = Manager::STATS()->getTopPower(10);
 $text = "§b§l--- Top Power ---\n";
 $i = 1;
 foreach ($top as $name => $data) {
 $power = (int)($data["power"] ?? 0);
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $text .= "{$medal} §f{$name} §7- §b{$power} power\n";
 $i++;
 }
 return rtrim($text);
 }

 private function buildTopMoney(): string
 {
 $top = Manager::ECONOMY()->getTopMoney(10);
 $text = "§6§l--- Top Money ---\n";
 $i = 1;
 foreach ($top as $name => $data) {
 $money = (float)($data["money"] ?? 0);
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $text .= "{$medal} §f{$name} §7- §6" . number_format($money, 0, ".", " ") . "§7$\n";
 $i++;
 }
 return rtrim($text);
 }

 private function buildFTop(): string
 {
 $factions = Manager::FACTION()->getFactions();
 $powers = [];
 foreach ($factions as $f) {
 $total = 0;
 foreach (array_merge([$f->getOwner()], $f->getAll()) as $member) {
 $total += Manager::STATS()->getPower($member);
 }
 $powers[$f->getName()] = $total;
 }
 arsort($powers);
 $text = "§5§l--- Top Faction ---\n";
 $i = 1;
 foreach (array_slice($powers, 0, 10, true) as $name => $power) {
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $text .= "{$medal} §f{$name} §7- §5{$power} power\n";
 $i++;
 }
 return rtrim($text);
 }

 private function buildVote(): string
 {
 $current = VoteManager::getCurrentVotes();
 $max = VoteManager::MAX_VOTES;
 return
 "§a§l--- Vote ---\n" .
 "§7Votez pour des recompenses !\n" .
 "§fhttps://serveur.com/vote\n" .
 "§7Progression : " . $this->bar($current, $max, "§a") . "\n" .
 "§f{$current}§7/§f{$max} §7votes";
 }

 private function buildDiscord(): string
 {
 return
 "§9§l--- Discord ---\n" .
 "§7Rejoignez la communaute !\n" .
 "§fdiscord.gg/VOTRE_DISCORD\n" .
 "§7Support - Annonces - Events";
 }

 private function buildEventNeutral(string $key): string
 {
 $color = match ($key) {
 "koth" => "§c",
 "nexus" => "§5",
 "totem" => "§2",
 default => "§e",
 };
 $name = ucfirst($key);
 return "{$color}§l-= {$name} =-\n§7Etat : §fInactif\n§7En attente du prochain event.";
 }

 // ── Helper barre de progression ────────────────────────────────────────

 private function bar(int $progress, int $max, string $color = "§a"): string
 {
 $filled = $max > 0 ? (int)round(($progress / $max) * 10) : 0;
 return $color . str_repeat("|", $filled) . "§7" . str_repeat("-", 10 - $filled);
 }


 /** Supprime un panneau (entite + position du JSON) */
 public function delete(string $key): void
 {
 if (isset($this->entities[$key])) {
 if (!$this->entities[$key]->isClosed()) {
 $this->entities[$key]->flagForDespawn();
 }
 unset($this->entities[$key]);
 }
 unset($this->positions[$key]);
 $this->savePositions();
 }

 /** Supprime tous les panneaux */
 public function deleteAll(): void
 {
 foreach ($this->entities as $entity) {
 if (!$entity->isClosed()) $entity->flagForDespawn();
 }
 $this->entities = [];
 // On ne supprime pas les positions du JSON pour pouvoir les respawner
 }

 /** Spawn toutes les entites FT visibles au joueur qui vient de rejoindre */
 public function spawnToPlayer(\pocketmine\player\Player $player): void
 {
 foreach ($this->entities as $entity) {
 if (!$entity->isClosed()) {
 $entity->spawnTo($player);
 }
 }
 }
 // ── Top Assist ──────────────────────────────────────────────────────────

 private function buildTopAssist(): string
 {
  $top  = Manager::STATS()->getTopAssists(10);
  $text = "§e§l--- Top Assists ---\n";
  $i    = 1;
  foreach ($top as $name => $data) {
   $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
   $text .= "{$medal} §f{$name} §7- §e" . ($data["assists"] ?? 0) . " assists\n";
   $i++;
  }
  return rtrim($text);
 }

 // ── Top KillStreak ───────────────────────────────────────────────────────

 private function buildTopKillStreak(): string
 {
  $top  = Manager::STATS()->getTopKillStreak(10);
  $text = "§c§l--- Top KillStreak ---\n";
  $i    = 1;
  foreach ($top as $name => $data) {
   $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
   $text .= "{$medal} §f{$name} §7- §c" . ($data["bestkillstreak"] ?? 0) . " streak\n";
   $i++;
  }
  return rtrim($text);
 }

 // ── Top Niveau ───────────────────────────────────────────────────────────

 private function buildTopNiveau(): string
 {
  $all = Manager::LEVEL_DATA()->getAllLevels();
  arsort($all);
  $top  = array_slice($all, 0, 10, true);
  $text = "§a§l--- Top Niveau ---\n";
  $i    = 1;
  foreach ($top as $name => $lvl) {
   $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
   $text .= "{$medal} §f{$name} §7- §aNiveau §f{$lvl}\n";
   $i++;
  }
  return rtrim($text);
 }

 private function buildKoth(): string
 {
  $event = Manager::EVENT();
  $player = method_exists($event, 'getKothCapturingPlayer') ? ($event->getKothCapturingPlayer() ?? 'Aucun') : 'Aucun';
  $progress = method_exists($event, 'getCaptureProgress') ? $event->getCaptureProgress() : 0;
  $required = method_exists($event, 'getCaptureRequired') ? $event->getCaptureRequired() : 60;
  return "§e§l-= KOTH =-\n" .
   "§7En capture par : §a" . $player . "\n" .
   "§7Progression : " . $this->bar($progress, $required) .
   " §f(" . $progress . "/" . $required . "s)";
 }
}
