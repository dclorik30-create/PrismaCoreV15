<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\PrismCrop;
use CarailleNoir\PrismaItems\blocks\RubyCrop;
use CarailleNoir\PrismaItems\items\fragment\PrismDust;
use CarailleNoir\PrismaItems\items\fragment\RubyFragment;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use CarailleNoir\PrismaItems\manager\SeedManager;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\math\Facing;
use pocketmine\world\particle\HappyVillagerParticle;
use pocketmine\world\sound\PopSound;

class SeedListener implements Listener
{
    /**
     * Plantation :
     *  - PrismSeed  + clic droit dessus de Soul Sand  => pose prisma:prism_crop
     *  - RubySeed   + clic droit dessus de Dirt/Grass => pose prisma:ruby_crop
     */
    public function onInteract(PlayerInteractEvent $event): void
    {
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if ($event->getFace() !== Facing::UP) return;

        $player  = $event->getPlayer();
        $hand    = $player->getInventory()->getItemInHand();
        $block   = $event->getBlock();
        $above   = $block->getSide(Facing::UP);

        // L'emplacement au-dessus doit être de l'air
        if ($above->getTypeId() !== VanillaBlocks::AIR()->getTypeId()) return;

        $isPrism = $hand instanceof PrismSeed;
        $isRuby  = $hand instanceof RubySeed;
        if (!$isPrism && !$isRuby) return;

        // Vérifier le bloc support
        $soulSandId = VanillaBlocks::SOUL_SAND()->getTypeId();
        $dirtId     = VanillaBlocks::DIRT()->getTypeId();
        $grassId    = VanillaBlocks::GRASS()->getTypeId();

        if ($isPrism && $block->getTypeId() !== $soulSandId) {
            $player->sendMessage("§cLa Graine de Prisme ne peut être plantée que sur du Sable des Âmes !");
            $event->cancel();
            return;
        }
        if ($isRuby && $block->getTypeId() !== $dirtId && $block->getTypeId() !== $grassId) {
            $player->sendMessage("§cLa Graine de Rubis ne peut être plantée que sur de la Terre ou de l'Herbe !");
            $event->cancel();
            return;
        }

        $event->cancel();

        $abovePos = $above->getPosition();
        $world    = $player->getWorld();

        if ($isPrism) {
            // Poser le bloc custom prisma:prism_crop
            $world->setBlock($abovePos, new PrismCrop());
            SeedManager::plant("prism", $abovePos);
            $player->sendMessage("§bGraine de Prisme plantée ! Brisez-la pour tenter votre chance (1/100).");
        } else {
            // Poser le bloc custom prisma:ruby_crop
            $world->setBlock($abovePos, new RubyCrop());
            SeedManager::plant("ruby", $abovePos);
            $player->sendMessage("§cGraine de Rubis plantée ! Brisez-la pour tenter votre chance (1/50).");
        }

        // Consommer 1 graine
        $hand->setCount($hand->getCount() - 1);
        $player->getInventory()->setItemInHand($hand);

        $world->addParticle($abovePos->add(0.5, 0.5, 0.5), new HappyVillagerParticle());
        $world->addSound($abovePos->add(0.5, 0.5, 0.5), new PopSound());
    }

    /**
     * Récolte : briser le crop custom → roll de drop
     */
    public function onBreak(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();

        // Vérifie instanceof crop custom OU position dans SeedManager
        $isRubyCrop  = $block instanceof RubyCrop;
        $isPrismCrop = $block instanceof PrismCrop;

        if (!$isRubyCrop && !$isPrismCrop) return;

        $pos  = $block->getPosition();
        $type = SeedManager::harvest($pos);

        // Annuler les drops naturels
        $event->setDrops([]);

        $player = $event->getPlayer();

        // Déterminer le type depuis instanceof si SeedManager a perdu la trace (redémarrage)
        if ($type === null) {
            $type = $isRubyCrop ? "ruby" : "prism";
        }

        $roll = random_int(1, ($type === "prism" ? 100 : 50));

        if ($roll === 1) {
            if ($type === "prism") {
                $player->getInventory()->addItem(new PrismDust());
                $player->sendMessage("§b§l★ §bPoussiere de Prisme obtenue !");
            } else {
                $player->getInventory()->addItem(new RubyFragment());
                $player->sendMessage("§c§l★ §cFragment de Rubis obtenu !");
            }
            $player->getWorld()->addParticle($pos->add(0.5, 1.0, 0.5), new HappyVillagerParticle());
        } else {
            $player->sendMessage("§7Pas de chance cette fois... (1/" . ($type === "prism" ? "100" : "50") . ")");
        }
    }
}
