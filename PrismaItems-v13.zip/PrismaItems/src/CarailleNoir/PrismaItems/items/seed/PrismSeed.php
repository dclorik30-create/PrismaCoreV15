<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\seed;

use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;

class PrismSeed extends Item implements ICustomItem
{
 public function __construct()
 {
  parent::__construct(new ItemIdentifier("prisma:prism_seed", 30065), "§bGraine de Prisme");
 }

 public function getIdentifier(): ItemIdentifier
 {
  $id = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
  assert($id instanceof ItemIdentifier);
  return $id;
 }

 public function getItemBuilder(): ItemBuilder
 {
  return ItemBuilder::create()
   ->setItem($this)
   ->setDefaultMaxStack()
   ->setDefaultName()
   ->setIcon("prisma_prism_seed")
   ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::NATURE));
 }
}
