<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\manager;

use pocketmine\world\Position;

/**
 * Suit les positions ou des graines ont ete plantees.
 * Cle : "worldName:x:y:z"
 * Valeur : "prism" | "ruby"
 */
class SeedManager
{
    private static array $planted = [];

    private static function key(Position $pos): string
    {
        return $pos->getWorld()->getFolderName()
            . ":" . (int)floor($pos->x)
            . ":" . (int)floor($pos->y)
            . ":" . (int)floor($pos->z);
    }

    public static function plant(string $type, Position $pos): void
    {
        self::$planted[self::key($pos)] = $type;
    }

    /** Retourne le type de graine ("prism"|"ruby") ou null si pas de graine ici. */
    public static function harvest(Position $pos): ?string
    {
        $k = self::key($pos);
        if (!isset(self::$planted[$k])) return null;
        $type = self::$planted[$k];
        unset(self::$planted[$k]);
        return $type;
    }

    public static function isPlanted(Position $pos): bool
    {
        return isset(self::$planted[self::key($pos)]);
    }
}
