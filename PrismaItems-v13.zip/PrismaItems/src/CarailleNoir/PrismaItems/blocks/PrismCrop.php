<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Bloc visuel représentant une culture de Prisme plantée.
 * Posé par SeedListener sur du Soul Sand via prisma:prism_seed.
 * Briser ce bloc déclenche la récolte dans SeedListener.
 */
class PrismCrop extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:prism_crop", 4011),
            "§bCrop de Prisme",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE));
    }
}
