<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Bloc visuel représentant une culture de Rubis plantée.
 * Posé par SeedListener sur de la Terre/Herbe via prisma:ruby_seed.
 * Briser ce bloc déclenche la récolte dans SeedListener.
 */
class RubyCrop extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:ruby_crop", 4010),
            "§cCrop de Rubis",
            new BlockTypeInfo(BlockBreakInfo::instant())
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE));
    }
}
