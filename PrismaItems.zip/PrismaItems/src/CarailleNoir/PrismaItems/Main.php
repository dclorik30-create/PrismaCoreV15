<?php
declare(strict_types=1);

namespace CarailleNoir\PrismaItems;

use CarailleNoir\PrismaItems\blocks\AntiPearlBlock;
use CarailleNoir\PrismaItems\blocks\BoxBlock;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\RubyCrop;
use CarailleNoir\PrismaItems\blocks\PrismCrop;
use CarailleNoir\PrismaItems\blocks\spawner\CreeperSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\SkeletonSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\ZombieSpawner;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondBoots;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondChestplate;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondHelmet;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondLeggings;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldBoots;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldChestplate;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldHelmet;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldLeggings;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismBoots;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismChestplate;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismHelmet;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismLeggings;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyBoots;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyChestplate;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyHelmet;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyLeggings;
use CarailleNoir\PrismaItems\items\consumable\SoupItem;
use CarailleNoir\PrismaItems\items\fragment\PrismDust;
use CarailleNoir\PrismaItems\items\fragment\PrismFragment;
use CarailleNoir\PrismaItems\items\fragment\RubyFragment;
use CarailleNoir\PrismaItems\items\ingot\DiamondIngot;
use CarailleNoir\PrismaItems\items\ingot\EmeraldIngot;
use CarailleNoir\PrismaItems\items\ingot\PrismIngot;
use CarailleNoir\PrismaItems\items\ingot\RubyIngot;
use CarailleNoir\PrismaItems\items\key\BoutiqueKey;
use CarailleNoir\PrismaItems\items\key\DieuKey;
use CarailleNoir\PrismaItems\items\key\HerosKey;
use CarailleNoir\PrismaItems\items\key\NobleKey;
use CarailleNoir\PrismaItems\items\key\VoteKey;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use CarailleNoir\PrismaItems\items\staff\AntiItemStick;
use CarailleNoir\PrismaItems\items\staff\AntiPearlStick;
use CarailleNoir\PrismaItems\items\staff\ArcPunchItem;
use CarailleNoir\PrismaItems\items\staff\BumpItem;
use CarailleNoir\PrismaItems\items\staff\FreezeStick;
use CarailleNoir\PrismaItems\items\staff\PumpkinStick;
use CarailleNoir\PrismaItems\items\staff\TeleportStick;
use CarailleNoir\PrismaItems\items\sword\DiamondSword;
use CarailleNoir\PrismaItems\items\sword\EmeraldSword;
use CarailleNoir\PrismaItems\items\sword\PrismSword;
use CarailleNoir\PrismaItems\items\sword\RubySword;
use CarailleNoir\PrismaItems\listeners\AntiPearlListener;
use CarailleNoir\PrismaItems\listeners\BoxListener;
use CarailleNoir\PrismaItems\listeners\CropBreakListener;
use pocketmine\crafting\ExactRecipeIngredient;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\item\VanillaItems;
use pocketmine\plugin\PluginBase;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyBlockFactory;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyItemFactory;

class Main extends PluginBase
{
    protected function onLoad(): void
    {
        $bf = SymplyBlockFactory::getInstance();
        $bf->register(static fn() => new DiamondOre());
        $bf->register(static fn() => new EmeraldOre());
        $bf->register(static fn() => new RubyOre());
        $bf->register(static fn() => new PrismOre());
        $bf->register(static fn() => new ZombieSpawner());
        $bf->register(static fn() => new SkeletonSpawner());
        $bf->register(static fn() => new CreeperSpawner());
        $bf->register(static fn() => new AntiPearlBlock());
        $bf->register(static fn() => new BoxBlock());
        $bf->register(static fn() => new RubyCrop());
        $bf->register(static fn() => new PrismCrop());

        $if = SymplyItemFactory::getInstance();
        $if->register(static fn() => new DiamondIngot());
        $if->register(static fn() => new EmeraldIngot());
        $if->register(static fn() => new RubyIngot());
        $if->register(static fn() => new PrismIngot());
        $if->register(static fn() => new RubySeed());
        $if->register(static fn() => new PrismSeed());

        $if->register(static fn() => new DiamondSword());
        $if->register(static fn() => new EmeraldSword());
        $if->register(static fn() => new RubySword());
        $if->register(static fn() => new PrismSword());

        $if->register(static fn() => new DiamondHelmet());
        $if->register(static fn() => new DiamondChestplate());
        $if->register(static fn() => new DiamondLeggings());
        $if->register(static fn() => new DiamondBoots());
        $if->register(static fn() => new EmeraldHelmet());
        $if->register(static fn() => new EmeraldChestplate());
        $if->register(static fn() => new EmeraldLeggings());
        $if->register(static fn() => new EmeraldBoots());
        $if->register(static fn() => new RubyHelmet());
        $if->register(static fn() => new RubyChestplate());
        $if->register(static fn() => new RubyLeggings());
        $if->register(static fn() => new RubyBoots());
        $if->register(static fn() => new PrismHelmet());
        $if->register(static fn() => new PrismChestplate());
        $if->register(static fn() => new PrismLeggings());
        $if->register(static fn() => new PrismBoots());

        $if->register(static fn() => new ArcPunchItem());
        $if->register(static fn() => new FreezeStick());
        $if->register(static fn() => new AntiPearlStick());
        $if->register(static fn() => new AntiItemStick());
        $if->register(static fn() => new BumpItem());
        $if->register(static fn() => new RubyFragment());
        $if->register(static fn() => new PrismDust());
        $if->register(static fn() => new PrismFragment());
        $if->register(static fn() => new PumpkinStick());
        $if->register(static fn() => new TeleportStick());
        $if->register(static fn() => new SoupItem());
        $if->register(static fn() => new VoteKey());
        $if->register(static fn() => new NobleKey());
        $if->register(static fn() => new HerosKey());
        $if->register(static fn() => new DieuKey());
        $if->register(static fn() => new BoutiqueKey());

        $this->getLogger()->info("§aPrismaItems chargé — 4 minerais, 4 lingots, 4 épées, 16 armures, 6 items staff, 1 consommable, 5 clés, 1 Box.");
    }

    protected function onEnable(): void
    {
        $this->getServer()->getPluginManager()->registerEvents(new AntiPearlListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new BoxListener(), $this);
        $this->getServer()->getPluginManager()->registerEvents(new CropBreakListener(), $this);
        $this->registerCustomRecipes();
    }

    private function registerCustomRecipes(): void
    {
        $cm = $this->getServer()->getCraftingManager();
        $stick = new ExactRecipeIngredient(VanillaItems::STICK());
        $recipe = static function(array $shape, array $map, array $results) use ($cm): void {
            $cm->registerShapedRecipe(new ShapedRecipe($shape, $map, $results));
        };

        $diamond = new ExactRecipeIngredient(new DiamondIngot());
        $emerald = new ExactRecipeIngredient(new EmeraldIngot());
        $ruby = new ExactRecipeIngredient(new RubyIngot());
        $prism = new ExactRecipeIngredient(new PrismIngot());

        $recipe(["XXX", "X X"], ["X" => $diamond], [new DiamondHelmet()]);
        $recipe(["X X", "XXX", "XXX"], ["X" => $diamond], [new DiamondChestplate()]);
        $recipe(["XXX", "X X", "X X"], ["X" => $diamond], [new DiamondLeggings()]);
        $recipe(["X X", "X X"], ["X" => $diamond], [new DiamondBoots()]);
        $recipe(["X", "X", "S"], ["X" => $diamond, "S" => $stick], [new DiamondSword()]);

        $recipe(["XXX", "X X"], ["X" => $emerald], [new EmeraldHelmet()]);
        $recipe(["X X", "XXX", "XXX"], ["X" => $emerald], [new EmeraldChestplate()]);
        $recipe(["XXX", "X X", "X X"], ["X" => $emerald], [new EmeraldLeggings()]);
        $recipe(["X X", "X X"], ["X" => $emerald], [new EmeraldBoots()]);
        $recipe(["X", "X", "S"], ["X" => $emerald, "S" => $stick], [new EmeraldSword()]);

        $recipe(["XXX", "X X"], ["X" => $ruby], [new RubyHelmet()]);
        $recipe(["X X", "XXX", "XXX"], ["X" => $ruby], [new RubyChestplate()]);
        $recipe(["XXX", "X X", "X X"], ["X" => $ruby], [new RubyLeggings()]);
        $recipe(["X X", "X X"], ["X" => $ruby], [new RubyBoots()]);
        $recipe(["X", "X", "S"], ["X" => $ruby, "S" => $stick], [new RubySword()]);

        $recipe(["XXX", "X X"], ["X" => $prism], [new PrismHelmet()]);
        $recipe(["X X", "XXX", "XXX"], ["X" => $prism], [new PrismChestplate()]);
        $recipe(["XXX", "X X", "X X"], ["X" => $prism], [new PrismLeggings()]);
        $recipe(["X X", "X X"], ["X" => $prism], [new PrismBoots()]);
        $recipe(["X", "X", "S"], ["X" => $prism, "S" => $stick], [new PrismSword()]);


        // ══ Compactage Prisme : 9 PrismDust → 1 PrismFragment ══
        $cm->registerShapedRecipe(new ShapedRecipe(
            ["XXX", "XXX", "XXX"],
            ["X" => new ExactRecipeIngredient(new PrismDust())],
            [new PrismFragment()]
        ));
        // ══ Compactage Prisme : 9 PrismFragment → 1 PrismIngot ══
        $cm->registerShapedRecipe(new ShapedRecipe(
            ["XXX", "XXX", "XXX"],
            ["X" => new ExactRecipeIngredient(new PrismFragment())],
            [new PrismIngot()]
        ));
        // ══ Compactage Rubis : 9 RubyFragment → 1 RubyIngot ══
        $cm->registerShapedRecipe(new ShapedRecipe(
            ["XXX", "XXX", "XXX"],
            ["X" => new ExactRecipeIngredient(new RubyFragment())],
            [new RubyIngot()]
        ));
        $this->getLogger()->info("§a23 recettes custom enregistrées.");
    }
}