<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Bloc AntiPearl — ID prisma:anti_pearl (4201)
 * Annule le téléport d'une ender pearl qui atterrit dessus.
 * Solidité proche de l'andésite.
 */
class AntiPearlBlock extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:anti_pearl", 4201),
            "§5Bloc AntiPearl",
            new BlockTypeInfo(new BlockBreakInfo(1.5, BlockToolType::PICKAXE, 1))
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::CONSTRUCTION));
    }
}
