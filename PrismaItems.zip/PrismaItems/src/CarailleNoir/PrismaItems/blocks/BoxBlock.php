<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

/**
 * Bloc Box — ID prisma:box (4200)
 * 1 seul bloc, plusieurs clés possibles (VoteKey, NobleKey, HerosKey, DieuKey, BoutiqueKey).
 * Cassable uniquement avec la permission prismabox.admin.
 */
class BoxBlock extends Opaque
{
 public function __construct()
 {
 parent::__construct(
 new BlockIdentifier("prisma:box", 4200),
 "§6Box",
 new BlockTypeInfo(new BlockBreakInfo(50.0, BlockToolType::PICKAXE, 1))
 );
 }

 public function getBlockBuilder(): BlockBuilder
 {
 return parent::getBlockBuilder()
 ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::CONSTRUCTION));
 }
}
