<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks\spawner;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class SkeletonSpawner extends Opaque
{
 public const LORE_ID = "§8ID:spawner_skeleton";

 public function __construct()
 {
 parent::__construct(
 new BlockIdentifier("prisma:skeleton_spawner", 4102),
 "§7Spawneur à Squelette",
 new BlockTypeInfo(new BlockBreakInfo(5.0, BlockToolType::PICKAXE, 1))
 );
 }

 public function getBlockBuilder(): BlockBuilder
 {
 return parent::getBlockBuilder()
 ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE));
 }
}
