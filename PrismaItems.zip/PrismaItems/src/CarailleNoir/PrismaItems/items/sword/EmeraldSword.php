<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\sword;

use SenseiTarzan\SymplyPlugin\Behavior\Items\Sword;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class EmeraldSword extends Sword
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:emerald_sword", 30018),
 "§aÉpée en Émeraude",
 new ToolTier(
 harvestLevel: 4,
 maxDurability: 2000,
 baseAttackPoints: 7,
 baseEfficiency: 8,
 enchantability: 10
 )
 );
 }

 public function getItemBuilder(): ItemBuilder
 {
 return parent::getItemBuilder()->setIcon("prisma_emerald_sword");
 }
}
