<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\sword;

use SenseiTarzan\SymplyPlugin\Behavior\Items\Sword;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class PrismSword extends Sword
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:prism_sword", 30020),
 "§dÉpée en Prisme",
 new ToolTier(
 harvestLevel: 4,
 maxDurability: 3000,
 baseAttackPoints: 9,
 baseEfficiency: 8,
 enchantability: 10
 )
 );
 }

 public function getItemBuilder(): ItemBuilder
 {
 return parent::getItemBuilder()->setIcon("prisma_prism_sword");
 }
}
