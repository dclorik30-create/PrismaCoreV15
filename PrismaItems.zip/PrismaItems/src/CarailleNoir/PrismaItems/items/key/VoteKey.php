<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\key;

use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;

class VoteKey extends Item implements ICustomItem
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:key_vote", 30110),
 "§aClé Vote"
 );
 $this->setLore(["§8ID:item_key_vote", "§eUtilisez cette clé pour ouvrir un coffre !"]);
 }

 public function getMaxStackSize(): int { return 64; }

 public function getIdentifier(): ItemIdentifier
 {
 $identifier = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
 assert($identifier instanceof ItemIdentifier);
 return $identifier;
 }

 public function getItemBuilder(): ItemBuilder
 {
 return ItemBuilder::create()
 ->setItem($this)
 ->setDefaultMaxStack()
 ->setDefaultName()
 ->setIcon("key_vote")
 ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
 }
}
