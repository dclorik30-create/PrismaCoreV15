<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\consumable;

use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;

class SoupItem extends Item implements ICustomItem
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:soup", 30100),
 "§aSoupe"
 );
 $this->setLore(["§8ID:item_soup", "§7Clic droit pour se soigner."]);
 }

 public function getMaxStackSize(): int { return 64; }

 public function getIdentifier(): ItemIdentifier
 {
 $identifier = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
 assert($identifier instanceof ItemIdentifier);
 return $identifier;
 }

 public function getItemBuilder(): ItemBuilder
 {
 return ItemBuilder::create()
 ->setItem($this)
 ->setDefaultMaxStack()
 ->setDefaultName()
 ->setIcon("mushroom_stew")
 ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
 }
}
