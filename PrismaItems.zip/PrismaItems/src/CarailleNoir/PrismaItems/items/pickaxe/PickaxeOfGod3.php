<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\pickaxe;

use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Pickaxe;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class PickaxeOfGod3 extends Pickaxe implements ICustomItem
{
    public const LEVEL = 3;
    public const REQUIRED_BLOCKS = 7000;

    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:pickaxeofgod3", 30123),
            "§6Pickaxe Of God 3",
            new ToolTier(
                harvestLevel: 10,
                maxDurability: 2147483647,
                baseAttackPoints: 0,
                baseEfficiency: 12,
                enchantability: 30
            )
        );
        $this->setLore([
            "§7Une pioche divine qui évolue en minant.",
            "§8ID:item_pog_3",
            "§e0 Blocks / 7000",
            "§7Progression vers le niveau suivant"
        ]);
    }

    public function getIdentifier(): ItemIdentifier
    {
        $identifier = (new ReflectionProperty(\pocketmine\item\Item::class, "identifier"))->getValue($this);
        assert($identifier instanceof ItemIdentifier);
        return $identifier;
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("item_pog_3")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
    }
}
