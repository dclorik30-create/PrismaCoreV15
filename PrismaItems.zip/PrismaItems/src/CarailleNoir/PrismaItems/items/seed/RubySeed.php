<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\seed;

use CarailleNoir\PrismaItems\blocks\RubyCrop;
use pocketmine\block\Block;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;

class RubySeed extends Item
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:ruby_seed", 30063),
            "§cGraine de Rubis"
        );
    }

    public function getBlock(?int $clickedFace = null): Block
    {
        return (new RubyCrop())->setAge(0);
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("ruby_seed")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::NATURE));
    }
}
