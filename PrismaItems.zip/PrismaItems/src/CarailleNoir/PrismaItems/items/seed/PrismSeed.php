<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\seed;

use CarailleNoir\PrismaItems\blocks\PrismCrop;
use pocketmine\block\Block;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Item;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;

class PrismSeed extends Item
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:prism_seed", 30064),
            "§dGraine de Prisme"
        );
    }

    public function getBlock(?int $clickedFace = null): Block
    {
        return (new PrismCrop())->setAge(0);
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("prism_seed")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::NATURE));
    }
}
