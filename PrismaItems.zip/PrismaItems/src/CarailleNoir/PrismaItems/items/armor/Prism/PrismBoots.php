<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Prism;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class PrismBoots extends Armor implements IPrismaArmor
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:prism_boots", 30016),
 "§dBottes en Prisme",
 new ArmorTypeInfo(
 maxDurability: 4000,
 defensePoints: 4,
 armorSlot: ArmorInventory::SLOT_FEET,
 toughness: 2
 )
 );
 }

 public function getPrismaTier(): int { return 3; }

 public function getItemBuilder(): ItemBuilder
 {
 return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_prism_boots");
 }
}
