<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\ingot;

use pocketmine\item\Item;
use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;

class PrismIngot extends Item implements ICustomItem
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:prism_ingot", 30024),
 "§dLingot de Prisme"
 );
 }

 public function getIdentifier(): ItemIdentifier
 {
 $identifier = (new ReflectionProperty(Item::class, "identifier"))->getValue($this);
 assert($identifier instanceof ItemIdentifier);
 return $identifier;
 }

 public function getItemBuilder(): ItemBuilder
 {
 return ItemBuilder::create()
 ->setItem($this)
 ->setDefaultMaxStack()
 ->setDefaultName()
 ->setIcon("prisma_prism_ingot")
 ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
 }
}
