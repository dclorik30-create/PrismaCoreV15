<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\interface;

interface IPrismaArmor
{
 /** Retourne le tier Prisma (0=Diamant, 1=Émeraude, 2=Rubis, 3=Prisme). */
 public function getPrismaTier(): int;
}
