<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use pocketmine\entity\projectile\EnderPearl;
use pocketmine\event\entity\ProjectileHitBlockEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\world\particle\SmokeParticle;
use pocketmine\world\sound\FizzSound;

class AntiPearlListener implements Listener
{
    /** @var int[] */
    private array $blockIds = [];

    public function __construct()
    {
        // On passe par StringToItemParser exactement comme la référence :
        // SymplyPlugin enregistre 'prisma:anti_pearl' → on récupère le bloc enregistré → typeId fiable
        $item = StringToItemParser::getInstance()->parse('prisma:anti_pearl');
        if ($item !== null) {
            $block = $item->getBlock();
            $this->blockIds[] = $block->getTypeId();
        }
    }

    public function onHitBlock(ProjectileHitBlockEvent $event): void
    {
        $entity   = $event->getEntity();
        $owner    = $entity->getOwningEntity();
        $blockHit = $event->getBlockHit();

        if (!$entity instanceof EnderPearl) return;

        if ($owner instanceof Player && in_array($blockHit->getTypeId(), $this->blockIds, true)) {
            $entity->setOwningEntity(null);

            $owner->getInventory()->addItem(VanillaItems::ENDER_PEARL());
            $owner->sendMessage("§5[AntiPearl] §cVotre pearl a été bloquée !");

            $pos   = $blockHit->getPosition()->add(0.5, 1.0, 0.5);
            $world = $blockHit->getPosition()->getWorld();
            for ($i = 0; $i < 8; $i++) {
                $world->addParticle($pos->add(
                    mt_rand(-10, 10) / 20,
                    mt_rand(0, 20) / 20,
                    mt_rand(-10, 10) / 20
                ), new SmokeParticle());
            }
            $world->addSound($pos, new FizzSound());
        }
    }
}
