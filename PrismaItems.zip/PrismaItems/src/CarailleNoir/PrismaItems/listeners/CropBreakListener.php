<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\listeners;

use CarailleNoir\PrismaItems\blocks\PrismCrop;
use CarailleNoir\PrismaItems\blocks\RubyCrop;
use CarailleNoir\PrismaItems\items\seed\PrismSeed;
use CarailleNoir\PrismaItems\items\seed\RubySeed;
use pocketmine\block\VanillaBlocks;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\EventPriority;
use pocketmine\event\Listener;

/**
 * Gère les crops Prisma au cassage :
 *
 * Crop IMMATURE :
 *   - Cancel l'event (bloque le XP de PrismaCore qui écoute NORMAL)
 *   - Retire le bloc manuellement (setBlock AIR)
 *   - Drop 1 graine manuellement via dropItem
 *
 * Crop MATURE :
 *   - Laisse l'event passer, impose les drops via setDrops()
 *
 * @priority LOWEST
 * @handleCancelled false
 */
class CropBreakListener implements Listener
{
    public function onCropBreak(BlockBreakEvent $event): void
    {
        $block = $event->getBlock();

        if (!($block instanceof RubyCrop) && !($block instanceof PrismCrop)) {
            return;
        }

        $age    = $block->getAge();
        $maxAge = $block::MAX_AGE;
        $world  = $block->getPosition()->getWorld();
        $pos    = $block->getPosition();

        if ($age < $maxAge) {
            // ── Immature : cancel → PrismaCore (NORMAL) ne voit pas l'event ──
            $event->cancel();

            // Retirer le bloc manuellement
            $world->setBlock($pos, VanillaBlocks::AIR());

            // Drop la graine correspondante
            $seed = $block instanceof RubyCrop ? new RubySeed() : new PrismSeed();
            $world->dropItem($pos->add(0.5, 0.5, 0.5), $seed);

        } else {
            // ── Mature : imposer les drops, laisser XP passer ──
            $event->setDrops($block->getDropsForCompatibleTool($event->getItem()));
        }
    }
}
