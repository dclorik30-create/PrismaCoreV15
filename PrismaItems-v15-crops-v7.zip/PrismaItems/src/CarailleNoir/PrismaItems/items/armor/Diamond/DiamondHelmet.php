<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Diamond;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class DiamondHelmet extends Armor implements IPrismaArmor
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:diamond_helmet", 30001),
 "§bDiamond §7Casque",
 new ArmorTypeInfo(
 maxDurability: 1500,
 defensePoints: 2,
 armorSlot: ArmorInventory::SLOT_HEAD,
 toughness: 0
 )
 );
 }

 public function getPrismaTier(): int { return 0; }

 public function getItemBuilder(): ItemBuilder
 {
 return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_diamond_helmet");
 }
}
