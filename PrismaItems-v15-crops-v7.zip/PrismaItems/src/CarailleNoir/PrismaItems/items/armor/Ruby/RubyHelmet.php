<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Ruby;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class RubyHelmet extends Armor implements IPrismaArmor
{
 public function __construct()
 {
 parent::__construct(
 new ItemIdentifier("prisma:ruby_helmet", 30009),
 "§cRuby §7Casque",
 new ArmorTypeInfo(
 maxDurability: 3000,
 defensePoints: 4,
 armorSlot: ArmorInventory::SLOT_HEAD,
 toughness: 1
 )
 );
 }

 public function getPrismaTier(): int { return 2; }

 public function getItemBuilder(): ItemBuilder
 {
 return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_ruby_helmet");
 }
}
