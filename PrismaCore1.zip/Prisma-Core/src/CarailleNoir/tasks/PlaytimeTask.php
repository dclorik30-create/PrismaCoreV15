<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class PlaytimeTask extends Task
{
    public function onRun(): void
    {
        Manager::PLAYTIME()->flushSessions();
    }
}
