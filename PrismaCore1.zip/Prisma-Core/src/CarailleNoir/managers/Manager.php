<?php

namespace CarailleNoir\managers;

use CarailleNoir\managers\type\AlertWhitelistManager;
use CarailleNoir\managers\type\LevelDataManager;
use CarailleNoir\managers\type\LevelManager;
use CarailleNoir\managers\type\LevelRewardManager;
use CarailleNoir\managers\type\AliasManager;
use CarailleNoir\managers\type\AntiItemManager;
use CarailleNoir\managers\type\StickFreezeManager;
use CarailleNoir\managers\type\CustomEnchantManager;
use CarailleNoir\managers\type\AtoutManager;
use CarailleNoir\managers\type\BanManager;
use CarailleNoir\managers\type\BoxManager;
use CarailleNoir\managers\type\CoinsManager;
use CarailleNoir\managers\type\DailyManager;
use CarailleNoir\managers\type\PlaytimeManager;
use CarailleNoir\managers\type\CombatlogManager;
use CarailleNoir\managers\type\EconomyManager;
use CarailleNoir\managers\type\EventManager;
use CarailleNoir\managers\type\Faction\FactionManager;
use CarailleNoir\managers\type\GradeManager;
use CarailleNoir\managers\type\KitManager;
use CarailleNoir\managers\type\OutpostManager;
use CarailleNoir\managers\type\FloatingTextManager;
use CarailleNoir\managers\type\HdvManager;
use CarailleNoir\managers\type\MarketManager;
use CarailleNoir\managers\type\MineManager;
use CarailleNoir\managers\type\MuteManager;
use CarailleNoir\managers\type\OfflinePlayerDataManager;
use CarailleNoir\managers\type\PearlManager;
use CarailleNoir\managers\type\PermissionManager;
use CarailleNoir\managers\type\PlayerVaultManager;
use CarailleNoir\managers\type\Region\RegionManager;
use CarailleNoir\managers\type\SanctionManager;
use CarailleNoir\managers\type\SettingsManager;
use CarailleNoir\managers\type\ShopManager;
use CarailleNoir\managers\type\SpawnerManager;
use CarailleNoir\managers\type\StatsManager;
use CarailleNoir\managers\type\TIGManager;
use CarailleNoir\managers\type\TIGBlockManager;
use CarailleNoir\managers\type\VoteManager;
use CarailleNoir\managers\type\WarnManager;
use pocketmine\utils\RegistryTrait;

/**
 * @method static AliasManager ALIAS()
 * @method static AntiItemManager ANTIITEM()
 * @method static StickFreezeManager STICKFREEZE()
 * @method static CustomEnchantManager CUSTOMENCHANT()
 * @method static AtoutManager ATOUT()
 * @method static SanctionManager SANCTION()
 * @method static BanManager BAN()
 * @method static BoxManager BOX()
 * @method static CoinsManager COINS()
 * @method static DailyManager DAILY()
 * @method static PlaytimeManager PLAYTIME()
 * @method static CombatlogManager COMBATLOG()
 * @method static EconomyManager ECONOMY()
 * @method static EventManager EVENT()
 * @method static FactionManager FACTION()
 * @method static GradeManager GRADE()
 * @method static KitManager KIT()
 * @method static HdvManager HDV()
 * @method static MarketManager MARKET()
 * @method static MineManager MINE()
 * @method static MuteManager MUTE()
 * @method static OfflinePlayerDataManager OPD()
 * @method static PearlManager PEARL()
 * @method static PermissionManager PERMISSION()
 * @method static PlayerVaultManager PV()
 * @method static RegionManager REGION()
 * @method static SettingsManager SETTINGS()
 * @method static ShopManager SHOP()
 * @method static SpawnerManager SPAWNER()
 * @method static StatsManager STATS()
 * @method static TIGManager TIG()
 * @method static TIGBlockManager TIGBLOCK()
 * @method static VoteManager VOTE()
 * @method static WarnManager WARN()
 * @method static OutpostManager OUTPOST()
 * @method static AlertWhitelistManager ALERT_WHITELIST()
 * @method static LevelDataManager LEVEL_DATA()
 * @method static LevelManager LEVEL()
 * @method static LevelRewardManager LEVEL_REWARD()
 * @method static FloatingTextManager FLOATINGTEXT()
 */
class Manager
{
 use RegistryTrait;

 protected static function setup(): void
 {
 self::_registryRegister("customenchant", new CustomEnchantManager());
 self::_registryRegister("antiitem", new AntiItemManager());
 self::_registryRegister("stickfreeze", new StickFreezeManager());
 self::_registryRegister("alias", new AliasManager());
 self::_registryRegister("atout", new AtoutManager());
 self::_registryRegister("sanction", new SanctionManager());
 self::_registryRegister("ban", new BanManager());
 self::_registryRegister("box", new BoxManager());
 self::_registryRegister("coins", new CoinsManager());
 self::_registryRegister("daily", new DailyManager());
 self::_registryRegister("playtime", new PlaytimeManager());
 self::_registryRegister("combatlog", new CombatlogManager());
 self::_registryRegister("economy", new EconomyManager());
 self::_registryRegister("event", new EventManager());
 self::_registryRegister("faction", new FactionManager());
 self::_registryRegister("grade", new GradeManager());
 self::_registryRegister("kit", new KitManager());
 self::_registryRegister("hdv", new HdvManager());
 self::_registryRegister("market", new MarketManager());
 self::_registryRegister("mine", new MineManager());
 self::_registryRegister("mute", new MuteManager());
 self::_registryRegister("opd", new OfflinePlayerDataManager());
 self::_registryRegister("pearl", new PearlManager());
 self::_registryRegister("permission", new PermissionManager());
 self::_registryRegister("pv", new PlayerVaultManager());
 self::_registryRegister("region", new RegionManager());
 self::_registryRegister("settings", new SettingsManager());
 self::_registryRegister("shop", new ShopManager());
 self::_registryRegister("spawner", new SpawnerManager());
 self::_registryRegister("stats", new StatsManager());
 self::_registryRegister("tig", new TIGManager());
 self::_registryRegister("tigblock", new TIGBlockManager());
 self::_registryRegister("vote", new VoteManager());
 self::_registryRegister("warn", new WarnManager());
 self::_registryRegister("outpost", new OutpostManager());
 self::_registryRegister("floatingtext", new FloatingTextManager());
 self::_registryRegister("alert_whitelist", new AlertWhitelistManager());
 $df = \CarailleNoir\Core::getInstance()->getDataFolder();
 self::_registryRegister("level_data",   new LevelDataManager($df));
 self::_registryRegister("level_reward", new LevelRewardManager($df));
 self::_registryRegister("level",        new LevelManager($df));
 }
}
