<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\commands\Joueur\Faction\Sub\args\PermTypeArgument;
use CarailleNoir\commands\Joueur\Faction\Sub\args\PermScopeArgument;
use CarailleNoir\commands\Joueur\Faction\Sub\args\PermValueArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class PermissionSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("permission", "Gérer les permissions de l'île", [], []);
    }

    protected function prepare(): array
    {
        return [
            new PermTypeArgument("type", false),
            new PermScopeArgument("scope", false),
            new PermValueArgument("value", false),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $faction = $sender->getFaction();
        if ($faction === null) { FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []); return; }
        if ($faction->getOwner() !== $sender->getName()) {
            FactionMessageEnum::NOT_OWNER->sendToPlayer($sender, []); return;
        }

        $type  = strtolower($args["type"]  ?? "");
        $scope = strtolower($args["scope"] ?? "");
        $value = strtolower($args["value"] ?? "");

        if ($type !== "ally" || ($scope !== "island" && $scope !== "ap")) {
            $sender->sendMessage("§cUsage : §f/f permission ally island <true|false>");
            $sender->sendMessage("§f        §f/f permission ally ap <true|false>");
            return;
        }
        if ($value !== "true" && $value !== "false") {
            $sender->sendMessage("§cValeur invalide : §ftrue §7ou §ffalse"); return;
        }

        $allowed = $value === "true";
        if ($scope === "island") {
            $faction->setAllyBuildAllowed($allowed);
            Manager::FACTION()->save();
            $sender->sendMessage($allowed
                ? "§aLes alliés peuvent maintenant builder sur votre island !"
                : "§cLes alliés ne peuvent plus builder sur votre island.");
        } else {
            $faction->setAllyClaimAllowed($allowed);
            Manager::FACTION()->save();
            $sender->sendMessage($allowed
                ? "§aLes alliés peuvent maintenant interagir dans vos claims !"
                : "§cLes alliés ne peuvent plus interagir dans vos claims.");
        }
    }
}
