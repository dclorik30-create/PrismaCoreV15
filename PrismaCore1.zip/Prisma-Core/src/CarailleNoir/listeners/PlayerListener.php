<?php

namespace CarailleNoir\listeners;

use CarailleNoir\tasks\FlyTask;
use CarailleNoir\handlers\ChatHandler;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\invmenu\SanctionMenu;
use CarailleNoir\managers\AssistTracker;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\RegionOption;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\managers\type\SettingsManager;
use CarailleNoir\tasks\PumpkinRestoreTask;
use CarailleNoir\tasks\NameTagTask;
use CarailleNoir\tasks\ScoreboardTask;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\projectile\Snowball;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\entity\EntityEffectAddEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemConsumeEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;
use pocketmine\network\mcpe\protocol\types\BoolGameRule;
use pocketmine\player\chat\LegacyRawChatFormatter;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;

class PlayerListener extends ChatHandler implements Listener
{
 /** @var array<string, array{world:string,chunkX:int,chunkZ:int}> */
 private static array $playerChunkCache = [];

 /** @var array<string, int> cooldowns items spéciaux */
 private array $itemCooldowns = [];
 /** @var array<string, int> partagé avec TipTask */
 public static array $arcPunchCooldowns = [];
 /** @var array<string, true> boules de neige SwitchBall en vol */
 public static array $activeSwitchBall = [];
 private array $lastAttackers = [];
 private array $savedHelmets = [];
 private array $chorusCooldowns = [];



 public function onCreation(PlayerCreationEvent $event): void
 {
 $event->setPlayerClass(PrismaPlayer::class);
 }

 public function onLogin(PlayerLoginEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;


 if (!Manager::ALIAS()->hasProfil($player->getName())) {
 Manager::ALIAS()->createProfil($player);
 }

 if (Manager::BAN()->isBanned($player)) {
 $banInfo = Manager::BAN()->getBanInfo($player);
 $reason = $banInfo["reason"];
 $staff = $banInfo["staff"];
 $expire = $banInfo["expire"] ? date("d/m/Y H-i-s", $banInfo["expire"]) : "Permanent";
 $player->kick("§cBanni pour: §f$reason\n§7Par: $staff\n§7Expire: $expire");
 return;
 }

 Manager::ECONOMY()->ensurePlayer($player->getName());
 Manager::COINS()->ensurePlayer($player->getName());
 Manager::STATS()->ensurePlayer($player->getName());
 Manager::SETTINGS()->ensurePlayer($player->getName());
 Manager::GRADE()->setDefaultGrade($player->getName());
 }

 public function onJoin(PlayerJoinEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 // TIG check
 Manager::TIG()->checkOnLogin($player);

 // Initialiser faim et saturation au maximum (AntiHunger)
 // 19 = pas de régénération de vie (la regen se déclenche à 20)
 $player->getHungerManager()->setFood(19);
 $player->getHungerManager()->setSaturation(0.0);

 $player->freeze($player->isFreeze());
 Manager::PERMISSION()->register($player);

 $gradeData = Manager::GRADE()->getPlayerGradeData($player->getName());
 $gradeName = $gradeData["name"] ?? null;
 $gradeColor = $gradeData["color"] ?? "§f";

 if ($gradeName !== null && strtolower($gradeData["id"] ?? "") !== "joueur") {
 $joinMsg = "§a[+] §r{$gradeColor}{$gradeName} §r{$player->getName()}§a a rejoint le serveur";
 } else {
 $joinMsg = "§a[+] §r§f{$player->getName()}";
 }

 if (!$player->hasPlayedBefore()) {
 Server::getInstance()->broadcastMessage(TextUtils::PREFIX . str_replace("{name}", $player->getName(), TextUtils::NEW_PLAYER));
 } else {
 Server::getInstance()->broadcastMessage($joinMsg);
 }

 // Nightvision si activé dans les settings
 if (Manager::SETTINGS()->getSetting($player->getName(), SettingsManager::SETTING_NIGHTVISION)) {
 $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999, 0, false, false));
 }

 $player->getNetworkSession()->sendDataPacket(GameRulesChangedPacket::create([
 "showcoordinates" => new BoolGameRule(true, false)
 ]));

 $event->setJoinMessage("");

 // Spawn les floating texts au joueur qui rejoint
 Manager::FLOATINGTEXT()->spawnToPlayer($player);
 // Scoreboard : rafraîchir tous (compteur Joueurs)
 $player->setNameTag(NameTagTask::buildTag($player));
 $player->setNameTagAlwaysVisible(true);
 ScoreboardTask::refreshAll();
 Manager::PLAYTIME()->startSession($player->getName());
 }

 public function onLeave(PlayerQuitEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

        // CombatLog : drop du stuff + mort si déco en combat
        if (Manager::COMBATLOG()->isTagged($player->getName()) && $player->isAlive()) {
            $cLogger = $player->getName();
            $lastAtk = Manager::COMBATLOG()->getLastAttacker($cLogger);

            // Drop tout l'inventaire au sol
            $pos   = $player->getPosition();
            $world = $player->getWorld();
            foreach ($player->getInventory()->getContents() as $dropItem) {
                $world->dropItem($pos, $dropItem);
            }
            foreach ($player->getArmorInventory()->getContents() as $dropItem) {
                $world->dropItem($pos, $dropItem);
            }
            $player->getInventory()->clearAll();
            $player->getArmorInventory()->clearAll();

            Manager::STATS()->addDeath($cLogger);
            Manager::COMBATLOG()->untag($cLogger);

            if ($lastAtk !== null) {
                Manager::STATS()->addKill($lastAtk);
                if (($atk = Server::getInstance()->getPlayerExact($lastAtk)) instanceof PrismaPlayer) {
                    ScoreboardTask::refresh($atk);
                }                Server::getInstance()->broadcastMessage(
                    "§f{$cLogger} §7s'est deconnecte en combat ! §8(§7Tue par : §f{$lastAtk}§8)"
                );
            } else {
                Server::getInstance()->broadcastMessage(
                    "§f{$cLogger} §7s'est deconnecte en combat !"
                );
            }
        }
 $lKey = strtolower($player->getName());
 unset($this->savedHelmets[$lKey], $this->lastAttackers[$lKey], $this->chorusCooldowns[$lKey]);
		AssistTracker::clear($player->getName());
		AssistTracker::clear($player->getName());

 $gradeColor = $player->getGradeColor();
 Server::getInstance()->broadcastMessage("[§c-§r] {$gradeColor}{$player->getName()}");

 Manager::PERMISSION()->unregister($player);
 if (Manager::FACTION()->hasInvite($player->getName())) {
 Manager::FACTION()->removeInvite($player->getName());
 }
 // Nettoyage des cooldowns en mémoire pour éviter les fuites
 $name = $player->getName();
 foreach (array_keys($this->itemCooldowns) as $k) {
 if (str_starts_with((string)$k, strtolower($name))) {
 unset($this->itemCooldowns[$k]);
 }
 }
 
 $player->invalidateGradeCache();
 Manager::ANTIITEM()->remove($name);
 Manager::STICKFREEZE()->unfreeze($name);
 Manager::FACTION()->removeBypass($player->getName());
 unset(self::$playerChunkCache[$player->getName()]);
 $event->setQuitMessage("");
 FlyTask::stopFly($player->getName());
 Manager::PLAYTIME()->endSession($player->getName());
 // Scoreboard : rafraîchir tous (compteur Joueurs après déco)
 ScoreboardTask::refreshAll();
 }

 public function onDeath(PlayerDeathEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 // Supprime le message de mort vanilla
 $event->setDeathMessage("");

 Manager::STATS()->addDeath($player->getName());
 ScoreboardTask::refresh($player);
 Manager::COMBATLOG()->untag($player->getName());
 ScoreboardTask::refresh($player); // Scoreboard : hors combat
 $dKey = strtolower($player->getName());
 if (isset($this->savedHelmets[$dKey])) {
 $helmet = $this->savedHelmets[$dKey];
 unset($this->savedHelmets[$dKey]);
 if (!$helmet->isNull()) { $player->getInventory()->addItem($helmet); }
 }
 }

 public function onPlayerDamage(EntityDamageEvent $event): void
 {
 $entity = $event->getEntity();
 $cause = $event->getCause();

 // ── Monde island_ : AUCUN dégât autorisé ──────────────────────────
 if ($entity instanceof PrismaPlayer) {
 $worldName = $entity->getWorld()->getFolderName();
 if (str_starts_with($worldName, "island_")) {
 $event->cancel();
 if ($cause === EntityDamageEvent::CAUSE_VOID) {
 // Sécurité supplémentaire : TP spawn si VOID se déclenche quand même
 $wm = Server::getInstance()->getWorldManager();
 $w = $wm->getWorldByName($worldName);
 if ($w !== null) $entity->teleport($w->getSpawnLocation());
 }
 return;
 }
 }

 // ── Hors island : logique normale ─────────────────────────────────
 $blacklist = [
 EntityDamageEvent::CAUSE_VOID,
 EntityDamageEvent::CAUSE_DROWNING,
 EntityDamageEvent::CAUSE_SUICIDE,
 EntityDamageEvent::CAUSE_LAVA
 ];
 if (in_array($cause, $blacklist, true)) { $event->cancel(); return; }

 $player = $event->getEntity();
 if (!$player instanceof PrismaPlayer) return;

 // StaffMod noclip : ignorer les degats environnementaux pendant la traversee des blocs
 if ($player->isStaffMode() && in_array($cause, [EntityDamageEvent::CAUSE_SUFFOCATION, EntityDamageEvent::CAUSE_CONTACT, EntityDamageEvent::CAUSE_FALL, EntityDamageEvent::CAUSE_VOID, EntityDamageEvent::CAUSE_LAVA, EntityDamageEvent::CAUSE_FIRE, EntityDamageEvent::CAUSE_FIRE_TICK, EntityDamageEvent::CAUSE_DROWNING, EntityDamageEvent::CAUSE_MAGIC], true)) {
 $player->extinguish();
 $event->cancel();
 return;
 }

 if (Manager::MINE()->isMineWorld($player->getWorld()->getFolderName())) {
 $cause = $event->getCause();
 if (in_array($cause, [EntityDamageEvent::CAUSE_ENTITY_ATTACK, EntityDamageEvent::CAUSE_PROJECTILE, EntityDamageEvent::CAUSE_FIRE, EntityDamageEvent::CAUSE_FIRE_TICK, EntityDamageEvent::CAUSE_LAVA, EntityDamageEvent::CAUSE_BLOCK_EXPLOSION, EntityDamageEvent::CAUSE_ENTITY_EXPLOSION, EntityDamageEvent::CAUSE_CONTACT, EntityDamageEvent::CAUSE_MAGIC], true)) {
 $player->extinguish();
 $event->cancel();
 return;
 }
 }

 $region = Manager::REGION()->getMainRegionAt($player->getPosition());
 if ($region !== null) {
 if (!$region->isSettingsEnabled(RegionOption::PARAM_FALL_DAMAGE->getType()) && $cause === EntityDamageEvent::CAUSE_FALL) {
 $event->cancel();
 }
 if (!$region->isSettingsEnabled(RegionOption::PARAM_FIRE_DAMAGE->getType()) &&
 ($cause === EntityDamageEvent::CAUSE_FIRE || $cause === EntityDamageEvent::CAUSE_FIRE_TICK || $cause === EntityDamageEvent::CAUSE_MAGIC)) {
 $player->extinguish();
 $event->cancel();
 }
 }
 }

 /** Vérifie si deux joueurs sont dans la même faction ou alliés */
 private function areFriendly(\CarailleNoir\player\PrismaPlayer $a, \CarailleNoir\player\PrismaPlayer $b): bool
 {
 $fA = $a->getFaction();
 $fB = $b->getFaction();
 if ($fA === null || $fB === null) return false;
 if ($fA->getId() === $fB->getId()) return true; // même faction
 return $fA->isAlly($fB->getId()); // alliés
 }

 public function onAttack(EntityDamageByEntityEvent $event): void
 {
 $attacker = $event->getDamager();
 $victim = $event->getEntity();
 if (!$attacker instanceof PrismaPlayer || !$victim instanceof PrismaPlayer) return;

 if ($attacker->isStaffMode()) {
 $event->cancel();
 if (SpecialItems::isSanctionStick($attacker->getInventory()->getItemInHand())) {
  SanctionMenu::sendTargetPanel($attacker, $victim);
 }
 return;
 }

 if (Manager::MINE()->isMineWorld($victim->getWorld()->getFolderName()) || Manager::MINE()->isMineWorld($attacker->getWorld()->getFolderName())) {
 $event->cancel();
 return;
 }

 $attackerName = strtolower($attacker->getName());
 $victimName = strtolower($victim->getName());
 $held = $attacker->getInventory()->getItemInHand();
 $now = time();

 if ($attacker->isFreeze() || $victim->isFreeze()) {
 $event->cancel(); return;
 }
 if ($this->areFriendly($attacker, $victim)) {
 $attacker->sendTip("§eVous ne pouvez pas attaquer un allié !");
 $event->cancel();
 return;
 }

 $pos = $victim->getPosition()->floor();
 $region = Manager::REGION()->getMainRegionAt($pos);
 if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_PVP->getType())) {
 $attacker->sendMessage("§cVous ne pouvez pas taper un joueur dans une zone protégée !");
 $event->cancel();
 return;
 }

 // Message combat uniquement à la première mise en combat
 if (!Manager::COMBATLOG()->isTagged($attacker->getName())) {
  $attacker->sendMessage("§c[Combat] §fVous avez ete mis en combat durant 15 secondes.");
 }
 if (!Manager::COMBATLOG()->isTagged($victim->getName())) {
  $victim->sendMessage("§c[Combat] §fVous avez ete mis en combat durant 15 secondes.");
 }
 Manager::COMBATLOG()->tag($attacker->getName());
 Manager::COMBATLOG()->tag($victim->getName());
 Manager::COMBATLOG()->setLastAttacker($victim->getName(), $attacker->getName());
 // Tracker assists — enregistre le coup pour la fenêtre 60s
 AssistTracker::recordHit($victim->getName(), $attacker->getName());
 // CPS comptabilisé via ServerListener
 // Scoreboard : actualiser immédiatement lors du tag combat
 ScoreboardTask::refresh($attacker);
 ScoreboardTask::refresh($victim);

 // Tracker dernier attaquant (TeleportStick)
 $this->lastAttackers[strtolower($victimName)] = ['name' => $attacker->getName(), 'time' => $now];

 // ── Stick Citrouille — cooldown $attackerName (pas $name !) ──────
 if (SpecialItems::isPumpkinStick($held)) {
 $event->cancel();
 $cdKey = $attackerName . "_pumpkin"; // FIX: $attackerName défini en début de onAttack
 $cdPumpkin = 30;
 if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdPumpkin) {
 $remaining = $cdPumpkin - ($now - $this->itemCooldowns[$cdKey]);
 $attacker->sendTip("§6Citrouille §8» §cCooldown : §f{$remaining}s");
 return;
 }
 $this->itemCooldowns[$cdKey] = $now;
 $vKey = strtolower($victimName);
 if (!isset($this->savedHelmets[$vKey])) {
 $savedHelmet = clone $victim->getArmorInventory()->getHelmet();
 $this->savedHelmets[$vKey] = $savedHelmet;
 $victim->getArmorInventory()->setHelmet(SpecialItems::makeTempPumpkin());
 $victim->sendTip("§6Citrouille posée ! §7Casque remplacé pendant §e5s§7.");
 $attacker->sendTip("§6Citrouille sur §f" . $victim->getName() . " §6!");
 $plugin = \pocketmine\Server::getInstance()->getPluginManager()->getPlugin('Prisma');
 if ($plugin !== null) {
 $plugin->getScheduler()->scheduleDelayedTask(
 new PumpkinRestoreTask($victim->getName(), $savedHelmet, $this), 100);
 }
 } else {
 $attacker->sendTip("§cCe joueur a déjà une citrouille !");
 }
 return;
 }

 if ($victim->getHealth() - $event->getFinalDamage() <= 0) {
  Manager::STATS()->addKill($attacker->getName());
  $streak = Manager::STATS()->incrementKillStreak($attacker->getName());
  ScoreboardTask::refresh($attacker);
  Manager::STATS()->resetKillStreak($victim->getName());
  $assistNames   = AssistTracker::getAssists($victim->getName(), $attacker->getName());
  $assistDisplay = [];
  foreach ($assistNames as $assistLow) {
   Manager::STATS()->addAssist($assistLow);
   $assistDisplay[] = "§f" . $assistLow;
   $ap = \pocketmine\Server::getInstance()->getPlayerExact($assistLow);
   if ($ap !== null) Manager::LEVEL()->addExp($ap, 15, "Assist");
  }
  $assistPart = !empty($assistDisplay) ? " §7| §eAssist : " . implode("§7, ", $assistDisplay) : "";
  $streakPart = $streak >= 3 ? " §c§l[×{$streak}]" : "";
     // Compter les soupes du gagnant
   $soupCount = 0;
   foreach ($attacker->getInventory()->getContents() as $__it) {
    if ($__it->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($__it)) {
     $soupCount += $__it->getCount();
    }
   }
   Server::getInstance()->broadcastMessage(
    "§8[§6Prisma§8] §f" . $victim->getName() . " §7a ete tue par §f" . $attacker->getName() . " §8[§6Soupe : §f" . $soupCount . "§8]" . $streakPart
   );
}
 $event->setKnockBack(0.42);
 }

 public function onExhaust(PlayerExhaustEvent $event): void
 {
 // AntiHunger global : aucun joueur ne perd de faim sur ce serveur.
 // La gestion régionale est conservée mais inutile ici vu le cancel global.
 $event->cancel();
 }

 public function onChat(PlayerChatEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 // ── Anti-spam ──────────────────────────────────────────────────────
 $name = $player->getName();
 $now = time();
 if (isset($this->chatCooldowns[$name]) && ($now - $this->chatCooldowns[$name]) < 2) {
 $event->cancel();
 $player->sendMessage("§cAnti-spam : attendez §e2 secondes §centre chaque message.");
 return;
 }
 $this->chatCooldowns[$name] = $now;

 // ── Bloquer chat depuis TIG (uniquement pour le joueur TIG, pas le staff) ──
 if ($player->getWorld()->getFolderName() === \CarailleNoir\managers\type\TIGManager::TIG_WORLD
 && Manager::TIG()->isTIG($player->getName())) {
 $event->cancel();
 $player->sendMessage("§cVous ne pouvez pas parler depuis la TIG.");
 return;
 }

 $region = Manager::REGION()->getMainRegionAt($player->getPosition()->asVector3());
 if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_CHAT->getType())) {
 $player->sendMessage("§cVous ne pouvez pas parler dans une zone mute !");
 $event->cancel();
 return;
 }

 if (Manager::MUTE()->isMuted($player)) {
 $event->cancel();
 $info = Manager::MUTE()->getMuteInfo($player);
 $expire = $info["expire"] ? date("d/m/Y H:i:s", $info["expire"]) : "Permanent";
 $player->sendMessage("§cVous êtes mute !\nRaison : {$info["reason"]}\nExpire : {$expire}");
 return;
 }

 $gradeData = Manager::GRADE()->getPlayerGradeData($player->getName());
 $faction = $player->getFaction();
 $color = $gradeData["color"] ?? TextFormat::GREEN;
 $gradeName = $gradeData["name"] ?? "Joueur";

 $message = str_replace(
 ["{grade}", "{facname}", "{playername}", "{message}", "{color}"],
 [$gradeName, $faction?->getName() ?? "Aucune", $player->getVisualName(), "{%1}", $color],
 "{color}[{grade}§r{color}] §f[{facname}§f] {color}{playername}§f »{color} {message}"
 );
 $event->setFormatter(new LegacyRawChatFormatter($message));
 }

 public function onItemUse(PlayerItemUseEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $item = $event->getItem();
 $name = strtolower($player->getName());
 $now = time();

 // ===================== Soupe =====================
 if ($item->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($item)) {
 $event->cancel();

 // ── Vérification et clear des surplus (petits stacks en premier) ──
 $inv = $player->getInventory();

 /**
 * Supprime l'excédent d'un type d'item en commençant par les plus petits stacks.
 * @param array<int,\pocketmine\item\Item> &$contents
 */
 $clearExcess = static function(
 \pocketmine\inventory\Inventory $inv,
 int $total, int $max,
 \Closure $matcher
 ) use (&$item): void {
 if ($total <= $max) return;
 $excess = $total - $max;
 // Collecter les slots matchants triés par count ASC (petits stacks d'abord)
 $slots = [];
 foreach ($inv->getContents() as $slot => $it) {
 if ($matcher($it)) $slots[$slot] = $it->getCount();
 }
 asort($slots);
 foreach ($slots as $slot => $count) {
 if ($excess <= 0) break;
 $it = $inv->getItem($slot);
 $remove = min($excess, $it->getCount());
 $it->setCount($it->getCount() - $remove);
 $inv->setItem($slot, $it->getCount() > 0 ? $it : \pocketmine\item\VanillaItems::AIR());
 $excess -= $remove;
 }
 $item = $inv->getItemInHand(); // rafraîchir ref
 };

 // Soupe : max 64
 $soupCount = 0;
 foreach ($inv->getContents() as $it) {
 if ($it->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($it))
 $soupCount += $it->getCount();
 }
 $clearExcess($inv, $soupCount, 64,
 fn($it) => $it->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($it));

 // Pearl : max 16
 $pearlCount = 0;
 foreach ($inv->getContents() as $it) {
 if ($it->getTypeId() === ItemTypeIds::ENDER_PEARL) $pearlCount += $it->getCount();
 }
 $clearExcess($inv, $pearlCount, 16,
 fn($it) => $it->getTypeId() === ItemTypeIds::ENDER_PEARL);

 // Golden Apple : max 6
 $gappleCount = 0;
 foreach ($inv->getContents() as $it) {
 if ($it->getTypeId() === ItemTypeIds::GOLDEN_APPLE) $gappleCount += $it->getCount();
 }
 $clearExcess($inv, $gappleCount, 6,
 fn($it) => $it->getTypeId() === ItemTypeIds::GOLDEN_APPLE);

 // ── Soin ──────────────────────────────────────────────────────────
 $maxHealth = $player->getMaxHealth();
 $missing = $maxHealth - $player->getHealth();
 if ($missing <= 0) {
 $player->sendMessage("§cVous avez déjà pleine vie !");
 return;
 }
 $healsNeeded = (int)ceil($missing / 2);
 $available = $item->getCount();
 $toConsume = min($healsNeeded, $available);
 $healAmount = $toConsume * 2;

 $player->setHealth(min($maxHealth, $player->getHealth() + $healAmount));
 $invItem = $player->getInventory()->getItemInHand();
 $invItem->setCount(max(0, $invItem->getCount() - $toConsume));
 $player->getInventory()->setItemInHand($invItem->getCount() > 0 ? $invItem : VanillaItems::AIR());
 return;
 }

 if (Manager::ANTIITEM()->hasEffect($name)) {
 if (SpecialItems::isAntiItemBlockedItem($item) || $item->getTypeId() === ItemTypeIds::SNOWBALL) {
 $event->cancel();
 $remaining = Manager::ANTIITEM()->getRemaining($name);
 $player->sendTip("§dAnti-Item actif : §f{$remaining}s restants");
 return;
 }
 }

 // ===================== Pearl cooldown =====================
 if ($item->getTypeId() === ItemTypeIds::ENDER_PEARL) {
 // Anti-Pearl stick check
 if (Manager::PEARL()->hasAntiPearl($name)) {
 $event->cancel();
 $remaining = Manager::PEARL()->getAntiPearlRemaining($name);
 $player->sendTip("§cAnti-Pearl actif : §f{$remaining}s restants");
 return;
 }
 if (Manager::PEARL()->hasCooldown($name)) {
 $event->cancel();
 $remaining = Manager::PEARL()->getCooldownRemaining($name);
 $player->sendTip("§bPearl §8» §cCooldown : §f{$remaining}s");
 return;
 }
 Manager::PEARL()->setCooldown($name);
 return;
 }

 // ===================== Arc-Punch =====================
 if (SpecialItems::isArcPunch($item)) {
 $event->cancel();
 // Vérifier que l'arc a bien l'enchantement Punch
 $punchLevel = Manager::CUSTOMENCHANT()->getLevel($item, "punch");
 if ($punchLevel <= 0) {
 $player->sendTip("§cCet arc n'a pas d'enchantement §ePunch§c !");
 return;
 }
 $cdKey = $name . "_arcpunch";
 if (isset(self::$arcPunchCooldowns[$name]) && ($now - self::$arcPunchCooldowns[$name]) < 5) {
 return;
 }
 self::$arcPunchCooldowns[$name] = $now;
 // Force proportionnelle au niveau Punch
 $force = 0.55 + ($punchLevel * 0.15); // Punch1=0.70, Punch2=0.85
 $dir = $player->getDirectionVector()->normalize()->multiply($force);
 $player->setMotion(new Vector3($dir->x, 0.20, $dir->z));
 return;
 }

 // ===================== Stick Téléportation =====================
 if (SpecialItems::isTeleportStick($item)) {
 $event->cancel();
 // $name défini ligne 378 (début de onItemUse) — pas de problème ici
 $cdKey = $name . "_teleport";
 $cdTeleport = 20;
 if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdTeleport) {
 $remaining = $cdTeleport - ($now - $this->itemCooldowns[$cdKey]);
 $player->sendTip("§dTéléportation §8» §cCooldown : §f{$remaining}s");
 return;
 }
 $key = strtolower($name);
 if (!isset($this->lastAttackers[$key])) {
 $player->sendTip("§cPersonne ne t'a frappé récemment !"); return;
 }
 $entry = $this->lastAttackers[$key];
 if ($now - $entry['time'] > 15) {
 unset($this->lastAttackers[$key]);
 $player->sendTip("§cLa fenêtre de §e15s §cest expirée !"); return;
 }
 $target = Server::getInstance()->getPlayerExact($entry['name']);
 if ($target === null || !$target->isConnected()) {
 $player->sendTip("§c" . $entry['name'] . " §cn'est plus en ligne !"); return;
 }
 $this->itemCooldowns[$cdKey] = $now;
 $player->teleport($target->getPosition());
 $player->sendTip("§dTéléporté sur §f" . $target->getName() . " §d!");
 unset($this->lastAttackers[$key]);
 return;
 }

 // ===================== Bump =====================
 if (SpecialItems::isBump($item)) {
 $event->cancel();
 $cdKey = $name . "_bump";
 $cdBump = 10; // cooldown 10s
 if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdBump) {
 $remaining = $cdBump - ($now - $this->itemCooldowns[$cdKey]);
 $player->sendTip("§6Bump §8» §cCooldown : §f{$remaining}s");
 return;
 }
 $this->itemCooldowns[$cdKey] = $now;
 // ~60 blocs en l'air : v = sqrt(2*g*h) ≈ sqrt(2*0.08*60) ≈ 3.1
 $player->setMotion(new Vector3(0, 3.1, 0));
 return;
 }

 // ===================== Chèque Cash (Money / Coins) =====================
 if (SpecialItems::isCashMoney($item) || SpecialItems::isCashCoins($item)) {
 $event->cancel(); // pas de comportement vanilla
 $inv = $player->getInventory();
 $slot = $inv->getHeldItemIndex();

 if (SpecialItems::isCashMoney($item)) {
 $amount = SpecialItems::getCashMoneyAmount($item);
 if ($amount > 0) {
 Manager::ECONOMY()->addMoney($player->getName(), $amount);
 ScoreboardTask::refresh($player);
 Manager::ECONOMY()->saveData();
 $player->sendMessage("§6 §fVous avez encaissé §e" . number_format($amount, 0, ",", " ") . "§6$ §f!");
 $player->sendTip("§6+" . number_format($amount, 0, ",", " ") . "§6$");
 }
 } else {
 $amount = SpecialItems::getCashCoinsAmount($item);
 if ($amount > 0) {
 Manager::COINS()->addCoins($player->getName(), $amount);
 ScoreboardTask::refresh($player);
 Manager::COINS()->saveData();
 $player->sendMessage("§5 §fVous avez encaissé §b" . number_format($amount, 0, ",", " ") . "§5 Coins§f !");
 $player->sendTip("§5+" . number_format($amount, 0, ",", " ") . "§5 Coins");
 }
 }

 // Consommer le chèque (1 seul usage)
 $newItem = clone $item;
 $newItem->setCount($item->getCount() - 1);
 $inv->setItem($slot, $newItem);
 return;
 }

 // ===================== SwitchBall (Snowball vanilla) =====================
 if ($item->getTypeId() === ItemTypeIds::SNOWBALL) {
 $cdKey = $name . "_switchball";
 $cdSwitch = 120;
 if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdSwitch) {
 $event->cancel();
 $remaining = $cdSwitch - ($now - $this->itemCooldowns[$cdKey]);
 $player->sendTip("§5SwitchBall §8» §cCooldown : §f{$remaining}s");
 return;
 }
 // Cooldown immédiat au lancer + marquer actif pour le hit
 $this->itemCooldowns[$cdKey] = $now;
 self::$activeSwitchBall[$name] = $now;
 return;
 }
 }

 public function onPlayerInteract(PlayerInteractEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $item = $event->getItem();
 $pos = $event->getBlock()->getPosition();
 $lore = $item->getLore();
 $name = strtolower($player->getName());
 $now = time();

 // Island protection — bloquer interaction si pas autorisé
 $iWorld = $player->getWorld()->getFolderName();
 if (
 str_starts_with($iWorld, "island_")
 && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK
 && !$this->canBuildOnIsland($player, $iWorld)
 ) {
 $event->cancel();
 $player->sendTip("§cVous ne pouvez pas interagir ici !");
 return;
 }
 // Claim protection interact
 if (
 !str_starts_with($iWorld, "island_")
 && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK
 && !$this->canInteractInClaim($player, $event->getBlock()->getPosition(), $iWorld)
 ) {
 $event->cancel();
 $player->sendTip("§cCe territoire est claim par une faction !");
 return;
 }

 // Wand Region
 if ($lore && in_array("§7Clique gauche = Pos1", $lore, true)) {
 $blockPos = $event->getBlock()->getPosition();
 if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
 Manager::REGION()->setPosition1($player->getName(), $blockPos);
 $player->sendMessage("§aPos1 définie : " . $blockPos->getX() . " " . $blockPos->getY() . " " . $blockPos->getZ());
 } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
 Manager::REGION()->setPosition2($player->getName(), $blockPos);
 $player->sendMessage("§aPos2 définie : " . $blockPos->getX() . " " . $blockPos->getY() . " " . $blockPos->getZ());
 }
 $event->cancel();
 return;
 }
 // SwitchBall : géré via snowball vanilla (voir onPlayerItemUse)

 $region = Manager::REGION()->getMainRegionAt($pos);
 if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_INTERACT->getType())) {
 $player->sendMessage("§cVous ne pouvez pas interagir ici !");
 $event->cancel();
 }
 }



 /** Vérifie si un joueur peut builder/interagir dans un chunk claimé
 * - Recrue de la faction proprio : 
 * - Membre+ de la faction proprio : 
 * - Membre+ d'une faction alliée + allyClaimAllowed=true : 
 */
 private function canInteractInClaim(\CarailleNoir\player\PrismaPlayer $player, \pocketmine\math\Vector3 $pos, string $world): bool
 {
 $chunkX = $pos->getFloorX() >> 4;
 $chunkZ = $pos->getFloorZ() >> 4;
 $fManager = \CarailleNoir\managers\Manager::FACTION();
 $ownerFaction = $fManager->getClaimOwner($world, $chunkX, $chunkZ);
 if ($ownerFaction === null) return true; // pas de claim ici → libre

 // Bypass OP
 if ($fManager->hasBypass($player->getName())) return true;

 // Membre de la faction proprio
 $playerRole = $ownerFaction->getPlayerRole($player->getName());
 if ($playerRole !== null) {
 return $playerRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
 }

 // Ally
 $playerFaction = $player->getFaction();
 if ($playerFaction !== null && $ownerFaction->isAlly($playerFaction->getId())) {
 if (!$ownerFaction->isAllyClaimAllowed()) return false;
 $allyRole = $playerFaction->getPlayerRole($player->getName());
 return $allyRole !== null &&
 $allyRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
 }
 return false;
 }

 /** Vérifie si un joueur peut builder/interagir dans un monde island_
 * Règles :
 * - Recrue de la faction proprio : interdit
 * - Membre+ de la faction proprio : autorisé
 * - Membre+ d'une faction alliée + allyBuildAllowed=true : autorisé
 * - Tout autre joueur : interdit
 */
 private function canBuildOnIsland(\CarailleNoir\player\PrismaPlayer $player, string $worldName): bool
 {
 if (!str_starts_with($worldName, "island_")) return true;

 $fManager = \CarailleNoir\managers\Manager::FACTION();

 // Bypass OP → accès total sans restrictions
 if ($fManager->hasBypass($player->getName())) return true;

 // Trouver la faction propriétaire de ce monde
 $ownerFaction = null;
 foreach ($fManager->getFactions() as $f) {
 $island = $fManager->getIsland($f->getId());
 if ($island !== null && ($island["world"] ?? "") === $worldName) {
 $ownerFaction = $f;
 break;
 }
 }
 if ($ownerFaction === null) return false;

 // ── Joueur de la faction propriétaire ──
 $playerRole = $ownerFaction->getPlayerRole($player->getName());
 if ($playerRole !== null) {
 // Recrues : interdites. Membres et au-dessus : autorisés.
 return $playerRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
 }

 // ── Joueur d'une faction alliée ──
 $playerFaction = $player->getFaction();
 if ($playerFaction !== null && $ownerFaction->isAlly($playerFaction->getId())) {
 // La faction proprio doit avoir activé /f permission ally island true
 if (!$ownerFaction->isAllyBuildAllowed()) return false;
 // Le joueur doit être au moins Membre dans sa propre faction
 $allyRole = $playerFaction->getPlayerRole($player->getName());
 return $allyRole !== null &&
 $allyRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
 }

 return false;
 }

 public function onBlockBreak(BlockBreakEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $block = $event->getBlock();
 $pos = $block->getPosition();
 $worldName = $player->getWorld()->getFolderName();

 if (!$player->hasPermission("group.op") && !$player->hasPermission("prisma.command.staff") && Manager::MINE()->isMineWorld($worldName) && !Manager::MINE()->canBreakAt($worldName, (int) $pos->x, (int) $pos->y, (int) $pos->z)) {
 $event->cancel();
 return;
 }

 // TIG mining — seul l'émeraude est cassable, donne money, 0 drop
 if (Manager::TIG()->isTIG($player->getName())) {
 if ($block->getTypeId() !== \pocketmine\block\BlockTypeIds::EMERALD_ORE) {
 $event->cancel();
 return;
 }
 $event->setDrops([]);
 $event->setXpDropAmount(0);
 $reward = Manager::TIGBLOCK()->getMoneyReward();
 Manager::ECONOMY()->addMoney($player->getName(), (float)$reward);
 ScoreboardTask::refresh($player);
 Manager::TIG()->addMinedBlock($player->getName());
 Manager::TIGBLOCK()->notifyBroken((int)$pos->x, (int)$pos->y, (int)$pos->z);
 $player->sendTip("§a+§f{$reward}§6$");
 return;
 }

 // Island protection
 if (str_starts_with($worldName, "island_") && !$this->canBuildOnIsland($player, $worldName)) {
 $event->cancel();
 $player->sendTip("§cVous ne pouvez pas miner ici !");
 return;
 }
 // Claim protection
 if (!str_starts_with($worldName, "island_") && !$this->canInteractInClaim($player, $event->getBlock()->getPosition(), $worldName)) {
 $event->cancel();
 $player->sendTip("§cCe territoire est claim par une faction !");
 return;
 }

 // Mine tracked block respawn
 if (Manager::MINE()->canBreakAt($worldName, (int) $pos->x, (int) $pos->y, (int) $pos->z)) {
 Manager::MINE()->handleOreBreak($pos->getWorld(), $pos->asVector3());
 return;
 }

 // Region block break
 $region = Manager::REGION()->getMainRegionAt($pos);
 if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_BUILD->getType())) {
 $player->sendMessage("§cVous ne pouvez pas casser de blocs ici !");
 $event->cancel();
 }
 }

 public function onBlockPlace(BlockPlaceEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 // Block interdit en TIG
 if (Manager::TIG()->isTIG($player->getName())) { $event->cancel(); return; }

 // Island protection
 $placeWorld = $player->getWorld()->getFolderName();
 if (str_starts_with($placeWorld, "island_") && !$this->canBuildOnIsland($player, $placeWorld)) {
 $event->cancel();
 $player->sendTip("§cVous ne pouvez pas poser de blocs ici !");
 return;
 }
 // Claim protection
 if (!str_starts_with($placeWorld, "island_")) {
 foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
 if (!$this->canInteractInClaim($player, new Position($x, $y, $z, $player->getWorld()), $placeWorld)) {
 $event->cancel();
 $player->sendTip("§cCe territoire est claim par une faction !");
 return;
 }
 }
 }

 $transaction = $event->getTransaction();
 foreach ($transaction->getBlocks() as [$x, $y, $z, $block]) {
 $pos = new Position($x, $y, $z, $player->getWorld());
 $region = Manager::REGION()->getMainRegionAt($pos);
 if ($region === null) continue;
 if (!$region->isSettingsEnabled(RegionOption::PARAM_BUILD->getType())) {
 $event->cancel();
 return;
 }
 }
 }

 public function onMove(PlayerMoveEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $playerName = strtolower($player->getName());
 // ── Island void : TP au spawn si Y <= -104 ─────────────────────────
 $to = $event->getTo();
 $worldName = $player->getWorld()->getFolderName();
 if (str_starts_with($worldName, "island_") && $to->getY() <= -104) {
 $wm = Server::getInstance()->getWorldManager();
 $w = $wm->getWorldByName($worldName);
 if ($w !== null) $player->teleport($w->getSpawnLocation());
 return;
 }

 // TIG : confine le joueur dans le monde TIG (sans bloquer le mouvement à l'intérieur)
 if (Manager::TIG()->isTIG($player->getName())) {
 $tigWorld = \CarailleNoir\managers\type\TIGManager::TIG_WORLD;
 if ($player->getWorld()->getFolderName() !== $tigWorld) {
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($tigWorld)) $wm->loadWorld($tigWorld);
 $world = $wm->getWorldByName($tigWorld);
 if ($world !== null) {
 $player->teleport($world->getSpawnLocation());
 $player->sendMessage("§cVous êtes en TIG ! Vous ne pouvez pas quitter la prison.");
 }
 }
 return;
 }

 $player->updateRegion($event->getTo()->asVector3());

 // Fly : couper immédiatement si on n'est plus dans un monde island_* 
 $world = $player->getWorld()->getFolderName();
 if (FlyTask::isFlying($player->getName()) && !str_starts_with($world, "island_")) {
 FlyTask::stopFly($player->getName());
 $player->setAllowFlight(false);
 $player->setFlying(false);
 $player->sendMessage("§c[Prisma] Vous ne pouvez pas fly en dehors des islands.");
 }

 // ── Détection entrée de claim ──────────────────────────────────────
 if (str_starts_with($world, "island_")) return; // pas de message dans les islands

 $newChunkX = $to->getFloorX() >> 4;
 $newChunkZ = $to->getFloorZ() >> 4;
 $name = $player->getName();
 $cached = self::$playerChunkCache[$name] ?? null;

 if ($cached !== null &&
 $cached["world"] === $world &&
 $cached["chunkX"] === $newChunkX &&
 $cached["chunkZ"] === $newChunkZ) {
 return; // même chunk, rien à faire
 }

 self::$playerChunkCache[$name] = ["world" => $world, "chunkX" => $newChunkX, "chunkZ" => $newChunkZ];

 $fManager = Manager::FACTION();
 $claimOwner = $fManager->getClaimOwner($world, $newChunkX, $newChunkZ);
 $playerFaction = $player->getFaction();


 if ($claimOwner === null) {
 // Zone neutre : on peut quand même afficher "Nature" une fois si utile (optionnel, omis)
 return;
 }

 // Déterminer la couleur selon la relation
 if ($playerFaction !== null && $claimOwner->getId() === $playerFaction->getId()) {
 $color = "§a"; // propre faction → vert
 } elseif ($playerFaction !== null && $claimOwner->isAlly($playerFaction->getId())) {
 $color = "§5"; // allié → violet
 } else {
 $color = "§c"; // ennemi → rouge
 }

 $player->sendTip($color . $claimOwner->getName());
 }
 /**
 * SwitchBall : échange la position du lanceur avec la cible touchée.
 */
 public function onProjectileHit(ProjectileHitEntityEvent $event): void
 {
 $proj = $event->getEntity();
 if (!($proj instanceof Snowball)) return;

 $owner = $proj->getOwningEntity();
 if (!$owner instanceof PrismaPlayer) return;

 $ownerName = strtolower($owner->getName());
 if (!isset(self::$activeSwitchBall[$ownerName])) return;

 unset(self::$activeSwitchBall[$ownerName]);
 

 $target = $event->getEntityHit();
 if (!$target instanceof PrismaPlayer) return;

 // Pas de SwitchBall entre membres de la même faction ou alliés
 if ($this->areFriendly($owner, $target)) {
 $owner->sendTip("§eVous ne pouvez pas utiliser le SwitchBall sur un allié !");
 return;
 }

 $posA = $owner->getPosition()->asVector3();
 $posB = $target->getPosition()->asVector3();
 $owner->teleport(Position::fromObject($posB, $target->getWorld()));
 $target->teleport(Position::fromObject($posA, $owner->getWorld()));

 $owner->sendTip("§5SwitchBall §8» §fÉchangé avec §e" . $target->getName() . " §f!");
 $target->sendTip("§5SwitchBall §8» §fÉchangé avec §e" . $owner->getName() . " §f!");
 }

 /**
 * @priority LOWEST
 * Bloque toutes les commandes joueurs dans le monde TIG (PM5 = CommandEvent)
 * + Protection /pv : anti-duplication et acces OP aux vaults hors-ligne
 */
 public function onCommand(CommandEvent $event): void
 {
 $sender = $event->getSender();
 if (!$sender instanceof PrismaPlayer) return;

 // ── TIG : bloquer les commandes UNIQUEMENT pour le joueur TIG (pas le staff) ──
 if ($sender->getWorld()->getFolderName() === \CarailleNoir\managers\type\TIGManager::TIG_WORLD
 && Manager::TIG()->isTIG($sender->getName())) {
 $event->cancel();
 $remaining = Manager::TIG()->getRemainingTime($sender->getName());
 $h = intdiv($remaining, 3600);
 $m = intdiv($remaining % 3600, 60);
 $sender->sendMessage("§cCommandes désactivées en TIG. Temps restant : §e{$h}h {$m}min");
 return;
 }

 $cmd = $event->getCommand();

 // Anti-spam commandes (1s)
 $cmdName = $sender->getName();
 $cmdNow  = time();
 if (isset($this->cmdCooldowns[$cmdName]) && ($cmdNow - $this->cmdCooldowns[$cmdName]) < 1) {
  $event->cancel();
  $sender->sendMessage("§cAnti-spam : attendez §e1 seconde §centre chaque commande.");
  return;
 }
 $this->cmdCooldowns[$cmdName] = $cmdNow;

 if (Manager::COMBATLOG()->isTagged($sender->getName())) {
 $event->cancel();
 $sender->sendMessage("§cCommandes bloquées en combat ! §8(§e".Manager::COMBATLOG()->getRemainingTime($sender->getName())."s§8 restants)");
 return;
 }

 }


 /**
 * Déverrouille les PV quand un joueur (OP ou cible) se déconnecte.
 */
 public function onConsume(PlayerItemConsumeEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;
 if ($event->getItem()->getTypeId() !== ItemTypeIds::CHORUS_FRUIT) return;
 $key = strtolower($player->getName()); $now = time();
 if (isset($this->chorusCooldowns[$key]) && ($now - $this->chorusCooldowns[$key]) < 15) {
 $event->cancel();
 $player->sendTip("§5Chorus §8» §cCooldown : §f" . (15 - ($now - $this->chorusCooldowns[$key])) . "s");
 return;
 }
 $this->chorusCooldowns[$key] = $now;
 }

 public function onQuit(PlayerQuitEvent $event): void
 {
 $name = $event->getPlayer()->getName();

 $event->setQuitMessage("");
 }



 public function clearSavedHelmet(string $playerName): void
 {
 unset($this->savedHelmets[strtolower($playerName)]);
 }
}