<?php

namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ScoreboardTask extends Task
{
    private const OBJECTIVE = "prisma_sb";

    /** @var array<string, bool> joueurs pour lesquels l'objectif a déjà été créé */
    private array $initialised = [];

    public function onRun(): void
    {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if (!$player instanceof PrismaPlayer) continue;
            if (!$player->isConnected()) continue;
            if (!Manager::SETTINGS()->getSetting($player->getName(), Manager::SETTINGS()::SETTING_SCOREBOARD)) {
                // Si l'objectif existe mais que le joueur a désactivé le scoreboard → retirer
                if (isset($this->initialised[$player->getName()])) {
                    $player->getNetworkSession()->sendDataPacket(
                        RemoveObjectivePacket::create(self::OBJECTIVE)
                    );
                    unset($this->initialised[$player->getName()]);
                }
                continue;
            }
            $this->sendScoreboard($player);
        }
    }

    private function sendScoreboard(PrismaPlayer $player): void
    {
        $name = $player->getName();

        $faction    = $player->getFaction();
        $gradeColor = $player->getGradeColor();
        $gradeName  = $player->getGradeName();

        $combatTag = Manager::COMBATLOG()->isTagged($name);

        // Les 10 lignes — index 0 à 9
        // On ajoute un espace invisible différent (§r§0 / §r§f) pour éviter les doublons de customName
        $lines = [
            0 => "§8§m" . str_repeat("─", 9),          // titre séparateur haut
            1 => "§7Grade : {$gradeColor}{$gradeName}",
            2 => "§7Faction : §f" . ($faction?->getName() ?? "Aucune"),
            3 => "§7Argent : §6" . number_format($player->getMoney(), 2) . "$",
            4 => "§7Coins : §e" . $player->getCoins(),
            5 => "§7Kills : §a" . $player->getKills(),
            6 => "§7Deaths : §c" . $player->getDeaths(),
            7 => "§7Power : §b" . $player->getPower(),
            8 => $combatTag
                ? "§cCombat : §f" . Manager::COMBATLOG()->getTagRemaining($name) . "s"
                : "§7Combat : §aHors combat",
            9 => "§8§m" . str_repeat("═", 9),           // séparateur bas — différent du haut
        ];

        // Créer l'objectif la première fois seulement
        if (!isset($this->initialised[$name])) {
            $player->getNetworkSession()->sendDataPacket(
                SetDisplayObjectivePacket::create(
                    SetDisplayObjectivePacket::DISPLAY_SLOT_SIDEBAR,
                    self::OBJECTIVE,
                    "§6§lPrisma",
                    "dummy",
                    SetDisplayObjectivePacket::SORT_ORDER_ASCENDING
                )
            );
            $this->initialised[$name] = true;
        }

        // Mettre à jour les entrées à chaque tick
        $entries = [];
        foreach ($lines as $score => $text) {
            $entry = new ScorePacketEntry();
            $entry->objectiveName = self::OBJECTIVE;
            $entry->type          = ScorePacketEntry::TYPE_FAKE_PLAYER;
            $entry->customName    = $text;
            $entry->score         = $score;
            $entry->scoreboardId  = $score + 1; // offset pour éviter 0
            $entries[] = $entry;
        }

        $player->getNetworkSession()->sendDataPacket(
            SetScorePacket::create(SetScorePacket::TYPE_CHANGE, $entries)
        );
    }

    /** Appelé lors du quit pour libérer la mémoire */
    public function removePlayer(string $name): void
    {
        unset($this->initialised[$name]);
    }
}
