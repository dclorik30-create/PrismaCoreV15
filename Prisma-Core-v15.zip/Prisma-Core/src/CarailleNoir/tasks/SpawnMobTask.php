<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\entities\vanilla\Piglin;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\World;

class SpawnMobTask extends Task
{
    private int $ticker = 0;

    /** 20t × 60s × 5min */
    private const SPAWN_INTERVAL = 20 * 60 * 5;
    private const SEARCH_RADIUS  = 30;

    public function onRun(): void
    {
        if (++$this->ticker < self::SPAWN_INTERVAL) return;
        $this->ticker = 0;

        $world = Server::getInstance()->getWorldManager()->getDefaultWorld();
        if ($world === null) return;
        if (empty(Server::getInstance()->getOnlinePlayers())) return;

        $origin = $world->getSpawnLocation()->asVector3();
        $pos    = $this->findSafePosition($world, $origin);

        $entity = new Piglin(Location::fromObject($pos, $world), CompoundTag::create());
        $entity->setNameTag("§6§lPiglin §c§l[EVENT]");
        $entity->setNameTagAlwaysVisible(true);
        $entity->spawnToAll();

        $cx = (int)round($pos->x);
        $cy = (int)round($pos->y);
        $cz = (int)round($pos->z);

        Server::getInstance()->broadcastMessage(
            "§6[Event] §eUn Piglin §eest apparu en §6{$cx}§7, §6{$cy}§7, §6{$cz}§e ! " .
            "§eTuez-le pour obtenir une §5cle§e !"
        );
    }

    private function findSafePosition(World $world, Vector3 $origin): Vector3
    {
        $r = self::SEARCH_RADIUS;
        for ($attempt = 0; $attempt < 80; $attempt++) {
            $x = (int)$origin->x + mt_rand(-$r, $r);
            $z = (int)$origin->z + mt_rand(-$r, $r);
            for ($y = min(254, (int)$origin->y + $r); $y >= 2; $y--) {
                if ($world->getBlockAt($x, $y - 1, $z)->isSolid()
                    && !$world->getBlockAt($x, $y, $z)->isSolid()
                    && !$world->getBlockAt($x, $y + 1, $z)->isSolid()
                ) {
                    return new Vector3($x + 0.5, $y, $z + 0.5);
                }
            }
        }
        return new Vector3($origin->x + 0.5, $origin->y + 2, $origin->z + 0.5);
    }
}
