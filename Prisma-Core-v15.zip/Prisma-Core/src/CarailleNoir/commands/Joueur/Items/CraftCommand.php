<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\CommandSender;

class CraftCommand extends BaseCommand {
    public function __construct() { parent::__construct("craft", "Ouvrir la table de craft", [], [], ["prisma.command.craft"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $world = $sender->getWorld();
        $pos = $sender->getPosition()->floor();
        $real = $world->getBlock($pos);
        $world->setBlock($pos, VanillaBlocks::CRAFTING_TABLE());
        $sender->sendBlock([$sender], $pos);
        $sender->getNetworkSession()->syncWorldTime($world->getTime());
        $sender->sendMessage("§aClique sur la table de craft apparue sous toi.");
        $world->setBlock($pos, $real);
    }
}
