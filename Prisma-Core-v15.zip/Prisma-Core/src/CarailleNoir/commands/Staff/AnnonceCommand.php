<?php
namespace CarailleNoir\commands\Staff;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\Server;
class AnnonceCommand extends BaseCommand {
    public function __construct() { parent::__construct("annonce", "Faire une annonce serveur", [], [], ["prisma.command.staff", "prisma.command.annonce"]); }
    protected function prepare(): array { return [new TextArgument("message")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $msg = $args["message"];
        Server::getInstance()->broadcastMessage("§8[§6Annonce§8] §f{$msg}");
        Server::getInstance()->broadcastTitle("§6Annonce", "§f" . (strlen($msg) > 40 ? substr($msg, 0, 40) . "..." : $msg), 10, 60, 10);
        $sender->sendMessage("§aAnnonce envoyée !");
    }
}
