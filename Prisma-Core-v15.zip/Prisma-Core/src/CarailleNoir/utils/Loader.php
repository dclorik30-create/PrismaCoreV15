<?php
namespace CarailleNoir\utils;

use CarailleNoir\Core;
use CarailleNoir\entities\BoxNameEntity;
use CarailleNoir\entity\FloatingTextEntity;
use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Piglin;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\PacketHooker;
use CarailleNoir\listeners\EnchantTableListener;
use CarailleNoir\listeners\ItemClearListener;
use CarailleNoir\listeners\KnockbackListener;
use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\listeners\OutpostListener;
use CarailleNoir\listeners\ServerListener;
use CarailleNoir\listeners\SpawnerListener;
use CarailleNoir\listeners\StickListener;
use CarailleNoir\managers\Manager;
use CarailleNoir\tasks\ArmorEffectTask;
use CarailleNoir\tasks\ClearlagTask;
use CarailleNoir\tasks\EventTickTask;
use CarailleNoir\tasks\OutpostTask;
use CarailleNoir\tasks\FloatingTextTask;
use CarailleNoir\tasks\ItemClearTask;
use CarailleNoir\tasks\ScoreboardTask;
use CarailleNoir\tasks\TIGBlockTask;
use CarailleNoir\tasks\TipTask;
use CarailleNoir\tasks\SpawnMobTask;
use CarailleNoir\tasks\SpawnerTask;
use CarailleNoir\tasks\VipMineRespawnTask;
use Exception;
use pocketmine\command\Command;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\crafting\ShapelessRecipe;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\Entity;
use pocketmine\entity\EntityFactory;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\world\World;
use ReflectionClass;
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
use SplFileInfo;

class Loader
{
    private static ?ClearlagTask  $clearlagTask  = null;
    private static ?ItemClearTask $itemClearTask = null;

    /** @throws Exception */
    public function __construct(Core $instance)
    {
        $this->unloadCommands();
        $this->initCommands($instance);
        $this->initTasks();
        $this->initEvents();
        Manager::FACTION()->loadIslands();
        $this->initEntities();
        $this->loadWorlds();
        $this->RemoveCraft();
    }

    private function unloadCommands(): void
    {
        $core     = Core::getInstance();
        $commands = ["kick","me","ban","unban","ban-ip","unban-ip","banlist","about"];
        foreach ($commands as $cmd) {
            $c = $core->getServer()->getCommandMap()->getCommand($cmd);
            if ($c !== null) $core->getServer()->getCommandMap()->unregister($c);
        }
        $core->getLogger()->info("Il y a eu un total de §e" . count($commands) . " §fcommandes déchargées !");
    }

    private static function initCommands(Core $instance): void
    {
        $path      = __DIR__ . "/../commands";
        $namespace = "CarailleNoir\\commands";
        $counter   = 0;
        $map       = $instance->getServer()->getCommandMap();
        $iterator  = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
        /** @var SplFileInfo $file */
        foreach ($iterator as $file) {
            if ($file->getExtension() !== "php") continue;
            $custompath = str_replace($path . DIRECTORY_SEPARATOR, "", $file->getPathname());
            $class = $namespace . "\\" . str_replace([DIRECTORY_SEPARATOR, ".php"], ["\\", ""], $custompath);
            if (!class_exists($class)) continue;
            $r = new ReflectionClass($class);
            if (($r->isSubclassOf(Command::class) || $r->isSubclassOf(BaseCommand::class)) && !$r->isAbstract()) {
                /** @var Command $command */
                $command = $r->newInstance($instance);
                $old     = $map->getCommand($command->getName());
                if ($old !== null) $map->unregister($old);
                $map->register($command->getName(), $command);
                $counter++;
            }
        }
        $instance->getLogger()->notice("§e- §fUn total de §e$counter commandes §fviennent d'être chargés");
    }

    private function initTasks(): void
    {
        $scheduler = Core::getInstance()->getScheduler();

        // ItemClearTask : check toutes les 5s (100 ticks)
        self::$itemClearTask = new ItemClearTask();
        $scheduler->scheduleRepeatingTask(self::$itemClearTask, 100);

        // ArmorEffectTask : check toutes les 1t (50ms) — retrait quasi-instantané
        $scheduler->scheduleRepeatingTask(new ArmorEffectTask(), 1);

        // ClearlagTask : NON schedulé — déclenché manuellement via /clearlag
        self::$clearlagTask = new ClearlagTask();

        // Autres tâches inchangées
        $scheduler->scheduleRepeatingTask(new VipMineRespawnTask(), 20);
        $scheduler->scheduleRepeatingTask(new ScoreboardTask(), 40);
        $scheduler->scheduleRepeatingTask(new FloatingTextTask(), 6000); // refresh tops toutes les 5min
        $scheduler->scheduleRepeatingTask(new TIGBlockTask(), 20);
        $scheduler->scheduleRepeatingTask(new TipTask(), 20);
        $scheduler->scheduleRepeatingTask(new SpawnMobTask(), 1);
        $scheduler->scheduleRepeatingTask(new SpawnerTask(), 600); // Respawn spawners toutes les 30s
        $scheduler->scheduleRepeatingTask(new EventTickTask(), 20);
        $scheduler->scheduleRepeatingTask(new OutpostTask(), 20); // Outpost tick toutes les secondes

        Core::getInstance()->getLogger()->info("§aTasks chargées !");
    }

    private function initEvents(): void
    {
        $core   = Core::getInstance();
        $events = [
            new PlayerListener(),
            new KnockbackListener(),
            new ServerListener(),
            new StickListener(),
            new SpawnerListener(),
            new EnchantTableListener(),
            new ItemClearListener(self::$itemClearTask),
            new PacketHooker(),
            new OutpostListener(),
        ];
        foreach ($events as $event) {
            $core->getServer()->getPluginManager()->registerEvents($event, Core::getInstance());
        }
        $core->getLogger()->info("Il y a eu un total de §e" . count($events) . " §fevents chargés !");
    }

    public static function getClearlagTask(): ?ClearlagTask   { return self::$clearlagTask; }
    public static function getItemClearTask(): ?ItemClearTask { return self::$itemClearTask; }

    private function initEntities(): void
    {
        EntityFactory::getInstance()->register(FloatingTextEntity::class, static fn(World $world, CompoundTag $nbt): Entity => new FloatingTextEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["FloatingText"]);
        EntityFactory::getInstance()->register(BoxNameEntity::class,      static fn(World $world, CompoundTag $nbt): Entity => new BoxNameEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt),      ["BoxName"]);
        EntityFactory::getInstance()->register(Creeper::class,            static fn(World $world, CompoundTag $nbt): Entity => new Creeper(EntityDataHelper::parseLocation($nbt, $world), $nbt),            ["Creeper"]);
        EntityFactory::getInstance()->register(Zombie::class,            static fn(World $world, CompoundTag $nbt): Entity => new Zombie(EntityDataHelper::parseLocation($nbt, $world), $nbt),            ["PrismaZombie"]);
        EntityFactory::getInstance()->register(Piglin::class,            static fn(World $world, CompoundTag $nbt): Entity => new Piglin(EntityDataHelper::parseLocation($nbt, $world), $nbt),            ["PrismaPiglin"]);
        EntityFactory::getInstance()->register(Skeleton::class,           static fn(World $world, CompoundTag $nbt): Entity => new Skeleton(EntityDataHelper::parseLocation($nbt, $world), $nbt),           ["Skeleton"]);
    }

    private function loadWorlds(): void
    {
        $core = Core::getInstance();
        $wm   = $core->getServer()->getWorldManager();
        $dir  = $core->getServer()->getDataPath() . "worlds/";
        if (!is_dir($dir)) { $core->getLogger()->info("Le dossier de mondes n'existe pas"); return; }
        $loaded = 0;
        foreach (array_filter(glob($dir . "*"), 'is_dir') as $d) {
            $name = basename($d);
            if (!$wm->isWorldLoaded($name)) { $wm->loadWorld($name, true); $loaded++; }
        }
        $core->getLogger()->info("Il y a eu un total de §e{$loaded} §fmondes chargés !");
    }

    /** @throws \ReflectionException */
    public function RemoveCraft(): void
    {
        $removed = [];
        $targets = [
            VanillaItems::DIAMOND_BOOTS(), VanillaItems::DIAMOND_LEGGINGS(),
            VanillaItems::DIAMOND_CHESTPLATE(), VanillaItems::DIAMOND_HELMET(),
            VanillaItems::DIAMOND_SWORD(), VanillaItems::IRON_BOOTS(),
            VanillaItems::IRON_LEGGINGS(), VanillaItems::IRON_CHESTPLATE(),
            VanillaItems::IRON_HELMET(), VanillaItems::IRON_SWORD(),
        ];
        foreach ($targets as $i) $removed[] = $i->getTypeId();

        $cm = Server::getInstance()->getCraftingManager();
        $rc = new \ReflectionClass($cm);
        $newRecipes = [];
        foreach ($cm->getCraftingRecipeIndex() as $recipe) {
            $valid = true;
            if ($recipe instanceof ShapedRecipe || $recipe instanceof ShapelessRecipe) {
                foreach ($recipe->getResults() as $item) if (in_array($item->getTypeId(), $removed)) $valid = false;
            }
            if ($valid) $newRecipes[] = $recipe;
        }
        $p = $rc->getProperty("craftingRecipeIndex");
        $p->setAccessible(true);
        $p->setValue($cm, $newRecipes);
        $p->setAccessible(false);
    }
}
