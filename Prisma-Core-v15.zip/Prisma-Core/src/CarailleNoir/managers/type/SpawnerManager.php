<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\plugin\Plugin;
use pocketmine\world\Position;

class SpawnerManager
{
    private const SAVE_FILE = "spawners.json";

    private static array $loots = [
        "zombie"   => [
            ["item"=>"rotten_flesh","min"=>1,"max"=>2,"chance"=>80],
            ["item"=>"iron_ingot",  "min"=>1,"max"=>1,"chance"=>20],
            ["item"=>"carrot",      "min"=>1,"max"=>1,"chance"=>10],
        ],
        "skeleton" => [
            ["item"=>"bone", "min"=>1,"max"=>2,"chance"=>80],
            ["item"=>"arrow","min"=>2,"max"=>4,"chance"=>70],
            ["item"=>"bow",  "min"=>1,"max"=>1,"chance"=>5],
        ],
        "creeper"  => [
            ["item"=>"gunpowder","min"=>1,"max"=>2,"chance"=>80],
            ["item"=>"tnt",      "min"=>1,"max"=>1,"chance"=>10],
        ],
    ];
    private static array $prices = ["zombie"=>200,"skeleton"=>200,"creeper"=>300];

    /** @var array<string,array{type:string,world:string,entityId:int|null}> */
    private array $spawners = [];

    /**
     * FIX : entityIndex supporte plusieurs spawners par entité (groupe type+monde).
     * @var array<int, string[]>  eid → liste de clés spawner
     */
    private array $entityIndex = [];

    private static function key(Position $pos): string
    {
        return $pos->getFloorX().":".$pos->getFloorY().":".$pos->getFloorZ().":".$pos->getWorld()->getFolderName();
    }

    public function register(Position $pos, string $type): void
    {
        $this->spawners[self::key($pos)] = ["type"=>strtolower($type),"world"=>$pos->getWorld()->getFolderName(),"entityId"=>null];
    }

    public function unregister(Position $pos): void
    {
        $k   = $this->key($pos);
        if (!isset($this->spawners[$k])) return;
        $eid = $this->spawners[$k]["entityId"];
        if ($eid !== null) {
            // Retirer cette clé de l'index multi-entrées
            $this->entityIndex[$eid] = array_values(
                array_filter($this->entityIndex[$eid] ?? [], fn($x) => $x !== $k)
            );
            if (empty($this->entityIndex[$eid])) unset($this->entityIndex[$eid]);
        }
        unset($this->spawners[$k]);
    }

    public function isSpawner(Position $pos): bool  { return isset($this->spawners[self::key($pos)]); }
    public function getType(Position $pos): ?string  { return $this->spawners[self::key($pos)]["type"] ?? null; }
    public function getAllSpawners(): array           { return $this->spawners; }

    public function computeStack(string $type, string $world): int
    {
        $n = 0;
        foreach ($this->spawners as $d)
            if ($d["world"] === $world && $d["type"] === strtolower($type)) $n++;
        return max(1, $n);
    }

    public function setEntityId(Position $pos, int $id): void
    {
        $k = self::key($pos);
        if (!isset($this->spawners[$k])) return;

        // Nettoyer l'ancienne entrée si l'entityId change
        $oldEid = $this->spawners[$k]["entityId"];
        if ($oldEid !== null && $oldEid !== $id) {
            $this->entityIndex[$oldEid] = array_values(
                array_filter($this->entityIndex[$oldEid] ?? [], fn($x) => $x !== $k)
            );
            if (empty($this->entityIndex[$oldEid])) unset($this->entityIndex[$oldEid]);
        }

        $this->spawners[$k]["entityId"] = $id;
        // FIX : ajouter la clé sans doublon
        if (!in_array($k, $this->entityIndex[$id] ?? [], true)) {
            $this->entityIndex[$id][] = $k;
        }
    }

    public function getEntityId(Position $pos): ?int { return $this->spawners[self::key($pos)]["entityId"] ?? null; }

    public function getSpawnerByEntity(int $eid): ?array
    {
        $keys = $this->entityIndex[$eid] ?? [];
        if (empty($keys)) return null;
        return $this->spawners[$keys[0]] ?? null;
    }

    public function onEntityDeath(int $eid): void
    {
        $keys = $this->entityIndex[$eid] ?? [];
        unset($this->entityIndex[$eid]);
        // FIX : réinitialise l'entityId pour TOUS les spawners du groupe
        foreach ($keys as $k) {
            if (isset($this->spawners[$k])) {
                $this->spawners[$k]["entityId"] = null;
            }
        }
    }

    public function rollLoots(string $type, int $stack = 1): array
    {
        $r = [];
        foreach ((self::$loots[strtolower($type)] ?? []) as $l) {
            if (mt_rand(1, 100) <= $l["chance"])
                $r[] = ["item" => $l["item"], "amount" => min(mt_rand($l["min"], $l["max"]) * $stack, 64)];
        }
        return $r;
    }

    public function getPrice(string $type): int     { return self::$prices[strtolower($type)] ?? 200; }
    public function getAvailableTypes(): array       { return array_keys(self::$loots); }
    public function getLootsFor(string $type): array { return self::$loots[strtolower($type)] ?? []; }

    public function makeSpawnerItem(string $type): Item
    {
        // FIX : item brut identique à celui de l'inventaire créatif (sans lore ajoutée)
        $item = StringToItemParser::getInstance()->parse("prisma:{$type}_spawner") ?? VanillaItems::BONE_MEAL();
        $item->setCount(1);
        return $item;
    }

    public function getSpawnerTypeFromItem(Item $item): ?string
    {
        foreach ($item->getLore() as $l) {
            if (str_starts_with($l, "§8ID:spawner_")) {
                return mb_substr($l, 13);
            }
        }
        return null;
    }

    public function buildNametag(string $type, int $stack): string
    {
        return match(strtolower($type)) {
            "zombie"   => "§2§lZombie §f§lx{$stack}",
            "skeleton" => "§7§lSquelette §f§lx{$stack}",
            "creeper"  => "§a§lCreeper §f§lx{$stack}",
            default    => "§f§l" . ucfirst($type) . " §f§lx{$stack}",
        };
    }

    public function save(Plugin $plugin): void
    {
        $d = [];
        foreach ($this->spawners as $k => $s)
            $d[] = ["key" => $k, "type" => $s["type"], "world" => $s["world"]];
        file_put_contents($plugin->getDataFolder() . self::SAVE_FILE, json_encode($d, JSON_PRETTY_PRINT));
    }

    public function load(Plugin $plugin): void
    {
        $path = $plugin->getDataFolder() . self::SAVE_FILE;
        if (!file_exists($path)) return;
        foreach (json_decode(file_get_contents($path), true) ?? [] as $e)
            $this->spawners[$e["key"]] = ["type" => $e["type"], "world" => $e["world"], "entityId" => null];
    }
}
