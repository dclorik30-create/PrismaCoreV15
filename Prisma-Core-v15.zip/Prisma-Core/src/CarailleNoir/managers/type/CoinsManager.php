<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class CoinsManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("Coins");
    }

    public function getCoins(string $player): int
    {
        return (int)($this->data[strtolower($player)]["coins"] ?? 0);
    }

    public function setCoins(string $player, int $amount): void
    {
        $this->data[strtolower($player)]["coins"] = max(0, $amount);
    }

    public function addCoins(string $player, int $amount): void
    {
        $this->setCoins($player, $this->getCoins($player) + $amount);
    }

    public function removeCoins(string $player, int $amount): bool
    {
        $current = $this->getCoins($player);
        if ($current < $amount) return false;
        $this->setCoins($player, $current - $amount);
        return true;
    }

    public function hasCoins(string $player, int $amount): bool
    {
        return $this->getCoins($player) >= $amount;
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = ["coins" => 0];
        }
    }
}
