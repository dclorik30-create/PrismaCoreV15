<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class EconomyManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("Economy");
    }

    public function getMoney(string $player): float
    {
        return (float)($this->data[strtolower($player)]["money"] ?? 0);
    }

    public function setMoney(string $player, float $amount): void
    {
        $this->data[strtolower($player)]["money"] = max(0, $amount);
    }

    public function addMoney(string $player, float $amount): void
    {
        $this->setMoney($player, $this->getMoney($player) + $amount);
    }

    public function removeMoney(string $player, float $amount): bool
    {
        $current = $this->getMoney($player);
        if ($current < $amount) return false;
        $this->setMoney($player, $current - $amount);
        return true;
    }

    public function hasMoney(string $player, float $amount): bool
    {
        return $this->getMoney($player) >= $amount;
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = ["money" => 0];
        }
    }

    public function getTopMoney(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["money"] ?? 0) <=> ($a["money"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }
}
