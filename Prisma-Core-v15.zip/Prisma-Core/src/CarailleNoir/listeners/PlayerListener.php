<?php

namespace CarailleNoir\listeners;

use CarailleNoir\handlers\ChatHandler;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\RegionOption;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\managers\type\SettingsManager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\block\BlockTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\entity\EntityItemPickupEvent;
use pocketmine\entity\Location;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\entity\projectile\Snowball;
use pocketmine\event\entity\ProjectileHitEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerChatEvent;
use pocketmine\event\server\CommandEvent;
use pocketmine\event\player\PlayerCreationEvent;
use pocketmine\event\player\PlayerDeathEvent;
use pocketmine\event\player\PlayerDropItemEvent;
use pocketmine\event\player\PlayerExhaustEvent;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerLoginEvent;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\VanillaItems;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\GameRulesChangedPacket;
use pocketmine\network\mcpe\protocol\types\BoolGameRule;
use pocketmine\player\chat\LegacyRawChatFormatter;
use pocketmine\Server;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;

class PlayerListener extends ChatHandler implements Listener
{
    /** @var array<string, array{world:string,chunkX:int,chunkZ:int}> */
    private static array $playerChunkCache = [];

    /** @var array<string, int> cooldowns items spéciaux */
    private array $itemCooldowns = [];
    /** @var array<string, int> partagé avec TipTask */
    public static array $arcPunchCooldowns = [];
    /** @var array<string, true> boules de neige SwitchBall en vol */
    public static array $activeSwitchBall = [];



    public function onCreation(PlayerCreationEvent $event): void
    {
        $event->setPlayerClass(PrismaPlayer::class);
    }

    public function onLogin(PlayerLoginEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        if (!Manager::ALIAS()->hasProfil($player->getName())) {
            Manager::ALIAS()->createProfil($player);
        }

        if (Manager::BAN()->isBanned($player)) {
            $banInfo = Manager::BAN()->getBanInfo($player);
            $reason  = $banInfo["reason"];
            $staff   = $banInfo["staff"];
            $expire  = $banInfo["expire"] ? date("d/m/Y H-i-s", $banInfo["expire"]) : "Permanent";
            $player->kick("§cBanni pour: §f$reason\n§7Par: $staff\n§7Expire: $expire");
            return;
        }

        Manager::ECONOMY()->ensurePlayer($player->getName());
        Manager::COINS()->ensurePlayer($player->getName());
        Manager::STATS()->ensurePlayer($player->getName());
        Manager::SETTINGS()->ensurePlayer($player->getName());
        Manager::GRADE()->setDefaultGrade($player->getName());
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        // TIG check
        Manager::TIG()->checkOnLogin($player);

        $player->freeze($player->isFreeze());
        Manager::PERMISSION()->register($player);

        $gradeData = Manager::GRADE()->getPlayerGradeData($player->getName());
        $gradeName = $gradeData["name"] ?? null;
        $gradeColor = $gradeData["color"] ?? "§f";

        if ($gradeName !== null && strtolower($gradeData["id"] ?? "") !== "joueur") {
            $joinMsg = "§a[+] §r{$gradeColor}{$gradeName} §r{$player->getName()}§a a rejoint le serveur";
        } else {
            $joinMsg = "§a[+] §r§f{$player->getName()}";
        }

        if (!$player->hasPlayedBefore()) {
            Server::getInstance()->broadcastMessage(TextUtils::PREFIX . str_replace("{name}", $player->getName(), TextUtils::NEW_PLAYER));
        } else {
            Server::getInstance()->broadcastMessage($joinMsg);
        }

        // Nightvision si activé dans les settings
        if (Manager::SETTINGS()->getSetting($player->getName(), SettingsManager::SETTING_NIGHTVISION)) {
            $player->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999, 0, false, false));
        }

        $player->getNetworkSession()->sendDataPacket(GameRulesChangedPacket::create([
            "showcoordinates" => new BoolGameRule(true, false)
        ]));

        $event->setJoinMessage("");

        // Spawn les floating texts au joueur qui rejoint
        Manager::FLOATINGTEXT()->spawnToPlayer($player);
    }

    public function onLeave(PlayerQuitEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        // CombatLog : mort comptée uniquement si le joueur n'était pas déjà mort
        if (Manager::COMBATLOG()->isTagged($player->getName()) && $player->isAlive()) {
            $cLogger  = $player->getName();
            $lastAtk  = Manager::COMBATLOG()->getLastAttacker($cLogger);
            Manager::STATS()->addDeath($cLogger);
            Manager::COMBATLOG()->untag($cLogger);
            if ($lastAtk !== null) {
                Manager::STATS()->addKill($lastAtk);
                Server::getInstance()->broadcastMessage("§c{$cLogger} §7s'est déconnecté en combat ! §8(§cCombatLog§8) §7— Kill : §f{$lastAtk}");
            } else {
                Server::getInstance()->broadcastMessage("§c{$cLogger} §7s'est déconnecté en combat ! §8(§cCombatLog§8)");
            }
        }

        $gradeColor = $player->getGradeColor();
        Server::getInstance()->broadcastMessage("[§c-§r] {$gradeColor}{$player->getName()}");

        Manager::PERMISSION()->unregister($player);
        if (Manager::FACTION()->hasInvite($player->getName())) {
            Manager::FACTION()->removeInvite($player->getName());
        }
        // Nettoyage des cooldowns en mémoire pour éviter les fuites
        $name = $player->getName();
        foreach (array_keys($this->itemCooldowns) as $k) {
            if (str_starts_with((string)$k, strtolower($name))) {
                unset($this->itemCooldowns[$k]);
            }
        }
        
        $player->invalidateGradeCache();
        Manager::ANTIITEM()->remove($name);
        Manager::STICKFREEZE()->unfreeze($name);
        Manager::FACTION()->removeBypass($player->getName());
        unset(self::$playerChunkCache[$player->getName()]);
        $event->setQuitMessage("");
    }

    public function onDeath(PlayerDeathEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;
        Manager::STATS()->addDeath($player->getName());
        Manager::COMBATLOG()->untag($player->getName());
    }

    public function onPlayerDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        $cause  = $event->getCause();

        // ── Monde island_ : AUCUN dégât autorisé ──────────────────────────
        if ($entity instanceof PrismaPlayer) {
            $worldName = $entity->getWorld()->getFolderName();
            if (str_starts_with($worldName, "island_")) {
                $event->cancel();
                if ($cause === EntityDamageEvent::CAUSE_VOID) {
                    // Sécurité supplémentaire : TP spawn si VOID se déclenche quand même
                    $wm = Server::getInstance()->getWorldManager();
                    $w  = $wm->getWorldByName($worldName);
                    if ($w !== null) $entity->teleport($w->getSpawnLocation());
                }
                return;
            }
        }

        // ── Hors island : logique normale ─────────────────────────────────
        $blacklist = [
            EntityDamageEvent::CAUSE_VOID,
            EntityDamageEvent::CAUSE_DROWNING,
            EntityDamageEvent::CAUSE_SUICIDE,
            EntityDamageEvent::CAUSE_LAVA
        ];
        if (in_array($cause, $blacklist, true)) { $event->cancel(); return; }

        $player = $event->getEntity();
        if (!$player instanceof PrismaPlayer) return;

        if (Manager::MINE()->isMineWorld($player->getWorld()->getFolderName())) {
            $cause = $event->getCause();
            if (in_array($cause, [EntityDamageEvent::CAUSE_ENTITY_ATTACK, EntityDamageEvent::CAUSE_PROJECTILE, EntityDamageEvent::CAUSE_FIRE, EntityDamageEvent::CAUSE_FIRE_TICK, EntityDamageEvent::CAUSE_LAVA, EntityDamageEvent::CAUSE_BLOCK_EXPLOSION, EntityDamageEvent::CAUSE_ENTITY_EXPLOSION, EntityDamageEvent::CAUSE_CONTACT, EntityDamageEvent::CAUSE_MAGIC], true)) {
                $player->extinguish();
                $event->cancel();
                return;
            }
        }

        $region = Manager::REGION()->getMainRegionAt($player->getPosition());
        if ($region !== null) {
            if (!$region->isSettingsEnabled(RegionOption::PARAM_FALL_DAMAGE->getType()) && $cause === EntityDamageEvent::CAUSE_FALL) {
                $event->cancel();
            }
            if (!$region->isSettingsEnabled(RegionOption::PARAM_FIRE_DAMAGE->getType()) &&
                ($cause === EntityDamageEvent::CAUSE_FIRE || $cause === EntityDamageEvent::CAUSE_FIRE_TICK || $cause === EntityDamageEvent::CAUSE_MAGIC)) {
                $player->extinguish();
                $event->cancel();
            }
        }
    }

    /** Vérifie si deux joueurs sont dans la même faction ou alliés */
    private function areFriendly(\CarailleNoir\player\PrismaPlayer $a, \CarailleNoir\player\PrismaPlayer $b): bool
    {
        $fA = $a->getFaction();
        $fB = $b->getFaction();
        if ($fA === null || $fB === null) return false;
        if ($fA->getId() === $fB->getId()) return true; // même faction
        return $fA->isAlly($fB->getId());               // alliés
    }

    public function onAttack(EntityDamageByEntityEvent $event): void
    {
        $attacker = $event->getDamager();
        $victim   = $event->getEntity();
        if (!$attacker instanceof PrismaPlayer || !$victim instanceof PrismaPlayer) return;

        if (Manager::MINE()->isMineWorld($victim->getWorld()->getFolderName()) || Manager::MINE()->isMineWorld($attacker->getWorld()->getFolderName())) {
            $event->cancel();
            return;
        }

        $attackerName = strtolower($attacker->getName());
        $victimName = strtolower($victim->getName());
        $held = $attacker->getInventory()->getItemInHand();
        $now = time();

        if ($attacker->isFreeze() || $victim->isFreeze()) {
            $event->cancel(); return;
        }
        if ($this->areFriendly($attacker, $victim)) {
            $attacker->sendTip("§eVous ne pouvez pas attaquer un allié !");
            $event->cancel();
            return;
        }

        $pos = $victim->getPosition()->floor();
        $region = Manager::REGION()->getMainRegionAt($pos);
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_PVP->getType())) {
            $attacker->sendMessage("§cVous ne pouvez pas taper un joueur dans une zone protégée !");
            $event->cancel();
            return;
        }

        Manager::COMBATLOG()->tag($attacker->getName());
        Manager::COMBATLOG()->tag($victim->getName());
        Manager::COMBATLOG()->setLastAttacker($victim->getName(), $attacker->getName());

        if ($victim->getHealth() - $event->getFinalDamage() <= 0) {
            Manager::STATS()->addKill($attacker->getName());
        }

        $event->setKnockBack(0.42);
    }

    public function onExhaust(PlayerExhaustEvent $event): void
    {
        $player = $event->getPlayer();
        $region = Manager::REGION()->getMainRegionAt($player->getPosition());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_HUNGER->getType())) {
            $event->cancel();
        }
    }

    public function onChat(PlayerChatEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        // ── Anti-spam ──────────────────────────────────────────────────────
        $name = $player->getName();
        $now  = time();
        if (isset($this->chatCooldowns[$name]) && ($now - $this->chatCooldowns[$name]) < 2) {
            $event->cancel();
            $player->sendMessage("§cAnti-spam : attendez §e2 secondes §centre chaque message.");
            return;
        }
        $this->chatCooldowns[$name] = $now;

        // ── Bloquer chat depuis TIG ─────────────────────────────────────────
        if ($player->getWorld()->getFolderName() === \CarailleNoir\managers\type\TIGManager::TIG_WORLD) {
            $event->cancel();
            $player->sendMessage("§cVous ne pouvez pas parler depuis la TIG.");
            return;
        }

        $region = Manager::REGION()->getMainRegionAt($player->getPosition()->asVector3());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_CHAT->getType())) {
            $player->sendMessage("§cVous ne pouvez pas parler dans une zone mute !");
            $event->cancel();
            return;
        }

        if (Manager::MUTE()->isMuted($player)) {
            $event->cancel();
            $info   = Manager::MUTE()->getMuteInfo($player);
            $expire = $info["expire"] ? date("d/m/Y H:i:s", $info["expire"]) : "Permanent";
            $player->sendMessage("§cVous êtes mute !\nRaison : {$info["reason"]}\nExpire : {$expire}");
            return;
        }

        $gradeData  = Manager::GRADE()->getPlayerGradeData($player->getName());
        $faction    = $player->getFaction();
        $color      = $gradeData["color"] ?? TextFormat::GREEN;
        $gradeName  = $gradeData["name"]  ?? "Joueur";

        $message = str_replace(
            ["{grade}", "{facname}", "{playername}", "{message}", "{color}"],
            [$gradeName, $faction?->getName() ?? "Aucune", "{%0}", "{%1}", $color],
            "{color}[{grade}§r{color}] §f[{facname}§f] {color}{playername}§f »{color} {message}"
        );
        $event->setFormatter(new LegacyRawChatFormatter($message));
    }

    public function onItemUse(PlayerItemUseEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $item = $event->getItem();
        $name = strtolower($player->getName());
        $now  = time();

        // ===================== Soupe =====================
        if ($item->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($item)) {
            $event->cancel();

            // ── Vérification et clear des surplus (petits stacks en premier) ──
            $inv = $player->getInventory();

            /**
             * Supprime l'excédent d'un type d'item en commençant par les plus petits stacks.
             * @param array<int,\pocketmine\item\Item> &$contents
             */
            $clearExcess = static function(
                \pocketmine\inventory\Inventory $inv,
                int $total, int $max,
                \Closure $matcher
            ) use (&$item): void {
                if ($total <= $max) return;
                $excess = $total - $max;
                // Collecter les slots matchants triés par count ASC (petits stacks d'abord)
                $slots = [];
                foreach ($inv->getContents() as $slot => $it) {
                    if ($matcher($it)) $slots[$slot] = $it->getCount();
                }
                asort($slots);
                foreach ($slots as $slot => $count) {
                    if ($excess <= 0) break;
                    $it     = $inv->getItem($slot);
                    $remove = min($excess, $it->getCount());
                    $it->setCount($it->getCount() - $remove);
                    $inv->setItem($slot, $it->getCount() > 0 ? $it : \pocketmine\item\VanillaItems::AIR());
                    $excess -= $remove;
                }
                $item = $inv->getItemInHand(); // rafraîchir ref
            };

            // Soupe : max 64
            $soupCount = 0;
            foreach ($inv->getContents() as $it) {
                if ($it->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($it))
                    $soupCount += $it->getCount();
            }
            $clearExcess($inv, $soupCount, 64,
                fn($it) => $it->getTypeId() === ItemTypeIds::MUSHROOM_STEW || SpecialItems::isSoup($it));

            // Pearl : max 16
            $pearlCount = 0;
            foreach ($inv->getContents() as $it) {
                if ($it->getTypeId() === ItemTypeIds::ENDER_PEARL) $pearlCount += $it->getCount();
            }
            $clearExcess($inv, $pearlCount, 16,
                fn($it) => $it->getTypeId() === ItemTypeIds::ENDER_PEARL);

            // Golden Apple : max 6
            $gappleCount = 0;
            foreach ($inv->getContents() as $it) {
                if ($it->getTypeId() === ItemTypeIds::GOLDEN_APPLE) $gappleCount += $it->getCount();
            }
            $clearExcess($inv, $gappleCount, 6,
                fn($it) => $it->getTypeId() === ItemTypeIds::GOLDEN_APPLE);

            // ── Soin ──────────────────────────────────────────────────────────
            $maxHealth = $player->getMaxHealth();
            $missing   = $maxHealth - $player->getHealth();
            if ($missing <= 0) {
                $player->sendMessage("§cVous avez déjà pleine vie !");
                return;
            }
            $healsNeeded = (int)ceil($missing / 2);
            $available   = $item->getCount();
            $toConsume   = min($healsNeeded, $available);
            $healAmount  = $toConsume * 2;

            $player->setHealth(min($maxHealth, $player->getHealth() + $healAmount));
            $invItem = $player->getInventory()->getItemInHand();
            $invItem->setCount(max(0, $invItem->getCount() - $toConsume));
            $player->getInventory()->setItemInHand($invItem->getCount() > 0 ? $invItem : VanillaItems::AIR());
            return;
        }

        if (Manager::ANTIITEM()->hasEffect($name)) {
            if (SpecialItems::isAntiItemBlockedItem($item) || $item->getTypeId() === ItemTypeIds::SNOWBALL) {
                $event->cancel();
                $remaining = Manager::ANTIITEM()->getRemaining($name);
                $player->sendTip("§dAnti-Item actif : §f{$remaining}s restants");
                return;
            }
        }

        // ===================== Pearl cooldown =====================
        if ($item->getTypeId() === ItemTypeIds::ENDER_PEARL) {
            // Anti-Pearl stick check
            if (Manager::PEARL()->hasAntiPearl($name)) {
                $event->cancel();
                $remaining = Manager::PEARL()->getAntiPearlRemaining($name);
                $player->sendTip("§cAnti-Pearl actif : §f{$remaining}s restants");
                return;
            }
            if (Manager::PEARL()->hasCooldown($name)) {
                $event->cancel();
                $remaining = Manager::PEARL()->getCooldownRemaining($name);
                $player->sendTip("§bPearl §8» §cCooldown : §f{$remaining}s");
                return;
            }
            Manager::PEARL()->setCooldown($name);
            return;
        }

        // ===================== Arc-Punch =====================
        if (SpecialItems::isArcPunch($item)) {
            $event->cancel();
            // Vérifier que l'arc a bien l'enchantement Punch
            $punchLevel = Manager::CUSTOMENCHANT()->getLevel($item, "punch");
            if ($punchLevel <= 0) {
                $player->sendTip("§cCet arc n'a pas d'enchantement §ePunch§c !");
                return;
            }
            $cdKey = $name . "_arcpunch";
            if (isset(self::$arcPunchCooldowns[$name]) && ($now - self::$arcPunchCooldowns[$name]) < 5) {
                return;
            }
            self::$arcPunchCooldowns[$name] = $now;
            // Force proportionnelle au niveau Punch
            $force = 0.55 + ($punchLevel * 0.15); // Punch1=0.70, Punch2=0.85
            $dir   = $player->getDirectionVector()->normalize()->multiply($force);
            $player->setMotion(new Vector3($dir->x, 0.20, $dir->z));
            return;
        }

        // ===================== Bump =====================
        if (SpecialItems::isBump($item)) {
            $event->cancel();
            $cdKey = $name . "_bump";
            $cdBump = 10; // cooldown 10s
            if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdBump) {
                $remaining = $cdBump - ($now - $this->itemCooldowns[$cdKey]);
                $player->sendTip("§6Bump §8» §cCooldown : §f{$remaining}s");
                return;
            }
            $this->itemCooldowns[$cdKey] = $now;
            // ~60 blocs en l'air : v = sqrt(2*g*h) ≈ sqrt(2*0.08*60) ≈ 3.1
            $player->setMotion(new Vector3(0, 3.1, 0));
            return;
        }

        // ===================== SwitchBall (Snowball vanilla) =====================
        if ($item->getTypeId() === ItemTypeIds::SNOWBALL && !SpecialItems::isSwitchBall($item)) {
            $cdKey    = $name . "_switchball";
            $cdSwitch = 120;
            if (isset($this->itemCooldowns[$cdKey]) && ($now - $this->itemCooldowns[$cdKey]) < $cdSwitch) {
                $event->cancel();
                $remaining = $cdSwitch - ($now - $this->itemCooldowns[$cdKey]);
                $player->sendTip("§5SwitchBall §8» §cCooldown : §f{$remaining}s");
                return;
            }
            // Cooldown immédiat au lancer + marquer actif pour le hit
            $this->itemCooldowns[$cdKey]   = $now;
            self::$activeSwitchBall[$name] = $now;
            return;
        }
    }

    public function onPlayerInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $item = $event->getItem();
        $pos  = $event->getBlock()->getPosition();
        $lore = $item->getLore();
        $name = strtolower($player->getName());
        $now  = time();

        // Island protection — bloquer interaction si pas autorisé
        $iWorld = $player->getWorld()->getFolderName();
        if (
            str_starts_with($iWorld, "island_")
            && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK
            && !$this->canBuildOnIsland($player, $iWorld)
        ) {
            $event->cancel();
            $player->sendTip("§cVous ne pouvez pas interagir ici !");
            return;
        }
        // Claim protection interact
        if (
            !str_starts_with($iWorld, "island_")
            && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK
            && !$this->canInteractInClaim($player, $event->getBlock()->getPosition(), $iWorld)
        ) {
            $event->cancel();
            $player->sendTip("§cCe territoire est claim par une faction !");
            return;
        }

        // Wand Region
        if ($lore && in_array("§7Clique gauche = Pos1", $lore, true)) {
            $blockPos = $event->getBlock()->getPosition();
            if ($event->getAction() === PlayerInteractEvent::LEFT_CLICK_BLOCK) {
                Manager::REGION()->setPosition1($player->getName(), $blockPos);
                $player->sendMessage("§aPos1 définie : " . $blockPos->getX() . " " . $blockPos->getY() . " " . $blockPos->getZ());
            } elseif ($event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
                Manager::REGION()->setPosition2($player->getName(), $blockPos);
                $player->sendMessage("§aPos2 définie : " . $blockPos->getX() . " " . $blockPos->getY() . " " . $blockPos->getZ());
            }
            $event->cancel();
            return;
        }
        // SwitchBall : annuler interaction bloc (géré dans onPlayerItemUse)
        if (SpecialItems::isSwitchBall($item) && $event->getAction() === PlayerInteractEvent::RIGHT_CLICK_BLOCK) {
            $event->cancel();
            return;
        }

        $region = Manager::REGION()->getMainRegionAt($pos);
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_INTERACT->getType())) {
            $player->sendMessage("§cVous ne pouvez pas interagir ici !");
            $event->cancel();
        }
    }



    /** Vérifie si un joueur peut builder/interagir dans un chunk claimé
     *  - Recrue de la faction proprio : ❌
     *  - Membre+ de la faction proprio : ✅
     *  - Membre+ d'une faction alliée + allyClaimAllowed=true : ✅
     */
    private function canInteractInClaim(\CarailleNoir\player\PrismaPlayer $player, \pocketmine\math\Vector3 $pos, string $world): bool
    {
        $chunkX = $pos->getFloorX() >> 4;
        $chunkZ = $pos->getFloorZ() >> 4;
        $fManager = \CarailleNoir\managers\Manager::FACTION();
        $ownerFaction = $fManager->getClaimOwner($world, $chunkX, $chunkZ);
        if ($ownerFaction === null) return true; // pas de claim ici → libre

        // Bypass OP
        if ($fManager->hasBypass($player->getName())) return true;

        // Membre de la faction proprio
        $playerRole = $ownerFaction->getPlayerRole($player->getName());
        if ($playerRole !== null) {
            return $playerRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
        }

        // Ally
        $playerFaction = $player->getFaction();
        if ($playerFaction !== null && $ownerFaction->isAlly($playerFaction->getId())) {
            if (!$ownerFaction->isAllyClaimAllowed()) return false;
            $allyRole = $playerFaction->getPlayerRole($player->getName());
            return $allyRole !== null &&
                $allyRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
        }
        return false;
    }

    /** Vérifie si un joueur peut builder/interagir dans un monde island_
     *  Règles :
     *  - Recrue de la faction proprio : ❌ interdit
     *  - Membre+ de la faction proprio : ✅ autorisé
     *  - Membre+ d'une faction alliée + allyBuildAllowed=true : ✅ autorisé
     *  - Tout autre joueur : ❌ interdit
     */
    private function canBuildOnIsland(\CarailleNoir\player\PrismaPlayer $player, string $worldName): bool
    {
        if (!str_starts_with($worldName, "island_")) return true;

        $fManager = \CarailleNoir\managers\Manager::FACTION();

        // Bypass OP → accès total sans restrictions
        if ($fManager->hasBypass($player->getName())) return true;

        // Trouver la faction propriétaire de ce monde
        $ownerFaction = null;
        foreach ($fManager->getFactions() as $f) {
            $island = $fManager->getIsland($f->getId());
            if ($island !== null && ($island["world"] ?? "") === $worldName) {
                $ownerFaction = $f;
                break;
            }
        }
        if ($ownerFaction === null) return false;

        // ── Joueur de la faction propriétaire ──
        $playerRole = $ownerFaction->getPlayerRole($player->getName());
        if ($playerRole !== null) {
            // Recrues : interdites. Membres et au-dessus : autorisés.
            return $playerRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
        }

        // ── Joueur d'une faction alliée ──
        $playerFaction = $player->getFaction();
        if ($playerFaction !== null && $ownerFaction->isAlly($playerFaction->getId())) {
            // La faction proprio doit avoir activé /f permission ally island true
            if (!$ownerFaction->isAllyBuildAllowed()) return false;
            // Le joueur doit être au moins Membre dans sa propre faction
            $allyRole = $playerFaction->getPlayerRole($player->getName());
            return $allyRole !== null &&
                $allyRole->getPriority() >= \CarailleNoir\managers\option\Faction\FactionRoleEnum::MEMBERS->getPriority();
        }

        return false;
    }

    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $block = $event->getBlock();
        $pos   = $block->getPosition();
        $worldName = $player->getWorld()->getFolderName();

        if (!$player->hasPermission("group.op") && !$player->hasPermission("prisma.command.staff") && Manager::MINE()->isMineWorld($worldName) && !Manager::MINE()->canBreakAt($worldName, (int) $pos->x, (int) $pos->y, (int) $pos->z)) {
            $event->cancel();
            return;
        }

        // TIG mining — seul l'émeraude est cassable, donne money, 0 drop
        if (Manager::TIG()->isTIG($player->getName())) {
            if ($block->getTypeId() !== \pocketmine\block\BlockTypeIds::EMERALD_ORE) {
                $event->cancel();
                return;
            }
            $event->setDrops([]);
            $event->setXpDropAmount(0);
            $reward = Manager::TIGBLOCK()->getMoneyReward();
            Manager::ECONOMY()->addMoney($player->getName(), (float)$reward);
            Manager::TIG()->addMinedBlock($player->getName());
            Manager::TIGBLOCK()->notifyBroken((int)$pos->x, (int)$pos->y, (int)$pos->z);
            $player->sendTip("§a+§f{$reward}§6$");
            return;
        }

        // Island protection
        if (str_starts_with($worldName, "island_") && !$this->canBuildOnIsland($player, $worldName)) {
            $event->cancel();
            $player->sendTip("§cVous ne pouvez pas miner ici !");
            return;
        }
        // Claim protection
        if (!str_starts_with($worldName, "island_") && !$this->canInteractInClaim($player, $event->getBlock()->getPosition(), $worldName)) {
            $event->cancel();
            $player->sendTip("§cCe territoire est claim par une faction !");
            return;
        }

        // Mine tracked block respawn
        if (Manager::MINE()->canBreakAt($worldName, (int) $pos->x, (int) $pos->y, (int) $pos->z)) {
            Manager::MINE()->handleOreBreak($pos->getWorld(), $pos->asVector3());
            return;
        }

        // Region block break
        $region = Manager::REGION()->getMainRegionAt($pos);
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_BUILD->getType())) {
            $player->sendMessage("§cVous ne pouvez pas casser de blocs ici !");
            $event->cancel();
        }
    }

    public function onBlockPlace(BlockPlaceEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        // Block interdit en TIG
        if (Manager::TIG()->isTIG($player->getName())) { $event->cancel(); return; }

        // Island protection
        $placeWorld = $player->getWorld()->getFolderName();
        if (str_starts_with($placeWorld, "island_") && !$this->canBuildOnIsland($player, $placeWorld)) {
            $event->cancel();
            $player->sendTip("§cVous ne pouvez pas poser de blocs ici !");
            return;
        }
        // Claim protection
        if (!str_starts_with($placeWorld, "island_")) {
            foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
                if (!$this->canInteractInClaim($player, new Position($x, $y, $z, $player->getWorld()), $placeWorld)) {
                    $event->cancel();
                    $player->sendTip("§cCe territoire est claim par une faction !");
                    return;
                }
            }
        }

        $transaction = $event->getTransaction();
        foreach ($transaction->getBlocks() as [$x, $y, $z, $block]) {
            $pos = new Position($x, $y, $z, $player->getWorld());
            $region = Manager::REGION()->getMainRegionAt($pos);
            if ($region === null) continue;
            if (!$region->isSettingsEnabled(RegionOption::PARAM_BUILD->getType())) {
                    $event->cancel();
                return;
            }
        }
    }

    public function onMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $playerName = strtolower($player->getName());
        // ── Island void : TP au spawn si Y <= -104 ─────────────────────────
        $to = $event->getTo();
        $worldName = $player->getWorld()->getFolderName();
        if (str_starts_with($worldName, "island_") && $to->getY() <= -104) {
            $wm = Server::getInstance()->getWorldManager();
            $w  = $wm->getWorldByName($worldName);
            if ($w !== null) $player->teleport($w->getSpawnLocation());
            return;
        }

        // TIG : confine le joueur dans le monde TIG (sans bloquer le mouvement à l'intérieur)
        if (Manager::TIG()->isTIG($player->getName())) {
            $tigWorld = \CarailleNoir\managers\type\TIGManager::TIG_WORLD;
            if ($player->getWorld()->getFolderName() !== $tigWorld) {
                $wm = \pocketmine\Server::getInstance()->getWorldManager();
                if (!$wm->isWorldLoaded($tigWorld)) $wm->loadWorld($tigWorld);
                $world = $wm->getWorldByName($tigWorld);
                if ($world !== null) {
                    $player->teleport($world->getSpawnLocation());
                    $player->sendMessage("§cVous êtes en TIG ! Vous ne pouvez pas quitter la prison.");
                }
            }
            return;
        }

        $player->updateRegion($event->getTo()->asVector3());

        // ── Détection entrée de claim ──────────────────────────────────────
        $world = $player->getWorld()->getFolderName();
        if (str_starts_with($world, "island_")) return; // pas de message dans les islands

        $newChunkX = $to->getFloorX() >> 4;
        $newChunkZ = $to->getFloorZ() >> 4;
        $name      = $player->getName();
        $cached    = self::$playerChunkCache[$name] ?? null;

        if ($cached !== null &&
            $cached["world"]  === $world   &&
            $cached["chunkX"] === $newChunkX &&
            $cached["chunkZ"] === $newChunkZ) {
            return; // même chunk, rien à faire
        }

        self::$playerChunkCache[$name] = ["world" => $world, "chunkX" => $newChunkX, "chunkZ" => $newChunkZ];

        $fManager     = Manager::FACTION();
        $claimOwner   = $fManager->getClaimOwner($world, $newChunkX, $newChunkZ);
        $playerFaction = $player->getFaction();

        if ($claimOwner === null) {
            // Zone neutre : on peut quand même afficher "Nature" une fois si utile (optionnel, omis)
            return;
        }

        // Déterminer la couleur selon la relation
        if ($playerFaction !== null && $claimOwner->getId() === $playerFaction->getId()) {
            $color = "§a"; // propre faction → vert
        } elseif ($playerFaction !== null && $claimOwner->isAlly($playerFaction->getId())) {
            $color = "§5"; // allié → violet
        } else {
            $color = "§c"; // ennemi → rouge
        }

        $player->sendTip($color . $claimOwner->getName());
    }
    /**
     * SwitchBall : échange la position du lanceur avec la cible touchée.
     */
    public function onProjectileHit(ProjectileHitEntityEvent $event): void
    {
        $proj = $event->getEntity();
        if (!($proj instanceof Snowball)) return;

        $owner = $proj->getOwningEntity();
        if (!$owner instanceof PrismaPlayer) return;

        $ownerName = strtolower($owner->getName());
        if (!isset(self::$activeSwitchBall[$ownerName])) return;

        unset(self::$activeSwitchBall[$ownerName]);
        

        $target = $event->getEntityHit();
        if (!$target instanceof PrismaPlayer) return;

        // Pas de SwitchBall entre membres de la même faction ou alliés
        if ($this->areFriendly($owner, $target)) {
            $owner->sendTip("§eVous ne pouvez pas utiliser le SwitchBall sur un allié !");
            return;
        }

        $posA = $owner->getPosition()->asVector3();
        $posB = $target->getPosition()->asVector3();
        $owner->teleport(Position::fromObject($posB, $target->getWorld()));
        $target->teleport(Position::fromObject($posA, $owner->getWorld()));

        $owner->sendTip("§5SwitchBall §8» §fÉchangé avec §e" . $target->getName() . " §f!");
        $target->sendTip("§5SwitchBall §8» §fÉchangé avec §e" . $owner->getName() . " §f!");
    }

    /**
     * @priority LOWEST
     * Bloque toutes les commandes joueurs dans le monde TIG (PM5 = CommandEvent)
     * + Protection /pv : anti-duplication et acces OP aux vaults hors-ligne
     */
    public function onCommand(CommandEvent $event): void
    {
        $sender = $event->getSender();
        if (!$sender instanceof PrismaPlayer) return;

        // ── TIG : bloquer toutes les commandes ────────────────────────────────
        if ($sender->getWorld()->getFolderName() === \CarailleNoir\managers\type\TIGManager::TIG_WORLD) {
            $event->cancel();
            $remaining = Manager::TIG()->getRemainingTime($sender->getName());
            $h = intdiv($remaining, 3600);
            $m = intdiv($remaining % 3600, 60);
            $sender->sendMessage("§cCommandes désactivées en TIG. Temps restant : §e{$h}h {$m}min");
            return;
        }

        $cmd = $event->getCommand();

        if (Manager::COMBATLOG()->isTagged($sender->getName())) {
            $event->cancel();
            $sender->sendMessage("§cCommandes bloquées en combat ! §8(§e".Manager::COMBATLOG()->getRemainingTime($sender->getName())."s§8 restants)");
            return;
        }

    }


    /**
     * Déverrouille les PV quand un joueur (OP ou cible) se déconnecte.
     */
    public function onQuit(PlayerQuitEvent $event): void
    {
        $name = $event->getPlayer()->getName();

        $event->setQuitMessage("");
    }

}
