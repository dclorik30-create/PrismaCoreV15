<?php
declare(strict_types=1);
namespace CarailleNoir\items;

use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;

class SpecialItems
{
    private const LORE_FREEZE    = "§8ID:stick_freeze";
    private const LORE_ANTIPEARL = "§8ID:stick_antipearl";
    private const LORE_ANTIITEM  = "§8ID:stick_antiitem";
    private const LORE_ARCPUNCH  = "§8ID:item_arcpunch";
    private const LORE_SWITCH    = "§8ID:item_switchball";
    private const LORE_BUMP      = "§8ID:item_bump";

    public static function makeFreezeStick(): Item
    {
        $item = VanillaItems::STICK()->setCount(1);
        $item->setCustomName("§b\u2726 Stick Freeze");
        $item->setLore([self::LORE_FREEZE, "§7Frappe un joueur pour le freeze !"]);
        return $item;
    }

    public static function makeAntiPearlStick(): Item
    {
        $item = VanillaItems::BLAZE_ROD()->setCount(1);
        $item->setCustomName("§c\u2726 Anti-Pearl");
        $item->setLore([self::LORE_ANTIPEARL, "§7Empêche la pearl !", "§eDurée : §f45s"]);
        return $item;
    }

    public static function makeAntiItemStick(): Item
    {
        $item = VanillaItems::BLAZE_ROD()->setCount(1);
        $item->setCustomName("§d\u2726 Anti-Item");
        $item->setLore([self::LORE_ANTIITEM, "§7Désactive les items spéciaux !", "§eDurée : §f10s"]);
        return $item;
    }

    public static function makeArcPunch(): Item
    {
        $item = VanillaItems::BOW()->setCount(1);
        $item->setCustomName("§e\u2726 Arc-Punch");
        $item->setLore([self::LORE_ARCPUNCH, "§7Propulse vers l'avant !", "§7Pas besoin de flèches.", "§eCooldown : §f5s"]);
        return $item;
    }

    public static function makeSwitchBall(): Item
    {
        $item = VanillaItems::SNOWBALL()->setCount(1);
        $item->setCustomName("§5\u2726 SwitchBall");
        $item->setLore([self::LORE_SWITCH, "§7Lance et échange ta position !", "§eCooldown : §f15s"]);
        return $item;
    }

    private const LORE_SOUP = "§8ID:item_soup";

    /**
     * Soupe custom — utilise prisma:soup (stackable x64, enregistré dans PrismaItems).
     * Fallback sur MUSHROOM_STEW si PrismaItems n'est pas chargé.
     */
    public static function makeSoup(int $count = 1): Item
    {
        $item = StringToItemParser::getInstance()->parse("prisma:soup");
        if ($item === null) {
            // Fallback si PrismaItems pas encore chargé
            $item = VanillaItems::MUSHROOM_STEW();
            $item->setCustomName("§c§lSoupe§r §7(+4 PV)");
            $item->setLore([self::LORE_SOUP, "§7Clic droit pour se soigner."]);
        }
        return $item->setCount(max(1, min($count, 64)));
    }

    public static function isSoup(Item $item): bool { return in_array(self::LORE_SOUP, $item->getLore(), true); }

    public static function makeBump(): Item
    {
        $item = VanillaItems::BLAZE_ROD()->setCount(1);
        $item->setCustomName("§a\u2726 Bump");
        $item->setLore([self::LORE_BUMP, "§7Propulse vers le ciel !", "§eCooldown : §f10s"]);
        return $item;
    }

    public static function isFreezeStick(Item $item): bool    { return in_array(self::LORE_FREEZE,    $item->getLore(), true); }
    public static function isAntiPearlStick(Item $item): bool { return in_array(self::LORE_ANTIPEARL, $item->getLore(), true); }
    public static function isAntiItemStick(Item $item): bool  { return in_array(self::LORE_ANTIITEM,  $item->getLore(), true); }
    public static function isArcPunch(Item $item): bool       { return in_array(self::LORE_ARCPUNCH,  $item->getLore(), true); }
    public static function isSwitchBall(Item $item): bool     { return in_array(self::LORE_SWITCH,    $item->getLore(), true); }
    public static function isBump(Item $item): bool           { return in_array(self::LORE_BUMP,      $item->getLore(), true); }

    public static function isAntiItemBlockedItem(Item $item): bool
    {
        return self::isBump($item) || self::isSwitchBall($item) || self::isFreezeStick($item)
            || self::isAntiPearlStick($item) || self::isAntiItemStick($item) || self::isArcPunch($item);
    }
}
