<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Ruby;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class RubyLeggings extends Armor implements IPrismaArmor
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:ruby_leggings", 30011),
            "§cRuby §7Jambières",
            new ArmorTypeInfo(
                maxDurability: 610,
                defensePoints: 6,
                armorSlot: ArmorInventory::SLOT_LEGS,
                toughness: 3
            )
        );
    }

    public function getPrismaTier(): int { return 2; }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_ruby_leggings");
    }
}
