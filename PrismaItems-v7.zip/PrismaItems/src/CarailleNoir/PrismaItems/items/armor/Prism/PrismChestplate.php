<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Prism;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class PrismChestplate extends Armor implements IPrismaArmor
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:prism_chestplate", 30014),
            "§5Prism §7Plastron",
            new ArmorTypeInfo(
                maxDurability: 720,
                defensePoints: 8,
                armorSlot: ArmorInventory::SLOT_CHEST,
                toughness: 4
            )
        );
    }

    public function getPrismaTier(): int { return 3; }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_prism_chestplate");
    }
}
