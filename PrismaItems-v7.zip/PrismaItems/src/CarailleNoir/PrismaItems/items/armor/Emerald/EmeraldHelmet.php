<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\armor\Emerald;

use CarailleNoir\PrismaItems\interface\IPrismaArmor;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\ArmorTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Armor;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class EmeraldHelmet extends Armor implements IPrismaArmor
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:emerald_helmet", 30005),
            "§aEmerald §7Casque",
            new ArmorTypeInfo(
                maxDurability: 407,
                defensePoints: 3,
                armorSlot: ArmorInventory::SLOT_HEAD,
                toughness: 2
            )
        );
    }

    public function getPrismaTier(): int { return 1; }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setDefaultName()->setIcon("prisma_emerald_helmet");
    }
}
