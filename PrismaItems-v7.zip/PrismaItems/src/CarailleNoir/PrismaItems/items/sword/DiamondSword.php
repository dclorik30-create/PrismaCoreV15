<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\sword;

use SenseiTarzan\SymplyPlugin\Behavior\Items\Sword;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class DiamondSword extends Sword
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:diamond_sword", 30017),
            "§bÉpée Diamond",
            new ToolTier(
                harvestLevel:      4,
                maxDurability:     1561,
                baseAttackPoints:  7,
                baseEfficiency:    8,
                enchantability:    10
            )
        );
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setIcon("prisma_diamond_sword");
    }
}
