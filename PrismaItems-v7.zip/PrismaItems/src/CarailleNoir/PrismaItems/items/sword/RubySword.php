<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\sword;

use SenseiTarzan\SymplyPlugin\Behavior\Items\Sword;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;

class RubySword extends Sword
{
    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:ruby_sword", 30019),
            "§cÉpée Ruby",
            new ToolTier(
                harvestLevel:      4,
                maxDurability:     2500,
                baseAttackPoints:  8,
                baseEfficiency:    8,
                enchantability:    10
            )
        );
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()->setIcon("prisma_ruby_sword");
    }
}
