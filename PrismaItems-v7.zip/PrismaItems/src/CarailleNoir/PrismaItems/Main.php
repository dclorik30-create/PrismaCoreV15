<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems;

use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\spawner\CreeperSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\SkeletonSpawner;
use CarailleNoir\PrismaItems\blocks\spawner\ZombieSpawner;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondHelmet;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondChestplate;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondLeggings;
use CarailleNoir\PrismaItems\items\armor\Diamond\DiamondBoots;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldHelmet;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldChestplate;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldLeggings;
use CarailleNoir\PrismaItems\items\armor\Emerald\EmeraldBoots;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyHelmet;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyChestplate;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyLeggings;
use CarailleNoir\PrismaItems\items\armor\Ruby\RubyBoots;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismHelmet;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismChestplate;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismLeggings;
use CarailleNoir\PrismaItems\items\armor\Prism\PrismBoots;
use CarailleNoir\PrismaItems\items\ingot\DiamondIngot;
use CarailleNoir\PrismaItems\items\ingot\EmeraldIngot;
use CarailleNoir\PrismaItems\items\ingot\RubyIngot;
use CarailleNoir\PrismaItems\items\ingot\PrismIngot;
use CarailleNoir\PrismaItems\items\sword\DiamondSword;
use CarailleNoir\PrismaItems\items\sword\EmeraldSword;
use CarailleNoir\PrismaItems\items\sword\RubySword;
use CarailleNoir\PrismaItems\items\sword\PrismSword;
use CarailleNoir\PrismaItems\items\staff\ArcPunchItem;
use CarailleNoir\PrismaItems\items\staff\FreezeStick;
use CarailleNoir\PrismaItems\items\staff\AntiPearlStick;
use CarailleNoir\PrismaItems\items\staff\AntiItemStick;
use CarailleNoir\PrismaItems\items\staff\BumpItem;
use CarailleNoir\PrismaItems\items\staff\SwitchBallItem;
use CarailleNoir\PrismaItems\items\consumable\SoupItem;
use CarailleNoir\PrismaItems\items\key\VoteKey;
use CarailleNoir\PrismaItems\items\key\NobleKey;
use CarailleNoir\PrismaItems\items\key\HerosKey;
use CarailleNoir\PrismaItems\items\key\DieuKey;
use CarailleNoir\PrismaItems\items\key\BoutiqueKey;
use pocketmine\plugin\PluginBase;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyBlockFactory;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyItemFactory;

class Main extends PluginBase
{
    protected function onLoad(): void
    {
        // ── Blocs (static fn pour éviter la capture de $this → thread-safe) ──
        $bf = SymplyBlockFactory::getInstance();
        $bf->register(static fn() => new DiamondOre());
        $bf->register(static fn() => new EmeraldOre());
        $bf->register(static fn() => new RubyOre());
        $bf->register(static fn() => new PrismOre());
        $bf->register(static fn() => new ZombieSpawner());
        $bf->register(static fn() => new SkeletonSpawner());
        $bf->register(static fn() => new CreeperSpawner());

        // ── Items ─────────────────────────────────────────────────────────────
        $if = SymplyItemFactory::getInstance();
        // Lingots
        $if->register(static fn() => new DiamondIngot());
        $if->register(static fn() => new EmeraldIngot());
        $if->register(static fn() => new RubyIngot());
        $if->register(static fn() => new PrismIngot());
        // Épées
        $if->register(static fn() => new DiamondSword());
        $if->register(static fn() => new EmeraldSword());
        $if->register(static fn() => new RubySword());
        $if->register(static fn() => new PrismSword());
        // Armures
        $if->register(static fn() => new DiamondHelmet());
        $if->register(static fn() => new DiamondChestplate());
        $if->register(static fn() => new DiamondLeggings());
        $if->register(static fn() => new DiamondBoots());
        $if->register(static fn() => new EmeraldHelmet());
        $if->register(static fn() => new EmeraldChestplate());
        $if->register(static fn() => new EmeraldLeggings());
        $if->register(static fn() => new EmeraldBoots());
        $if->register(static fn() => new RubyHelmet());
        $if->register(static fn() => new RubyChestplate());
        $if->register(static fn() => new RubyLeggings());
        $if->register(static fn() => new RubyBoots());
        $if->register(static fn() => new PrismHelmet());
        $if->register(static fn() => new PrismChestplate());
        $if->register(static fn() => new PrismLeggings());
        $if->register(static fn() => new PrismBoots());

        // Items Staff
        $if->register(static fn() => new ArcPunchItem());
        $if->register(static fn() => new FreezeStick());
        $if->register(static fn() => new AntiPearlStick());
        $if->register(static fn() => new AntiItemStick());
        $if->register(static fn() => new BumpItem());
        $if->register(static fn() => new SwitchBallItem());
        // Soupe custom stackable x64
        $if->register(static fn() => new SoupItem());
        // Clés
        $if->register(static fn() => new VoteKey());
        $if->register(static fn() => new NobleKey());
        $if->register(static fn() => new HerosKey());
        $if->register(static fn() => new DieuKey());
        $if->register(static fn() => new BoutiqueKey());

        $this->getLogger()->info("§aPrismaItems chargé — 4 minerais, 4 lingots, 4 épées, 16 armures, 6 items staff, 1 consommable, 5 clés.");
    }
}
