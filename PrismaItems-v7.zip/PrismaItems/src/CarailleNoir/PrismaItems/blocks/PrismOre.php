<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\blocks;

use pocketmine\block\BlockBreakInfo;
use pocketmine\block\BlockToolType;
use pocketmine\block\BlockTypeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\BlockIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Builder\BlockBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Info\BlockCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Blocks\Opaque;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class PrismOre extends Opaque
{
    public function __construct()
    {
        parent::__construct(
            new BlockIdentifier("prisma:prism_ore", 4004),
            "§5Minerai de Prism",
            new BlockTypeInfo(
                new BlockBreakInfo(3.0, BlockToolType::PICKAXE, 1)
            )
        );
    }

    public function getBlockBuilder(): BlockBuilder
    {
        return parent::getBlockBuilder()
            ->setCreativeInfo(new BlockCreativeInfo(CategoryCreativeEnum::NATURE));
    }
}
