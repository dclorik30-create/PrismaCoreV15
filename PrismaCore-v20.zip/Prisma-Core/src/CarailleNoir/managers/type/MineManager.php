<?php

declare(strict_types=1);

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\World;

class MineManager
{
 private const MINE_WORLD = "Mine";
 private const VIP_MINE_WORLD = "MineVIP";
 private const SPAWN_DELAY = 8;

 private array $data = [];
 private array $timers = [];

 public function register(): void
 {
 $path = Core::getInstance()->getDataFolder() . "mine.json";
 if (!file_exists($path)) {
 file_put_contents($path, json_encode([
 "mine" => [
 "world" => self::MINE_WORLD,
 "spawn" => ["x" => -1, "y" => 119, "z" => 16],
 "bedrock_positions" => []
 ],
 "minevip" => [
 "world" => self::VIP_MINE_WORLD,
 "spawn" => ["x" => -1, "y" => 119, "z" => 16],
 "bedrock_positions" => []
 ]
 ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
 }
 $this->data = json_decode(file_get_contents($path), true) ?? [];
 }

 public function save(): void
 {
 file_put_contents(Core::getInstance()->getDataFolder() . "mine.json", json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
 }

 public function getMineConfig(): array
 {
 return $this->data["mine"] ?? [];
 }

 public function rollBlock(string $type = "mine"): ?array
 {
 $block = $this->rollOre(strtolower($type));
 return ["block" => $block];
 }

 public function initializeMine(string $type): int
 {
 $type = strtolower($type);
 if ($type === 'minevip') return 0; // géré par plugin externe
 if (!isset($this->data[$type])) {
 return 0;
 }

 $worldName = $this->data[$type]["world"] ?? ($type === "minevip" ? self::VIP_MINE_WORLD : self::MINE_WORLD);
 $wm = Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($worldName)) {
 $wm->loadWorld($worldName);
 }
 $world = $wm->getWorldByName($worldName);
 if ($world === null) {
 return 0;
 }

 $positions = [];
 $count = 0;
 $world->loadChunk(0, 0);
 foreach ($world->getLoadedChunks() as $chunkHash => $chunk) {
 World::getXZ($chunkHash, $cx, $cz);
 for ($x = $cx << 4; $x < ($cx << 4) + 16; $x++) {
 for ($z = $cz << 4; $z < ($cz << 4) + 16; $z++) {
 for ($y = World::Y_MIN; $y <= World::Y_MAX; $y++) {
 $block = $world->getBlockAt($x, $y, $z);
 if ($block->getTypeId() === VanillaBlocks::BEDROCK()->getTypeId()) {
 $positions[] = ["x" => $x, "y" => $y, "z" => $z];
 $count++;
 }
 }
 }
 }
 }

 $this->data[$type]["bedrock_positions"] = $positions;
 $this->save();
 return $count;
 }

 public function tick(): void
 {
 $this->tickType("mine");
 // minevip géré par plugin externe
 }

 private function tickType(string $type): void
 {
 $cfg = $this->data[$type] ?? null;
 if ($cfg === null) {
 return;
 }

 $worldName = $cfg["world"] ?? ($type === "minevip" ? self::VIP_MINE_WORLD : self::MINE_WORLD);
 $wm = Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($worldName)) {
 return;
 }
 $world = $wm->getWorldByName($worldName);
 if ($world === null) {
 return;
 }

 foreach (($cfg["bedrock_positions"] ?? []) as $pos) {
 $x = (int) $pos["x"];
 $y = (int) $pos["y"];
 $z = (int) $pos["z"];
 $key = $this->getKey($type, $x, $y, $z);
 $block = $world->getBlockAt($x, $y, $z);
 $typeId = $block->getTypeId();

 if ($typeId === VanillaBlocks::AIR()->getTypeId()) {
 $world->setBlockAt($x, $y, $z, VanillaBlocks::BEDROCK());
 $this->timers[$key] = time() + self::SPAWN_DELAY;
 continue;
 }

 if ($typeId === VanillaBlocks::BEDROCK()->getTypeId()) {
 if (!isset($this->timers[$key])) {
 $this->timers[$key] = time() + self::SPAWN_DELAY;
 continue;
 }
 if (time() >= $this->timers[$key]) {
 $world->setBlockAt($x, $y, $z, $this->rollOre($type));
 unset($this->timers[$key]);
 }
 }
 }
 }

 public function handleOreBreak(World $world, Vector3 $pos): void
 {
 $type = $this->getMineTypeByWorld($world->getFolderName());
 if ($type === null || !$this->isTrackedPosition($type, (int) $pos->x, (int) $pos->y, (int) $pos->z)) {
 return;
 }

 $world->setBlock($pos, VanillaBlocks::BEDROCK());
 $this->timers[$this->getKey($type, (int) $pos->x, (int) $pos->y, (int) $pos->z)] = time() + self::SPAWN_DELAY;
 }

 public function isMineWorld(string $worldName): bool
 {
 return $this->getMineTypeByWorld($worldName) !== null;
 }

 public function canBreakAt(string $worldName, int $x, int $y, int $z): bool
 {
 $type = $this->getMineTypeByWorld($worldName);
 return $type !== null && $this->isTrackedPosition($type, $x, $y, $z);
 }

 public function isVipOreBlock(int $x, int $y, int $z): bool
 {
 return $this->isTrackedPosition("minevip", $x, $y, $z);
 }

 public function getVipMineConfig(): array
 {
 return $this->data["minevip"] ?? [];
 }

 public function markVipBlockMined(int $x, int $y, int $z, int $respawnDelay): void
 {
 $this->timers[$this->getKey("minevip", $x, $y, $z)] = time() + max(1, $respawnDelay);
 }

 public function checkVipRespawns(World $world): void
 {
 $this->tickType("minevip");
 }

 private function getMineTypeByWorld(string $worldName): ?string
 {
 $normalized = strtolower($worldName);
 if ($normalized === strtolower($this->data["mine"]["world"] ?? self::MINE_WORLD)) {
 return "mine";
 }
 if ($normalized === strtolower($this->data["minevip"]["world"] ?? self::VIP_MINE_WORLD)) {
 return "minevip";
 }
 return null;
 }

 private function isTrackedPosition(string $type, int $x, int $y, int $z): bool
 {
 foreach (($this->data[$type]["bedrock_positions"] ?? []) as $pos) {
 if ((int) $pos["x"] === $x && (int) $pos["y"] === $y && (int) $pos["z"] === $z) {
 return true;
 }
 }
 return false;
 }

 private function getKey(string $type, int $x, int $y, int $z): string
 {
 return $type . ':' . $x . ':' . $y . ':' . $z;
 }

 private function rollOre(string $type): Block
 {
 return match (strtolower($type)) {
 "mine" => $this->weighted([
 [new DiamondOre(), 50],
 [new EmeraldOre(), 35],
 [new RubyOre(), 15],
 ]),
 "minevip" => $this->weighted([
 [new EmeraldOre(), 30],
 [new RubyOre(), 60],
 [new PrismOre(), 10],
 ]),
 "emeraude", "emerald" => new EmeraldOre(),
 "rubis" => new RubyOre(),
 "prisme", "prisme" => new PrismOre(),
 default => new DiamondOre()
 };
 }

 private function weighted(array $entries): Block
 {
 $total = 0;
 foreach ($entries as $entry) {
 $total += $entry[1];
 }
 $rand = mt_rand(1, $total);
 $current = 0;
 foreach ($entries as $entry) {
 $block = $entry[0];
 $weight = $entry[1];
 $current += $weight;
 if ($rand <= $current) {
 return $block;
 }
 }
 return $entries[0][0];
 }
}
