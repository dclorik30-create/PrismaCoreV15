<?php

declare(strict_types=1);

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\World;

class MineManager
{
    private const MINE_WORLD = "Mine";
    private const VIP_MINE_WORLD = "MineVIP";
    private const SPAWN_DELAY = 8;

    private array $data = [];
    /** @var array<string, true> */
    private array $trackedPositions = [];
    /** @var array<string, int> */
    private array $pendingRespawns = [];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "mine.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode([
                "mine" => [
                    "world" => self::MINE_WORLD,
                    "spawn" => ["x" => -1, "y" => 119, "z" => 16],
                    "bedrock_positions" => []
                ],
                "minevip" => [
                    "world" => self::VIP_MINE_WORLD,
                    "spawn" => ["x" => -1, "y" => 119, "z" => 16],
                    "bedrock_positions" => []
                ]
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        $decoded = json_decode(file_get_contents($path), true) ?? [];
        if (isset($decoded['vipmime']) && !isset($decoded['minevip'])) {
            $decoded['minevip'] = $decoded['vipmime'];
            unset($decoded['vipmime']);
        }

        $decoded['mine'] ??= [
            'world' => self::MINE_WORLD,
            'spawn' => ['x' => -1, 'y' => 119, 'z' => 16],
            'bedrock_positions' => []
        ];
        $decoded['minevip'] ??= [
            'world' => self::VIP_MINE_WORLD,
            'spawn' => ['x' => -1, 'y' => 119, 'z' => 16],
            'bedrock_positions' => []
        ];

        $this->data = $decoded;
        $this->rebuildTrackedPositions();
        $this->save();
    }

    public function save(): void
    {
        file_put_contents(Core::getInstance()->getDataFolder() . "mine.json", json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public function getMineConfig(): array
    {
        return $this->data['mine'] ?? [];
    }

    public function getVipMineConfig(): array
    {
        return $this->data['minevip'] ?? [];
    }

    public function rollBlock(string $type = 'mine'): ?array
    {
        return ['block' => $this->rollOre(strtolower($type))];
    }

    public function initializeMine(string $type): int
    {
        $type = strtolower($type);
        if (!isset($this->data[$type])) {
            return 0;
        }

        $worldName = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($worldName)) {
            $wm->loadWorld($worldName);
        }

        $world = $wm->getWorldByName($worldName);
        if ($world === null) {
            foreach ($wm->getWorlds() as $loadedWorld) {
                if (strtolower($loadedWorld->getFolderName()) === strtolower($worldName)) {
                    $world = $loadedWorld;
                    break;
                }
            }
        }
        if ($world === null) {
            return 0;
        }

        $positions = [];
        $count = 0;
        $world->loadChunk(0, 0);
        foreach ($world->getLoadedChunks() as $chunkHash => $chunk) {
            World::getXZ($chunkHash, $cx, $cz);
            for ($x = $cx << 4; $x < ($cx << 4) + 16; $x++) {
                for ($z = $cz << 4; $z < ($cz << 4) + 16; $z++) {
                    for ($y = World::Y_MIN; $y <= World::Y_MAX; $y++) {
                        $block = $world->getBlockAt($x, $y, $z);
                        if ($block->getTypeId() === VanillaBlocks::BEDROCK()->getTypeId()) {
                            $positions[] = ['x' => $x, 'y' => $y, 'z' => $z];
                            $count++;
                        }
                    }
                }
            }
        }

        $this->data[$type]['bedrock_positions'] = $positions;
        $this->rebuildTrackedPositions();
        $this->pendingRespawns = [];
        $this->save();
        return $count;
    }

    public function tick(): void
    {
        $this->tickPendingType('mine');
    }

    private function tickPendingType(string $type): void
    {
        if ($this->pendingRespawns === []) {
            return;
        }

        $world = $this->resolveWorld($type);
        if ($world === null) {
            return;
        }

        $now = time();
        foreach ($this->pendingRespawns as $key => $respawnAt) {
            if (!str_starts_with($key, $type . ':')) {
                continue;
            }
            if ($now < $respawnAt) {
                continue;
            }

            [, $x, $y, $z] = explode(':', $key, 4);
            $ix = (int) $x;
            $iy = (int) $y;
            $iz = (int) $z;

            if (!$this->isTrackedPosition($type, $ix, $iy, $iz)) {
                unset($this->pendingRespawns[$key]);
                continue;
            }

            $block = $world->getBlockAt($ix, $iy, $iz);
            $typeId = $block->getTypeId();

            if ($typeId === VanillaBlocks::AIR()->getTypeId()) {
                $world->setBlockAt($ix, $iy, $iz, VanillaBlocks::BEDROCK());
                $this->pendingRespawns[$key] = $now + self::SPAWN_DELAY;
                continue;
            }

            if ($typeId !== VanillaBlocks::BEDROCK()->getTypeId()) {
                unset($this->pendingRespawns[$key]);
                continue;
            }

            $world->setBlockAt($ix, $iy, $iz, $this->rollOre($type));
            unset($this->pendingRespawns[$key]);
        }
    }

    public function handleOreBreak(World $world, Vector3 $pos): void
    {
        $type = $this->getMineTypeByWorld($world->getFolderName());
        if ($type !== 'mine') {
            return;
        }

        $x = (int) $pos->x;
        $y = (int) $pos->y;
        $z = (int) $pos->z;
        if (!$this->isTrackedPosition($type, $x, $y, $z)) {
            return;
        }

        $world->setBlock($pos, VanillaBlocks::BEDROCK());
        $this->pendingRespawns[$this->getKey($type, $x, $y, $z)] = time() + self::SPAWN_DELAY;
    }

    public function isMineWorld(string $worldName): bool
    {
        return $this->getMineTypeByWorld($worldName) === 'mine';
    }

    public function canBreakAt(string $worldName, int $x, int $y, int $z): bool
    {
        $type = $this->getMineTypeByWorld($worldName);
        return $type === 'mine' && isset($this->trackedPositions[$this->getKey($type, $x, $y, $z)]);
    }

    public function isVipOreBlock(int $x, int $y, int $z): bool
    {
        return false;
    }

    public function markVipBlockMined(int $x, int $y, int $z, int $respawnDelay): void
    {
    }

    public function checkVipRespawns(World $world): void
    {
    }

    private function resolveWorld(string $type): ?World
    {
        $worldName = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($worldName)) {
            return null;
        }

        $world = $wm->getWorldByName($worldName);
        if ($world !== null) {
            return $world;
        }

        foreach ($wm->getWorlds() as $loadedWorld) {
            if (strtolower($loadedWorld->getFolderName()) === strtolower($worldName)) {
                return $loadedWorld;
            }
        }

        return null;
    }

    private function getMineTypeByWorld(string $worldName): ?string
    {
        $normalized = strtolower($worldName);
        if ($normalized === strtolower($this->data['mine']['world'] ?? self::MINE_WORLD)) {
            return 'mine';
        }
        return null;
    }

    private function isTrackedPosition(string $type, int $x, int $y, int $z): bool
    {
        return isset($this->trackedPositions[$this->getKey($type, $x, $y, $z)]);
    }

    private function rebuildTrackedPositions(): void
    {
        $this->trackedPositions = [];
        foreach (['mine'] as $type) {
            foreach (($this->data[$type]['bedrock_positions'] ?? []) as $pos) {
                $this->trackedPositions[$this->getKey($type, (int) $pos['x'], (int) $pos['y'], (int) $pos['z'])] = true;
            }
        }
    }

    private function getKey(string $type, int $x, int $y, int $z): string
    {
        return $type . ':' . $x . ':' . $y . ':' . $z;
    }

    private function rollOre(string $type): Block
    {
        return match (strtolower($type)) {
            'mine' => $this->weighted([
                [new DiamondOre(), 50],
                [new EmeraldOre(), 35],
                [new RubyOre(), 15],
            ]),
            'minevip' => $this->weighted([
                [new EmeraldOre(), 30],
                [new RubyOre(), 60],
                [new PrismOre(), 10],
            ]),
            'emeraude', 'emerald' => new EmeraldOre(),
            'rubis' => new RubyOre(),
            'prisme' => new PrismOre(),
            default => new DiamondOre()
        };
    }

    private function weighted(array $entries): Block
    {
        $total = 0;
        foreach ($entries as $entry) {
            $total += $entry[1];
        }

        $rand = mt_rand(1, $total);
        $current = 0;
        foreach ($entries as $entry) {
            $block = $entry[0];
            $weight = $entry[1];
            $current += $weight;
            if ($rand <= $current) {
                return $block;
            }
        }

        return $entries[0][0];
    }
}
