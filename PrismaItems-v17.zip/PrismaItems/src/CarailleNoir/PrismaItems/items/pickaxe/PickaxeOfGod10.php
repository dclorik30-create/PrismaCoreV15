<?php
declare(strict_types=1);
namespace CarailleNoir\PrismaItems\items\pickaxe;

use ReflectionProperty;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Builder\ItemBuilder;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ICustomItem;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Info\ItemCreativeInfo;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ItemIdentifier;
use SenseiTarzan\SymplyPlugin\Behavior\Items\Pickaxe;
use SenseiTarzan\SymplyPlugin\Behavior\Items\ToolTier;
use SenseiTarzan\SymplyPlugin\Behavior\Common\Enum\CategoryCreativeEnum;

class PickaxeOfGod10 extends Pickaxe implements ICustomItem
{
    public const LEVEL = 10;
    public const REQUIRED_BLOCKS = 20000;

    public function __construct()
    {
        parent::__construct(
            new ItemIdentifier("prisma:pickaxeofgod10", 30130),
            "§6Pickaxe Of God 10",
            new ToolTier(
                harvestLevel: 10,
                maxDurability: 14000,
                baseAttackPoints: 14,
                baseEfficiency: 120,
                enchantability: 30
            )
        );
        $this->setLore([
            "§7Une pioche divine qui évolue en minant.",
            "§8ID:item_pog_10",
            "§e0 Blocks / 20000",
            "§7Progression vers le niveau suivant"
        ]);
    }

    public function getIdentifier(): ItemIdentifier
    {
        $identifier = (new ReflectionProperty(\pocketmine\item\Item::class, "identifier"))->getValue($this);
        assert($identifier instanceof ItemIdentifier);
        return $identifier;
    }

    public function getItemBuilder(): ItemBuilder
    {
        return parent::getItemBuilder()
            ->setIcon("item_pog_10")
            ->setCreativeInfo(new ItemCreativeInfo(CategoryCreativeEnum::ITEMS));
    }
}
