<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use pocketmine\block\Block;
use pocketmine\block\VanillaBlocks;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyBlockFactory;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\Position;
use pocketmine\world\World;

class TotemManager
{
    public const MAX_DURATION = 1800; // 30 minutes
    private const BLOCK_COUNT = 4;
    private const BREAK_COOLDOWN_TICKS = 4;

    private bool $active = false;
    private ?string $breaker = null;
    private int $progress = 0;
    private int $expireAt = 0;
    private ?string $lastWinner = null;
    private int $lastWinAt = 0;

    /** @var array<int, bool> */
    private array $broken = [];
    /** @var array<string, int> */
    private array $spamGuard = [];

    public function start(): void
    {
        $this->active = true;
        $this->breaker = null;
        $this->progress = 0;
        $this->expireAt = time() + self::MAX_DURATION;
        $this->broken = array_fill(0, count($this->getPillarBlocks()), false);
        $this->spawnPillar();
        Manager::FLOATINGTEXT()->updateTotem('active', null, 0, $this->getRequired(), null);
        // Pas de broadcast ici : EventManager::startEvent() diffuse déjà un message de démarrage
    }

    public function stop(bool $clearBlocks = true): void
    {
        $this->active = false;
        $this->breaker = null;
        $this->progress = 0;
        $this->expireAt = 0;
        $this->broken = [];
        if ($clearBlocks) $this->clearPillar();
        Manager::FLOATINGTEXT()->updateTotem('idle', null, 0, $this->getRequired(), $this->lastWinner);
    }

    public function isActive(): bool { return $this->active; }
    public function getBreaker(): ?string { return $this->breaker; }
    public function getProgress(): int { return $this->progress; }
    public function getRequired(): int { return max(1, count($this->getPillarBlocks())); }
    public function getExpireAt(): int { return $this->expireAt; }
    public function getLastWinner(): ?string { return $this->lastWinner; }

    public function tick(): void
    {
        if (!$this->active) return;
        if ($this->expireAt > 0 && time() >= $this->expireAt) {
            $this->stop();
            Server::getInstance()->broadcastMessage("§c[Totem] §fPersonne n'a reussi a detruire le totem. Event termine.");
            return;
        }
    }

    public function isInZone(Position $pos): bool
    {
        return Manager::EVENT()->isInEventZone('totem', $pos);
    }

    /** @return Vector3[] */
    public function getPillarBlocks(): array
    {
        $zone = Manager::EVENT()->getZone('totem');
        if ($zone === null) {
            return [];
        }

        $x1 = (int) $zone['pos1']['x'];
        $y1 = (int) $zone['pos1']['y'];
        $z1 = (int) $zone['pos1']['z'];
        $x2 = (int) $zone['pos2']['x'];
        $y2 = (int) $zone['pos2']['y'];
        $z2 = (int) $zone['pos2']['z'];

        $minX = min($x1, $x2);
        $maxX = max($x1, $x2);
        $minY = min($y1, $y2);
        $maxY = max($y1, $y2);
        $minZ = min($z1, $z2);
        $maxZ = max($z1, $z2);

        $blocks = [];
        for ($x = $minX; $x <= $maxX; $x++) {
            for ($y = $minY; $y <= $maxY; $y++) {
                for ($z = $minZ; $z <= $maxZ; $z++) {
                    $blocks[] = new Vector3($x, $y, $z);
                }
            }
        }

        return $blocks;
    }

    public function isTotemBlock(Vector3 $pos): int
    {
        foreach ($this->getPillarBlocks() as $i => $v) {
            if ((int)$v->x === (int)$pos->x && (int)$v->y === (int)$pos->y && (int)$v->z === (int)$pos->z) {
                return $i;
            }
        }
        return -1;
    }

    public function canBreak(string $playerName, int $serverTick): bool
    {
        $last = $this->spamGuard[$playerName] ?? -99999;
        if (($serverTick - $last) < self::BREAK_COOLDOWN_TICKS) return false;
        $this->spamGuard[$playerName] = $serverTick;
        return true;
    }

    public function handleBreak(string $playerName, int $blockIndex): array
    {
        if (!$this->active) return ['type' => 'ignore'];
        if ($blockIndex < 0 || $blockIndex >= $this->getRequired()) return ['type' => 'ignore'];
        if ($this->broken[$blockIndex]) return ['type' => 'ignore'];

        if ($this->breaker === null) {
            $this->breaker = $playerName;
        } elseif ($this->breaker !== $playerName) {
            $old = $this->breaker;
            // NOTE: spawnPillar() est appelé par rebuildAfterContest() dans le listener — ne pas double-appeler ici
            $this->breaker = null;
            return ['type' => 'contest', 'breaker' => $old, 'contester' => $playerName];
        }

        $this->broken[$blockIndex] = true;
        $this->progress++;

        if ($this->progress >= $this->getRequired()) {
            $this->lastWinner = $playerName;
            $this->lastWinAt = time();
            $key = Manager::BOX()->makeKeyItem('heros');
            $player = Server::getInstance()->getPlayerExact($playerName);
            if ($player !== null && $key !== null) {
                $player->getInventory()->addItem($key);
            } elseif ($key !== null) {
                // Joueur hors ligne au moment de la victoire : on sauvegarde la clé en attente
                Manager::BOX()->addPendingKey($playerName, $boxId);
            }
            Server::getInstance()->broadcastMessage('§6[Event] §e' . $playerName . ' §fa detruit les §6' . $this->getRequired() . ' blocs §fdu TOTEM et remporte une cle §e' . strtoupper('heros') . '§f !');
            Manager::EVENT()->stopEvent();
            return ['type' => 'win', 'player' => $playerName];
        }

        return ['type' => 'progress', 'player' => $playerName, 'progress' => $this->progress];
    }

    public function spawnPillar(): void
    {
        $world = $this->getWorld();
        if ($world === null) return;
        $blocks = $this->getPillarBlocks();
        $this->broken = array_fill(0, count($blocks), false);
        $this->progress = 0;
        foreach ($blocks as $pos) {
            $totemBlock = SymplyBlockFactory::getInstance()->get("prisma:totem");
            $world->setBlock($pos, $totemBlock ?? VanillaBlocks::OBSIDIAN());
        }
    }

    public function clearPillar(): void
    {
        $world = $this->getWorld();
        if ($world === null) return;
        foreach ($this->getPillarBlocks() as $pos) {
            $world->setBlock($pos, VanillaBlocks::AIR());
        }
    }

    public function rebuildAfterContest(string $contester): void
    {
        $this->spawnPillar();
        $this->breaker = null;
        Server::getInstance()->broadcastMessage('§c[Totem] §fLe totem a ete conteste par §e' . $contester . '§f ! Reset instantane.');
    }

    private function getWorld(): ?World
    {
        $cfg = Manager::EVENT()->getEventConfig('totem') ?? [];
        $worldName = (string)($cfg['world'] ?? 'Map');
        $wm = Server::getInstance()->getWorldManager();
        $world = $wm->getWorldByName($worldName);
        if ($world === null) {
            $wm->loadWorld($worldName);
            $world = $wm->getWorldByName($worldName);
        }
        return $world;
    }
}
