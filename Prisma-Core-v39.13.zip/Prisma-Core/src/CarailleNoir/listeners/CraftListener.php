<?php
declare(strict_types=1);

namespace CarailleNoir\listeners;

use pocketmine\block\VanillaBlocks;
use pocketmine\event\inventory\CraftItemEvent;
use pocketmine\event\Listener;
use pocketmine\item\VanillaItems;

class CraftListener implements Listener
{
    /** @var list<int> */
    private static array $blocked = [];

    public static function init(): void
    {
        self::$blocked = [
            // Leather armor
            VanillaItems::LEATHER_CAP()->getTypeId(),
            VanillaItems::LEATHER_TUNIC()->getTypeId(),
            VanillaItems::LEATHER_PANTS()->getTypeId(),
            VanillaItems::LEATHER_BOOTS()->getTypeId(),
            // Chain armor
            VanillaItems::CHAINMAIL_HELMET()->getTypeId(),
            VanillaItems::CHAINMAIL_CHESTPLATE()->getTypeId(),
            VanillaItems::CHAINMAIL_LEGGINGS()->getTypeId(),
            VanillaItems::CHAINMAIL_BOOTS()->getTypeId(),
            // Iron armor
            VanillaItems::IRON_HELMET()->getTypeId(),
            VanillaItems::IRON_CHESTPLATE()->getTypeId(),
            VanillaItems::IRON_LEGGINGS()->getTypeId(),
            VanillaItems::IRON_BOOTS()->getTypeId(),
            // Gold armor
            VanillaItems::GOLDEN_HELMET()->getTypeId(),
            VanillaItems::GOLDEN_CHESTPLATE()->getTypeId(),
            VanillaItems::GOLDEN_LEGGINGS()->getTypeId(),
            VanillaItems::GOLDEN_BOOTS()->getTypeId(),
            // Diamond armor
            VanillaItems::DIAMOND_HELMET()->getTypeId(),
            VanillaItems::DIAMOND_CHESTPLATE()->getTypeId(),
            VanillaItems::DIAMOND_LEGGINGS()->getTypeId(),
            VanillaItems::DIAMOND_BOOTS()->getTypeId(),
            // Vanilla swords
            VanillaItems::WOODEN_SWORD()->getTypeId(),
            VanillaItems::STONE_SWORD()->getTypeId(),
            VanillaItems::IRON_SWORD()->getTypeId(),
            VanillaItems::GOLDEN_SWORD()->getTypeId(),
            VanillaItems::DIAMOND_SWORD()->getTypeId(),
            // Other blocked crafts
            VanillaItems::BOW()->getTypeId(),
            VanillaItems::ITEM_FRAME()->getTypeId(),
            VanillaBlocks::BARREL()->asItem()->getTypeId(),
        ];
    }

    public function onCraft(CraftItemEvent $event): void
    {
        foreach ($event->getOutputs() as $output) {
            if (in_array($output->getTypeId(), self::$blocked, true)) {
                $event->cancel();
                $event->getPlayer()->sendMessage("§cCe craft est désactivé sur ce serveur !");
                return;
            }
        }
    }
}
