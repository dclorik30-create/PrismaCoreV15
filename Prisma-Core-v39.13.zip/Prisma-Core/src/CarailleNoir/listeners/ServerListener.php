<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\cps\CpsManager;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\RegionOption;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\block\BlockExplodeEvent;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\event\block\BlockMeltEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\InventoryTransactionPacket;
use pocketmine\network\mcpe\protocol\PlayerAuthInputPacket;
use pocketmine\network\mcpe\protocol\SetTimePacket;
use pocketmine\network\mcpe\protocol\types\inventory\UseItemOnEntityTransactionData;
use pocketmine\network\mcpe\protocol\types\PlayerAuthInputFlags;

class ServerListener implements Listener
{
    public function onBlockGrow(BlockGrowEvent $event): void
    {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_GROW->getType())) {
            $event->cancel();
        }
    }

    public function onBlockExplode(BlockExplodeEvent $event): void
    {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_EXPLOSION->getType())) {
            $event->cancel();
        }
    }

    public function onLeavesDecay(LeavesDecayEvent $event): void
    {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_DECAY->getType())) {
            $event->cancel();
        }
    }

    public function onBlockMelt(BlockMeltEvent $event): void
    {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null && !$region->isSettingsEnabled(RegionOption::PARAM_DECAY->getType())) {
            $event->cancel();
        }
    }

    public function onPacketSend(DataPacketSendEvent $event): void
    {
        foreach ($event->getPackets() as $packet) {
            if ($packet instanceof SetTimePacket) {
                $packet->time = 1000;
            }
        }
    }

    public function onPacketReceive(DataPacketReceiveEvent $event): void
    {
        $packet = $event->getPacket();
        $player = $event->getOrigin()->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $isClick = false;

        // Coup dans le vide (MISSED_SWING — une fois par tick client ~20/s)
        if ($packet instanceof PlayerAuthInputPacket) {
            try {
                $isClick = $packet->getInputFlags()->get(PlayerAuthInputFlags::MISSED_SWING);
            } catch (\Throwable) {
                $isClick = false;
            }
        }

        // Coup sur entité (UseItemOnEntity — fire par clic client réel, sans cooldown serveur)
        if (!$isClick && $packet instanceof InventoryTransactionPacket) {
            $isClick = $packet->trData instanceof UseItemOnEntityTransactionData;
        }

        if ($isClick) {
            CpsManager::addClick($player);
        }
    }

    public function onPlayerQuit(PlayerQuitEvent $event): void
    {
        if ($event->getPlayer() instanceof PrismaPlayer) {
            CpsManager::remove($event->getPlayer()->getName());
        }
    }
}
