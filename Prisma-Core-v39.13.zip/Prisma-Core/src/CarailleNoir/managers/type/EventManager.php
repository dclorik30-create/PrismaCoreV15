<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use pocketmine\math\Vector3;
use pocketmine\Server;

class EventManager
{
 public const TYPE_KOTH = "koth";
 public const TYPE_OUTPOST = "outpost";
 public const TYPE_TOTEM = "totem";
 public const TYPE_NEXUS = "nexus";

 private ?string $activeEvent = null;
 private ?string $capturePlayer = null;
 private int $captureProgress = 0;
 private int $captureRequired = 120; // secondes
 private int $eventStartTime = 0;

 private array $config = [];

 public function register(): void
 {
 $path = Core::getInstance()->getDataFolder() . "events.json";
 if (!file_exists($path)) {
 file_put_contents($path, json_encode([
 "koth" => ["world" => "world", "x" => 0, "y" => 65, "z" => 0, "capture_time" => 120, "reward_box" => "heros"],
 "outpost" => ["world" => "world", "x" => 100, "y" => 65, "z" => 100, "capture_time" => 180, "reward_box" => "noble"],
 "totem" => ["world" => "world", "x" => -100, "y" => 65, "z" => -100, "hp" => 50, "reward_box" => "vote"],
 "nexus" => ["world" => "world", "x" => 0, "y" => 65, "z" => -200, "hp" => 100, "reward_box" => "dieu"]
 ], JSON_PRETTY_PRINT));
 }
 $this->config = json_decode(file_get_contents($path), true);
 }

 public function save(): void {}

 public function isEventActive(): bool { return $this->activeEvent !== null; }
 public function getActiveEvent(): ?string { return $this->activeEvent; }
 public function getCapturePlayer(): ?string { return $this->capturePlayer; }
 public function getCaptureProgress(): int { return $this->captureProgress; }
 public function getCaptureRequired(): int { return $this->captureRequired; }

 public function startEvent(string $type): void
 {
 if ($this->isEventActive()) return;
 $this->activeEvent = $type;
 $this->capturePlayer = null;
 $this->captureProgress = 0;
 $this->captureRequired = $this->config[$type]["capture_time"] ?? 120;
 $this->eventStartTime = time();

 Server::getInstance()->broadcastMessage(
 "§6[Event] §eLe §f" . strtoupper($type) . " §ecommence ! Rendez-vous à la zone pour le capturer !"
 );
 }

 public function stopEvent(): void
 {
 $this->activeEvent = null;
 $this->capturePlayer = null;
 $this->captureProgress = 0;
 }

 public function tickCapture(string $player): bool
 {
 if (!$this->isEventActive()) return false;
 if ($this->capturePlayer !== null && $this->capturePlayer !== $player) {
 $this->captureProgress = max(0, $this->captureProgress - 2);
 return false;
 }
 $this->capturePlayer = $player;
 $this->captureProgress++;
 return $this->captureProgress >= $this->captureRequired;
 }

 public function getEventConfig(string $type): ?array
 {
 return $this->config[$type] ?? null;
 }

 public function getEventPosition(string $type): ?Vector3
 {
 $cfg = $this->getEventConfig($type);
 if ($cfg === null) return null;
 return new Vector3($cfg["x"], $cfg["y"], $cfg["z"]);
 }

 public function getRewardBoxId(string $type): string
 {
 return $this->config[$type]["reward_box"] ?? "vote";
 }

 public function onEventWon(string $playerName): void
 {
 if ($this->activeEvent === null) return;
 $type = $this->activeEvent;
 $boxId = $this->getRewardBoxId($type);
 $key = Manager::BOX()->makeKeyItem($boxId);
 $player = Server::getInstance()->getPlayerExact($playerName);

 Server::getInstance()->broadcastMessage("§6[Event] §a$playerName §ea remporté le §f" . strtoupper($type) . " §eet reçoit une clé §6" . strtoupper($boxId) . " §e!");

 if ($player !== null && $key !== null) {
 $player->getInventory()->addItem($key);
 }
 $this->stopEvent();
 }

 public function getAvailableTypes(): array
 {
 return [self::TYPE_KOTH, self::TYPE_OUTPOST, self::TYPE_TOTEM, self::TYPE_NEXUS];
 }
}
