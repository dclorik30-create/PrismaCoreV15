<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use pocketmine\item\StringToItemParser;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;

class BoxManager
{
 /** @var array<string, array> */
 private array $boxes = [];

 private static array $defaultBoxes = [
 "vote" => ["name" => "§aBoîte Vote", "color" => "§a", "key" => "vote_key", "loots" => [
 ["item" => "gold_ingot", "amount" => 16, "chance" => 40, "display" => "§6Lingot d'Or x16"],
 ["item" => "diamond", "amount" => 4, "chance" => 25, "display" => "§bDiamant x4"],
 ["item" => "emerald", "amount" => 8, "chance" => 20, "display" => "§2Emeraude x8"],
 ["item" => "iron_ingot", "amount" => 32, "chance" => 15, "display" => "§7Lingot de Fer x32"]
 ]],
 "noble" => ["name" => "§9Boîte Noble", "color" => "§9", "key" => "noble_key", "loots" => [
 ["item" => "diamond", "amount" => 8, "chance" => 35, "display" => "§bDiamant x8"],
 ["item" => "gold_ingot", "amount" => 32, "chance" => 30, "display" => "§6Lingot d'Or x32"],
 ["item" => "emerald", "amount" => 16, "chance" => 25, "display" => "§2Emeraude x16"],
 ["item" => "iron_block", "amount" => 4, "chance" => 10, "display" => "§7Bloc de Fer x4"]
 ]],
 "heros" => ["name" => "§cBoîte Héros", "color" => "§c", "key" => "heros_key", "loots" => [
 ["item" => "diamond_block", "amount" => 2, "chance" => 30, "display" => "§bBloc de Diamant x2"],
 ["item" => "diamond", "amount" => 16, "chance" => 30, "display" => "§bDiamant x16"],
 ["item" => "emerald", "amount" => 32, "chance" => 25, "display" => "§2Emeraude x32"],
 ["item" => "gold_block", "amount" => 4, "chance" => 15, "display" => "§6Bloc d'Or x4"]
 ]],
 "dieu" => ["name" => "§6Boîte Dieu", "color" => "§6", "key" => "dieu_key", "loots" => [
 ["item" => "diamond_block", "amount" => 4, "chance" => 30, "display" => "§bBloc de Diamant x4"],
 ["item" => "netherite_ingot","amount" => 2, "chance" => 25, "display" => "§8Netherite x2"],
 ["item" => "emerald_block", "amount" => 4, "chance" => 25, "display" => "§2Bloc d'Emeraude x4"],
 ["item" => "gold_block", "amount" => 8, "chance" => 20, "display" => "§6Bloc d'Or x8"]
 ]]
 ];

 public function register(): void
 {
 $path = Core::getInstance()->getDataFolder() . "boxes.json";
 if (!file_exists($path)) {
 file_put_contents($path, json_encode(self::$defaultBoxes, JSON_PRETTY_PRINT));
 }
 $content = file_get_contents($path);
 $this->boxes = json_decode($content, true) ?? self::$defaultBoxes;
 }

 public function save(): void
 {
 $path = Core::getInstance()->getDataFolder() . "boxes.json";
 file_put_contents($path, json_encode($this->boxes, JSON_PRETTY_PRINT));
 }

 public function getBox(string $id): ?array
 {
 return $this->boxes[strtolower($id)] ?? null;
 }

 public function getBoxes(): array
 {
 return $this->boxes;
 }

 public function rollLoot(string $boxId): ?array
 {
 $box = $this->getBox($boxId);
 if ($box === null) return null;

 $rand = mt_rand(1, 100);
 $cumul = 0;
 foreach ($box["loots"] as $loot) {
 $cumul += $loot["chance"];
 if ($rand <= $cumul) return $loot;
 }
 return $box["loots"][array_key_last($box["loots"])];
 }

 public function makeKeyItem(string $boxId): ?Item
 {
 $box = $this->getBox($boxId);
 if ($box === null) return null;
 $item = VanillaItems::TRIPWIRE_HOOK()->setCount(1);
 $item->setCustomName($box["color"] . "Clé " . ucfirst($boxId));
 $item->setLore(["§7Clé pour ouvrir une §r" . $box["name"], "§8ID:key_" . $boxId]);
 return $item;
 }

 public function isKey(Item $item, string $boxId): bool
 {
 $lore = $item->getLore();
 return in_array("§8ID:key_" . $boxId, $lore, true);
 }

 public function getKeyBoxId(Item $item): ?string
 {
 foreach ($item->getLore() as $line) {
 if (str_starts_with($line, "§8ID:key_")) {
 return substr($line, strlen("§8ID:key_"));
 }
 }
 return null;
 }
}
