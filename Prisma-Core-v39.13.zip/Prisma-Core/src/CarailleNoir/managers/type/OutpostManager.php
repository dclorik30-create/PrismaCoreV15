<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;
use pocketmine\world\Position;

class OutpostManager
{
 // =========================================================================
 // CONFIGURATION DE LA ZONE — MODIFIEZ CES VALEURS DIRECTEMENT
 // =========================================================================

 public const ZONE_WORLD = "world";

 public const ZONE_X1 = -10;
 public const ZONE_Y1 = 60;
 public const ZONE_Z1 = -10;

 public const ZONE_X2 = 10;
 public const ZONE_Y2 = 80;
 public const ZONE_Z2 = 10;

 // =========================================================================
 // PARAMETRES DE GAMEPLAY
 // =========================================================================

 public const CAPTURE_TIME = 180; // secondes pour capturer
 public const DECAPTURE_TIME = 60; // secondes pour décapturer
 public const REWARD_MONEY = 5000; // argent par cycle
 public const REWARD_POWER = 10; // power par membre par cycle
 public const REWARD_INTERVAL = 300; // toutes les 5 min

 // =========================================================================
 // ETATS
 // =========================================================================

 public const STATE_NEUTRAL = "neutral";
 public const STATE_CAPTURING = "capturing";
 public const STATE_CAPTURED = "captured";
 public const STATE_CONTESTED = "contested";
 public const STATE_DECAPTURING = "decapturing";

 // ── Runtime ───────────────────────────────────────────────────────────────
 private string $state = self::STATE_NEUTRAL;
 private ?string $capturingFaction = null; // factionId
 private ?string $capturedFaction = null; // factionId
 private ?string $decapturingFaction = null; // factionId
 private int $captureProgress = 0;
 private int $decaptureProgress = 0;
 private int $rewardTimer = 0;

 /** @var array<string, list<string>> factionId => [playerNames] */
 private array $playersInZone = [];

 // ── Getters ───────────────────────────────────────────────────────────────

 public function hasZone(): bool { return true; }
 public function getState(): string { return $this->state; }
 public function getCapturedFaction(): ?string { return $this->capturedFaction; }
 public function getCapturingFaction(): ?string { return $this->capturingFaction; }
 public function getDecapturingFaction(): ?string { return $this->decapturingFaction; }
 public function getCaptureProgress(): int { return $this->captureProgress; }
 public function getDecaptureProgress(): int { return $this->decaptureProgress; }
 public function getRewardTimer(): int { return $this->rewardTimer; }

 // ── Zone ──────────────────────────────────────────────────────────────────

 public function isInZone(Position $pos): bool
 {
 if ($pos->getWorld()->getFolderName() !== self::ZONE_WORLD) return false;
 $x = (int)floor($pos->getX());
 $y = (int)floor($pos->getY());
 $z = (int)floor($pos->getZ());
 return $x >= min(self::ZONE_X1, self::ZONE_X2)
 && $x <= max(self::ZONE_X1, self::ZONE_X2)
 && $y >= min(self::ZONE_Y1, self::ZONE_Y2)
 && $y <= max(self::ZONE_Y1, self::ZONE_Y2)
 && $z >= min(self::ZONE_Z1, self::ZONE_Z2)
 && $z <= max(self::ZONE_Z1, self::ZONE_Z2);
 }

 // ── Presence joueurs ──────────────────────────────────────────────────────

 public function enterZone(string $player, string $factionId): void
 {
 if (!isset($this->playersInZone[$factionId])) $this->playersInZone[$factionId] = [];
 if (!in_array($player, $this->playersInZone[$factionId], true))
 $this->playersInZone[$factionId][] = $player;
 }

 public function leaveZone(string $player): void
 {
 foreach ($this->playersInZone as $fid => &$players) {
 $players = array_values(array_filter($players, fn($p) => $p !== $player));
 if (empty($players)) unset($this->playersInZone[$fid]);
 }
 }

 public function getFactionsInZone(): array
 {
 return array_keys(array_filter($this->playersInZone, fn($p) => count($p) > 0));
 }

 // ── Helper : nom de faction depuis son ID ─────────────────────────────────

 private function factionName(?string $id): string
 {
 if ($id === null) return "Aucune";
 $f = Manager::FACTION()->getFaction($id);
 return $f !== null ? $f->getName() : $id;
 }

 // ── Tick (appele chaque seconde par OutpostTask) ───────────────────────────

 public function tick(): void
 {
 $factions = $this->getFactionsInZone();
 $count = count($factions);

 // Recompenses periodiques quand capture
 if ($this->state === self::STATE_CAPTURED && $this->capturedFaction !== null) {
 $this->rewardTimer++;
 if ($this->rewardTimer >= self::REWARD_INTERVAL) {
 $this->rewardTimer = 0;
 $this->giveRewards($this->capturedFaction);
 }
 }

 switch ($this->state) {

 case self::STATE_NEUTRAL:
 if ($count === 1) {
 $this->state = self::STATE_CAPTURING;
 $this->capturingFaction = $factions[0];
 $this->captureProgress = 0;
 $name = $this->factionName($factions[0]);
 $this->broadcast("§e§l[Outpost] §fLa faction §a{$name} §fcommence la capture !");
 }
 break;

 case self::STATE_CAPTURING:
 if ($count === 0) {
 $this->state = self::STATE_NEUTRAL;
 $this->capturingFaction = null;
 $this->captureProgress = 0;
 } elseif ($count >= 2) {
 $this->state = self::STATE_CONTESTED;
 } elseif ($factions[0] === $this->capturingFaction) {
 $this->captureProgress++;
 if ($this->captureProgress >= self::CAPTURE_TIME) {
 $this->capturedFaction = $this->capturingFaction;
 $this->capturingFaction = null;
 $this->captureProgress = 0;
 $this->state = self::STATE_CAPTURED;
 $name = $this->factionName($this->capturedFaction);
 $this->broadcast("§e§l[Outpost] §a✔ La faction §f{$name} §aa capturé l'Outpost !");
 $this->giveRewards($this->capturedFaction);
 }
 } else {
 $this->state = self::STATE_CONTESTED;
 }
 break;

 case self::STATE_CONTESTED:
 if ($count === 0) {
 $this->state = self::STATE_NEUTRAL;
 $this->capturingFaction = null;
 $this->captureProgress = 0;
 } elseif ($count === 1) {
 $this->state = self::STATE_CAPTURING;
 $this->capturingFaction = $factions[0];
 }
 break;

 case self::STATE_CAPTURED:
 if ($count === 0) break;
 if ($count >= 2) {
 $this->state = self::STATE_CONTESTED;
 break;
 }
 // 1 seule faction dans la zone
 if ($factions[0] !== $this->capturedFaction) {
 $this->state = self::STATE_DECAPTURING;
 $this->decapturingFaction = $factions[0];
 $this->decaptureProgress = 0;
 $name = $this->factionName($factions[0]);
 $current = $this->factionName($this->capturedFaction);
 $this->broadcast("§e§l[Outpost] §c⚠ §f{$name} §ctente de décapturer l'Outpost de §f{$current} §c(60s)");
 }
 break;

 case self::STATE_DECAPTURING:
 if ($count === 0) {
 // Ennemi sorti — outpost reste à la faction d'origine
 $this->state = self::STATE_CAPTURED;
 $this->decapturingFaction = null;
 $this->decaptureProgress = 0;
 } elseif ($count >= 2) {
 $this->state = self::STATE_CONTESTED;
 } elseif ($factions[0] === $this->decapturingFaction) {
 $this->decaptureProgress++;
 if ($this->decaptureProgress >= self::DECAPTURE_TIME) {
 // Décapture réussie → la faction ennemie recommence la capture (240s)
 $name = $this->factionName($this->decapturingFaction);
 $this->broadcast("§e§l[Outpost] §cL'Outpost a été décapturé ! §f{$name} §ccommence la capture (240s).");
 $this->capturingFaction = $this->decapturingFaction;
 $this->capturedFaction = null;
 $this->decapturingFaction = null;
 $this->decaptureProgress = 0;
 $this->captureProgress = 0;
 $this->state = self::STATE_CAPTURING;
 }
 } else {
 $this->state = self::STATE_CONTESTED;
 }
 break;
 }
 }

 // ── Récompenses : argent + power pour tous les membres en ligne ───────────

 private function giveRewards(string $factionId): void
 {
 $faction = Manager::FACTION()->getFaction($factionId);
 if ($faction === null) return;

 $name = $faction->getName();
 $online = $faction->getOnlinePlayers();
 if (empty($online)) return;

 foreach ($online as $p) {
 if (!($p instanceof PrismaPlayer)) continue;
 $p->addMoney((float)self::REWARD_MONEY);
 Manager::STATS()->addPower($p->getName(), self::REWARD_POWER);
 $p->sendMessage("§e§l[Outpost] §a+§f" . self::REWARD_MONEY . "§a$ §7& §a+" . self::REWARD_POWER . " §7power reçus !");
 }

 $this->broadcast("§e§l[Outpost] §fLa faction §a{$name} §freçoit les récompenses de l'Outpost !");
 }

 public function broadcast(string $msg): void
 {
 foreach (Server::getInstance()->getOnlinePlayers() as $p) {
 $p->sendMessage($msg);
 }
 }

 public function getStatusBar(): string
 {
 return match ($this->state) {
 self::STATE_NEUTRAL => "§7[Outpost] §fNeutre",
 self::STATE_CAPTURING => "§7[Outpost] §aCapture §f" . $this->factionName($this->capturingFaction) . " §7(" . $this->captureProgress . "/" . self::CAPTURE_TIME . "s)",
 self::STATE_CAPTURED => "§7[Outpost] §a" . $this->factionName($this->capturedFaction),
 self::STATE_CONTESTED => "§7[Outpost] §c Contesté",
 self::STATE_DECAPTURING => "§7[Outpost] §cDécapture §f" . $this->factionName($this->decapturingFaction) . " §7(" . $this->decaptureProgress . "/" . self::DECAPTURE_TIME . "s)",
 default => ""
 };
 }
}
