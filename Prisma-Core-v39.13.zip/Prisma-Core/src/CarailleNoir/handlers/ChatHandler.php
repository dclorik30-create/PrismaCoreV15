<?php

namespace CarailleNoir\handlers;

class ChatHandler
{

}