<?php
namespace CarailleNoir\commands\Staff;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class EventCommand extends BaseCommand {
 public function __construct() {
 parent::__construct("event", "Gérer les events", [], [], ["prisma.command.staff", "prisma.command.event"]);
 }
 protected function prepare(): array {
 return [new RawStringArgument("action"), new RawStringArgument("type", true)];
 }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 $action = strtolower($args["action"]);
 $types = Manager::EVENT()->getAvailableTypes();
 $type = strtolower($args["type"] ?? "");
 switch ($action) {
 case "start":
 if (Manager::EVENT()->isEventActive()) { $sender->sendMessage("§cUn event est déjà en cours : §e" . Manager::EVENT()->getActiveEvent()); return; }
 if (!in_array($type, $types, true)) { $sender->sendMessage("§cType invalide. Types : " . implode(", ", $types)); return; }
 Manager::EVENT()->startEvent($type);
 $sender->sendMessage("§aEvent §f" . strtoupper($type) . " §adémarré !");
 break;
 case "stop":
 if (!Manager::EVENT()->isEventActive()) { $sender->sendMessage("§cAucun event actif !"); return; }
 Manager::EVENT()->stopEvent();
 $sender->sendMessage("§aEvent arrêté.");
 break;
 case "status":
 if (!Manager::EVENT()->isEventActive()) { $sender->sendMessage("§eAucun event en cours."); return; }
 $ev = Manager::EVENT()->getActiveEvent();
 $cap = Manager::EVENT()->getCapturePlayer() ?? "Personne";
 $prg = Manager::EVENT()->getCaptureProgress();
 $req = Manager::EVENT()->getCaptureRequired();
 $pct = $req > 0 ? round($prg / $req * 100) : 0;
 $sender->sendMessage("§6Event §e{$ev} §f— Capture : §a{$cap} §f({$pct}% — {$prg}/{$req}s)");
 break;
 default:
 $sender->sendMessage("§cUsage : /event <start|stop|status> [type]");
 }
 }
}
