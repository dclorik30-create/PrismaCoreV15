<?php
namespace CarailleNoir\commands\Staff;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
class StaffModCommand extends BaseCommand {
 public function __construct() { parent::__construct("staffmod", "Activer/désactiver le mode staff", [], [], ["prisma.command.staff", "prisma.command.staffmod"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $mode = !$sender->isStaffMode();
 $sender->setStaffMode($mode);
 if ($mode) {
 $sender->setInvisible(true);
 $sender->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999, 0, false, false));
 $sender->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 999999, 2, false, false));
 $sender->sendMessage("§a[StaffMod] §fActivé. Vous êtes invisible et rapide.");
 } else {
 $sender->setInvisible(false);
 $sender->getEffects()->remove(VanillaEffects::SPEED());
 $sender->sendMessage("§c[StaffMod] §fDésactivé.");
 }
 }
}
