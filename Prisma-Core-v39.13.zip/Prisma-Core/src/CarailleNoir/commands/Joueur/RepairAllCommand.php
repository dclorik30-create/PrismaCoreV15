<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;

class RepairAllCommand extends BaseCommand
{
 /** @var array<string, int> Clé = strtolower(gradeId), valeur = cooldown en secondes (0 = aucun) */
 private const GRADE_COOLDOWNS = [
 "joueur" => 86400, // 24h
 "noble" => 43200, // 12h
 "heros" => 21600, // 6h
 "héros" => 21600,
 "dieu" => 10800, // 3h
 "fondateur" => 3600, // 1h
 "influenceur" => 43200, // 12h
 "vote" => 86400, // 24h
 "guide" => 0, // Staff — aucun cooldown
 "modérateur" => 0,
 "moderateur" => 0,
 "administrateur" => 0,
 ];

 /** @var array<string, int> playerName => last_repair_timestamp */
 private array $cooldowns = [];

 public function __construct()
 {
 parent::__construct("repairall", "Répare tous les items de l'inventaire", [], [], ["prisma.command.repairall"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $name = strtolower($sender->getName());
 $gradeId = strtolower($sender->getGradeId());
 $cooldown = self::GRADE_COOLDOWNS[$gradeId] ?? 86400;

 if ($cooldown > 0 && isset($this->cooldowns[$name])) {
 $elapsed = time() - $this->cooldowns[$name];
 $remaining = $cooldown - $elapsed;
 if ($remaining > 0) {
 $h = floor($remaining / 3600);
 $m = floor(($remaining % 3600) / 60);
 $s = $remaining % 60;
 $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
 $sender->sendMessage("§cRepairAll en cooldown : §f{$fmt} §crestant.");
 return;
 }
 }

 $inv = $sender->getInventory();
 $armor = $sender->getArmorInventory();
 $repaired = 0;

 foreach (array_merge($inv->getContents(), $armor->getContents()) as $item) {
 if ($item instanceof Durable && $item->getDamage() > 0) {
 $item->setDamage(0);
 $repaired++;
 }
 }

 // Appliquer les items réparés
 foreach ($inv->getContents() as $slot => $item) {
 if ($item instanceof Durable) { $item->setDamage(0); $inv->setItem($slot, $item); }
 }
 foreach ($armor->getContents() as $slot => $item) {
 if ($item instanceof Durable) { $item->setDamage(0); $armor->setItem($slot, $item); }
 }

 if ($cooldown > 0) $this->cooldowns[$name] = time();

 $sender->sendMessage($repaired > 0
 ? "§a✔ §f{$repaired} item(s) réparé(s) !"
 : "§7Aucun item à réparer.");
 }
}
