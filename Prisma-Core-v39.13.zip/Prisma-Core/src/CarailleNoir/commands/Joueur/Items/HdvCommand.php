<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\invmenu\HdvMenu;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\FloatArgument;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;

class HdvCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("hdv", "Hôtel des Ventes", [], [], "prisma.command.hdv");
 }

 protected function prepare(): array
 {
 $this->registerArgument(0, new RawStringArgument("action", true));
 $this->registerArgument(1, new FloatArgument("prix", true));
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $action = strtolower($args["action"] ?? "");

 if ($action === "sell") {
 $price = isset($args["prix"]) ? (float)$args["prix"] : 0.0;
 if ($price <= 0) { $sender->sendMessage("§cUsage : /hdv sell <prix>"); return; }

 $item = $sender->getInventory()->getItemInHand();
 if ($item->isNull()) { $sender->sendMessage("§cTenez l'item à vendre en main !"); return; }

 $hdv = Manager::HDV();
 $used = $hdv->getUsedSlots($sender->getName());
 $max = $hdv->getSlots($sender->getGradeId());

 if ($used >= $max) {
 $sender->sendMessage("§cSlots HDV pleins §8(§e{$used}§8/§e{$max}§8)§c. Retirez une annonce.");
 return;
 }

 $toSell = clone $item;
 $sender->getInventory()->setItemInHand(VanillaItems::AIR());

 if ($hdv->addListing($sender, $toSell, $price)) {
 $sender->sendMessage("§a✔ §f" . $toSell->getName() . " §amis en vente pour §e" . number_format($price, 2) . "§6\$");
 $sender->sendMessage("§7Slots : §e" . ($used + 1) . "/{$max}");
 } else {
 $sender->sendMessage("§cImpossible de mettre l'item en vente.");
 $sender->getInventory()->addItem($toSell);
 }
 return;
 }

 if ($action === "mine") {
 HdvMenu::openMine($sender);
 return;
 }

 HdvMenu::openBrowse($sender);
 }
}
