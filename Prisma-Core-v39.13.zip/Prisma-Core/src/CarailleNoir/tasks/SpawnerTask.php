<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\managers\Manager;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\Position;
use pocketmine\world\World;

/**
 * Toutes les 30s :
 * - Tous les spawners du MÊME type dans le MÊME monde partagent UNE seule entité.
 * - Si l'entité est vivante → stack += (nb spawners × MOBS_PER_SPAWNER), cap MAX_STACK
 * - Si l'entité est morte → spawn d'une nouvelle entité (stack = 1)
 * - Spawn : 1 bloc au-dessus du spawner, sans vérification de surface (vide OK)
 */
class SpawnerTask extends Task
{
 private const MAX_STACK = 5000;
 private const MOBS_PER_SPAWNER = 3; // mobs ajoutés au stack par spawner par tick

 public function onRun(): void
 {
 $wm = Server::getInstance()->getWorldManager();

 // Grouper les spawners par (type + monde)
 $groups = [];
 foreach (Manager::SPAWNER()->getAllSpawners() as $key => $data) {
 $gk = $data["type"] . "\0" . $data["world"];
 $groups[$gk][$key] = $data;
 }

 foreach ($groups as $gk => $entries) {
 [$type, $worldName] = explode("\0", $gk, 2);

 if (!$wm->isWorldLoaded($worldName)) continue;
 $world = $wm->getWorldByName($worldName);
 if ($world === null) continue;

 // Chercher une entité vivante dans le groupe
 $entity = null;
 foreach ($entries as $data) {
 if ($data["entityId"] === null) continue;
 $candidate = $world->getEntity($data["entityId"]);
 if (($candidate instanceof Zombie
 || $candidate instanceof Skeleton
 || $candidate instanceof Creeper)
 && $candidate->isAlive()
 && !$candidate->isFlaggedForDespawn()
 ) {
 $entity = $candidate;
 break;
 }
 }

 if ($entity !== null) {
 // Entité vivante → incrément par nb de spawners × MOBS_PER_SPAWNER
 if ($entity->stack < self::MAX_STACK) {
 $entity->stack = min(self::MAX_STACK, $entity->stack + count($entries) * self::MOBS_PER_SPAWNER);
 $newMax = 20 * $entity->stack;
 $entity->setMaxHealth($newMax);
 $entity->setHealth($newMax);
 $entity->setNameTag(Manager::SPAWNER()->buildNametag($type, $entity->stack));
 }
 continue;
 }

 // Aucune entité vivante → spawn 1 bloc au-dessus du premier spawner
 $firstKey = array_key_first($entries);
 $parts = explode(":", $firstKey);
 $sx = (int)$parts[0];
 $sy = (int)$parts[1];
 $sz = (int)$parts[2];

 $world->loadChunk($sx >> 4, $sz >> 4);

 // Spawn aléatoire sur les CÔTÉS du spawner (rayon 1–5 blocs)
 // jamais directement au-dessus (dx=0 ET dz=0 interdit)
 do {
 $dx = mt_rand(-5, 5);
 $dz = mt_rand(-5, 5);
 } while ($dx === 0 && $dz === 0);
 $spawnPos = new Vector3($sx + $dx + 0.5, $sy + 1, $sz + $dz + 0.5);
 $loc = Location::fromObject($spawnPos, $world);

 $newEntity = match($type) {
 "skeleton" => new Skeleton($loc, CompoundTag::create()),
 "creeper" => new Creeper($loc, CompoundTag::create()),
 default => new Zombie($loc, CompoundTag::create()),
 };

 $newEntity->setNameTag(Manager::SPAWNER()->buildNametag($type, 1));
 $newEntity->setNameTagAlwaysVisible(true);
 $newEntity->setMaxHealth(20);
 $newEntity->setHealth(20);
 $newEntity->spawnToAll();

 // Enregistrer l'entité pour TOUS les spawners du groupe
 foreach ($entries as $key => $_) {
 $kp = explode(":", $key);
 Manager::SPAWNER()->setEntityId(
 new Position((int)$kp[0], (int)$kp[1], (int)$kp[2], $world),
 $newEntity->getId()
 );
 }
 }
 }
}
