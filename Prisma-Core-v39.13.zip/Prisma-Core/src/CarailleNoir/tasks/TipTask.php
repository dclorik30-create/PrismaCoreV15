<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class TipTask extends Task
{
 private const ARCPUNCH_CD = 5;

 public function onRun(): void
 {
  $now = time();
  foreach (Server::getInstance()->getOnlinePlayers() as $player) {
   if (!$player instanceof PrismaPlayer) continue;
   $name = strtolower($player->getName());

   // Arc-Punch cooldown
   if (isset(PlayerListener::$arcPunchCooldowns[$name])) {
    $remaining = self::ARCPUNCH_CD - ($now - PlayerListener::$arcPunchCooldowns[$name]);
    if ($remaining > 0) {
     $player->sendTip("§6Arc-Punch §8» §c" . $remaining . "s");
    } else {
     unset(PlayerListener::$arcPunchCooldowns[$name]);
     $player->sendTip("§6Arc-Punch §8» §aPret !");
    }
   }
  }
 }
}
