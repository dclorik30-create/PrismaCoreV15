<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ArmorEffectTask extends Task
{
 private const DUR = 2147483647;

 /** Singletons PM5 — stables pendant toute la session */
 private static function managedTypes(): array
 {
 return [
 spl_object_id(VanillaEffects::SPEED()) => VanillaEffects::SPEED(),
 spl_object_id(VanillaEffects::STRENGTH()) => VanillaEffects::STRENGTH(),
 spl_object_id(VanillaEffects::RESISTANCE()) => VanillaEffects::RESISTANCE(),
 spl_object_id(VanillaEffects::HASTE()) => VanillaEffects::HASTE(),
 ];
 }

 public function onRun(): void
 {
 $ce = Manager::CUSTOMENCHANT();

 foreach (Server::getInstance()->getOnlinePlayers() as $player) {
 if (!$player instanceof PrismaPlayer) continue;

 $inv = $player->getArmorInventory();
 $pieces = [
 $inv->getHelmet(),
 $inv->getChestplate(),
 $inv->getLeggings(),
 $inv->getBoots(),
 ];

 // 1. Calculer les effets mérités (meilleur amp par type)
 /** @var EffectInstance[] $toApply */
 $toApply = [];
 foreach ($pieces as $piece) {
 if ($piece->isNull()) continue;
 foreach ($ce->getItemEnchants($piece) as $id => $level) {
 $level = (int)$level;
 if ($level <= 0) continue;
 $amp = max(0, $level - 1);
 // Plafonner Speed / Strength / Resistance à II (amp=1)
 $ampCap = match(strtolower((string)$id)) {
 'speed', 'force', 'resistance' => 1,
 default => PHP_INT_MAX,
 };
 $amp = min($amp, $ampCap);
 $effType = match (strtolower((string)$id)) {
 'speed' => VanillaEffects::SPEED(),
 'force' => VanillaEffects::STRENGTH(),
 'resistance' => VanillaEffects::RESISTANCE(),
 'haste' => VanillaEffects::HASTE(),
 default => null,
 };
 if ($effType === null) continue;
 $key = spl_object_id($effType);
 if (!isset($toApply[$key]) || $amp > $toApply[$key]->getAmplifier()) {
 $toApply[$key] = new EffectInstance($effType, self::DUR, $amp, false, false);
 }
 }
 }

 $effects = $player->getEffects();

 // 2. Retirer TOUS les effets gérés en premier
 // → PM5 ne downgrade pas un effet actif, donc on vide d'abord
 foreach (self::managedTypes() as $effType) {
 $effects->remove($effType);
 }

 // 3. Ré-appliquer uniquement les effets mérités (amplificateur correct garanti)
 foreach ($toApply as $eff) {
 $effects->add($eff);
 }
 }
 }
}
