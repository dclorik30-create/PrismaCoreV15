<?php
declare(strict_types=1);
namespace CarailleNoir\form\level;

use CarailleNoir\managers\type\LevelManager;
use CarailleNoir\managers\type\LevelRewardManager;
use pocketmine\form\Form;
use pocketmine\player\Player;

class ClaimRewardForm implements Form
{
    /** @var int[] niveaux disponibles */
    private array $available;

    public function __construct(
        private LevelManager  $lm,
        private LevelRewardManager $rm,
        private Player        $player
    ) {
        $this->available = $rm->getAvailableRewards($player->getName());
    }

    public function jsonSerialize(): array
    {
        if (empty($this->available)) {
            return [
                "type"    => "form",
                "title"   => "§6§lRécompenses disponibles",
                "content" => "§fAucune récompense à récupérer pour le moment.\n\n§7Montez de niveau pour débloquer des récompenses !",
                "buttons" => [["text" => "§f◄ Retour"]],
            ];
        }

        $buttons = [];
        foreach ($this->available as $lvl) {
            $label = $this->rm->getLabel($lvl);
            $buttons[] = ["text" => "§6Niveau {$lvl}\n§e{$label}"];
        }
        $buttons[] = ["text" => "§f◄ Retour"];

        return [
            "type"    => "form",
            "title"   => "§6§lRécompenses disponibles",
            "content" => "§fSélectionnez une récompense à récupérer :",
            "buttons" => $buttons,
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!is_int($data) && !is_float($data)) return;
        $idx = (int)$data;

        // Dernier bouton = retour
        if ($idx === count($this->available) || empty($this->available)) {
            $player->sendForm(new MainForm($this->lm, $this->rm, $player));
            return;
        }

        if (!isset($this->available[$idx])) return;
        $level  = $this->available[$idx];
        $result = $this->rm->claimReward($player, $level);

        match ($result) {
            "ok"       => null, // message envoyé dans RewardManager
            "already"  => $player->sendMessage("§cVous avez déjà récupéré la récompense du niveau {$level}."),
            "locked"   => $player->sendMessage("§cNiveau {$level} non atteint."),
            "no_reward"=> $player->sendMessage("§cAucune récompense configurée pour le niveau {$level}."),
            default    => null,
        };

        // Ré-ouvrir le form mis à jour
        $player->sendForm(new ClaimRewardForm($this->lm, $this->rm, $player));
    }
}
