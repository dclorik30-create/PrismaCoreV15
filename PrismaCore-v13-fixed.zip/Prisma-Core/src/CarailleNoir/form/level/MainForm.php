<?php
declare(strict_types=1);
namespace CarailleNoir\form\level;

use CarailleNoir\managers\type\LevelManager;
use CarailleNoir\managers\type\LevelRewardManager;
use pocketmine\form\Form;
use pocketmine\player\Player;

class MainForm implements Form
{
    public function __construct(
        private LevelManager  $lm,
        private LevelRewardManager $rm,
        private Player        $player
    ) {}

    public function jsonSerialize(): array
    {
        $name      = $this->player->getName();
        $level     = $this->lm->getLevel($name);
        $available = count($this->rm->getAvailableRewards($name));
        $badge     = $available > 0 ? " §c({$available})" : "";

        return [
            "type"    => "form",
            "title"   => "§6§lSystème de Niveaux",
            "content" => "§fNiveau actuel : §6{$level}§7/100
" . $this->lm->getProgressBar($name),
            "buttons" => [
                ["text" => "§a§lRécompenses disponibles{$badge}"],
                ["text" => "§e§lInformations"],
                ["text" => "§b§lListe des récompenses"],
            ],
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!is_int($data) && !is_float($data)) return;
        match ((int)$data) {
            0 => $player->sendForm(new ClaimRewardForm($this->lm, $this->rm, $player)),
            1 => $player->sendForm(new InfoForm($this->lm, $this->rm, $player)),
            2 => $player->sendForm(new RewardsListForm($this->lm, $this->rm, $player)),
            default => null,
        };
    }
}
