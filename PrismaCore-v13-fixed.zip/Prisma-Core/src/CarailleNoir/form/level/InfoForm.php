<?php
declare(strict_types=1);
namespace CarailleNoir\form\level;

use CarailleNoir\managers\type\LevelManager;
use CarailleNoir\managers\type\LevelRewardManager;
use pocketmine\form\Form;
use pocketmine\player\Player;

class InfoForm implements Form
{
    public function __construct(
        private LevelManager  $lm,
        private LevelRewardManager $rm,
        private Player        $player
    ) {}

    public function jsonSerialize(): array
    {
        $name  = $this->player->getName();
        $level = $this->lm->getLevel($name);
        $exp   = $this->lm->getExp($name);
        $req   = $this->lm->getRequiredExp($level);
        $isMax = $level >= LevelManager::MAX_LEVEL;

        $next = $isMax
            ? "§c§lNIVEAU MAXIMUM ATTEINT !"
            : "§7Prochain niveau dans : §6" . number_format($req - $exp) . " EXP";

        $content = implode("\n", [
            "§fNiveau actuel : §6§l{$level} §f/ §6§l100",
            "§fEXP actuelle :    §a" . number_format($exp),
            "§fEXP requise :    §a" . ($isMax ? "—" : number_format($req)),
            "",
            $this->lm->getProgressBar($name),
            "",
            $next,
            "",
            "§7Minage, récolte et kills vous donnent de l'EXP.",
        ]);

        return [
            "type"    => "form",
            "title"   => "§6§lNiveau {$level} — Informations",
            "content" => $content,
            "buttons" => [["text" => "§f◄ Retour"]],
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        $player->sendForm(new MainForm($this->lm, $this->rm, $player));
    }
}
