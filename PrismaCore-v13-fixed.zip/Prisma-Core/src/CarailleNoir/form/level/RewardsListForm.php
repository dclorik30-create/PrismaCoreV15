<?php
declare(strict_types=1);
namespace CarailleNoir\form\level;

use CarailleNoir\managers\type\LevelManager;
use CarailleNoir\managers\type\LevelRewardManager;
use pocketmine\form\Form;
use pocketmine\player\Player;

/**
 * Affiche la liste de toutes les récompenses en pagination (20 par page).
 */
class RewardsListForm implements Form
{
    private const PER_PAGE = 20;

    public function __construct(
        private LevelManager  $lm,
        private LevelRewardManager $rm,
        private Player        $player,
        private int           $page = 0
    ) {}

    public function jsonSerialize(): array
    {
        $name      = $this->player->getName();
        $playerLvl = $this->lm->getLevel($name);
        $all       = $this->rm->getAllRewards();
        ksort($all);

        $levels    = array_keys($all);
        $total     = count($levels);
        $maxPage   = (int)ceil($total / self::PER_PAGE) - 1;
        $page      = max(0, min($this->page, $maxPage));
        $slice     = array_slice($levels, $page * self::PER_PAGE, self::PER_PAGE);

        $content   = "§fPage §e" . ($page + 1) . "§f/§e" . ($maxPage + 1) . " §7— Votre niveau : §6{$playerLvl}\n\n";

        foreach ($slice as $lvl) {
            $label    = $this->rm->getLabel($lvl);
            $claimed  = $this->player instanceof Player && method_exists($this->lm, 'getPdm')
                      ? false
                      : false; // Sera évalué via RewardManager

            $locked   = $lvl > $playerLvl;
            $claimed  = !$locked && $this->rm->isClaimed($name, $lvl);

            if ($claimed)      $status = "§a✔ Récupérée";
            elseif ($locked)   $status = "§c✖ Verrouillée (niv. {$lvl})";
            else               $status = "§e● Disponible";

            $content .= "§6Niv. §e{$lvl} §7— §f{$label} §7| {$status}\n";
        }

        $buttons = [];
        if ($page > 0)          $buttons[] = ["text" => "§f◄ Précédent"];
        if ($page < $maxPage)   $buttons[] = ["text" => "§fSuivant ►"];
        $buttons[]              = ["text" => "§f◄ Retour au menu"];

        return [
            "type"    => "form",
            "title"   => "§6§lListe des Récompenses",
            "content" => $content,
            "buttons" => $buttons,
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!is_int($data) && !is_float($data)) return;

        $all     = $this->rm->getAllRewards();
        $total   = count($all);
        $maxPage = (int)ceil($total / self::PER_PAGE) - 1;
        $page    = max(0, min($this->page, $maxPage));

        $hasPrev = $page > 0;
        $hasNext = $page < $maxPage;
        $idx     = (int)$data;

        $btnIdx = 0;
        if ($hasPrev) { if ($idx === $btnIdx) { $player->sendForm(new self($this->lm, $this->rm, $player, $page - 1)); return; } $btnIdx++; }
        if ($hasNext) { if ($idx === $btnIdx) { $player->sendForm(new self($this->lm, $this->rm, $player, $page + 1)); return; } $btnIdx++; }

        // Retour
        $player->sendForm(new MainForm($this->lm, $this->rm, $player));
    }
}
