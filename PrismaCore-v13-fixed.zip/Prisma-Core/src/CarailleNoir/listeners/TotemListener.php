<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;
use pocketmine\Server;

class TotemListener implements Listener
{
    public function onBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $totem = Manager::TOTEM();
        if (!$totem->isActive()) return;
        // Vérification sur le bloc cassé, pas sur la position du joueur (sinon reach depuis l'extérieur possible)
        if (!$totem->isInZone($event->getBlock()->getPosition())) return;

        $index = $totem->isTotemBlock($event->getBlock()->getPosition());
        if ($index === -1) return;

        $event->setDrops([]);
        $event->setXpDropAmount(0);

        $tick = Server::getInstance()->getTick();
        if (!$totem->canBreak($player->getName(), $tick)) {
            $event->cancel();
            return;
        }

        $result = $totem->handleBreak($player->getName(), $index);
        if (($result['type'] ?? '') === 'ignore') {
            $event->cancel();
            return;
        }

        if (($result['type'] ?? '') === 'contest') {
            $event->cancel();
            $totem->rebuildAfterContest((string)$result['contester']);
            Manager::FLOATINGTEXT()->updateTotem('contest', null, 0, $totem->getRequired(), null);
            foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                if ($p instanceof PrismaPlayer && $totem->isInZone($p->getPosition())) {
                    $p->sendTip('§cTotem conteste ! Reset...');
                }
            }
            return;
        }

        if (($result['type'] ?? '') === 'progress') {
            $progress = (int)($result['progress'] ?? 0);
            Manager::FLOATINGTEXT()->updateTotem('active', (string)$result['player'], $progress, $totem->getRequired(), null);
            foreach (Server::getInstance()->getOnlinePlayers() as $p) {
                if ($p instanceof PrismaPlayer && $totem->isInZone($p->getPosition())) {
                    $p->sendTip('§6Totem §7- §f' . $progress . '/' . $totem->getRequired() . ' blocs detruits');
                }
            }
            return;
        }

        if (($result['type'] ?? '') === 'win') {
            Manager::FLOATINGTEXT()->updateTotem('ended', (string)$result['player'], $totem->getRequired(), $totem->getRequired(), (string)$result['player']);
            $player->sendTitle('§6§lVICTOIRE', '§fTu remportes le Totem !', 10, 50, 10);
            return;
        }
    }
}
