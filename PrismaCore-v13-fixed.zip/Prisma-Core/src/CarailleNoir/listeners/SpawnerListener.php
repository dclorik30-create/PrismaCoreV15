<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;

class SpawnerListener implements Listener
{
 private function getTypeFromBlock(Block $block): ?string
 {
  $name = preg_replace('/§[0-9a-fk-or]/i', '', $block->getName());
  return match(true) {
   str_contains($name, 'Zombie') => 'zombie',
   str_contains($name, 'Squelette') => 'skeleton',
   str_contains($name, 'Skeleton') => 'skeleton',
   str_contains($name, 'Creeper') => 'creeper',
   default => null,
  };
 }

 public function onPlace(BlockPlaceEvent $event): void
 {
  foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
   $type = $this->getTypeFromBlock($block);
   if ($type === null) $type = Manager::SPAWNER()->getSpawnerTypeFromItem($event->getPlayer()->getInventory()->getItemInHand());
   if ($type === null) continue;
   Manager::SPAWNER()->register($block->getPosition(), $type);
   Manager::SPAWNER()->save(Core::getInstance());
   $event->getPlayer()->sendMessage("§aSpawner §f" . ucfirst($type) . " §aplacé !");
  }
 }

 public function onBreak(BlockBreakEvent $event): void
 {
  $pos = $event->getBlock()->getPosition();
  $block = $event->getBlock();
  if (!Manager::SPAWNER()->isSpawner($pos)) {
   $type = $this->getTypeFromBlock($block);
   if ($type === null) return;
   Manager::SPAWNER()->register($pos, $type);
  }
  $type = Manager::SPAWNER()->getType($pos);
  $event->setDrops([]);
  if ($type !== null) $pos->getWorld()->dropItem($pos->add(0.5, 0.5, 0.5), Manager::SPAWNER()->makeSpawnerItem($type));
  Manager::SPAWNER()->unregister($pos);
  Manager::SPAWNER()->save(Core::getInstance());
 }

 public function onEntityDeath(EntityDeathEvent $event): void
 {
  $entity = $event->getEntity();
  $type = Manager::SPAWNER()->getSpawnerTypeByEntity($entity->getId());
  if ($type === null) return;

  $event->setDrops([]);
  foreach (Manager::SPAWNER()->rollLoots($type, 1) as $loot) {
   $item = StringToItemParser::getInstance()->parse($loot['item']);
   if ($item !== null) {
    $item->setCount($loot['amount']);
    $entity->getWorld()->dropItem($entity->getPosition(), $item);
   }
  }

  $cause = $entity->getLastDamageCause();
  $damager = method_exists($cause ?? new \stdClass, 'getDamager') ? $cause->getDamager() : null;
  if ($damager instanceof PrismaPlayer) {
   Manager::STATS()->addKill($damager->getName());
   $damager->sendMessage("§a+1 kill §8(Spawner §f{$type}§8)");
  }
  Manager::SPAWNER()->onEntityDeath($entity->getId());
 }
}
