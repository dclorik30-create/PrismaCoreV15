<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\Core;
use CarailleNoir\items\SpecialItems;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerItemUseEvent;
use pocketmine\scheduler\ClosureTask;

/**
 * Gère les sticks PVP joueurs.
 *
 * FREEZE : 15s | CD 10s — setNoClientPredictions (séparé du freeze staff)
 * ANTI-PEARL : 30s | CD 15s
 * ANTI-ITEM : 20s | CD 25s
 *
 * - Le hit N'EST PAS cancel : les dégâts passent normalement.
 * - Cooldown affiché en bas (sendTip) au moment du hit.
 * - Clic droit : affiche le cooldown ou "Pret a l'emploi".
 */
class StickListener implements Listener
{
 /** key = "playerName:type" value = timestamp d'expiration du cooldown */
 private array $cooldowns = [];

 // ── Hit ───────────────────────────────────────────────────────────────────

 public function onHit(EntityDamageByEntityEvent $event): void
 {
 $attacker = $event->getDamager();
 $victim = $event->getEntity();
 if (!$attacker instanceof PrismaPlayer || !$victim instanceof PrismaPlayer) return;

 $item = $attacker->getInventory()->getItemInHand();
 $now = time();
 $aKey = strtolower($attacker->getName());

 // Bloquer si l'attaquant est sous Anti-Item et tente d'utiliser un stick
 if (SpecialItems::isAntiItemBlockedItem($item) && Manager::ANTIITEM()->hasEffect($aKey)) {
 // Atout 'antiitem' : seul l'arc-punch reste bloqué (l'arc-punch passe par onHit via snowball, donc on bloque tout de même)
 $hasProtection = Manager::ATOUT()->hasAntiItemProtection($aKey);
 if (!$hasProtection || SpecialItems::isArcPunch($item)) {
 $rem = Manager::ANTIITEM()->getRemaining($aKey);
 $attacker->sendTip("§dAnti-Item actif : §f{$rem}s restants");
 return;
 }
 }

 // ── FREEZE ────────────────────────────────────────────────────────────
 if (SpecialItems::isFreezeStick($item)) {
 $cd = $aKey . ':freeze';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§bFreeze en cooldown : §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 10;
 // setNoClientPredictions SANS freeze() — le isFreeze() reste false
 // donc le check admin-freeze dans onAttack ne bloque pas les dégats
 $victim->setNoClientPredictions(true);
 Manager::STICKFREEZE()->freeze($victim->getName(), 15);
 $victim->sendMessage("§b[Freeze] §fVous etes freeze pendant 15s !");
 $attacker->sendTip("§b[Freeze] §fApplique sur §e" . $victim->getName() . " §f(15s).");
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new ClosureTask(function() use ($victim): void {
 if (!$victim->isConnected()) return;
 Manager::STICKFREEZE()->unfreeze($victim->getName());
 // Relacher seulement si pas aussi freeze par un staff
 if (!$victim->isFreeze()) $victim->setNoClientPredictions(false);
 $victim->sendTip("§aVous n'etes plus freeze !");
 }), 20 * 15
 );
 return;
 }

 // ── ANTI-PEARL ────────────────────────────────────────────────────────
 if (SpecialItems::isAntiPearlStick($item)) {
 $cd = $aKey . ':antipearl';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§cAnti-Pearl en cooldown : §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 15;
 Manager::PEARL()->applyAntiPearl($victim->getName(), 30);
 $victim->sendMessage("§c[Anti-Pearl] §fVous ne pouvez pas utiliser de pearl pendant 30s !");
 $attacker->sendTip("§c[Anti-Pearl] §fApplique sur §e" . $victim->getName() . " §f(30s).");
 return;
 }

 // ── ANTI-ITEM ─────────────────────────────────────────────────────────
 if (SpecialItems::isAntiItemStick($item)) {
 $cd = $aKey . ':antiitem';
 if (isset($this->cooldowns[$cd]) && $now < $this->cooldowns[$cd]) {
 $attacker->sendTip("§dAnti-Item en cooldown : §f" . ($this->cooldowns[$cd] - $now) . "s");
 return;
 }
 $this->cooldowns[$cd] = $now + 25;
 Manager::ANTIITEM()->apply($victim->getName(), 20);
 $victim->sendMessage("§d[Anti-Item] §fVous ne pouvez pas utiliser vos items pendant 20s !");
 $attacker->sendTip("§d[Anti-Item] §fApplique sur §e" . $victim->getName() . " §f(20s).");
 return;
 }
 }

 // ── Clic droit ────────────────────────────────────────────────────────────

 public function onUse(PlayerItemUseEvent $event): void
 {
 $player = $event->getPlayer();
 if (!$player instanceof PrismaPlayer) return;

 $item = $event->getItem();
 $now = time();
 $key = strtolower($player->getName());

 if (SpecialItems::isFreezeStick($item)) {
 $event->cancel();
 $cd = $key . ':freeze';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§bFreeze en cooldown : §f{$rem}s" : "§bFreeze : §aPret a l'emploi");
 return;
 }

 if (SpecialItems::isAntiPearlStick($item)) {
 $event->cancel();
 $cd = $key . ':antipearl';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§cAnti-Pearl en cooldown : §f{$rem}s" : "§cAnti-Pearl : §aPret a l'emploi");
 return;
 }

 if (SpecialItems::isAntiItemStick($item)) {
 $event->cancel();
 $cd = $key . ':antiitem';
 $rem = max(0, ($this->cooldowns[$cd] ?? 0) - $now);
 $player->sendTip($rem > 0 ? "§dAnti-Item en cooldown : §f{$rem}s" : "§dAnti-Item : §aPret a l'emploi");
 return;
 }
 }
}
