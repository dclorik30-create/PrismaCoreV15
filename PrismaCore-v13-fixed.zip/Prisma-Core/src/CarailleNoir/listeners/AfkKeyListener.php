<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;

class AfkKeyListener implements Listener
{
    /** @var array<string, bool> */
    private array $inZone = [];

    public function onMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $from = $event->getFrom();
        $to   = $event->getTo();

        if ((int) floor($from->getX()) === (int) floor($to->getX())
            && (int) floor($from->getY()) === (int) floor($to->getY())
            && (int) floor($from->getZ()) === (int) floor($to->getZ())) {
            return;
        }

        $manager = Manager::AFKKEY();
        $name    = $player->getName();
        $wasIn   = $this->inZone[$name] ?? false;
        $isIn    = $manager->isInZone($to);

        if (!$wasIn && $isIn) {
            if ($manager->enterZone($name)) {
                $this->inZone[$name] = true;
                $player->sendTip("§6[AfkKey] §fZone entree ! Restez §e3 minutes §fsans sortir pour gagner une cle !");
            } else {
                $occupant = $manager->getCapturingPlayer();
                $player->sendTip("§6[AfkKey] §cZone occupee par §e" . $occupant . "§c ! Revenez plus tard.");
            }
        } elseif ($wasIn && !$isIn) {
            unset($this->inZone[$name]);
            $manager->leaveZone($name);
            $player->sendTip("§6[AfkKey] §cVous avez quitte la zone ! Progression remise a zero.");
        }
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        $name = $event->getPlayer()->getName();
        if ($this->inZone[$name] ?? false) {
            unset($this->inZone[$name]);
            Manager::AFKKEY()->leaveZone($name);
        }
    }

    public function onDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        if (!$entity instanceof PrismaPlayer) return;
        if ($event->getFinalDamage() < $entity->getHealth()) return;
        $name = $entity->getName();
        if ($this->inZone[$name] ?? false) {
            unset($this->inZone[$name]);
            Manager::AFKKEY()->leaveZone($name);
        }
    }
}
