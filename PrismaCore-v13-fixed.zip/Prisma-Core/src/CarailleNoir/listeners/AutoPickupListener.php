<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\Listener;

/**
 * Envoie directement les drops dans l'inventaire du joueur.
 * Priorité HIGHEST : s'exécute après tous les autres handlers (OreDropListener, etc.)
 * qui ont pu modifier les drops.
 */
class AutoPickupListener implements Listener
{
    /**
     * @priority HIGHEST
     */
    public function onBlockBreak(BlockBreakEvent $event): void
    {
        if ($event->isCancelled()) return;

        $drops = $event->getDrops();
        if (empty($drops)) return;

        $player    = $event->getPlayer();
        $inventory = $player->getInventory();
        $leftover  = [];

        foreach ($drops as $item) {
            if ($inventory->canAddItem($item)) {
                $inventory->addItem($item);
            } else {
                $leftover[] = $item;
            }
        }

        // Si l'inventaire est plein, les items restants tombent au sol normalement
        $event->setDrops($leftover);
    }
}
