<?php

declare(strict_types=1);

namespace CarailleNoir\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;

class KothListener implements Listener
{
    /** @var array<string, bool> */
    private array $inZone = [];

    public function onMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;

        $from = $event->getFrom();
        $to = $event->getTo();
        if ((int) floor($from->getX()) === (int) floor($to->getX())
            && (int) floor($from->getY()) === (int) floor($to->getY())
            && (int) floor($from->getZ()) === (int) floor($to->getZ())) {
            return;
        }

        $manager = Manager::EVENT();
        if (!$manager->isRunning() || $manager->getType() !== 'koth') {
            return;
        }

        $name = $player->getName();
        $wasIn = $this->inZone[$name] ?? false;
        $isIn = $manager->isInKothZone($to);

        if (!$wasIn && $isIn) {
            $this->inZone[$name] = true;
            $manager->onKothEnter($player);
        } elseif ($wasIn && !$isIn) {
            unset($this->inZone[$name]);
            $manager->onKothLeave($name);
        }
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        $name = $event->getPlayer()->getName();
        if (isset($this->inZone[$name])) {
            unset($this->inZone[$name]);
            Manager::EVENT()->onKothLeave($name);
        }
    }

    public function onDamage(EntityDamageEvent $event): void
    {
        $entity = $event->getEntity();
        if (!$entity instanceof PrismaPlayer) return;
        if ($event->getFinalDamage() < $entity->getHealth()) return;

        $name = $entity->getName();
        if (isset($this->inZone[$name])) {
            unset($this->inZone[$name]);
            Manager::EVENT()->onKothLeave($name);
        }
    }
}
