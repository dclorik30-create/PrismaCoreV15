<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\managers\Manager;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerJoinEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\player\Player;
use pocketmine\utils\Config;

class LevelXpListener implements Listener
{
    /** @var array<string,int> id => xp (minerais vanilla) */
    private array $miningXp  = [];
    /** @var array<string,int> id => xp (farming vanilla) */
    private array $farmingXp = [];
    private int   $killXp    = 30;

    /** XP fixes pour les minerais custom Prisma */
    private const CUSTOM_ORE_XP = [
        DiamondOre::class => 1,
        EmeraldOre::class => 3,
        RubyOre::class    => 5,
        PrismOre::class   => 10,
    ];

    /** XP pour la récolte des graines custom */
    private const SEED_XP = 5;

    /** XP par mob de spawner (multiplié par le stack) */
    private const MOB_XP_PER_STACK = 1;

    public function __construct(string $dataFolder)
    {
        $cfg = new Config($dataFolder . "xp_sources.yml", Config::YAML);
        foreach ((array)$cfg->get("mining", []) as $id => $xp) {
            $this->miningXp[(string)$id] = (int)$xp;
        }
        foreach ((array)$cfg->get("farming", []) as $id => $xp) {
            $this->farmingXp[(string)$id] = (int)$xp;
        }
        $kills = (array)$cfg->get("kills", []);
        $this->killXp = (int)($kills["player"] ?? 30);
    }

    public function onJoin(PlayerJoinEvent $event): void
    {
        Manager::LEVEL()->getLevel($event->getPlayer()->getName());
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        Manager::LEVEL()->save($event->getPlayer()->getName());
    }

    // ── Minage & Récolte ─────────────────────────────────────────────────────

    public function onBlockBreak(BlockBreakEvent $event): void
    {
        $player = $event->getPlayer();
        $block  = $event->getBlock();

        // 1. Minerais custom Prisma (instanceof — 100 % fiable)
        foreach (self::CUSTOM_ORE_XP as $class => $xp) {
            if ($block instanceof $class) {
                Manager::LEVEL()->addExp($player, $xp, "Minage");
                return;
            }
        }

        // 2. Crops custom (Prisme / Rubis) → instanceof fiable
        if ($block instanceof \CarailleNoir\PrismaItems\blocks\RubyCrop ||
            $block instanceof \CarailleNoir\PrismaItems\blocks\PrismCrop) {
            Manager::LEVEL()->addExp($player, self::SEED_XP, "Récolte");
            return;
        }

        // 3. Blocs vanilla (minerais / farming) via Bedrock serializer
        $blockId = $this->getBlockStringId($block);

        if (isset($this->miningXp[$blockId])) {
            Manager::LEVEL()->addExp($player, $this->miningXp[$blockId], "Minage");
            return;
        }

        if (isset($this->farmingXp[$blockId]) && $this->isMatureCrop($block)) {
            Manager::LEVEL()->addExp($player, $this->farmingXp[$blockId], "Récolte");
        }
    }

    // ── Kills ─────────────────────────────────────────────────────────────────

    public function onEntityDamage(EntityDamageByEntityEvent $event): void
    {
        if ($event->isCancelled()) return;

        $victim   = $event->getEntity();
        $attacker = $event->getDamager();

        if (!$attacker instanceof Player) return;

        $isFatal = ($victim->getHealth() - $event->getFinalDamage()) <= 0;
        if (!$isFatal) return;

        // Mobs des spawners — 1 XP × stack
        if ($victim instanceof Zombie || $victim instanceof Skeleton || $victim instanceof Creeper) {
            $xp = max(1, $victim->stack) * self::MOB_XP_PER_STACK;
            Manager::LEVEL()->addExp($attacker, $xp, "Kill");
            return;
        }

        // Kills PvP
        if ($victim instanceof Player && $attacker->getName() !== $victim->getName()) {
            Manager::LEVEL()->addExp($attacker, $this->killXp, "Kill");
        }
    }

    // ── Helpers ──────────────────────────────────────────────────────────────

    private function getBlockStringId(Block $block): string
    {
        try {
            return \pocketmine\world\format\io\GlobalBlockStateHandlers::getSerializer()
                ->serializeBlock($block)
                ->getName();
        } catch (\Throwable) {
            return 'unknown:' . $block->getTypeId();
        }
    }

    private function isMatureCrop(Block $block): bool
    {
        if ($block instanceof \pocketmine\block\Crops) {
            return $block->getAge() >= $block->getMaxAge();
        }
        return true;
    }
}
