<?php
declare(strict_types=1);
namespace CarailleNoir\invmenu;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\libs\muqsit\invmenu\type\InvMenuTypeIds;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\Server;
use pocketmine\utils\TextFormat;

class SanctionMenu
{
 public static function getSanctionMenu(): InvMenu
 {
 $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
 $menu->setName("§cMenu de sanction");
 $players = array_values(Server::getInstance()->getOnlinePlayers());
 $page = 0;
 self::buildPlayerList($menu, $players, $page);

 $menu->setListener(function(InvMenuTransaction $tr) use ($menu, $players, &$page): InvMenuTransactionResult {
 $player = $tr->getPlayer();
 $item = $tr->getItemClicked();
 $name = TextFormat::clean($item->getCustomName());

 if ($name === "Fermer") { $player->removeCurrentWindow(); return $tr->discard(); }
 if ($name === "→ Page suivante") { $page++; self::buildPlayerList($menu, $players, $page); return $tr->discard(); }
 if ($name === "← Page précédente"){ if ($page > 0) { $page--; self::buildPlayerList($menu, $players, $page); } return $tr->discard(); }

 $tag = $item->getNamedTag()->getString("target_name", "");
 if ($tag !== "" && $player instanceof PrismaPlayer) {
 $target = Server::getInstance()->getPlayerExact($tag);
 if ($target instanceof PrismaPlayer) self::openManageMenu($target, $player, $menu);
 else { $player->sendMessage("§c$tag n'est plus en ligne."); $player->removeCurrentWindow(); }
 }
 return $tr->discard();
 });
 return $menu;
 }


 public static function sendTargetPanel(PrismaPlayer $sender, PrismaPlayer $target): void
 {
 $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
 $menu->setName("§cMenu de sanction");
 self::openManageMenu($target, $sender, $menu);
 $menu->send($sender);
 }

 private static function buildPlayerList(InvMenu $menu, array $players, int $page): void
 {
 $inv = $menu->getInventory(); $inv->clearAll();
 $slice = array_slice($players, $page * 45, 45);
 $idx = 0;
 foreach ($slice as $p) {
 if (!$p instanceof PrismaPlayer) continue;
 $head = StringToItemParser::getInstance()->parse("player_head")
 ->setCustomName("§e" . $p->getName());
 $nbt = $head->getNamedTag();
 $nbt->setString("target_name", $p->getName());
 $head->setNamedTag($nbt);
 $inv->setItem($idx++, $head);
 }
 $inv->setItem(45, VanillaItems::ARROW()->setCustomName("§a← Page précédente"));
 $inv->setItem(49, StringToItemParser::getInstance()->parse("barrier")->setCustomName("§cFermer"));
 $inv->setItem(53, VanillaItems::ARROW()->setCustomName("§a→ Page suivante"));
 }

 private static function openManageMenu(PrismaPlayer $target, PrismaPlayer $sender, InvMenu $menu): void
 {
 $inv = $menu->getInventory(); $inv->clearAll();

 $inv->setItem(21, StringToItemParser::getInstance()->parse("ender_pearl")->setCustomName("§bTP " . $target->getName() . " → Moi"));
 $inv->setItem(23, StringToItemParser::getInstance()->parse("ender_pearl")->setCustomName("§aTP Moi → " . $target->getName()));
 $inv->setItem(31, StringToItemParser::getInstance()->parse("packed_ice")->setCustomName("§9Freeze " . $target->getName()));
 $inv->setItem(13, StringToItemParser::getInstance()->parse("nether_star")->setCustomName("§cSanction Menu"));
 $inv->setItem(49, StringToItemParser::getInstance()->parse("barrier")->setCustomName("§4Fermer"));

 $menu->setListener(function(InvMenuTransaction $tr) use ($target, $sender, $menu): InvMenuTransactionResult {
 $player = $tr->getPlayer();
 $name = TextFormat::clean($tr->getItemClicked()->getCustomName());

 if (str_starts_with($name, "TP " . $target->getName())) {
 $target->teleport($sender->getLocation());
 $sender->sendMessage("§a" . $target->getName() . " téléporté à toi !");
 return $tr->discard();
 }
 if (str_starts_with($name, "TP Moi → ")) {
 $sender->teleport($target->getLocation());
 $sender->sendMessage("§aTéléporté à §e" . $target->getName() . " !");
 return $tr->discard();
 }
 if (str_starts_with($name, "Freeze ")) {
 if (method_exists($target, "freeze")) $target->freeze(!$target->isFreeze());
 $sender->sendMessage("§9Freeze toggleé pour §e" . $target->getName());
 $player->removeCurrentWindow();
 return $tr->discard();
 }
 if ($name === "Sanction Menu") {
 self::openSanctionPanel($target, $sender, $menu);
 return $tr->discard();
 }
 if ($name === "Fermer") {
 $player->removeCurrentWindow();
 return $tr->discard();
 }
 return $tr->discard();
 });
 }

 private static function openSanctionPanel(PrismaPlayer $target, PrismaPlayer $sender, InvMenu $menu): void
 {
 $inv = $menu->getInventory(); $inv->clearAll();

 $sanctions = [
 [0, "§cAvertissement", "red_banner", "warn"],
 [1, "§6Kick", "orange_banner", "kick"],
 [2, "§bMute", "light_blue_banner", "mute"],
 [3, "§bUnmute", "cyan_banner", "unmute"],
 [4, "§6TIG", "yellow_banner", "tig"],
 [5, "§aUn-TIG", "lime_banner", "untig"],
 ];

 foreach ($sanctions as [$slot, $label, $mat, $action]) {
 $sub1 = "";
 if ($action === "unmute") $sub1 = Manager::MUTE()->isMuted($target->getName()) ? "§a✔ Actuellement mute" : "§7Non mute";
 if ($action === "untig") $sub1 = Manager::TIG()->isTIG($target->getName()) ? "§a✔ En TIG" : "§7Pas en TIG";
 $d = Manager::WARN()->getWarnData($target->getName());
 $lore = ["§7" . $target->getName(), "§fWarn: §c{$d['warn']} §7| Mute: §b{$d['mute']} §7| Kick: §e{$d['kick']}", $sub1];
 $item = StringToItemParser::getInstance()->parse($mat)
 ->setCustomName($label)
 ->setLore(array_values(array_filter($lore)));
 $nbtTag = $item->getNamedTag();
 $nbtTag->setString("sanction_action", $action);
 $item->setNamedTag($nbtTag);
 $inv->setItem($slot, $item);
 }
 $inv->setItem(49, StringToItemParser::getInstance()->parse("barrier")->setCustomName("§cFermer"));

 $menu->setListener(function(InvMenuTransaction $tr) use ($sender, $target): InvMenuTransactionResult {
 $item = $tr->getItemClicked();
 $player = $tr->getPlayer();
 if (TextFormat::clean($item->getCustomName()) === "Fermer") {
 $player->removeCurrentWindow();
 return $tr->discard();
 }
 $action = $item->getNamedTag()->getString("sanction_action", "");
 if ($action !== "") {
 $player->removeCurrentWindow();
 Manager::SANCTION()->releaseAction($action, $target->getName(), $sender->getName());
 }
 return $tr->discard();
 });
 }
}
