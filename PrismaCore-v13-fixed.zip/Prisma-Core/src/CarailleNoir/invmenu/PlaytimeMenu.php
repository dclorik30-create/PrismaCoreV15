<?php
declare(strict_types=1);
namespace CarailleNoir\invmenu;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\libs\muqsit\invmenu\type\InvMenuTypeIds;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\PlaytimeManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\utils\TextFormat;

class PlaytimeMenu
{
    public static function send(PrismaPlayer $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName('§6Playtime');
        self::build($menu, $player);
        $menu->setListener(function(InvMenuTransaction $tr) use ($menu): InvMenuTransactionResult {
            $player = $tr->getPlayer();
            if (!$player instanceof PrismaPlayer) return $tr->discard();
            $slot = $tr->getAction()->getSlot();

            if ($slot === 49) { $player->removeCurrentWindow(); return $tr->discard(); }

            // Slots 0-44 = milestones
            $milestones = Manager::PLAYTIME()->getMilestones();
            $sorted = array_keys($milestones);
            if (isset($sorted[$slot])) {
                $minutes = $sorted[$slot];
                if (!Manager::PLAYTIME()->canClaim($player->getName(), $minutes)) return $tr->discard();
                $reward = Manager::PLAYTIME()->claim($player->getName(), $minutes);
                if ($reward !== null) {
                    if ($player->getInventory()->canAddItem($reward)) $player->getInventory()->addItem($reward);
                    else $player->getWorld()->dropItem($player->getPosition(), $reward);
                    $player->sendMessage('§aRécompense playtime récupérée §8(§7' . $minutes . ' min§8)');
                }
                self::build($menu, $player);
            }
            return $tr->discard();
        });
        $menu->send($player);
    }

    private static function build(InvMenu $menu, PrismaPlayer $player): void
    {
        $inv = $menu->getInventory();
        $inv->clearAll();

        $pm         = Manager::PLAYTIME();
        $milestones = $pm->getMilestones();
        $totalSec   = $pm->getTotalSeconds($player->getName());
        $dailySec   = $pm->getDailySeconds($player->getName());

        // Slot 45-48 : infos
        $infoTotal = StringToItemParser::getInstance()->parse('clock') ?? VanillaItems::PAPER();
        $infoTotal->setCustomName('§6Temps total');
        $infoTotal->setLore(['§7Temps joué : §f' . PlaytimeManager::formatSeconds($totalSec)]);
        $inv->setItem(45, $infoTotal);

        $infoDaily = StringToItemParser::getInstance()->parse('compass') ?? VanillaItems::PAPER();
        $infoDaily->setCustomName('§bTemps aujourd\'hui');
        $infoDaily->setLore(['§7Temps joué aujourd\'hui : §f' . PlaytimeManager::formatSeconds($dailySec)]);
        $inv->setItem(46, $infoDaily);

        $inv->setItem(47, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(48, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(49, StringToItemParser::getInstance()->parse('barrier')->setCustomName('§cFermer'));
        $inv->setItem(50, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(51, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(52, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(53, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());

        // Slots 0-44 : milestones
        $i = 0;
        foreach ($milestones as $minutes => $reward) {
            if ($i >= 45) break;
            $claimed  = $pm->hasClaimed($player->getName(), $minutes);
            $canClaim = $pm->canClaim($player->getName(), $minutes);
            $item = match(true) {
                $claimed  => StringToItemParser::getInstance()->parse('lime_stained_glass_pane')   ?? VanillaItems::PAPER(),
                $canClaim => StringToItemParser::getInstance()->parse('orange_stained_glass_pane') ?? VanillaItems::PAPER(),
                default   => StringToItemParser::getInstance()->parse('red_stained_glass_pane')    ?? VanillaItems::PAPER(),
            };
            $rewardName = ($reward !== null) ? (TextFormat::clean($reward->getCustomName()) !== '' ? TextFormat::clean($reward->getCustomName()) : $reward->getName()) : '§cNon définie';
            $lore = [
                '§7Palier : §f' . PlaytimeManager::formatSeconds($minutes * 60),
                '§7Récompense : §f' . $rewardName . ($reward !== null ? ' §7x' . $reward->getCount() : ''),
            ];
            if ($claimed)        $lore[] = '§aDéjà réclamé';
            elseif ($canClaim)   $lore[] = '§aClique pour réclamer !';
            else                 $lore[] = '§7Progrès : §f' . PlaytimeManager::formatSeconds($totalSec) . '§7/§f' . PlaytimeManager::formatSeconds($minutes * 60);
            $item->setCustomName('§6' . PlaytimeManager::formatSeconds($minutes * 60));
            $item->setLore($lore);
            $inv->setItem($i++, $item);
        }
    }
}
