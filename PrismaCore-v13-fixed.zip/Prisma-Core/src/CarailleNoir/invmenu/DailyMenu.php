<?php
declare(strict_types=1);
namespace CarailleNoir\invmenu;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\libs\muqsit\invmenu\type\InvMenuTypeIds;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\utils\TextFormat;

class DailyMenu
{
    public static function send(PrismaPlayer $player): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName('§6Daily');
        self::build($menu, $player);
        $menu->setListener(function(InvMenuTransaction $tr) use ($menu): InvMenuTransactionResult {
            $player = $tr->getPlayer();
            if (!$player instanceof PrismaPlayer) return $tr->discard();
            $slot = $tr->getAction()->getSlot();
            if ($slot === 49) {
                $player->removeCurrentWindow();
                return $tr->discard();
            }
            if ($slot < 0 || $slot >= 45) return $tr->discard();

            $day = $slot + 1;
            if (!Manager::DAILY()->canClaimDay($player->getName(), $day)) return $tr->discard();
            $reward = Manager::DAILY()->claim($player->getName());
            if ($reward !== null) {
                if ($player->getInventory()->canAddItem($reward)) {
                    $player->getInventory()->addItem($reward);
                } else {
                    $player->getWorld()->dropItem($player->getPosition(), $reward);
                }
                $player->sendMessage('§aRécompense daily récupérée : Jour ' . $day);
            }
            self::build($menu, $player);
            return $tr->discard();
        });
        $menu->send($player);
    }

    private static function build(InvMenu $menu, PrismaPlayer $player): void
    {
        $inv = $menu->getInventory();
        $inv->clearAll();
        for ($i = 1; $i <= 45; $i++) {
            $reward = Manager::DAILY()->getReward($i);
            $item = match(true) {
                Manager::DAILY()->hasClaimedDay($player->getName(), $i) => StringToItemParser::getInstance()->parse('lime_stained_glass_pane') ?? VanillaItems::PAPER(),
                Manager::DAILY()->canClaimDay($player->getName(), $i) => StringToItemParser::getInstance()->parse('orange_stained_glass_pane') ?? VanillaItems::PAPER(),
                default => StringToItemParser::getInstance()->parse('red_stained_glass_pane') ?? VanillaItems::PAPER(),
            };
            $lore = [];
            if ($reward !== null) {
                $rewardName = TextFormat::clean($reward->getCustomName()) !== '' ? TextFormat::clean($reward->getCustomName()) : $reward->getName();
                $lore[] = '§7Récompense : §f' . $rewardName . ' §7x' . $reward->getCount();
            } else {
                $lore[] = '§7Récompense : §cNon définie';
            }
            if (Manager::DAILY()->canClaimDay($player->getName(), $i)) {
                $lore[] = '§aClique pour réclamer';
            } elseif (Manager::DAILY()->hasClaimedDay($player->getName(), $i)) {
                $lore[] = '§aDéjà réclamé';
            } else {
                $lore[] = '§cPas encore disponible';
            }
            $item->setCustomName('§6Jour ' . $i);
            $item->setLore($lore);
            $inv->setItem($i - 1, $item);
        }

        $inv->setItem(45, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(46, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(47, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(48, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(49, StringToItemParser::getInstance()->parse('barrier')->setCustomName('§cFermer'));
        $inv->setItem(50, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(51, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(52, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
        $inv->setItem(53, StringToItemParser::getInstance()->parse('gray_stained_glass_pane') ?? VanillaItems::PAPER());
    }
}
