<?php
declare(strict_types=1);
namespace CarailleNoir\invmenu;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\type\InvMenuType;
use CarailleNoir\libs\muqsit\invmenu\type\util\InvMenuTypeBuilders;
use CarailleNoir\libs\muqsit\invmenu\type\graphic\InvMenuGraphic;
use pocketmine\block\inventory\CraftingTableInventory;
use pocketmine\block\VanillaBlocks;
use pocketmine\inventory\Inventory;
use pocketmine\math\Vector3;
use pocketmine\network\mcpe\protocol\types\inventory\WindowTypes;
use pocketmine\player\Player;
use pocketmine\world\Position;

final class CraftingTableInvMenuType implements InvMenuType
{
 public const TYPE_ID = "prismacore:workbench";

 private InvMenuType $inner;

 public function __construct()
 {
 $this->inner = InvMenuTypeBuilders::BLOCK_FIXED()
 ->setBlock(VanillaBlocks::CRAFTING_TABLE())
 ->setSize(9)
 ->setNetworkWindowType(WindowTypes::WORKBENCH)
 ->build();
 }

 public function createGraphic(InvMenu $menu, Player $player): ?InvMenuGraphic
 {
 return $this->inner->createGraphic($menu, $player);
 }

 public function createInventory(): Inventory
 {
 return new CraftingTableInventory(Position::fromObject(Vector3::zero(), null));
 }
}
