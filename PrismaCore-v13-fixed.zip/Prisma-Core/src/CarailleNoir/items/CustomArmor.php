<?php

namespace CarailleNoir\items;

use CarailleNoir\player\PrismaPlayer;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\inventory\ArmorInventory;
use pocketmine\item\Armor;
use pocketmine\item\enchantment\EnchantmentInstance;
use pocketmine\item\enchantment\VanillaEnchantments;
use pocketmine\item\Item;
use pocketmine\item\ItemTypeIds;
use pocketmine\item\VanillaItems;

class CustomArmor
{
 // Tier 0 : armure de base diamant (aucun effet)
 // Tier 1 : armure 1 (aucun effet mais meilleure prot)
 // Tier 2 : armure 2 (Speed 1)
 // Tier 3 : armure 3 (Speed 2, Force 1, Resis 1, Haste 2)

 public static function make(int $tier): array
 {
 $sets = [
 0 => [
 "helmet" => VanillaItems::DIAMOND_HELMET(),
 "chestplate" => VanillaItems::DIAMOND_CHESTPLATE(),
 "leggings" => VanillaItems::DIAMOND_LEGGINGS(),
 "boots" => VanillaItems::DIAMOND_BOOTS(),
 "color" => "§b",
 "name" => "Diamant"
 ],
 1 => [
 "helmet" => VanillaItems::DIAMOND_HELMET(),
 "chestplate" => VanillaItems::DIAMOND_CHESTPLATE(),
 "leggings" => VanillaItems::DIAMOND_LEGGINGS(),
 "boots" => VanillaItems::DIAMOND_BOOTS(),
 "color" => "§7",
 "name" => "Armure I"
 ],
 2 => [
 "helmet" => VanillaItems::DIAMOND_HELMET(),
 "chestplate" => VanillaItems::DIAMOND_CHESTPLATE(),
 "leggings" => VanillaItems::DIAMOND_LEGGINGS(),
 "boots" => VanillaItems::DIAMOND_BOOTS(),
 "color" => "§a",
 "name" => "Armure II"
 ],
 3 => [
 "helmet" => VanillaItems::DIAMOND_HELMET(),
 "chestplate" => VanillaItems::DIAMOND_CHESTPLATE(),
 "leggings" => VanillaItems::DIAMOND_LEGGINGS(),
 "boots" => VanillaItems::DIAMOND_BOOTS(),
 "color" => "§6",
 "name" => "Armure III"
 ]
 ];

 if (!isset($sets[$tier])) return [];
 $set = $sets[$tier];
 $pieces = [];

 $pieceDefs = [
 ["key" => "helmet", "slot" => "§7Casque"],
 ["key" => "chestplate", "slot" => "§7Plastron"],
 ["key" => "leggings", "slot" => "§7Jambières"],
 ["key" => "boots", "slot" => "§7Bottes"]
 ];

 foreach ($pieceDefs as $def) {
 /** @var Armor $item */
 $item = clone $set[$def["key"]];
 $item->setCustomName($set["color"] . $set["name"] . " " . $def["slot"]);

 $prot = 2 + $tier;
 $item->addEnchantment(new EnchantmentInstance(VanillaEnchantments::PROTECTION(), $prot));
 if ($tier >= 3) {
 $item->addEnchantment(new EnchantmentInstance(VanillaEnchantments::UNBREAKING(), 3));
 }

 $lore = ["§8tier:$tier", "§7" . $set["name"]];
 if ($tier === 0) $lore[] = "§fAucun effet";
 if ($tier === 1) $lore[] = "§fAucun effet";
 if ($tier === 2) $lore[] = "§aSpeed I";
 if ($tier === 3) $lore[] = "§aSpeed II §c| §cForce I §7| §bRésistance I §e| §eHâte II";
 $item->setLore($lore);
 $pieces[] = $item;
 }

 return $pieces;
 }

 public static function detectArmorTier(ArmorInventory $inv): int
 {
 $helmet = $inv->getHelmet();
 foreach ($helmet->getLore() as $line) {
 if (preg_match('/§8tier:(\d)/', $line, $m)) {
 return (int)$m[1];
 }
 }
 return -1;
 }

 public static function applyEffectsForTier(PrismaPlayer $player, int $tier): void
 {
 $effects = match ($tier) {
 2 => [
 new EffectInstance(VanillaEffects::SPEED(), 40, 0, false, false)
 ],
 3 => [
 new EffectInstance(VanillaEffects::SPEED(), 40, 1, false, false),
 new EffectInstance(VanillaEffects::STRENGTH(), 40, 0, false, false),
 new EffectInstance(VanillaEffects::RESISTANCE(), 40, 0, false, false),
 new EffectInstance(VanillaEffects::HASTE(), 40, 1, false, false)
 ],
 default => []
 };

 foreach ($effects as $effect) {
 $player->getEffects()->add($effect);
 }
 }
}
