<?php
declare(strict_types=1);

namespace CarailleNoir\items;

use pocketmine\block\Block;
use pocketmine\block\BlockTypeIds;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;

final class PickaxeOfGodManager
{
    public static function isPog(Item $item): bool
    {
        foreach ($item->getLore() as $line) {
            if (preg_match('/^§8ID:item_pog_(\d+)$/', $line)) {
                return true;
            }
        }
        return false;
    }

    public static function getLevel(Item $item): int
    {
        foreach ($item->getLore() as $line) {
            if (preg_match('/^§8ID:item_pog_(\d+)$/', $line, $m)) {
                return (int) $m[1];
            }
        }
        return 0;
    }

    public static function getRequiredForLevel(int $level): int
    {
        return $level * 2000;
    }

    public static function getBlocksMined(Item $item): int
    {
        foreach ($item->getLore() as $line) {
            if (preg_match('/^(\d+) Blocks \/ (\d+)$/', self::strip($line), $m)) {
                return (int) $m[1];
            }
        }
        return 0;
    }

    public static function updateProgress(Item $item, int $blocks): Item
    {
        $level = self::getLevel($item);
        if ($level < 1) {
            return $item;
        }
        $required = self::getRequiredForLevel($level);
        $display = min($blocks, $required);
        $lore = $item->getLore();
        foreach ($lore as $i => $line) {
            if (str_contains(self::strip($line), 'Blocks /')) {
                $lore[$i] = '§e' . $display . ' Blocks / ' . $required;
            }
        }
        $item->setLore($lore);
        return $item;
    }

    public static function makeLevel(int $level, int $blocks = 0): ?Item
    {
        $item = StringToItemParser::getInstance()->parse('prisma:pickaxeofgod' . $level);
        if ($item === null || $item->isNull()) {
            return null;
        }
        return self::updateProgress($item, $blocks);
    }

    public static function canInstantBreak(Block $block, int $level): bool
    {
        if ($level < 10) {
            return false;
        }
        return !in_array($block->getTypeId(), [
            BlockTypeIds::BEDROCK,
            BlockTypeIds::END_PORTAL_FRAME,
            BlockTypeIds::NETHER_PORTAL,
            BlockTypeIds::WATER,
            BlockTypeIds::LAVA,
        ], true);
    }

    private static function strip(string $text): string
    {
        return preg_replace('/§./', '', $text) ?? $text;
    }
}
