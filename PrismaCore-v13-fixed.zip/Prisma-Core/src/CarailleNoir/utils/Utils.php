<?php

namespace CarailleNoir\utils;

use CarailleNoir\Core;
use pocketmine\math\AxisAlignedBB;
use pocketmine\player\Player;
use pocketmine\utils\Config;
use pocketmine\utils\TextFormat;
use pocketmine\world\Position;

class Utils
{
 public static function parseColor(string $color): string
 {
 if (str_starts_with($color, "§")) {
 return $color;
 }

 if (preg_match("/^#([A-Fa-f0-9]{6})$/", $color, $matches)) {
 $hex = strtolower($matches[1]);
 $out = "§x";
 foreach (str_split($hex) as $c) {
 $out .= "§" . $c;
 }
 return $out;
 }

 return TextFormat::WHITE;
 }

 public static function getZone(Position $pos1, Position $pos2): AxisAlignedBB
 {

 return new AxisAlignedBB(
 min($pos1->x, $pos2->x),
 min($pos1->y, $pos2->y),
 min($pos1->z, $pos2->z),
 max($pos1->x, $pos2->x),
 max($pos1->y, $pos2->y),
 max($pos1->z, $pos2->z)
 );
 }

 public static function CustomPermission(string $perm): string {
 return "prisma.command." . $perm;
 }
}