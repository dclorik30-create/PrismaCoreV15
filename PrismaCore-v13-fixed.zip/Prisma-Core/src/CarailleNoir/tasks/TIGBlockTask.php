<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class TIGBlockTask extends Task
{
 public function onRun(): void
 {
 Manager::TIGBLOCK()->tick();
 }
}
