<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\managers\Manager;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\scheduler\Task;
use pocketmine\Server;
use pocketmine\world\Position;

class SpawnerTask extends Task
{
    private const MAX_STACK = 20000;
    private const MOBS_PER_SPAWNER = 3;
    /** @var array<string, bool> */
    private array $processed = [];

    public function onRun(): void
    {
        $this->processed = [];
        $wm = Server::getInstance()->getWorldManager();

        foreach (Manager::SPAWNER()->getAllSpawners() as $key => $data) {
            $worldName = $data['world'];
            if (!$wm->isWorldLoaded($worldName)) continue;
            $world = $wm->getWorldByName($worldName);
            if ($world === null) continue;

            $pos = new Position((int)$data['x'], (int)$data['y'], (int)$data['z'], $world);
            if (!$world->isChunkLoaded($pos->getFloorX() >> 4, $pos->getFloorZ() >> 4)) continue;

            $type = $data['type'];
            $cluster = Manager::SPAWNER()->getSpawnersNear($type, $world, $pos, 12.0);
            if ($cluster === []) continue;

            $clusterKeys = array_keys($cluster);
            sort($clusterKeys);
            $clusterId = md5($type . '|' . $worldName . '|' . implode('|', $clusterKeys));
            if (isset($this->processed[$clusterId])) continue;
            $this->processed[$clusterId] = true;

            $spawnAmount = max(1, count($cluster) * self::MOBS_PER_SPAWNER);
            $entity = Manager::SPAWNER()->findStackableEntity($world, $type, $pos, 12.0);

            if ($entity !== null) {
                $entity->stack = min(self::MAX_STACK, $entity->stack + $spawnAmount);
                $newMax = max(20, 20 * $entity->stack);
                $entity->setMaxHealth($newMax);
                $entity->setHealth($newMax);
                $entity->setNameTag(Manager::SPAWNER()->buildNametag($type, $entity->stack));
                Manager::SPAWNER()->markEntityType($entity, $type);
                continue;
            }

            do { $dx = mt_rand(-3, 3); $dz = mt_rand(-3, 3); } while ($dx === 0 && $dz === 0);
            $loc = Location::fromObject(new Vector3($pos->getX() + $dx + 0.5, $pos->getY() + 1, $pos->getZ() + $dz + 0.5), $world);

            $newEntity = match($type) {
                'skeleton' => new Skeleton($loc, CompoundTag::create()),
                'creeper'  => new Creeper($loc, CompoundTag::create()),
                default    => new Zombie($loc, CompoundTag::create()),
            };

            $newEntity->stack = min(self::MAX_STACK, $spawnAmount);
            $newEntity->setNameTag(Manager::SPAWNER()->buildNametag($type, $newEntity->stack));
            $newEntity->setNameTagAlwaysVisible(true);
            $newEntity->setMaxHealth(max(20, 20 * $newEntity->stack));
            $newEntity->setHealth(max(20, 20 * $newEntity->stack));
            $newEntity->spawnToAll();
            Manager::SPAWNER()->markEntityType($newEntity, $type);
        }
    }
}
