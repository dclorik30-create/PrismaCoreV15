<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class TotemTask extends Task
{
    private string $lastHash = '';
    private string $lastDailyKey = '';

    public function onRun(): void
    {
        $event = Manager::EVENT();
        $totem = Manager::TOTEM();

        $dailyKey = date('Y-m-d');
        if ($this->lastDailyKey !== $dailyKey && (int)date('G') === 20 && (int)date('i') === 0) {
            $this->lastDailyKey = $dailyKey;
            if (!$event->isEventActive()) {
                $event->startEvent('totem');
            }
        }

        $totem->tick();

        if (!$totem->isActive()) {
            $this->updateFloating('idle', null, 0, $totem->getRequired(), $totem->getLastWinner());
            return;
        }

        $this->updateFloating('active', $totem->getBreaker(), $totem->getProgress(), $totem->getRequired(), null);
    }

    private function updateFloating(string $state, ?string $player, int $progress, int $required, ?string $winner): void
    {
        $hash = $state . '|' . ($player ?? '-') . '|' . $progress . '|' . ($winner ?? '-');
        if ($hash === $this->lastHash) return;
        $this->lastHash = $hash;
        Manager::FLOATINGTEXT()->updateTotem($state, $player, $progress, $required, $winner);
    }
}
