<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class FlyTask extends Task
{
    /** @var array<string, int|null> playerName (lowercase) => remaining seconds (null = unlimited) */
    private static array $sessions = [];

    public static function startFly(string $player, ?int $seconds): void
    {
        self::$sessions[strtolower($player)] = $seconds;
    }

    public static function stopFly(string $player): void
    {
        unset(self::$sessions[strtolower($player)]);
    }

    public static function isFlying(string $player): bool
    {
        return isset(self::$sessions[strtolower($player)]);
    }

    public static function getRemaining(string $player): ?int
    {
        return self::$sessions[strtolower($player)] ?? null;
    }

    public static function getAll(): array
    {
        return self::$sessions;
    }

    public function onRun(): void
    {
        foreach (array_keys(self::$sessions) as $key) {
            $player = Server::getInstance()->getPlayerByPrefix($key);
            if (!$player instanceof PrismaPlayer || !$player->isOnline()) {
                unset(self::$sessions[$key]);
                continue;
            }

            $world = $player->getWorld()->getFolderName();
            if (strpos($world, 'island_') !== 0) {
                self::stopFly($player->getName());
                $player->setAllowFlight(false);
                $player->setFlying(false);
                $player->sendMessage('§c[Prisma] Vous ne pouvez pas fly en dehors des islands.');
                continue;
            }

            if (self::$sessions[$key] === null) {
                continue;
            }

            self::$sessions[$key]--;
            $remaining = self::$sessions[$key];

            if (in_array($remaining, [300, 120, 60, 30, 10], true)) {
                $player->sendMessage('§e[Fly] §fIl vous reste §e' . self::formatSeconds($remaining) . '§f de fly.');
            }

            if ($remaining <= 0) {
                self::stopFly($player->getName());
                $player->setAllowFlight(false);
                $player->setFlying(false);
                $player->sendMessage('§c[Fly] Votre temps de fly est épuisé.');
            }
        }
    }

    public static function formatSeconds(int $s): string
    {
        if ($s < 60) return $s . 's';
        $m = intdiv($s, 60);
        $sec = $s % 60;
        return $sec > 0 ? "{$m}min{$sec}s" : "{$m}min";
    }
}
