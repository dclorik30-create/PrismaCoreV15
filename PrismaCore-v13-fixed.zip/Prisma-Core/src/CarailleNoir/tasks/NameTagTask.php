<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

/**
 * Met a jour le nametag au-dessus de la tete de chaque joueur.
 * Format : §8[{gradeColor}{abbrev}§8] §f{pseudo} §8[§e{faction}§8]
 *
 * Abreviations de grades :
 *   joueur → J  |  noble → N  |  heros → H  |  dieu → D  |  vote → V
 *   Fallback : premiere lettre uppercase du gradeId
 */
class NameTagTask extends Task
{
    private const ABBREV = [
        "joueur" => "J",
        "noble"  => "N",
        "heros"  => "H",
        "dieu"   => "D",
        "vote"   => "V",
    ];

    public function onRun(): void
    {
        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if (!$player instanceof PrismaPlayer) continue;
            $player->setNameTag(self::buildTag($player));
            $player->setNameTagAlwaysVisible(true);
        }
    }

    public static function buildTag(PrismaPlayer $player): string
    {
        $gradeId    = $player->getGradeId();
        $gradeColor = $player->getGradeColor();
        $abbrev     = self::ABBREV[$gradeId] ?? strtoupper(substr($gradeId, 0, 1));

        $faction    = $player->getFaction();
        $facPart    = $faction !== null
            ? " §8[§e" . $faction->getName() . "§8]"
            : "";

        $level   = Manager::LEVEL()->getLevel($player->getName());
        $lvlPart = "§8[§7" . $level . "§8]";
        return $lvlPart . "§8[" . $gradeColor . $abbrev . "§8] §f" . $player->getVisualName() . $facPart;
    }
}
