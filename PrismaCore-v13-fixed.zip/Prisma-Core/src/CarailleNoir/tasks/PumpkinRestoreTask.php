<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class PumpkinRestoreTask extends Task
{
 public function __construct(
 private readonly string $victimName,
 private readonly ?Item $originalHelmet,
 private readonly PlayerListener $listener
 ) {}

 public function onRun(): void
 {
 $this->listener->clearSavedHelmet($this->victimName);
 $player = Server::getInstance()->getPlayerExact($this->victimName);
 if (!$player instanceof PrismaPlayer || !$player->isConnected()) return;
 if ($this->originalHelmet !== null && !$this->originalHelmet->isNull()) {
 $player->getArmorInventory()->setHelmet($this->originalHelmet);
 } else {
 $player->getArmorInventory()->setHelmet(VanillaItems::AIR());
 }
 $player->sendTip("§6Citrouille §7dissipée — casque restauré !");
 }
}
