<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class OutpostTask extends Task
{
    private string $lastHash = '';

    public function onRun(): void
    {
        $outpost = Manager::OUTPOST();
        $outpost->tick();

        $hash = implode('|', [
            $outpost->getState(),
            (string)$outpost->getCapturingFaction(),
            (string)$outpost->getCapturedFaction(),
            (string)$outpost->getDecapturingFaction(),
            (string)(int)$outpost->getCaptureProgress(),
            (string)(int)$outpost->getDecaptureProgress(),
            (string)$outpost->getRewardTimer(),
        ]);

        if ($hash === $this->lastHash) return;
        $this->lastHash = $hash;

        Manager::FLOATINGTEXT()->updateOutpost(
            $outpost->getState(),
            $outpost->getCapturingFaction(),
            $outpost->getCapturedFaction(),
            $outpost->getDecapturingFaction(),
            $outpost->getCaptureProgress(),
            $outpost->getDecaptureProgress(),
            $outpost->getRewardTimer()
        );
    }
}
