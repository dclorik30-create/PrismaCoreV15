<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

/**
 * Rafraichit les panneaux Top et Vote toutes les 5 minutes.
 */
class FloatingTextTask extends Task
{
 public function onRun(): void
 {
 Manager::FLOATINGTEXT()->refreshTops();
 }
}
