<?php

declare(strict_types=1);

namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\EventManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class EventTickTask extends Task
{
    private string $lastKothHash = '';

    public function onRun(): void
    {
        $event = Manager::EVENT();

        // Auto-start KOTH toutes les 3h si aucun event en cours
        if (!$event->isEventActive() && $event->canStartKothNow()) {
            $event->startEvent(EventManager::TYPE_KOTH);
        }

        if (!$event->isEventActive()) {
            $this->updateKothFloating('idle', null, null, 0, 60);
            return;
        }

        if ($event->getActiveEvent() !== EventManager::TYPE_KOTH) {
            return;
        }

        // Expiration 30 minutes sans victoire
        $expireAt = $event->getKothExpireAt();
        if ($expireAt > 0 && time() >= $expireAt) {
            $event->stopEvent();
            Server::getInstance()->broadcastMessage('§c[KOTH] §fPersonne n\'a capturé le KOTH. L\'event expire.');
            $this->updateKothFloating('idle', null, null, 0, 60);
            $this->lastKothHash = '';
            return;
        }

        $captorName = $event->getKothCapturingPlayer();
        $progress   = $event->getCaptureProgress();
        $required   = $event->getCaptureRequired();

        if ($captorName === null) {
            $this->updateKothFloating('waiting', null, null, 0, $required);
            return;
        }

        $player = Server::getInstance()->getPlayerExact($captorName);
        if (!$player instanceof PrismaPlayer || !$event->isInKothZone($player->getPosition())) {
            $event->onKothLeave($captorName);
            $this->updateKothFloating('waiting', null, null, 0, $required);
            return;
        }

        if ($event->tickCapture($captorName)) {
            $this->updateKothFloating('ended', null, $captorName, $required, $required);
            $event->onEventWon($captorName);
            $this->lastKothHash = '';
            return;
        }

        $progress = $event->getCaptureProgress();
        $this->updateKothFloating('capturing', $captorName, null, $progress, $required);
    }

    private function updateKothFloating(string $state, ?string $capturingPlayer, ?string $winner, int $progress, int $required): void
    {
        $hash = implode('|', [$state, (string) $capturingPlayer, (string) $winner, (string) $progress, (string) $required]);
        if ($hash === $this->lastKothHash) {
            return;
        }
        $this->lastKothHash = $hash;

        $timeLeft = max(0, $required - $progress);
        Manager::FLOATINGTEXT()->updateKoth($state, $capturingPlayer, $winner, $timeLeft);
    }
}
