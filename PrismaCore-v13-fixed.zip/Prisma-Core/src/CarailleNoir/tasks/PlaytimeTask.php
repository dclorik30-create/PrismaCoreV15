<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\VoteManager;
use pocketmine\scheduler\Task;

class PlaytimeTask extends Task
{
    public function onRun(): void
    {
        Manager::PLAYTIME()->flushSessions();
        // Vérifier l'expiration du grade Vote (24h)
        VoteManager::tickGradeExpiry();
    }
}
