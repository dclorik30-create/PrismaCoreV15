<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ArmorEffectTask extends Task
{
    private const DUR = 2147483647;

    /** @var array<string, string> playerName => armorHash */
    private array $armorHashes = [];

    private static function managedTypes(): array
    {
        return [
            spl_object_id(VanillaEffects::SPEED())      => VanillaEffects::SPEED(),
            spl_object_id(VanillaEffects::STRENGTH())   => VanillaEffects::STRENGTH(),
            spl_object_id(VanillaEffects::RESISTANCE()) => VanillaEffects::RESISTANCE(),
            spl_object_id(VanillaEffects::HASTE())      => VanillaEffects::HASTE(),
        ];
    }

    public function removePlayer(string $name): void
    {
        unset($this->armorHashes[$name]);
    }

    public function onRun(): void
    {
        $ce = Manager::CUSTOMENCHANT();

        foreach (Server::getInstance()->getOnlinePlayers() as $player) {
            if (!$player instanceof PrismaPlayer) continue;

            $inv    = $player->getArmorInventory();
            $pieces = [$inv->getHelmet(), $inv->getChestplate(), $inv->getLeggings(), $inv->getBoots()];

            // Hash rapide de l'armure courante
            $hash = '';
            foreach ($pieces as $piece) {
                if ($piece->isNull()) { $hash .= 'null|'; continue; }
                $enchants = $ce->getItemEnchants($piece);
                $hash .= $piece->getTypeId() . ':' . implode(',', array_keys($enchants)) . ':' . implode(',', $enchants) . '|';
            }

            $name = $player->getName();
            if (isset($this->armorHashes[$name]) && $this->armorHashes[$name] === $hash) continue;
            $this->armorHashes[$name] = $hash;

            // Calculer les effets mérités
            $toApply = [];
            foreach ($pieces as $piece) {
                if ($piece->isNull()) continue;
                foreach ($ce->getItemEnchants($piece) as $id => $level) {
                    $level = (int)$level;
                    if ($level <= 0) continue;
                    $amp    = max(0, $level - 1);
                    $ampCap = match(strtolower((string)$id)) {
                        'speed', 'force', 'resistance' => 1,
                        default => PHP_INT_MAX,
                    };
                    $amp     = min($amp, $ampCap);
                    $effType = match(strtolower((string)$id)) {
                        'speed'      => VanillaEffects::SPEED(),
                        'force'      => VanillaEffects::STRENGTH(),
                        'resistance' => VanillaEffects::RESISTANCE(),
                        'haste'      => VanillaEffects::HASTE(),
                        default      => null,
                    };
                    if ($effType === null) continue;
                    $key = spl_object_id($effType);
                    if (!isset($toApply[$key]) || $amp > $toApply[$key]->getAmplifier()) {
                        $toApply[$key] = new EffectInstance($effType, self::DUR, $amp, false, false);
                    }
                }
            }

            $effects = $player->getEffects();
            foreach (self::managedTypes() as $effType) $effects->remove($effType);
            foreach ($toApply as $eff) $effects->add($eff);
        }
    }
}
