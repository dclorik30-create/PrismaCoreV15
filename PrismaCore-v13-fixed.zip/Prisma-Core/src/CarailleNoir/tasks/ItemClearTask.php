<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\Task;

class ItemClearTask extends Task
{
    private const TTL_SECONDS = 30;

    /** @var array<int, array{ref: \WeakReference, ts: float}> entityId => {ref, timestamp} */
    private array $registry = [];

    public function register(ItemEntity $entity): void
    {
        $this->registry[$entity->getId()] = [
            'ref' => \WeakReference::create($entity),
            'ts'  => microtime(true),
        ];
    }

    public function unregister(int $entityId): void
    {
        unset($this->registry[$entityId]);
    }

    public function onRun(): void
    {
        if (empty($this->registry)) return;

        $now = microtime(true);
        foreach ($this->registry as $id => $entry) {
            $entity = $entry['ref']->get();
            if ($entity === null) {
                unset($this->registry[$id]);
                continue;
            }
            if (($now - $entry['ts']) >= self::TTL_SECONDS) {
                $entity->flagForDespawn();
                unset($this->registry[$id]);
            }
        }
    }
}
