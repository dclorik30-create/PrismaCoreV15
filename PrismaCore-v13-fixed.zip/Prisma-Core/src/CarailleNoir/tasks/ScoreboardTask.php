<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\network\mcpe\protocol\RemoveObjectivePacket;
use pocketmine\network\mcpe\protocol\SetDisplayObjectivePacket;
use pocketmine\network\mcpe\protocol\SetScorePacket;
use pocketmine\network\mcpe\protocol\types\ScorePacketEntry;
use pocketmine\scheduler\Task;
use pocketmine\Server;

/**
 * Scoreboard 100% événementiel.
 * onRun() ne fait rien — les refreshs sont déclenchés uniquement
 * quand une donnée change réellement (money, coins, kills, faction,
 * grade, connexion/déconnexion d'un joueur).
 */
class ScoreboardTask extends Task
{
 private const OBJECTIVE = "prisma_sb";
 private const LINES = 8;

 private static ?self $instance = null;
 private array $initialised = [];

 public function __construct()
 {
 self::$instance = $this;
 }

 // ── onRun vide — la task est schedulée uniquement pour instancier $instance
 public function onRun(): void {}

 // ── Refresh un seul joueur ─────────────────────────────────────────────
 public static function refresh(PrismaPlayer $player): void
 {
 if (self::$instance !== null && $player->isConnected()) {
 self::$instance->sendScoreboard($player);
 }
 }

 // ── Refresh tous les joueurs (connexion/déconnexion → compteur "Joueurs")
 public static function refreshAll(): void
 {
 if (self::$instance === null) return;
 foreach (Server::getInstance()->getOnlinePlayers() as $player) {
 if ($player instanceof PrismaPlayer && $player->isConnected()) {
 self::$instance->sendScoreboard($player);
 }
 }
 }

 // ── Construction & envoi du scoreboard ────────────────────────────────
 public function sendScoreboard(PrismaPlayer $player): void
 {
 if (!$player->isConnected()) return;
 if (!Manager::SETTINGS()->getSetting($player->getName(), Manager::SETTINGS()::SETTING_SCOREBOARD)) return;

 $name = $player->getName();
 $faction = $player->getFaction();
 $online = count(Server::getInstance()->getOnlinePlayers());

 $lines = [
 0 => "§8" . str_repeat("-", 18),
 1 => "§7Grade : " . $player->getGradeColor() . $player->getGradeName(),
 2 => "§7Faction : §f" . ($faction?->getName() ?? "Aucune"),
 3 => "§7Money : §6" . self::fmt($player->getMoney()),
 4 => "§7Coins : §b" . self::fmt((float)$player->getCoins()),
 5 => "§7Joueurs : §e" . $online,
 6 => "§6prismamc.fr",
 7 => "§8" . str_repeat("-", 18),
 ];

 if (!isset($this->initialised[$name])) {
 $player->getNetworkSession()->sendDataPacket(
 SetDisplayObjectivePacket::create(
 SetDisplayObjectivePacket::DISPLAY_SLOT_SIDEBAR,
 self::OBJECTIVE,
 "§6§lPrisma",
 "dummy",
 SetDisplayObjectivePacket::SORT_ORDER_ASCENDING
 )
 );
 $this->initialised[$name] = true;
 } else {
 $removes = [];
 for ($i = 0; $i < self::LINES; $i++) {
 $e = new ScorePacketEntry();
 $e->objectiveName = self::OBJECTIVE;
 $e->scoreboardId = $i + 1;
 $e->score = $i;
 $removes[] = $e;
 }
 $player->getNetworkSession()->sendDataPacket(
 SetScorePacket::create(SetScorePacket::TYPE_REMOVE, $removes)
 );
 }

 $entries = [];
 foreach ($lines as $score => $text) {
 $e = new ScorePacketEntry();
 $e->objectiveName = self::OBJECTIVE;
 $e->type = ScorePacketEntry::TYPE_FAKE_PLAYER;
 $e->customName = $text;
 $e->score = $score;
 $e->scoreboardId = $score + 1;
 $entries[] = $e;
 }
 $player->getNetworkSession()->sendDataPacket(
 SetScorePacket::create(SetScorePacket::TYPE_CHANGE, $entries)
 );
 }

 private static function fmt(float $v): string
 {
 if ($v >= 1_000_000) return number_format($v / 1_000_000, 1, '.', '') . 'M';
 if ($v >= 1_000) return number_format($v / 1_000, 1, '.', '') . 'k';
 return (string)(int)$v;
 }

 // Appelé au quit pour libérer mémoire
 public function removePlayer(string $name): void
 {
 unset($this->initialised[$name]);
 }
}
