<?php

namespace CarailleNoir\tasks;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ClearlagTask extends Task
{
 private int $ticker = 0;
 private const CLEAR_INTERVAL = 600;
 private const WARN_TICKS = [30, 10, 5];

 public function onRun(): void
 {
  $this->ticker++;
  $remaining = self::CLEAR_INTERVAL - $this->ticker;

  if (in_array($remaining, self::WARN_TICKS, true)) {
   Server::getInstance()->broadcastMessage("§c[ClearLag] §fLes items au sol et mobs de spawner seront supprimés dans §c{$remaining} §fsecondes !");
  }

  if ($this->ticker >= self::CLEAR_INTERVAL) {
   $this->ticker = 0;
   $this->doClear();
  }
 }

 public function doClear(): void
 {
  $itemCount = 0;
  $mobCount = 0;

  foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
   foreach ($world->getEntities() as $entity) {
    if ($entity instanceof ItemEntity) {
     $entity->flagForDespawn();
     $itemCount++;
     continue;
    }

    if ($entity instanceof Zombie || $entity instanceof Skeleton || $entity instanceof Creeper) {
     $entity->flagForDespawn();
     $mobCount++;
    }
   }
  }

  Server::getInstance()->broadcastMessage("§c[ClearLag] §f{$itemCount} items au sol et §c{$mobCount} §fmobs de spawner ont été supprimés !");
 }
}
