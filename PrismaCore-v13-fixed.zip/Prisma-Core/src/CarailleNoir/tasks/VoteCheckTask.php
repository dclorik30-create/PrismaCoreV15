<?php

namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\AsyncTask;
use pocketmine\Server;

class VoteCheckTask extends AsyncTask {

 private string $playerName;
 private string $apiKey;

 public function __construct(string $playerName, string $apiKey) {
 $this->playerName = $playerName;
 $this->apiKey = $apiKey;
 }

 public function onRun(): void {
 $safeName = str_replace(" ", "%20", $this->playerName);

 $url = "https://minecraftpocket-servers.com/api/?action=post&object=votes&element=claim&key={$this->apiKey}&username={$safeName}";

 $ch = curl_init($url);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 $result = curl_exec($ch);

 if ($result === false) {
 var_dump(curl_error($ch));
 }

 curl_close($ch);
 $this->setResult($result);
 }

 public function onCompletion(): void {
 $player = Server::getInstance()->getPlayerExact($this->playerName);
 if ($player === null) return;

 $result = $this->getResult();

 if ($result !== false && trim($result) === "1") {
 Manager::VOTE()->onVoteSuccess($player);
 } else {
 $player->sendMessage("§cTu n'as pas encore voté ou tu as déjà réclamé ta récompense.");
 }
 }
}