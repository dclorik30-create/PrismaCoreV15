<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\Core;
use CarailleNoir\handlers\ManagerHandler;
use pocketmine\scheduler\Task;

class AutoSaveTask extends Task
{
 private int $count = 0;

 public function onRun(): void
 {
 $this->count++;
 $start = microtime(true);
 ManagerHandler::UnLoad();
 $elapsed = round((microtime(true) - $start) * 1000, 1);
 Core::getInstance()->getLogger()->info(
 "§a[AutoSave] §fSauvegarde #{$this->count} terminée en §e{$elapsed}ms§f."
 );
 }
}
