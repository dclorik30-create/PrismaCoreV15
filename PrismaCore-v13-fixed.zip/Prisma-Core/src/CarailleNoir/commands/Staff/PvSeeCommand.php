<?php
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

class PvSeeCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("pvsee", "Voir un PV de joueur", [], [], ["prisma.command.pvsee"]);
 }

 protected function prepare(): array
 {
 return [new IntegerArgument("slot", false), new TargetPlayerArgument(false, "player")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 $slot = (int)($args["slot"] ?? 1);
 $target = $args["player"] ?? null;
 if ($target === null) {
 $sender->sendMessage("§cUsage : /pvsee <nombre> <joueur>");
 return;
 }
 if ($slot < 1 || $slot > 10) {
 $sender->sendMessage("§cSlot invalide (1-10) !");
 return;
 }

 $pvManager = Manager::PV();
 $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§cPVSee §f{$target} §7#{$slot}");

 $contents = $pvManager->getVaultContents($target, $slot);
 foreach ($contents as $i => $b64) {
 $item = $pvManager->deserializeItem($b64);
 if ($item !== null) {
 $menu->getInventory()->setItem((int)$i, $item);
 }
 }

 $menu->setListener(function(InvMenuTransaction $transaction): InvMenuTransactionResult {
 return $transaction->continue();
 });

 $menu->setInventoryCloseListener(function(Player $p, Inventory $inv) use ($pvManager, $target, $slot): void {
 $serialized = [];
 foreach ($inv->getContents() as $i => $item) {
 $serialized[$i] = $pvManager->serializeItem($item);
 }
 $pvManager->setVaultContents($target, $slot, $serialized);
 $pvManager->save();
 });

 $menu->send($sender);
 }
}
