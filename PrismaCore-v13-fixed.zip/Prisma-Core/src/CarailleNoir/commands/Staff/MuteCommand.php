<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class MuteCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("mute", "Rendre un joueur muet", [], [], ["prisma.command.mute"]);
 }

 protected function prepare(): array
 {
  return [
   new RawStringArgument("joueur"),
   new RawStringArgument("duree", true),
   new RawStringArgument("raison", true),
  ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  $duree      = $args["duree"]  ?? "permanent";
  $raison     = $args["raison"] ?? "Aucune raison donnee";

  if ($targetName === null) {
   $sender->sendMessage("§cUsage : /mute <joueur> [duree] [raison]");
   return;
  }

  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  if ($target === null) {
   $sender->sendMessage("§cJoueur introuvable ou hors ligne.");
   return;
  }

  Manager::SANCTION()->mute($target->getName(), $duree, $raison);

  $staffName = $sender instanceof PrismaPlayer ? $sender->getName() : "Console";
  $target->sendMessage("§cVous avez ete mute par §f" . $staffName . "§c pour §f" . $duree . "§c : §e" . $raison);
  $sender->sendMessage("§a" . $target->getName() . " a ete mute (" . $duree . ") : " . $raison);
  Server::getInstance()->broadcastMessage(
   "§8[§cMute§8] §f" . $target->getName() . " §7mute par §f" . $staffName . " §7(" . $duree . ")"
  );
 }
}
