<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\utils\trait\Time;
use CarailleNoir\utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\plugin\Plugin;
use pocketmine\Server;

class BanCommand extends BaseCommand
{
 use Time;
 public function __construct()
 {
 parent::__construct("ban", "Commande pour bannir un joueur", [], [], ["prisma.command.staff", "prisma.command.ban", DefaultPermissions::ROOT_OPERATOR]);
 }

 protected function prepare(): array
 {
 return [
 new TargetPlayerArgument(false, "name"),
 new RawStringArgument("time"),
 new TextArgument("reason")
 ];
 }
 
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $targetName = $args["name"];
 $timeStr = $args["time"];
 $reason = $args["reason"];

 if (Manager::ALIAS()->hasProfil($targetName)) {
 $duration = $this->parseTime($timeStr);
 Manager::BAN()->addBan($targetName, $reason, $sender->getName(), $duration);
 $sender->sendMessage("§eLe joueur $targetName vient d'être banni");

 $expire = $duration ? date("d/m/Y H:i:s", time() + $duration) : "Permanent";
 $target = Server::getInstance()->getPlayerExact($targetName);


 $alts = Manager::ALIAS()->getAccounts($targetName);
 foreach ($alts as $alt) {
 if (Manager::BAN()->isBanned($alt)) {
 $alt = Server::getInstance()->getPlayerExact($alt);
 $alt?->kick("§aBanni pour : §f$reason\n§7Par : {$sender->getName()}\n§7Expire : $expire");
 }
 }

 if (!is_null($target) && $target->isConnected()) {
 $target?->kick("§aBanni pour : §f$reason\n§7Par : {$sender->getName()}\n§7Expire : $expire");
 }
 }else {
 $sender->sendMessage("§cLe joueur §f$targetName §cne c'est jamais connecté au serveur");
 }
 }
}
