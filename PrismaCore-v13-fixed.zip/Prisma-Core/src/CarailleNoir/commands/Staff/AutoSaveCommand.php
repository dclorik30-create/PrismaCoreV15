<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\handlers\ManagerHandler;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;

/**
 * /autosave — Force une sauvegarde immédiate de toutes les données.
 * Permission : prisma.command.autosave (staff uniquement)
 */
class AutoSaveCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct(
 "autosave",
 "§7Force la sauvegarde de toutes les données du serveur",
 [],
 [],
 ["prisma.command.autosave"]
 );
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $sender->sendMessage("§e[AutoSave] §7Sauvegarde en cours...");

 $start = microtime(true);
 ManagerHandler::UnLoad();
 $elapsed = round((microtime(true) - $start) * 1000, 1);

 $sender->sendMessage("§a[AutoSave] §fSauvegarde terminée en §e{$elapsed}ms§f.");
 $sender->sendMessage("§7Données sauvegardées : §fFactions, Régions, Économie, Grades, Kits, Stats...");
 }
}
