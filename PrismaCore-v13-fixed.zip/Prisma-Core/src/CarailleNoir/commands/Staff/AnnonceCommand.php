<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;
use pocketmine\Server;

class AnnonceCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("annonce", "Envoyer une annonce globale", [], [], ["prisma.command.annonce"]);
 }

 protected function prepare(): array
 {
 return [new TextArgument("message", false)];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $message = trim((string)($args["message"] ?? ""));
 if ($message === "") {
 $sender->sendMessage("§cUsage : §f/annonce <message>");
 return;
 }

 $name = $sender instanceof Player ? $sender->getName() : $sender->getName();
 $line = "§8-------------------------------------";
 $body = "§6[ANNONCE] §e" . $name . " §f: §6" . $message;

 foreach (Server::getInstance()->getOnlinePlayers() as $player) {
 $player->sendMessage($line);
 $player->sendMessage($body);
 $player->sendMessage($line);
 }
 }
}
