<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class SetEventZoneCommand extends BaseCommand
{
    /** @var array<string, array{type:string, world:string, pos1?:array{x:int,y:int,z:int}}> */
    private static array $pending = [];

    public function __construct()
    {
        parent::__construct('seteventzone', "Définir la zone d'un event", [], [], ['prisma.command.staff']);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument('type')];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) {
            $sender->sendMessage('§cIngame only.');
            return;
        }

        $type = strtolower((string) ($args['type'] ?? ''));
        if (!in_array($type, ['koth', 'outpost', 'afkkey', 'totem'], true)) {
            $sender->sendMessage('§cUsage: /seteventzone <koth|outpost|afkkey|totem>');
            return;
        }

        $name = $sender->getName();
        $pos = $sender->getPosition();
        $current = self::$pending[$name] ?? null;

        if ($current === null || $current['type'] !== $type) {
            self::$pending[$name] = [
                'type' => $type,
                'world' => $pos->getWorld()->getFolderName(),
                'pos1' => [
                    'x' => $pos->getFloorX(),
                    'y' => $pos->getFloorY(),
                    'z' => $pos->getFloorZ()
                ]
            ];
            $sender->sendMessage("§e[Event] §fPos1 de §6{$type} §fenregistrée en §7{$pos->getFloorX()}, {$pos->getFloorY()}, {$pos->getFloorZ()}§f. Refaite §e/seteventzone {$type} §fpour définir la Pos2.");
            return;
        }

        $pos1 = $current['pos1'];
        $pos2 = [
            'x' => $pos->getFloorX(),
            'y' => $pos->getFloorY(),
            'z' => $pos->getFloorZ()
        ];

        Manager::EVENT()->setEventZone($type, $pos->getWorld()->getFolderName(), $pos1, $pos2);
        if ($type === 'outpost') {
            Manager::OUTPOST()->setZone($pos->getWorld()->getFolderName(), $pos1, $pos2);
        }

        unset(self::$pending[$name]);
        $sender->sendMessage("§a[Event] §fZone de §6{$type} §fenregistrée : Pos1 §7{$pos1['x']}, {$pos1['y']}, {$pos1['z']} §f/ Pos2 §7{$pos2['x']}, {$pos2['y']}, {$pos2['z']}§f.");
    }
}
