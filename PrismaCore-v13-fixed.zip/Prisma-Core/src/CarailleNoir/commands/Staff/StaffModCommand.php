<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\items\SpecialItems;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\Server;

class StaffModCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct('staffmod', 'Activer/désactiver le mode staff', [], [], ['prisma.command.staff', 'prisma.command.staffmod']);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument('mode', true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $mode = !$sender->isStaffMode();
        $sender->setStaffMode($mode);

        if ($mode) {
            $sender->setAllowFlight(true);
            $sender->setFlying(true);
            $sender->setHasBlockCollision(false);
            foreach (Server::getInstance()->getOnlinePlayers() as $online) {
                if ($online->getName() !== $sender->getName()) {
                    $online->hidePlayer($sender);
                }
            }
            $sender->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999, 0, false, false));
            $sender->getEffects()->add(new EffectInstance(VanillaEffects::SPEED(), 999999, 2, false, false));
            $sender->backupStaffInventory();
            $sender->getInventory()->clearAll();
            $sender->getArmorInventory()->clearAll();
            $sender->getOffHandInventory()->clearAll();
            $sender->getInventory()->setItem(0, SpecialItems::makeSanctionStick());
            $sender->sendMessage('§a[StaffMod] §fActivé §8(§7Fly + Noclip + Vanish + Stick utilisable§8)§f.');
        } else {
            $sender->setFlying(false);
            $sender->setAllowFlight(false);
            $sender->setHasBlockCollision(true);
            foreach (Server::getInstance()->getOnlinePlayers() as $online) {
                if ($online->getName() !== $sender->getName()) {
                    $online->showPlayer($sender);
                }
            }
            $sender->getEffects()->remove(VanillaEffects::SPEED());
            $sender->getEffects()->remove(VanillaEffects::NIGHT_VISION());
            $sender->restoreStaffInventory();
            $sender->sendMessage('§c[StaffMod] §fDésactivé.');
        }
    }
}
