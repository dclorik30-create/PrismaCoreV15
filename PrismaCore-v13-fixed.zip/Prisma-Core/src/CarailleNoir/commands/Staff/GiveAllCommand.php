<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class GiveAllCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("giveall", "Donner l'item en main a tous les joueurs connectes", [], [], ["prisma.command.giveall"]);
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if(!$sender instanceof PrismaPlayer) return;
        $item = clone $sender->getInventory()->getItemInHand();
        if($item->isNull()){
            $sender->sendMessage("§cVous devez tenir un item dans votre main.");
            return;
        }
        $count = 0;
        foreach(Server::getInstance()->getOnlinePlayers() as $player){
            $player->getInventory()->addItem(clone $item);
            $count++;
        }
        $sender->sendMessage("§aItem donne a §f{$count} §ajoueurs.");
    }
}
