<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\trait\Time;
use pocketmine\command\CommandSender;

class TIGCommand extends BaseCommand
{
 use Time;

 public function __construct()
 {
 parent::__construct(
 "tig",
 "Mettre un joueur en TIG (online ou offline)",
 [],
 [],
 ["prisma.command.tig", "prisma.command.staff"]
 );
 }

 protected function prepare(): array
 {
 return [
 new TargetPlayerArgument(false, "player"),
 new RawStringArgument("time", false),
 new TextArgument("reason", false),
 ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) {
 $sender->sendMessage("§cCette commande est réservée aux joueurs.");
 return;
 }

 $targetName = $args["player"] ?? null;
 $timeStr = $args["time"] ?? null;
 $reason = $args["reason"] ?? null;

 if ($targetName === null || $timeStr === null || $reason === null) {
 $sender->sendMessage("§cUsage : §f/tig <joueur> <durée> <raison>");
 $sender->sendMessage("§7Durée : §e1d§7, §e2h§7, §e30m§7, §e1d12h§7...");
 return;
 }

 if (!Manager::ALIAS()->hasProfil($targetName)) {
 $sender->sendMessage("§cCe joueur n'a jamais rejoint le serveur.");
 return;
 }

 if (Manager::TIG()->isTIG($targetName)) {
 $sender->sendMessage("§e$targetName §fest déjà en TIG !");
 return;
 }

 $duration = $this->parseTime($timeStr);
 if ($duration === null || $duration <= 0) {
 $sender->sendMessage("§cDurée invalide ! Exemples : §e1d§c, §e2h§c, §e30m§c, §e90s");
 return;
 }

 Manager::TIG()->addTIG($targetName, $duration, $reason, $sender->getName());

 // Confirmation staff
 $online = \pocketmine\Server::getInstance()->getPlayerExact($targetName) !== null;
 $suffix = $online ? "" : " §7(hors-ligne, sera appliqué à sa reconnexion)";
 $sender->sendMessage("§6$targetName §fa été placé en TIG §e$timeStr §f— §7$reason" . $suffix);
 }
}
