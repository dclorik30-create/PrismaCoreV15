<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\forms\CustomForm;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class NickCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("nick", "Nick visuel", [], [], ["prisma.command.nick"]);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if(!$sender instanceof PrismaPlayer) return;

        $form = new CustomForm(function(PrismaPlayer $player, ?array $data): void {
            if($data === null) return;

            $nick = trim((string)($data["nick"] ?? ""));

            if($nick === ""){
                $player->setVisualNick("");
                return;
            }

            if(strlen($nick) > 8){
                $player->sendMessage("§c8 caractères maximum.");
                return;
            }

            if(!preg_match('/^[a-zA-Z0-9_]+$/', $nick)){
                $player->sendMessage("§cCaractères invalides.");
                return;
            }

            $player->setVisualNick($nick);
        });
        $form->setTitle("Nick");
        $form->addInput("", "", $sender->getVisualNick(), "nick");
        $sender->sendForm($form);
    }
}
