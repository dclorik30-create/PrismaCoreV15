<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;

class RepairAllCommand extends BaseCommand
{
 private const GRADE_COOLDOWNS = [
  "noble"          => 3600,
  "heros"          => 900,
  "héros"          => 900,
  "influenceur"    => 900,
  "dieu"           => 0,
  "fondateur"      => 0,
  "administrateur" => 0,
  "modérateur"     => 0,
  "guide"          => 3600,
 ];

 private array $cooldowns = [];

 public function __construct()
 {
  parent::__construct("repairall", "Reparer tous les items de l'inventaire", [], [], ["prisma.command.repairall"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  $gradeId  = strtolower($sender->getGradeId());
  $cooldown = self::GRADE_COOLDOWNS[$gradeId] ?? 3600;
  $name     = strtolower($sender->getName());
  $now      = time();

  if ($cooldown > 0 && isset($this->cooldowns[$name])) {
   $remaining = $cooldown - ($now - $this->cooldowns[$name]);
   if ($remaining > 0) {
    $h = (int)floor($remaining / 3600);
    $m = (int)floor(($remaining % 3600) / 60);
    $s = $remaining % 60;
    $fmt = $h > 0 ? "{$h}h {$m}m" : ($m > 0 ? "{$m}m {$s}s" : "{$s}s");
    $sender->sendMessage("§cRepairAll en cooldown : §f{$fmt} §crestant.");
    return;
   }
  }

  $inv   = $sender->getInventory();
  $armor = $sender->getArmorInventory();
  $repaired = 0;

  foreach ($inv->getContents() as $slot => $item) {
   if ($item instanceof Durable && $item->getDamage() > 0) {
    $item->setDamage(0); $inv->setItem($slot, $item); $repaired++;
   }
  }
  foreach ($armor->getContents() as $slot => $item) {
   if ($item instanceof Durable && $item->getDamage() > 0) {
    $item->setDamage(0); $armor->setItem($slot, $item); $repaired++;
   }
  }

  if ($repaired === 0) { $sender->sendMessage("§7Aucun item a reparer."); return; }
  if ($cooldown > 0) $this->cooldowns[$name] = $now;
  $sender->sendMessage("§a{$repaired} item(s) repare(s) !");
 }
}
