<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\item\VanillaItems;

class ShopCommand extends BaseCommand
{
 public function __construct() { parent::__construct("shop", "Ouvrir le shop", [], [], ["prisma.command.shop"]); }
 protected function prepare(): array { return [new RawStringArgument("action", true), new RawStringArgument("categorie", true)]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 if (strtolower((string)($args['action'] ?? '')) === 'add') {
 if (!\pocketmine\Server::getInstance()->isOp($sender->getName())) {
 $sender->sendMessage("§cCommande réservée aux OP.");
 return;
 }
 $catId = strtolower((string)($args['categorie'] ?? ''));
 if ($catId === '') {
 $sender->sendMessage("§cUtilisation: /shop add <catégorie>");
 return;
 }
 if (Manager::SHOP()->getCategory($catId) === null) {
 $sender->sendMessage("§cCatégorie inconnue.");
 return;
 }
 $item = clone $sender->getInventory()->getItemInHand();
 if ($item->isNull()) {
 $sender->sendMessage("§cVous devez tenir un item en main.");
 return;
 }
 if (!Manager::SHOP()->addItemToCategory($catId, $item, 0, 0)) {
 $sender->sendMessage("§cImpossible d'ajouter l'item.");
 return;
 }
 $sender->sendMessage("§aItem ajouté à §f{$catId}§a. Modifiez ensuite buy/sell dans le shop.json.");
 return;
 }

 self::openCategories($sender);
 }

 public static function openCategories(PrismaPlayer $player): void
 {
 $menu = InvMenu::create(InvMenu::TYPE_CHEST);
 $menu->setName("§6Shop §7- §fCatégories");
 $inv = $menu->getInventory();
 $inv->clearAll();

 $cats = [
 10 => ['id' => 'pvp', 'item' => VanillaItems::DIAMOND_SWORD(), 'name' => '§cPVP'],
 12 => ['id' => 'farm', 'item' => VanillaItems::WHEAT(), 'name' => '§aFARM'],
 14 => ['id' => 'block', 'item' => VanillaItems::SNOWBALL(), 'name' => '§6BLOCK'],
 16 => ['id' => 'mob', 'item' => VanillaItems::BONE(), 'name' => '§5MOB'],
 22 => ['id' => 'minage', 'item' => VanillaItems::IRON_PICKAXE(), 'name' => '§bMINAGE'],
 ];

 foreach ($cats as $slot => $data) {
 $item = clone $data['item'];
 $item->setCustomName($data['name']);
 $item->setLore(["§fOuvrir la catégorie"]);
 $inv->setItem($slot, $item);
 }

 $menu->setListener(function(InvMenuTransaction $tx) use ($cats): InvMenuTransactionResult {
 $player = $tx->getPlayer();
 if (!$player instanceof PrismaPlayer) return $tx->discard();
 $clicked = $tx->getItemClicked();
 foreach ($cats as $data) {
 if ($clicked->getCustomName() === $data['name']) {
 // InvMenu ferme sa fenêtre seul via discard — pas besoin de removeCurrentWindow()
 $player->removeCurrentWindow();
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $data): void {
 self::openCategory($player, $data['id']);
 }), 3);
 break;
 }
 }
 return $tx->discard();
 });
 $menu->send($player);
 }

 public static function openCategory(PrismaPlayer $player, string $catId): void
 {
 $items = Manager::SHOP()->getItemsByCategory($catId);
 $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§6Shop §7- §f" . strtoupper($catId));
 $inv = $menu->getInventory();
 $inv->clearAll();

 $slot = 0;
 $map = [];
 foreach ($items as $key => $entry) {
 if ($slot >= $inv->getSize()) break;
 $item = Manager::SHOP()->makeShopItem($entry['item_id'], $entry['name'], max(1, (int)($entry['amount'] ?? 1)), (string)($entry['item_data'] ?? ''));
 if ($item === null) {
 $item = VanillaItems::BARRIER()->setCustomName("§cItem invalide");
 }
 $lore = $item->getLore();
 $lore[] = "§fAchat : §a" . number_format((float)$entry['buy_price'], 2) . "§6$";
 $lore[] = "§fVente : §c" . number_format((float)$entry['sell_price'], 2) . "§6$";
 $item->setCustomName($entry['name']);
 $item->setLore($lore);
 $inv->setItem($slot, $item);
 $map[$slot] = $key;
 $slot++;
 }

 $menu->setListener(function(InvMenuTransaction $tx) use ($map, $catId): InvMenuTransactionResult {
 $player = $tx->getPlayer();
 if (!$player instanceof PrismaPlayer) return $tx->discard();
 $clicked = $tx->getItemClicked();
 foreach ($map as $shopKey) {
 foreach (Manager::SHOP()->getItemsByCategory($catId) as $key => $entry) {
 if ($key === $shopKey && $clicked->getCustomName() === $entry['name']) {
 // Fermeture naturelle par InvMenu + 3 ticks de délai avant d'envoyer le Form
 $player->removeCurrentWindow();
 Core::getInstance()->getScheduler()->scheduleDelayedTask(
 new \pocketmine\scheduler\ClosureTask(function() use ($player, $catId, $key): void {
 ShopCommand::openItem($player, $catId, $key);
 }), 3);
 break 2;
 }
 }
 }
 return $tx->discard();
 });
 $menu->send($player);
 }

 public static function openItem(PrismaPlayer $player, string $catId, string $itemId): void
 {
 $item = null;
 foreach (Manager::SHOP()->getItemsByCategory($catId) as $key => $entry) {
 if ($key === $itemId) {
 $item = $entry;
 break;
 }
 }
 if ($item === null) {
 $player->sendMessage("§cItem introuvable dans le shop.");
 self::openCategory($player, $catId);
 return;
 }

 $count = Manager::SHOP()->countItemInInventory($player, $item['item_id']);
 $player->sendForm(new class($catId, $itemId, $item, $count) implements Form {
 public function __construct(private string $catId, private string $itemId, private array $item, private int $count) {}

 public function jsonSerialize(): array {
 return [
 "type" => "custom_form",
 "title" => $this->item['name'],
 "content" => [
 [
 "type" => "label",
 "text" => "§fItem : §e{$this->item['name']}\n§fPrix achat : §a" . number_format((float) $this->item['buy_price'], 2) . "§6$\n§7Prix de vente§8: §c" . number_format((float) $this->item['sell_price'], 2) . "§6$\n§7Nombre d'items dans l'inventaire§8: §e{$this->count}"
 ],
 ["type" => "toggle", "text" => "§aMode achat §f(OFF = vente)", "default" => true],
 ["type" => "input", "text" => "§fNombre d'items", "placeholder" => "Ex: 64", "default" => "1"]
 ]
 ];
 }

 public function handleResponse(\pocketmine\player\Player $player, mixed $data): void {
 if (!$player instanceof PrismaPlayer || $data === null) return;
 $buyMode = (bool) ($data[1] ?? true);
 $amount = max(1, (int) trim((string) ($data[2] ?? '1')));
 $entry = null;
 foreach (Manager::SHOP()->getItemsByCategory($this->catId) as $key => $shopEntry) {
 if ($key === $this->itemId) {
 $entry = $shopEntry;
 break;
 }
 }
 if ($entry === null) {
 $player->sendMessage("§cItem introuvable.");
 ShopCommand::openCategory($player, $this->catId);
 return;
 }

 if ($buyMode) {
 $unitPrice = (float) $entry['buy_price'];
 if ($unitPrice <= 0) {
 $player->sendMessage("§cCet item ne peut pas être acheté.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }

 $baseAmount = max(1, (int) ($entry['amount'] ?? 1));
 $totalPrice = $unitPrice * $amount;
 $give = Manager::SHOP()->makeShopItem($entry['item_id'], $entry['name'], $baseAmount * $amount, (string) ($entry['item_data'] ?? ''));
 if ($give === null) {
 $player->sendMessage("§cItem invalide.");
 ShopCommand::openCategory($player, $this->catId);
 return;
 }
 if (!$player->hasMoney($totalPrice)) {
 $player->sendMessage("§cPas assez d'argent.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 if (!$player->getInventory()->canAddItem($give)) {
 $player->sendMessage("§cPas assez de place dans l'inventaire.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $player->removeMoney($totalPrice);
 $player->getInventory()->addItem($give);
 $player->sendMessage("§aAchat effectué : §f" . $give->getCount() . "x " . $entry['name'] . " §apour §e" . number_format($totalPrice, 2) . "§6$");
 } else {
 $unitPrice = (float) $entry['sell_price'];
 if ($unitPrice <= 0) {
 $player->sendMessage("§cCet item ne peut pas être vendu.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $available = Manager::SHOP()->countItemInInventory($player, $entry['item_id']);
 if ($available < $amount) {
 $player->sendMessage("§cVous n'avez pas assez de cet item.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 if (!Manager::SHOP()->removeItemFromInventory($player, $entry['item_id'], $amount)) {
 $player->sendMessage("§cImpossible de retirer les items.");
 ShopCommand::openItem($player, $this->catId, $this->itemId);
 return;
 }
 $totalPrice = $unitPrice * $amount;
 $player->addMoney($totalPrice);
 $player->sendMessage("§aVente effectuée : §f" . $amount . "x " . $entry['name'] . " §apour §e" . number_format($totalPrice, 2) . "§6$");
 }

 ShopCommand::openItem($player, $this->catId, $this->itemId);
 }
 });
 }
}
