<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class SellAllCommand extends BaseCommand
{
 public function __construct() { parent::__construct("sellall", "Vendre tous les items de Minage et Farm", [], [], ["prisma.command.sellall"]); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  if (!$sender instanceof PrismaPlayer) return;

  $shop    = Manager::SHOP();
  $inv     = $sender->getInventory();
  $total   = 0.0;
  $summary = [];

  // Construire la liste des items vendables des catégories MINAGE + FARM
  $sellable = [];
  foreach (['minage', 'farm'] as $catId) {
   foreach ($shop->getItemsByCategory($catId) as $entry) {
    if (($entry['sell_price'] ?? 0) > 0 && ($entry['item_id'] ?? '') !== '') {
     $sellable[$entry['item_id']] = $entry;
    }
   }
  }

  // Parcourir l'inventaire
  foreach ($inv->getContents() as $slot => $item) {
   if ($item->isNull()) continue;

   // Chercher correspondance dans les items vendables MINAGE/FARM
   $entry = null;
   foreach ($sellable as $id => $e) {
    $probe = $shop->makeShopItem($id, $e['name'] ?? null, 1, $e['item_data'] ?? null);
    if ($probe !== null && $probe->getTypeId() === $item->getTypeId()) {
     $entry = $e;
     break;
    }
   }
   if ($entry === null || ($entry['sell_price'] ?? 0) <= 0) continue;

   $gained = (float)$entry['sell_price'] * $item->getCount();
   $total += $gained;
   $summary[$item->getName()] = ($summary[$item->getName()] ?? 0) + $item->getCount();
   $inv->clear($slot);
  }

  if ($total <= 0) {
   $sender->sendMessage("§cAucun item vendable (Minage/Farm) dans votre inventaire !");
   return;
  }

  $sender->addMoney($total);
  $sender->sendMessage("§aVente totale (Minage/Farm) : §f" . number_format($total, 2) . '§6$');

  $lines = [];
  foreach ($summary as $name => $qty) {
   $lines[] = "§7{$qty}x §f{$name}";
  }
  if (!empty($lines)) {
   $sender->sendMessage("§7Vendu : " . implode("§7, ", $lines));
  }
 }
}
