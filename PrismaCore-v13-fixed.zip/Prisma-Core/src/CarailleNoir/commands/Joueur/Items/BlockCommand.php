<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Items;
use CarailleNoir\Core;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\utils\DyeColor;
use pocketmine\block\VanillaBlocks;
use pocketmine\command\CommandSender;
use pocketmine\inventory\Inventory;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\scheduler\ClosureTask;
class BlockCommand extends BaseCommand {
 public function __construct(){parent::__construct("block","Menu blocs déco",[],[],["prisma.command.block"]);}
 protected function prepare(): array{return [];}
 public function onRun(CommandSender $sender,string $aliasUsed,array $args): void{
 if(!$sender instanceof PrismaPlayer)return;
 self::openPage($sender,0);
 }
 public static function getBlocks(): array{
 $b=[];
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::WOOL()->setColor($c)->asItem()->setCustomName("§fLaine §7".self::cn($c));
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::CONCRETE()->setColor($c)->asItem()->setCustomName("§fBéton §7".self::cn($c));
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::STAINED_CLAY()->setColor($c)->asItem()->setCustomName("§fTerre cuite §7".self::cn($c));
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::STAINED_GLASS()->setColor($c)->asItem()->setCustomName("§fVerre teinté §7".self::cn($c));
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::STAINED_GLASS_PANE()->setColor($c)->asItem()->setCustomName("§fPanneau verre §7".self::cn($c));
 foreach(DyeColor::cases() as $c) $b[]=VanillaBlocks::CARPET()->setColor($c)->asItem()->setCustomName("§fTapis §7".self::cn($c));
 $extras=[[VanillaBlocks::STONE(),"Pierre"],[VanillaBlocks::GRANITE(),"Granit"],[VanillaBlocks::POLISHED_GRANITE(),"Granit poli"],[VanillaBlocks::DIORITE(),"Diorite"],[VanillaBlocks::POLISHED_DIORITE(),"Diorite polie"],[VanillaBlocks::ANDESITE(),"Andésite"],[VanillaBlocks::POLISHED_ANDESITE(),"Andésite polie"],[VanillaBlocks::COBBLESTONE(),"Cobblestone"],[VanillaBlocks::MOSSY_COBBLESTONE(),"Cobble moussue"],[VanillaBlocks::STONE_BRICKS(),"Briques pierre"],[VanillaBlocks::MOSSY_STONE_BRICKS(),"Briques moussues"],[VanillaBlocks::CRACKED_STONE_BRICKS(),"Briques fissurées"],[VanillaBlocks::CHISELED_STONE_BRICKS(),"Briques ciselées"],[VanillaBlocks::SAND(),"Sable"],[VanillaBlocks::SANDSTONE(),"Grès"],[VanillaBlocks::SMOOTH_SANDSTONE(),"Grès lisse"],[VanillaBlocks::CHISELED_SANDSTONE(),"Grès ciselé"],[VanillaBlocks::RED_SAND(),"Sable rouge"],[VanillaBlocks::RED_SANDSTONE(),"Grès rouge"],[VanillaBlocks::SMOOTH_RED_SANDSTONE(),"Grès rouge lisse"],[VanillaBlocks::OAK_PLANKS(),"Planches chêne"],[VanillaBlocks::SPRUCE_PLANKS(),"Planches épicéa"],[VanillaBlocks::BIRCH_PLANKS(),"Planches bouleau"],[VanillaBlocks::JUNGLE_PLANKS(),"Planches jungle"],[VanillaBlocks::ACACIA_PLANKS(),"Planches acacia"],[VanillaBlocks::DARK_OAK_PLANKS(),"Planches chêne noir"],[VanillaBlocks::OAK_LOG(),"Tronc chêne"],[VanillaBlocks::SPRUCE_LOG(),"Tronc épicéa"],[VanillaBlocks::BIRCH_LOG(),"Tronc bouleau"],[VanillaBlocks::JUNGLE_LOG(),"Tronc jungle"],[VanillaBlocks::ACACIA_LOG(),"Tronc acacia"],[VanillaBlocks::DARK_OAK_LOG(),"Tronc chêne noir"],[VanillaBlocks::GLOWSTONE(),"Glowstone"],[VanillaBlocks::SEA_LANTERN(),"Lanterne marine"],[VanillaBlocks::GLASS(),"Verre"],[VanillaBlocks::GLASS_PANE(),"Panneau verre"],[VanillaBlocks::QUARTZ(),"Quartz"],[VanillaBlocks::SMOOTH_QUARTZ(),"Quartz lisse"],[VanillaBlocks::CHISELED_QUARTZ(),"Quartz ciselé"],[VanillaBlocks::QUARTZ_PILLAR(),"Colonne quartz"],[VanillaBlocks::BRICKS(),"Briques"],[VanillaBlocks::NETHER_BRICKS(),"Briques Nether"],[VanillaBlocks::RED_NETHER_BRICKS(),"Briques Nether rouge"],[VanillaBlocks::END_STONE(),"Pierre End"],[VanillaBlocks::END_STONE_BRICKS(),"Briques End"],[VanillaBlocks::PURPUR(),"Purpur"],[VanillaBlocks::PURPUR_PILLAR(),"Colonne Purpur"],[VanillaBlocks::HARDENED_CLAY(),"Terre cuite"],[VanillaBlocks::BOOKSHELF(),"Bibliothèque"],[VanillaBlocks::ICE(),"Glace"],[VanillaBlocks::PACKED_ICE(),"Glace compacte"],[VanillaBlocks::BLUE_ICE(),"Glace bleue"],[VanillaBlocks::NETHERRACK(),"Netherrack"],[VanillaBlocks::PRISMARINE(),"Prismarine"],[VanillaBlocks::DARK_PRISMARINE(),"Prismarine sombre"],[VanillaBlocks::PRISMARINE_BRICKS(),"Briques prismarine"]];
 foreach($extras as [$blk,$name]) $b[]=$blk->asItem()->setCustomName("§f{$name}");
 return $b;
 }
 public static function openPage(PrismaPlayer $player,int $page): void{
 $all=self::getBlocks();$pp=45;$tot=(int)ceil(count($all)/$pp);
 $page=max(0,min($page,$tot-1));$off=$page*$pp;
 $menu=InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
 $menu->setName("§6Blocs §8— §ePage §e".($page+1)."§f/§e{$tot}");
 $inv=$menu->getInventory();$inv->clearAll();
 foreach(array_slice($all,$off,$pp)as $i=>$item){$d=clone $item;$d->setCount(64);$d->setLore(["§7Clic → §ex64"]);$inv->setItem($i,$d);}
 if($page>0) $inv->setItem(45,VanillaItems::ARROW()->setCustomName("§e← Préc")->setLore(["§7Page ".($page)."/{$tot}"]));
 $inv->setItem(49,VanillaItems::PAPER()->setCustomName("§ePage §f".($page+1)."§8/§f{$tot}")->setLore(["§7".count($all)." blocs"]));
 if($page<$tot-1) $inv->setItem(53,VanillaItems::ARROW()->setCustomName("§eSuiv →")->setLore(["§7Page ".($page+2)."/{$tot}"]));
 $pending=null;
 $menu->setListener(function(InvMenuTransaction $tx)use($page,$tot,$off,$all,&$pending): InvMenuTransactionResult{
 $p=$tx->getPlayer();if(!$p instanceof PrismaPlayer)return $tx->discard();
 $s=$tx->getAction()->getSlot();
 if($s===45&&$page>0){$pending=$page-1;$p->removeCurrentWindow();return $tx->discard();}
 if($s===53&&$page<$tot-1){$pending=$page+1;$p->removeCurrentWindow();return $tx->discard();}
 if($s===49)return $tx->discard();
 $idx=$off+$s;
 if($idx<count($all)){$g=clone $all[$idx];$g->setCount(64);$g->setLore([]);
 if($p->getInventory()->canAddItem($g)){$p->getInventory()->addItem($g);$p->sendTip("§a+64 §f".$all[$idx]->getCustomName());}
 else $p->sendMessage("§cInventaire plein !");}
 return $tx->discard();
 });
 $menu->setInventoryCloseListener(function(Player $player,Inventory $inv)use(&$pending): void{
 if(!$player instanceof PrismaPlayer||$pending===null)return;
 $t=$pending;$pending=null;
 Core::getInstance()->getScheduler()->scheduleDelayedTask(new ClosureTask(fn()=>$player->isConnected()&&BlockCommand::openPage($player,$t)),3);
 });
 $menu->send($player);
 }
 private static function cn(DyeColor $c): string{
 return match($c){DyeColor::WHITE=>"Blanc",DyeColor::ORANGE=>"Orange",DyeColor::MAGENTA=>"Magenta",DyeColor::LIGHT_BLUE=>"Bleu clair",DyeColor::YELLOW=>"Jaune",DyeColor::LIME=>"Vert clair",DyeColor::PINK=>"Rose",DyeColor::GRAY=>"Gris",DyeColor::LIGHT_GRAY=>"Gris clair",DyeColor::CYAN=>"Cyan",DyeColor::PURPLE=>"Violet",DyeColor::BLUE=>"Bleu",DyeColor::BROWN=>"Marron",DyeColor::GREEN=>"Vert",DyeColor::RED=>"Rouge",DyeColor::BLACK=>"Noir",default=>$c->name};
 }
}
