<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class IslandVisitSubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("isvisit", "Visiter l'island d'une faction", ["iv"]); }
 protected function prepare(): array { return [new RawStringArgument("factionName", false)]; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $targetName = trim($args["factionName"] ?? "");
 if ($targetName === "") { $sender->sendMessage("§cUsage : §f/f islandvisit <faction>"); return; }

 $targetFaction = null;
 foreach (Manager::FACTION()->getFactions() as $f) {
 if (strtolower($f->getName()) === strtolower($targetName)) { $targetFaction = $f; break; }
 }
 if ($targetFaction === null) { $sender->sendMessage("§cFaction introuvable !"); return; }

 if (!$targetFaction->isEveryoneIslandAllowed()) {
 $viewerFaction = $sender->getFaction();
 $allowed = $targetFaction->hasPlayer($sender->getName())
 || $targetFaction->isWhitelistedForIsland($sender->getName())
 || ($viewerFaction !== null && $targetFaction->isAlly($viewerFaction->getId()));
 if (!$allowed) { $sender->sendMessage("§cCette île est verrouillée."); return; }
 }

 $island = Manager::FACTION()->getIsland($targetFaction->getId());
 if ($island === null) { $sender->sendMessage("§cCette faction n'a pas d'island !"); return; }

 $worldName = $island["world"] ?? "";
 $wm = \pocketmine\Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($worldName)) $wm->loadWorld($worldName);
 $world = $wm->getWorldByName($worldName);
 if ($world === null) { $sender->sendMessage("§cImpossible de charger le monde de cette island !"); return; }

 $sender->teleport($world->getSpawnLocation());
 $sender->sendMessage("§aTéléporté sur l'island de §f" . $targetFaction->getName());
 }
}
