<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class LeaveSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("leave", "Permet de quitter sa faction");
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $senderName = $sender->getName();

 $faction = $sender->getFaction();
 if (!$faction instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::NOT_IN_FACTION->value);
 return;
 }

 if ($faction->getOwner() === $senderName) {
 FactionMessageEnum::IS_OWNER->sendToPlayer($sender, []);
 return;
 }

 $faction->remove($senderName, $faction->getPlayerRole($senderName));
 $sender->setFaction("Aucune");
 FactionMessageEnum::FACTION_LEAVE->sendToPlayer($sender, []);
 FactionMessageEnum::PLAYER_LEAVE->sendToFaction($faction, ["{playername}" => $senderName]);
 }
}