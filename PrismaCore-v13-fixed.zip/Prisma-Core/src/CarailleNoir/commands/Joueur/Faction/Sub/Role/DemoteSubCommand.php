<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Role;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionPermissionEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class DemoteSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("demote", "Diminuer le grade d'un joueur dans sa faction", ["derank"]);
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(false, "playerName")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;
 $senderName = $sender->getName();

 $faction = $sender->getFaction();
 if (!$faction instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::NOT_IN_FACTION->value);
 return;
 }

 if (!FactionPermissionEnum::PROMOTE->has($faction, $senderName)) {
 FactionMessageEnum::NOT_PERMISSION_DEMOTE->sendToPlayer($sender, []);
 return;
 }

 $targetName = $args["playerName"];
 if (!Manager::ALIAS()->hasProfil($targetName)) {
 $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
 return;
 }

 $target = Server::getInstance()->getPlayerExact($targetName);
 if (!$target instanceof PrismaPlayer) {
 $sender->sendMessage("§cImpossible de récupérer le joueur !");
 return;
 }

 $factionT = $target->getFaction();
 if (!$factionT instanceof Faction) {
 $sender->sendMessage(FactionMessageEnum::TARGET_NOT_IN_FACTION->value);
 return;
 }

 if ($faction->getId() !== $factionT->getId()) {
 FactionMessageEnum::NOT_SAME_FACTION->sendToPlayer($sender, []);
 return;
 }

 $rank = $faction->getPlayerRole($senderName);
 $rankT = $faction->getPlayerRole($targetName);

 if ($rank->getPriority() < $rankT->getPriority() || $rankT === FactionRoleEnum::OWNER) {
 FactionMessageEnum::NOT_PERMISSION_DEMOTE_PLAYER->sendToPlayer($sender, []);
 return;
 }

 $faction->remove($targetName, $rankT);
 $faction->add($targetName, $rankT->getLowerRank());
 FactionMessageEnum::DEMOTE_PLAYER->sendToFaction($faction, ["{playername}" => $targetName, "{rankname}" => $rankT->getLowerRank()->value]);
 }
}