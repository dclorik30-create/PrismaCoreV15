<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Manage;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionPermissionEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class InviteSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("invite", "Permet d'inviter des gens dans sa faction");
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(false, "playerName")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 $fManager = Manager::FACTION();
 $faction = $sender->getFaction();

 if (!$faction instanceof Faction) {
 FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []);
 return;
 }

 if (!FactionPermissionEnum::INVITE->has($faction, $sender->getName())) {
 FactionMessageEnum::NOT_PERMISSION_INVITE->sendToPlayer($sender, []);
 return;
 }

 $targetName = $args["playerName"];
 if (!Manager::ALIAS()->hasProfil($targetName)) {
 $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
 return;
 }

 $target = Server::getInstance()->getPlayerExact($targetName);
 if (!$target instanceof PrismaPlayer) {
 $sender->sendMessage("§cImpossible de récupérer le joueur !");
 return;
 }

 $targetF = $target->getFaction();
 if ($targetF instanceof Faction) {
 FactionMessageEnum::TARGET_ALREADY_IN_FACTION->sendToPlayer($sender, []);
 return;
 }

 $fManager->invite($faction, $targetName);
 FactionMessageEnum::SENDER_NEW_INVITE->sendToPlayer($sender, ["{playername}" => $targetName]);
 FactionMessageEnum::TARGET_NEW_INVITE->sendToPlayer($target, ["{faction}" => $faction->getName()]);
 }
}