<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\tasks\FlyTask;
use pocketmine\command\CommandSender;

class FlySubCommand extends BaseSubCommand
{
    /** Permissions → durée en secondes (null = illimité) */
    private const FLY_DURATIONS = [
        'prisma.fly.unlimited' => null,
        'prisma.fly.120'       => 120 * 60,
        'prisma.fly.60'        => 60  * 60,
        'prisma.fly.30'        => 30  * 60,
        'prisma.fly.10'        => 10  * 60,
    ];

    public function __construct()
    {
        parent::__construct('fly', 'Voler sur le territoire de votre faction', [], []);
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $world = $sender->getWorld()->getFolderName();

        // Hors island_* : couper le fly restant et refuser l'activation
        if (strpos($world, 'island_') !== 0) {
            if (FlyTask::isFlying($sender->getName()) || $sender->getAllowFlight() || $sender->isFlying()) {
                FlyTask::stopFly($sender->getName());
                $sender->setAllowFlight(false);
                $sender->setFlying(false);
            }
            $sender->sendMessage('§c[Prisma] Vous ne pouvez pas fly en dehors des islands.');
            return;
        }

        // Toggle OFF
        if (FlyTask::isFlying($sender->getName())) {
            FlyTask::stopFly($sender->getName());
            $sender->setAllowFlight(false);
            $sender->setFlying(false);
            $sender->sendMessage('§c[Fly] Désactivé.');
            return;
        }

        // Doit être dans une faction
        $faction = $sender->getFaction();
        if ($faction === null) {
            $sender->sendMessage('§cVous devez être dans une faction pour utiliser /f fly.');
            return;
        }


        // Durée selon permission (la plus haute trouvée)
        $duration = -1; // -2 = pas de perm
        foreach (self::FLY_DURATIONS as $perm => $secs) {
            if ($sender->hasPermission($perm)) {
                if ($secs === null) { $duration = null; break; } // unlimited
                if ($duration === -1 || $secs > $duration) $duration = $secs;
            }
        }

        if ($duration === -1) {
            $sender->sendMessage('§cVous n\'avez pas de permission de fly (prisma.fly.10/30/60/120/unlimited).');
            return;
        }

        FlyTask::startFly($sender->getName(), $duration);
        $sender->setAllowFlight(true);
        $sender->setFlying(true);

        $msg = $duration === null
            ? '§a[Fly] Activé — §fdurée §aillimitée§f.'
            : '§a[Fly] Activé — §fdurée §a' . FlyTask::formatSeconds($duration) . '§f.';
        $sender->sendMessage($msg);
    }
}
