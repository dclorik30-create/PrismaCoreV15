<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Manage;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use Ramsey\Uuid\Uuid;

class CreateSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("create", "Permet de créer sa faction");
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument("name"),
            new TextArgument("description", true)
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;
        $fManager = Manager::FACTION();

        if ($sender->getFaction() instanceof Faction) {
            FactionMessageEnum::ALREADY_IN_FACTION->sendToPlayer($sender, []);
            return;
        }

        $rawName = trim((string)($args["name"] ?? ""));

        // Retirer les codes couleur §x pour compter les vrais caractères
        $cleanNew = strtolower(preg_replace('/§[0-9a-fklmnorA-FKLMNOR]/', '', $rawName));

        // Bloquer les caractères spéciaux — lettres, chiffres, tirets et underscores uniquement
        if (!preg_match('/^[a-zA-Z0-9_\-]+$/', $cleanNew)) {
            $sender->sendMessage("§cLe nom ne peut contenir que des §elettres§c, §echiffres§c, §e-§c et §e_§c.");
            return;
        }

        if (mb_strlen($cleanNew) < 3) {
            $sender->sendMessage("§cLe nom doit contenir au moins §e3 caractères§c.");
            return;
        }

        if (mb_strlen($cleanNew) > 12) {
            $sender->sendMessage("§cLe nom ne peut pas dépasser §e12 caractères§c.");
            return;
        }

        foreach ($fManager->getFactions() as $existing) {
            $cleanExisting = strtolower(preg_replace('/§[0-9a-fklmnorA-FKLMNOR]/', '', $existing->getName()));
            if ($cleanExisting === $cleanNew) {
                $sender->sendMessage("§cUne faction avec ce nom existe déjà !");
                return;
            }
        }

        $fManager->createFaction(
            Uuid::uuid5(Uuid::NAMESPACE_DNS, $sender->getName())->toString(),
            $rawName,
            $sender,
            $args["description"] ?? ""
        );
    }
}
