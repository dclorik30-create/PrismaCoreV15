<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class SetHomeSubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("sethome", "Définir le home de faction"); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
 $loc = $sender->getLocation(); // Location a getYaw()/getPitch(), pas Position
 $world = $loc->getWorld()->getFolderName();
 $chunkX = $loc->getFloorX() >> 4;
 $chunkZ = $loc->getFloorZ() >> 4;
 $claimOwner = Manager::FACTION()->getClaimOwner($world, $chunkX, $chunkZ);
 if ($claimOwner === null || $claimOwner->getId() !== $faction->getId()) {
 $sender->sendMessage("§cVous devez être dans un claim de votre faction pour définir le home !");
 return;
 }
 $faction->setHome($world, $loc->getX(), $loc->getY(), $loc->getZ(), $loc->getYaw(), $loc->getPitch());
 Manager::FACTION()->save();
 $sender->sendMessage("§aHome de faction défini.");
 }
}
