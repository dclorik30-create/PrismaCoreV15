<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub\args;

use CarailleNoir\libs\CortexPE\Commando\args\StringEnumArgument;
use pocketmine\command\CommandSender;

class PermValueArgument extends StringEnumArgument
{
    protected const VALUES = ["true" => "true", "false" => "false"];

    public function getEnumName(): string { return "faction_perm_value"; }

    public function getTypeName(): string { return "true|false"; }

    public function parse(string $argument, CommandSender $sender): string
    {
        return strtolower($argument);
    }
}
