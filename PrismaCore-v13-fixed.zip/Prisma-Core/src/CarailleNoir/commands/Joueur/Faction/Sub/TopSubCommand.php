<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;

class TopSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("top", "Classement des factions par power");
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 $factions = Manager::FACTION()->getFactions();
 $powers = [];
 foreach ($factions as $f) {
 $total = 0;
 foreach (array_merge([$f->getOwner()], $f->getAll()) as $member) {
 $total += Manager::STATS()->getPower($member);
 }
 $powers[$f->getName()] = $total;
 }
 arsort($powers);

 $sender->sendMessage("§5§l--- Top Faction ---");
 $i = 1;
 foreach (array_slice($powers, 0, 10, true) as $name => $power) {
 $medal = match ($i) { 1 => "§6#1", 2 => "§7#2", 3 => "§c#3", default => "§f#" . $i };
 $sender->sendMessage("{$medal} §f{$name} §7- §5{$power} power");
 $i++;
 }
 }
}
