<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub\args;

use CarailleNoir\libs\CortexPE\Commando\args\StringEnumArgument;
use pocketmine\command\CommandSender;

class PermScopeArgument extends StringEnumArgument
{
    protected const VALUES = ["island" => "island", "ap" => "ap"];

    public function getEnumName(): string { return "faction_perm_scope"; }

    public function getTypeName(): string { return "island|ap"; }

    public function parse(string $argument, CommandSender $sender): string
    {
        return strtolower($argument);
    }
}
