<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub\args;

use CarailleNoir\libs\CortexPE\Commando\args\StringEnumArgument;
use pocketmine\command\CommandSender;

class PermTypeArgument extends StringEnumArgument
{
    protected const VALUES = ["ally" => "ally", "everyone" => "everyone"];

    public function getEnumName(): string { return "faction_perm_type_v2"; }

    public function getTypeName(): string { return "ally|everyone"; }

    public function parse(string $argument, CommandSender $sender): string
    {
        return strtolower($argument);
    }
}
