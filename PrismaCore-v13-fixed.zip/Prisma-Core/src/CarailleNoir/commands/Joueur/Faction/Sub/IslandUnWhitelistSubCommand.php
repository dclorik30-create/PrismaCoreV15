<?php
declare(strict_types=1);

namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class IslandUnWhitelistSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("isunwl", "Retirer un joueur de la whitelist de l'île", [], []);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("player", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $faction = $sender->getFaction();
        if (!$faction instanceof Faction) {
            $sender->sendMessage("§cVous n'avez pas de faction.");
            return;
        }

        if ($faction->getOwner() !== $sender->getName()) {
            $sender->sendMessage("§cSeul le chef peut gérer la whitelist de l'île.");
            return;
        }

        $target = trim((string)($args["player"] ?? ""));
        if ($target === "") {
            $sender->sendMessage("§cUsage : §f/f isunwl <joueur>");
            return;
        }

        if ($faction->removeIslandWhitelist($target)) {
            Manager::FACTION()->save();
            $sender->sendMessage("§a" . $target . " §fa été retiré de la whitelist de votre île.");
        } else {
            $sender->sendMessage("§e" . $target . " §fn'était pas dans la whitelist de votre île.");
        }
    }
}
