<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\world\Position;

class HomeSubCommand extends BaseSubCommand {
 public function __construct() { parent::__construct("home", "Téléportation au home de faction"); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $faction = $sender->getFaction();
 if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
 $home = $faction->getHome();
 if ($home === null) { $sender->sendMessage("§cVotre faction n'a pas encore de home."); return; }
 $wm = Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded($home['world'])) {
 $wm->loadWorld($home['world']);
 }
 $world = $wm->getWorldByName($home['world']);
 if ($world === null) { $sender->sendMessage("§cLe monde du home est introuvable."); return; }
 $sender->teleport(Position::fromObject(new \pocketmine\math\Vector3((float)$home['x'], (float)$home['y'], (float)$home['z']), $world, (float)($home['yaw'] ?? 0), (float)($home['pitch'] ?? 0)));
 $sender->sendMessage("§aTéléportation au home de faction.");
 }
}
