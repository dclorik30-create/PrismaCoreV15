<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Manage;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class DisbandSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("disband", "Permet de supprimer sa faction", ["del"]);
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;
 $fManager = Manager::FACTION();
 $faction = $sender->getFaction();

 if (!$faction instanceof Faction) {
 FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []);

 return;
 }

 if ($faction->getOwner() !== $sender->getName()) {
 FactionMessageEnum::NOT_OWNER->sendToPlayer($sender, []);
 return;
 }
 $server = Server::getInstance();

 foreach ($faction->getAll() as $member) {
 $player = $server->getPlayerExact($member);
 if ($player instanceof PrismaPlayer && $player->isOnline()) {
 $player->setFaction("Aucune");
 FactionMessageEnum::KICK_FACTION->sendToPlayer($player, []);
 }else {
 $data = $server->getOfflinePlayerData($member);
 $data?->setString("factionId", "Aucune");
 $server?->saveOfflinePlayerData($member, $data);
 }

 }

 $o = $server->getPlayerExact($faction->getOwner());
 if ($o instanceof PrismaPlayer) {
 $o->sendMessage(FactionMessageEnum::DISBAND_FACTION->value);
 }
 // Reset la faction du chef
 $sender->setFaction("Aucune");
 $fManager->deleteFaction($faction->getId());
 }
}