<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Niveau;

use CarailleNoir\form\level\MainForm;
use CarailleNoir\managers\Manager;
use pocketmine\command\Command;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class NiveauCommand extends Command
{
    public function __construct() {
        parent::__construct("niveau", "Ouvre le menu de niveaux", "/niveau", ["niv", "level"]);
        $this->setPermission("prisma.command.niveau");
    }

    public function execute(CommandSender $sender, string $commandLabel, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCommande réservée aux joueurs.");
            return;
        }

        // Sous-commande admin : /niveau set <joueur> <niveau> [exp]
        if (
            isset($args[0]) &&
            strtolower($args[0]) === "set" &&
            $sender->hasPermission("prisma.admin.niveau")
        ) {
            $this->handleSet($sender, $args);
            return;
        }

        $sender->sendForm(new MainForm(Manager::LEVEL(), Manager::LEVEL_REWARD(), $sender));
    }

    private function handleSet(Player $sender, array $args): void
    {
        if (!isset($args[1], $args[2])) {
            $sender->sendMessage("§cUsage : /niveau set <joueur> <niveau> [exp]");
            return;
        }
        $targetName = $args[1];
        $level      = max(1, min(100, (int)$args[2]));
        $exp        = isset($args[3]) ? max(0, (int)$args[3]) : 0;

        Manager::LEVEL()->setLevel($targetName, $level, $exp);

        $target = $sender->getServer()->getPlayerExact($targetName);
        if ($target instanceof Player) {
            Manager::LEVEL()->save($target->getName());
            $target->sendMessage("§8[§6Niveau§8] §fVotre niveau a été défini à §6{$level}§f par un admin.");
        }
        $sender->sendMessage("§8[§6Admin§8] §fNiveau de §e{$targetName}§f défini à §6{$level} §f(EXP: §e{$exp}§f).");
    }
}