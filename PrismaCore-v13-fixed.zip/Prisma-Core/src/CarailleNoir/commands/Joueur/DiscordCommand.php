<?php
namespace CarailleNoir\commands\Joueur;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
class DiscordCommand extends BaseCommand {
 public function __construct() { parent::__construct("discord", "Lien du Discord", [], [], ["prisma.command.discord"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 $sender->sendMessage(TextUtils::PREFIX . " §fLien Discord : §bdiscord.gg/VOTRE_DISCORD");
 }
}
