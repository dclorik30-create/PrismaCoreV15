<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\invmenu\PlaytimeMenu;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\PlaytimeManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class PlaytimeCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct('playtime', 'Voir votre temps de jeu', [], [], ['prisma.command.ec']);
    }

    protected function prepare(): array
    {
        return [
            new RawStringArgument('action', true),
            new RawStringArgument('value1', true),
            new RawStringArgument('value2', true),
        ];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $sub = strtolower((string)($args['action'] ?? ''));

        if ($sub === 'add') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.'); return;
            }
            $palier = (int)($args['value1'] ?? 0);
            if ($palier < 1) { $sender->sendMessage('§cPalier invalide (minutes > 0).'); return; }
            $item = clone $sender->getInventory()->getItemInHand();
            if ($item->isNull()) { $sender->sendMessage('§cTenez l\'item en main.'); return; }
            Manager::PLAYTIME()->setMilestone($palier, $item);
            $sender->sendMessage('§aPalier §f' . PlaytimeManager::formatSeconds($palier * 60) . ' §aenregistré : §f' . ($item->getCustomName() !== '' ? $item->getCustomName() : $item->getName()) . ' §7x' . $item->getCount());
            return;
        }

        if ($sub === 'remove') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.'); return;
            }
            $palier = (int)($args['value1'] ?? 0);
            if ($palier < 1) { $sender->sendMessage('§cPalier invalide.'); return; }
            Manager::PLAYTIME()->removeMilestone($palier);
            $sender->sendMessage('§aPalier §f' . $palier . 'min §asupprimé.');
            return;
        }

        if ($sub === 'advance') {
            if (!Server::getInstance()->isOp($sender->getName())) {
                $sender->sendMessage('§cCommande réservée aux OP.'); return;
            }
            $target  = trim((string)($args['value1'] ?? ''));
            $minutes = max(1, (int)($args['value2'] ?? 1));
            if ($target === '') { $sender->sendMessage('§cUsage : /playtime advance <player> <minutes>'); return; }
            Manager::PLAYTIME()->addMinutes($target, $minutes);
            $sender->sendMessage('§a+' . $minutes . 'min ajoutées à §f' . $target . '§a.');
            return;
        }

        PlaytimeMenu::send($sender);
    }
}
