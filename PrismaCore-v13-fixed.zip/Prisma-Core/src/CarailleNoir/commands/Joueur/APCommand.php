<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\world\Position;

class APCommand extends BaseCommand
{
    private const DESTINATIONS = [
        'nord'  => ['world' => 'Map', 'x' => 0,    'y' => 58, 'z' => -308],
        'sud'   => ['world' => 'Map', 'x' => 0,    'y' => 59, 'z' => 308],
        'est'   => ['world' => 'Map', 'x' => 308,  'y' => 58, 'z' => 0],
        'ouest' => ['world' => 'Map', 'x' => -308, 'y' => 57, 'z' => 0],
    ];

    private const COLORS = [
        'nord'  => '§b',
        'sud'   => '§c',
        'est'   => '§a',
        'ouest' => '§6',
    ];

    public function __construct()
    {
        parent::__construct('ap', 'Se teleporter a un avant-poste', [], [], ['prisma.command.ap']);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument('direction', true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        if (empty($args['direction'])) {
            $sender->sendMessage('§8- §6§lAvant-Postes §8-');
            foreach (self::DESTINATIONS as $name => $dest) {
                $color = self::COLORS[$name];
                $sender->sendMessage("  {$color}/ap {$name}");
            }
            $sender->sendMessage('§8-§8-§8-§8-§8-§8-§8-§8-§8-§8-§8-§8-');
            return;
        }

        $choice = strtolower(trim((string) $args['direction']));
        if (!isset(self::DESTINATIONS[$choice])) {
            $sender->sendMessage('§cDestination inconnue. Choix : §f' . implode('§7, §f', array_keys(self::DESTINATIONS)));
            return;
        }

        $dest  = self::DESTINATIONS[$choice];
        $color = self::COLORS[$choice];
        $wm    = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($dest['world'])) $wm->loadWorld($dest['world']);
        $world = $wm->getWorldByName($dest['world']);
        if ($world === null) {
            $sender->sendMessage('§cMonde introuvable : §f' . $dest['world']);
            return;
        }

        $sender->teleport(new Position((float) $dest['x'], (float) $dest['y'], (float) $dest['z'], $world));
        $sender->sendMessage("§8[§6AP§8] §fTeleportation vers l'avant-poste {$color}{$choice}§f !");
    }
}
