<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Economy;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class MyMoneyCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("mymoney", "Voir votre argent", [], ["balance", "solde"], ["prisma.command.mymoney"]);
 }

 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $money = Manager::ECONOMY()->getMoney($sender->getName());
 $sender->sendMessage("§6Votre solde §8» §f" . number_format($money, 2) . "§6$");
 }
}
