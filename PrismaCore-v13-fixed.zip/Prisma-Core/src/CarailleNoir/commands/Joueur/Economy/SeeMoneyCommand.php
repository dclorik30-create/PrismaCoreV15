<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Economy;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class SeeMoneyCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("seemoney", "Voir l'argent d'un joueur", [], [], ["prisma.command.seemoney"]);
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(false, "player")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $target = \pocketmine\Server::getInstance()->getPlayerExact($args["player"]);
 if (!$target instanceof PrismaPlayer) {
 $sender->sendMessage("§cJoueur introuvable ou hors-ligne !");
 return;
 }
 $money = Manager::ECONOMY()->getMoney($target->getName());
 $sender->sendMessage("§6Argent de §f{$target->getName()} §8» §f" . number_format($money, 2) . "§6$");
 }
}
