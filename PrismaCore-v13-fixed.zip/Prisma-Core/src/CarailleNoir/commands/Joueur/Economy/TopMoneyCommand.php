<?php
namespace CarailleNoir\commands\Joueur\Economy;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopMoneyCommand extends BaseCommand {
 public function __construct() { parent::__construct("topmoney", "Top argent", [], [], ["prisma.command.topmoney"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 $top = Manager::ECONOMY()->getTopMoney(10);
 $sender->sendMessage("§6§l--- TOP MONEY ---");
 $i = 1;
 foreach ($top as $name => $data) {
 $sender->sendMessage("§e#{$i} §f{$name} §7— §a" . number_format($data["money"] ?? 0, 2) . "§6$");
 $i++;
 }
 }
}
