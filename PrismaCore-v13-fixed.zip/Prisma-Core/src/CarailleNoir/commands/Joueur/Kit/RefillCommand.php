<?php
namespace CarailleNoir\commands\Joueur\Kit;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class RefillCommand extends BaseCommand
{
 public function __construct() { parent::__construct("refill", "Refill rapide (soupes + pearls)", [], [], ["prisma.command.refill"]); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $refused = Manager::KIT()->giveKit($sender, "refill");
 $sender->sendMessage("§aRefill effectué !");
 }
}
