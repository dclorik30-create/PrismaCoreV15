<?php
namespace CarailleNoir\commands\Joueur\Kit;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;

class KitCommand extends BaseCommand
{
 public function __construct() { parent::__construct("kit", "Récupérer un kit", [], [], ["prisma.command.kit"]); }
 protected function prepare(): array { return []; }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;
 $kits = Manager::KIT()->getKits();
 $kitIds = array_keys($kits);
 if (empty($kits)) { $sender->sendMessage("§cAucun kit disponible."); return; }

 $sender->sendForm(new class($kits, $kitIds, $sender->getName()) implements Form {
 public function __construct(private array $kits, private array $kitIds, private string $pName) {}

 public function jsonSerialize(): array
 {
 $btns = [];
 foreach ($this->kits as $id => $kit) {
 $hasCd = Manager::KIT()->hasCooldown($this->pName, $id);
 $cdLine = $hasCd ? "\n§cCooldown: §f" . Manager::KIT()->getCooldownRemaining($this->pName, $id) . "s" : "\n§aDispo";
 $btns[] = ["text" => "§6" . ($kit["name"] ?? $id) . $cdLine];
 }
 return ["type" => "form", "title" => "§6§lKITS", "content" => "§fChoisissez un kit :", "buttons" => $btns];
 }

 public function handleResponse(\pocketmine\player\Player $player, mixed $data): void
 {
 if (!$player instanceof PrismaPlayer || $data === null) return;
  $kitId = (is_int($data) || is_float($data)) ? ($this->kitIds[(int)$data] ?? null) : null;
 if ($kitId === null) return;
 if (Manager::KIT()->hasCooldown($player->getName(), $kitId)) {
 $player->sendMessage("§cCooldown : §f" . Manager::KIT()->getCooldownRemaining($player->getName(), $kitId) . "s");
 return;
 }
 $refused = Manager::KIT()->giveKit($player, $kitId);
 $kit = Manager::KIT()->getKit($kitId);
 $player->sendMessage("§aKit §f" . ($kit["name"] ?? $kitId) . " §areçu !");
 if (!empty($refused)) {
 $player->sendMessage("§7(Limite atteinte pour : §f" . implode(", ", array_column($refused, "item")) . "§7)");
 }
 }
 });
 }
}