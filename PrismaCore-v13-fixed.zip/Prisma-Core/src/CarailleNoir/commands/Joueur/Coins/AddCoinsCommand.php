<?php
namespace CarailleNoir\commands\Joueur\Coins;
use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
class AddCoinsCommand extends BaseCommand {
 public function __construct() { parent::__construct("addcoins", "Ajouter des coins à un joueur", [], [], [DefaultPermissions::ROOT_OPERATOR]); }
 protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new IntegerArgument("amount")]; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  $name   = $args["player"];
  $amount = (int)$args["amount"];
  if ($amount <= 0) { $sender->sendMessage("§cMontant invalide !"); return; }
  if (!Manager::COINS()->playerExists($name)) { $sender->sendMessage("§cJoueur §f{$name} §cinconnu ! Il doit s'être connecté au moins une fois."); return; }
  Manager::COINS()->addCoins($name, $amount);
  $sender->sendMessage("§a+ §f{$amount} §6Coins §aajoutés à §f{$name} §7(total : §e" . Manager::COINS()->getCoins($name) . "§7)");
  $online = \pocketmine\Server::getInstance()->getPlayerExact($name);
  if ($online !== null) {
   $online->sendMessage("§8[§6Coins§8] §aVous avez reçu §f{$amount} §6Coins §ade la part du staff !");
  }
 }
}
