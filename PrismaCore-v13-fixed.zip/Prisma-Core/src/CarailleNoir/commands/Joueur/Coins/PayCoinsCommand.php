<?php
namespace CarailleNoir\commands\Joueur\Coins;
use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class PayCoinsCommand extends BaseCommand {
 public function __construct() { parent::__construct("paycoins", "Envoyer des coins à un joueur", [], [], ["prisma.command.paycoins"]); }
 protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new IntegerArgument("amount")]; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 if (!$sender instanceof PrismaPlayer) return;
 $target = \pocketmine\Server::getInstance()->getPlayerExact($args["player"]);
 $amount = (int)$args["amount"];
 if ($amount <= 0) { $sender->sendMessage("§cMontant invalide !"); return; }
 if (!$target instanceof PrismaPlayer) { $sender->sendMessage("§cJoueur introuvable !"); return; }
 if (!$sender->removeCoins($amount)) { $sender->sendMessage("§cVous n'avez pas assez de coins !"); return; }
 $target->addCoins($amount);
 $sender->sendMessage("§aVous avez envoyé §f{$amount} §6coins §aà §f{$target->getName()}");
 $target->sendMessage("§aVous avez reçu §f{$amount} §6coins §ade §f{$sender->getName()}");
 }
}
