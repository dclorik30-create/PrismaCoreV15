<?php

namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\lang\Translatable;
use pocketmine\Server;

class PingCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("ping", "Permet de voir les ping d'un joueur", [], ["ms"]);
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(true, "playerName")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 if (empty($args)) {
 $sender->sendMessage("Vous avez actuellement §6{$sender->getNetworkSession()->getPing()}§rms");
 return;
 }

 $targetName = $args["playerName"];
 $target = Server::getInstance()->getPlayerExact($targetName);
 $sender->sendMessage($target === null ? "Le joueur $targetName n'est pas connecté" : "Le joueur $targetName à actuellement §6{$target->getNetworkSession()->getPing()}§rms");
 }
}