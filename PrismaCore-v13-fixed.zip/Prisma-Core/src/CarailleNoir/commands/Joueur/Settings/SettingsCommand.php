<?php
namespace CarailleNoir\commands\Joueur\Settings;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\SettingsManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
class SettingsCommand extends BaseCommand {
 public function __construct() { parent::__construct("settings", "Gérer vos paramètres", [], [], ["prisma.command.settings"]); }
 protected function prepare(): array { return [new RawStringArgument("setting", true)]; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  if (!$sender instanceof PrismaPlayer) return;
  $validSettings = [
   SettingsManager::SETTING_SCOREBOARD  => "Scoreboard",
   SettingsManager::SETTING_NIGHTVISION => "Night Vision",
   SettingsManager::SETTING_CPS         => "Compteur CPS",
  ];
  if (!isset($args["setting"])) {
   $sender->sendMessage("§6--- Vos paramètres ---");
   foreach ($validSettings as $key => $label) {
    $val = Manager::SETTINGS()->getSetting($sender->getName(), $key);
    $sender->sendMessage("§e/settings {$key} §7— {$label} : " . ($val ? "§aActivé" : "§cDésactivé"));
   }
   return;
  }
  $setting = strtolower($args["setting"]);
  if (!isset($validSettings[$setting])) { $sender->sendMessage("§cParamètre invalide ! Valides : " . implode(", ", array_keys($validSettings))); return; }
  $newVal = Manager::SETTINGS()->toggleSetting($sender->getName(), $setting);
  $sender->sendMessage("§a" . $validSettings[$setting] . " : " . ($newVal ? "§aActivé" : "§cDésactivé"));
  if ($setting === SettingsManager::SETTING_NIGHTVISION) {
   if ($newVal) $sender->getEffects()->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), 999999, 0, false, false));
   else $sender->getEffects()->remove(VanillaEffects::NIGHT_VISION());
  }
 }
}
