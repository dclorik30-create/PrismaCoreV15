<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopAssistCommand extends BaseCommand {
 public function __construct() { parent::__construct("topassist", "Top assists", [], [], ["prisma.command.topassist"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  $sender->sendMessage("§6§l--- TOP ASSISTS ---");
  $i = 1;
  foreach (Manager::STATS()->getTopAssists(10) as $name => $data) {
   $assists = $data["assists"] ?? 0;
   $sender->sendMessage("§e#{$i} §f{$name} §7— §e{$assists} assists");
   $i++;
  }
 }
}
