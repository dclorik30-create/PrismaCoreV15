<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopKillStreakCommand extends BaseCommand {
 public function __construct() { parent::__construct("topkillstreak", "Top kill streaks", [], [], ["prisma.command.topkillstreak"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  $sender->sendMessage("§6§l--- TOP KILLSTREAK ---");
  $i = 1;
  foreach (Manager::STATS()->getTopKillStreak(10) as $name => $data) {
   $streak = $data["bestkillstreak"] ?? 0;
   $sender->sendMessage("§e#{$i} §f{$name} §7— §c{$streak} streak");
   $i++;
  }
 }
}
