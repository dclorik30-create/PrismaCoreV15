<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopNiveauCommand extends BaseCommand {
 public function __construct() { parent::__construct("topniveau", "Top niveaux", [], [], ["prisma.command.topniveau"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
  $sender->sendMessage("§6§l--- TOP NIVEAU ---");
  $all = Manager::LEVEL_DATA()->getAllLevels();
  arsort($all);
  $top = array_slice($all, 0, 10, true);
  $i = 1;
  foreach ($top as $name => $lvl) {
   $sender->sendMessage("§e#{$i} §f{$name} §7— §aNiveau §f{$lvl}");
   $i++;
  }
 }
}
