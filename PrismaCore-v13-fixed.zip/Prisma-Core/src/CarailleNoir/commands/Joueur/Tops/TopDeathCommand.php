<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopDeathCommand extends BaseCommand {
 public function __construct() { parent::__construct("topdeath", "Top morts", [], [], ["prisma.command.topdeath"]); }
 protected function prepare(): array { return []; }
 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
 $sender->sendMessage("§6§l--- TOP MORTS ---");
 $i = 1;
 foreach (Manager::STATS()->getTopDeaths(10) as $name => $data) {
 $sender->sendMessage("§e#{$i} §f{$name} §7— §c{$data["deaths"]} morts"); $i++;
 }
 }
}
