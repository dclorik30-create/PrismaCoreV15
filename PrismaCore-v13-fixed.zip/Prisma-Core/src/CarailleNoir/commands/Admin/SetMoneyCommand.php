<?php
namespace CarailleNoir\commands\Admin;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\FloatArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class SetMoneyCommand extends BaseCommand
{
 public function __construct()
 {
  parent::__construct("setmoney", "Définir l'argent d'un joueur", [], [], ["prisma.command.setmoney"]);
 }

 protected function prepare(): array
 {
  return [
   new RawStringArgument("joueur"),
   new FloatArgument("montant"),
  ];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
  $targetName = $args["joueur"] ?? null;
  $amount = (float)($args["montant"] ?? -1);

  if ($targetName === null) { $sender->sendMessage("§cUsage : §f/setmoney <joueur> <montant>"); return; }
  if ($amount < 0) { $sender->sendMessage("§cLe montant doit être ≥ 0 !"); return; }

  $target = Server::getInstance()->getPlayerByPrefix($targetName);
  $name = $target !== null ? $target->getName() : $targetName;

  if (!Manager::ECONOMY()->playerExists($name)) {
   $sender->sendMessage("§cJoueur §f{$name} §cinconnu ! Il doit s'être connecté au moins une fois.");
   return;
  }

  $old = Manager::ECONOMY()->getMoney($name);
  Manager::ECONOMY()->setMoney($name, $amount);

  $sender->sendMessage("§6Argent de §f{$name} §6défini à §f" . number_format($amount, 2) . "§6\$ §7(ancien: §f" . number_format($old, 2) . "§6\$§7)");
  if ($target !== null) $target->sendMessage("§6Votre argent a été §fdéfini à §f" . number_format($amount, 2) . "§6\$ §6par §f" . $sender->getName() . "§6.");
 }
}
