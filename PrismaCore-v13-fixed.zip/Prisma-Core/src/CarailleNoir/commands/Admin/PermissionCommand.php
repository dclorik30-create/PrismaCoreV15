<?php

namespace CarailleNoir\commands\Admin;

use CarailleNoir\commands\Admin\Sub\Permission\PlayerSubCommand;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class PermissionCommand extends BaseCommand
{
 public function __construct()
 {
 parent::__construct("permission", "Gerer les permissions", [
 new PlayerSubCommand()
 ]);
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer) return;

 }

}
