<?php

namespace CarailleNoir\commands\Admin\Sub\Region;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class DeleteSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("delete", "Delete une regions");
 }

 protected function prepare(): array
 {
 return [new RawStringArgument("id")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 Manager::REGION()->deleteRegion($sender, $args["id"]);
 }
}