<?php

namespace CarailleNoir\commands\Admin\Sub\Region;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;
use pocketmine\world\Position;

class TpSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("tp", "Permet de ce téléporter à une région.", ["teleport"]);
 }

 protected function prepare(): array
 {
 return [new RawStringArgument("RegionId")];
 }
 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;
 $regionId = $args["RegionId"];

 $data = Manager::REGION()->getRegionById($regionId);
 if (is_null($data)) {
 $sender->sendMessage("§cLa région §6{$regionId}§a n'existe pas !");
 return;
 }

 $zone = $data->getZone();
 $world = Server::getInstance()->getWorldManager()->getWorldByName($data->getWorldName());

 if (is_null($world)) {
 $sender->sendMessage("§cLe monde §6{$data->getWorldName()}§c n'existe pas ou bien n'est pas chargé !");
 return;
 }
 $pos = new Position($zone->minX+0.5, $zone->minY+1, $zone->minZ+0.5, $world);
 $sender->teleport($pos);
 }
}