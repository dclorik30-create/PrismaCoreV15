<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Admin\Sub\Outpost;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

/**
 * /setoutpost <x1> <y1> <z1> <x2> <y2> <z2>
 * Exemple : /setoutpost 100 64 100 150 80 150
 */
class SetOutpostCommand extends BaseCommand
{
 /** @var array<string, array{0:int,1:int,2:int}> playerName => pos1 en attente */
 private static array $pending = [];

 public function __construct()
 {
 parent::__construct("setoutpost", "Définir la zone de l'Outpost", [], [], ["prisma.command.staff"]);
 }

 protected function prepare(): array
 {
 return [];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer) { $sender->sendMessage("§cIngame only."); return; }

 // Mode : /setoutpost pos1 → /setoutpost pos2
 $name = $sender->getName();
 $pos = $sender->getPosition();

 if (!isset(self::$pending[$name])) {
 self::$pending[$name] = [(int)$pos->getX(), (int)$pos->getY(), (int)$pos->getZ()];
 $sender->sendMessage("§e[Outpost] §fPos1 enregistrée : " . implode(", ", self::$pending[$name]) . "\n§7Fais à nouveau §e/setoutpost §7pour définir la Pos2.");
 return;
 }

 [$x1, $y1, $z1] = self::$pending[$name];
 unset(self::$pending[$name]);
 $world = $pos->getWorld()->getFolderName();
 Manager::OUTPOST()->setZone($world, $x1, $y1, $z1, (int)$pos->getX(), (int)$pos->getY(), (int)$pos->getZ());
 $sender->sendMessage("§a[Outpost] §fZone définie dans §e{$world}§f : [{$x1},{$y1},{$z1}] → [{$pos->getX()},{$pos->getY()},{$pos->getZ()}]");
 }
}
