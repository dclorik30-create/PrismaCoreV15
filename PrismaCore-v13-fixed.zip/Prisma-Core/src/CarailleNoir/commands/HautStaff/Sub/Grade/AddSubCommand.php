<?php

namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\args\OptionArgument;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class AddSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("add", "Ajouter un grade au joueur", [], [], DefaultPermissions::ROOT_OPERATOR);
 }

 protected function prepare(): array
 {
 return [new TargetPlayerArgument(false, "playerName"), new RawStringArgument("identifier")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
 {
 if (!$sender instanceof PrismaPlayer)return;

 $playerName = $args["playerName"];
 $identifier = $args["identifier"];

 if (!Manager::ALIAS()->hasProfil($playerName)) {
 $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
 return;
 }

 if (!Manager::GRADE()->existGrade($identifier)) {
 $sender->sendMessage("§cLe grade avec l'ID {$identifier} n'existe pas !");
 return;
 }

 Manager::GRADE()->addGrade($sender, $identifier, $playerName);
 }

}