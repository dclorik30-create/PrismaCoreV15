<?php

namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class CreateSubCommand extends BaseSubCommand
{
 public function __construct()
 {
 parent::__construct("create", "Permet de créer un grade", [], [], DefaultPermissions::ROOT_OPERATOR);
 }

 protected function prepare(): array
 {
 return [new RawStringArgument("identifier"), new RawStringArgument("name"), new RawStringArgument("color")];
 }

 public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
 {
 $identifier = $args["identifier"];
 $name = $args["name"];
 $color = $args["color"];

 if (Manager::GRADE()->existGrade($identifier)) {
 $sender->sendMessage("Un grade avec l'identifiant {$identifier} existe déjà");
 return;
 }

 Manager::GRADE()->createGrade($identifier, $name, $color);
 $sender->sendMessage("Le grade {$name} a été créé avec l'identifiant {$identifier} et la couleur {$color}'couleur'");
 }
}