<?php

namespace CarailleNoir\libs\CortexPE\Commando\args;

use pocketmine\command\CommandSender;
use pocketmine\network\mcpe\protocol\types\command\CommandHardEnum;

abstract class ArrayEnumArgument extends BaseArgument {

 /** @var array<string, mixed> */
 protected array $value = [];

 public function __construct(
 string $name,
 string $enumName,
 array $option = [],
 bool $isOptional = false
 ) {
 parent::__construct($name, $isOptional);

 foreach ($option as $key => $val) {
 if (is_int($key)) {
 $this->addValue($val, $val);
 } else {
 $this->addValue($key, $val);
 }
 }

 $this->getNetworkParameterData()->enum = new CommandHardEnum($enumName, $this->getEnumValues());
 }

 public function getTypeName(): string {
 return 'enum';
 }

 public function getNetworkType() : int {
 return -1;
 }

 public function canParse(string $testString, CommandSender $sender) : bool {
 return isset($this->value[strtolower($testString)]);
 }

 public function addValue(string $name, mixed $value) : void {
 $this->value[strtolower($name)] = $value;
 }

 public function getValues(string $string) : mixed {
 return $this->value[strtolower($string)] ?? null;
 }

 /**
 * @return string[]
 */
 public function getEnumValues() : array {
 return array_keys($this->value);
 }
}
