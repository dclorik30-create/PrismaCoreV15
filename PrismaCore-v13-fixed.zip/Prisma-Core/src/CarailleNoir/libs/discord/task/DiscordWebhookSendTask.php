<?php

namespace CarailleNoir\libs\discord\task;

use CarailleNoir\libs\discord\Embed;
use pocketmine\scheduler\AsyncTask;
use pocketmine\scheduler\Task;
use CarailleNoir\libs\discord\Message;

class DiscordWebhookSendTask extends AsyncTask
{
 private string $webhookUrl;

 private string $messageJson;

 public function __construct(string $webhookUrl, string $messageJson)
 {
 $this->webhookUrl = $webhookUrl;
 $this->messageJson = $messageJson;
 }

 public function onRun(): void
 {
 $messageData = json_decode($this->messageJson, true);

 $message = new Message();

 if (isset($messageData['content'])) {
 $message->setContent($messageData['content']);
 }

 if (isset($messageData['username'])) {
 $message->setUsername($messageData['username']);
 }

 if (isset($messageData['avatar_url'])) {
 $message->setAvatarURL($messageData['avatar_url']);
 }

 if (isset($messageData['tts'])) {
 $message->setTextToSpeech($messageData['tts']);
 }

 if (isset($messageData['embeds']) && is_array($messageData['embeds'])) {
 foreach ($messageData['embeds'] as $embedData) {
 $embed = new Embed();
 if (isset($embedData['title'])) {
 $embed->setTitle($embedData['title']);
 }

 if (isset($embedData['color'])) {
 $embed->setColor($embedData['color']);
 }

 if (isset($embedData['author'])) {
 $author = $embedData['author'];
 if (isset($author['name'])) {
 $embed->setAuthor(
 $author['name'],
 $author['url'] ?? null,
 $author['icon_url'] ?? null
 );
 }
 }

 if (isset($embedData['description'])) {
 $embed->setDescription($embedData['description']);
 }

 if (isset($embedData['fields']) && is_array($embedData['fields'])) {
 foreach ($embedData['fields'] as $field) {
 if (isset($field['name']) && isset($field['value'])) {
 $embed->addField($field['name'], $field['value'], $field['inline'] ?? false);
 }
 }
 }

 if (isset($embedData['footer'])) {
 $footer = $embedData['footer'];
 if (isset($footer['text'])) {
 $embed->setFooter(
 $footer['text'],
 $footer['icon_url'] ?? null
 );
 }
 }

 $message->addEmbed($embed);
 }
 }

 $ch = curl_init($this->webhookUrl);
 curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($message));
 curl_setopt($ch, CURLOPT_POST, true);
 curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
 curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, false);
 curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false);
 curl_setopt($ch, CURLOPT_HTTPHEADER, ["Content-Type: application/json"]);

 $result = curl_exec($ch);
 $responseCode = curl_getinfo($ch, CURLINFO_RESPONSE_CODE);
 curl_close($ch);
 }

 public function onCompletion(): void
 {

 }
}
