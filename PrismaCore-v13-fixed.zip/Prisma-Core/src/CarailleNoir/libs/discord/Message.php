<?php

namespace CarailleNoir\libs\discord;

class Message implements \JsonSerializable {
 /** @var array */
 protected $data = [];

 public function setContent(string $content): void{
 $this->data["content"] = $content;
 }

 public function getContent(): ?string{
 return $this->data["content"];
 }

 public function setUsername(string $username): void{
 $this->data["username"] = $username;
 }

 public function getUsername(): ?string{
 return $this->data["username"];
 }

 public function setAvatarURL(string $avatarURL): void{
 $this->data["avatar_url"] = $avatarURL;
 }

 public function getAvatarURL(): ?string{
 return $this->data["avatar_url"];
 }

 public function setTextToSpeech(bool $ttsEnabled): void{
 $this->data["tts"] = $ttsEnabled;
 }

 public function addEmbed(Embed $embed): void {
 $this->data["embeds"][] = $embed->asArray();
 }

 public function jsonSerialize(): array {
 return $this->data;
 }
}
