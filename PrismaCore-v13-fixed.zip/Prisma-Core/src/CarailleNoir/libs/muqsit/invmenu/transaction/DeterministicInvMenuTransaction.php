<?php

declare(strict_types=1);

namespace CarailleNoir\libs\muqsit\invmenu\transaction;

use Closure;
use pocketmine\inventory\transaction\action\SlotChangeAction;
use pocketmine\inventory\transaction\InventoryTransaction;
use pocketmine\item\Item;
use pocketmine\player\Player;

final class DeterministicInvMenuTransaction implements InvMenuTransaction{

	public function __construct(
		readonly private InvMenuTransaction $inner,
		readonly private InvMenuTransactionResult $result
	){}

	/**
	 * Retourne silencieusement le résultat déjà commis.
	 * (ne pas throw : PlayerVaults peut rappeler cette méthode sur une transaction
	 * déjà résolue via InvMenu::readonly(), ce qui provoquerait un crash serveur)
	 */
	public function continue() : InvMenuTransactionResult{
		return $this->result;
	}

	public function discard() : InvMenuTransactionResult{
		return $this->result;
	}

	public function then(?Closure $callback) : void{
		$this->result->then($callback);
	}

	public function getPlayer() : Player{
		return $this->inner->getPlayer();
	}

	public function getOut() : Item{
		return $this->inner->getOut();
	}

	public function getIn() : Item{
		return $this->inner->getIn();
	}

	public function getItemClicked() : Item{
		return $this->inner->getItemClicked();
	}

	public function getItemClickedWith() : Item{
		return $this->inner->getItemClickedWith();
	}

	public function getAction() : SlotChangeAction{
		return $this->inner->getAction();
	}

	public function getTransaction() : InventoryTransaction{
		return $this->inner->getTransaction();
	}
}
