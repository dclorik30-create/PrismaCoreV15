<?php

declare(strict_types=1);

namespace CarailleNoir\libs\muqsit\invmenu\session\network\handler;

use Closure;
use CarailleNoir\libs\muqsit\invmenu\session\network\NetworkStackLatencyEntry;

interface PlayerNetworkHandler{

	public function createNetworkStackLatencyEntry(Closure $then) : NetworkStackLatencyEntry;
}