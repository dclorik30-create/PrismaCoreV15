<?php

namespace CarailleNoir\managers\option\Faction;

enum FactionRoleEnum: string {

 case OWNER = "owner";
 case SUB_OWNER = "subOwner";
 case OFFICIERS = "officers";
 case MEMBERS = "members";
 case RECRUITS = "recruits";

 public function getPriority(): int {
 return match($this) {
 self::RECRUITS => 1,
 self::MEMBERS => 2,
 self::OFFICIERS => 3,
 self::SUB_OWNER => 4,
 self::OWNER => 5,
 };
 }

 public function getBetterRank(): self
 {
 return match ($this) {
 self::RECRUITS => self::MEMBERS,
 self::MEMBERS => self::OFFICIERS,
 self::OFFICIERS => self::SUB_OWNER,
 self::SUB_OWNER,
 self::OWNER => self::OWNER,
 };
 }

 public function getLowerRank(): self
 {
 return match ($this) {
 self::RECRUITS => self::RECRUITS,
 self::MEMBERS => self::RECRUITS,
 self::OFFICIERS => self::MEMBERS,
 self::SUB_OWNER => self::OFFICIERS,
 self::OWNER => self::OWNER,
 };
 }
}
