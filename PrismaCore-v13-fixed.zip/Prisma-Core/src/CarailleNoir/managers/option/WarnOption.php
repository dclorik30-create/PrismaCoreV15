<?php
declare(strict_types=1);
namespace CarailleNoir\managers\option;

enum WarnOption
{
 const THRESHOLD_MESSAGE = 5;
 const THRESHOLD_BAN = 10;
 const THRESHOLD_BLACKLIST = 20;

 const SANCTION_MESSAGE = "Limite d'avertissements atteinte";
 const ALERT_MESSAGE = "§c⚠ Attention — vous approchez de la limite d'avertissements.";
 const BASE_MESSAGE = "§cVous avez reçu un avertissement.";
}
