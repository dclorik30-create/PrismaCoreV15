<?php
declare(strict_types=1);
namespace CarailleNoir\managers;

/**
 * Suit tous les attaquants récents (fenêtre de 60 s) pour chaque victime.
 * Permet de déduire les assists lors d'un kill PvP.
 */
class AssistTracker
{
    public const WINDOW = 60; // secondes

    /**
     * @var array<string, array<string, int>>
     *  victim_lower → [ attacker_lower => timestamp ]
     */
    private static array $hits = [];

    /** Enregistre un coup porté sur $victim par $attacker. */
    public static function recordHit(string $victim, string $attacker): void
    {
        $v = strtolower($victim);
        $a = strtolower($attacker);
        if ($v === $a) return;
        self::$hits[$v][$a] = time();
    }

    /**
     * Retourne les noms (casse originale préservée si possible) des joueurs
     * qui ont frappé $victim dans les 60 dernières secondes, hors $killer.
     *
     * @return string[]
     */
    public static function getAssists(string $victim, string $killer): array
    {
        $v   = strtolower($victim);
        $k   = strtolower($killer);
        $now = time();

        if (!isset(self::$hits[$v])) return [];

        $assists = [];
        foreach (self::$hits[$v] as $attacker => $ts) {
            if ($attacker === $k) continue;
            if (($now - $ts) <= self::WINDOW) {
                $assists[] = $attacker; // noms en lowercase (stockés ainsi)
            }
        }
        unset(self::$hits[$v]);
        return $assists;
    }

    /** Nettoie les données d'un joueur (mort, déco, etc.). */
    public static function clear(string $victim): void
    {
        unset(self::$hits[strtolower($victim)]);
    }
}
