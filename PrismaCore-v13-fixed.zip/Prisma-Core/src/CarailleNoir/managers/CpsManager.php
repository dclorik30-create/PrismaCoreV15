<?php
declare(strict_types=1);
namespace CarailleNoir\managers;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\SettingsManager;
use pocketmine\player\Player;
use pocketmine\Server;

class CpsManager
{
    private const MAX_CPS        = 20;
    private const TIP_THROTTLE   = 0.1;
    private const ALERT_COOLDOWN = 5.0; // secondes minimum entre 2 alertes OP pour le même joueur

    /** @var array<string, float[]> */
    private static array $clicks         = [];
    /** @var array<string, float> */
    private static array $lastTip        = [];
    /** @var array<string, int> dernier CPS max signalé aux OPs */
    private static array $lastAlertedMax = [];
    /** @var array<string, float> timestamp de la dernière alerte envoyée */
    private static array $lastAlertTime  = [];

    public static function addClick(Player $player): void
    {
        $name = $player->getName();
        $now  = microtime(true);

        self::$clicks[$name][] = $now;
        self::$clicks[$name]   = array_values(array_filter(
            self::$clicks[$name],
            static fn(float $t): bool => ($now - $t) <= 1.0
        ));

        $cps = count(self::$clicks[$name]);

        // Affichage CPS si setting actif
        if (Manager::SETTINGS()->getSetting($name, SettingsManager::SETTING_CPS)) {
            if (!isset(self::$lastTip[$name]) || ($now - self::$lastTip[$name]) >= self::TIP_THROTTLE) {
                self::$lastTip[$name] = $now;
                $player->sendTip("§cCPS : §f" . $cps);
            }
        }

        // Alerte OP : seulement si > MAX_CPS, cooldown respecté, nouveau pic ET pas en whitelist
        if ($cps > self::MAX_CPS && !Manager::ALERT_WHITELIST()->isWhitelisted($name)) {
            $lastMax   = self::$lastAlertedMax[$name] ?? 0;
            $lastAlert = self::$lastAlertTime[$name]  ?? 0.0;
            $cooldownOk = ($now - $lastAlert) >= self::ALERT_COOLDOWN;

            if ($cps > $lastMax || $cooldownOk) {
                // Envoyer uniquement si nouveau pic OU cooldown écoulé
                if ($cps > $lastMax || ($cooldownOk && $cps > self::MAX_CPS)) {
                    self::$lastAlertedMax[$name] = $cps;
                    self::$lastAlertTime[$name]  = $now;
                    $ping = $player->getNetworkSession()->getPing();
                    $msg  = "§8[§cAntiCheat§8] §f{$name} "
                          . "§7CPS superieur a " . self::MAX_CPS
                          . " §8| §cCPS Max §f{$cps}"
                          . " §8| §cPing §f{$ping}";
                    foreach (Server::getInstance()->getOnlinePlayers() as $op) {
                        if (Server::getInstance()->isOp($op->getName())) {
                            $op->sendMessage($msg);
                        }
                    }
                }
            }
        } else {
            unset(self::$lastAlertedMax[$name], self::$lastAlertTime[$name]);
        }
    }

    public static function getCps(string $name): int
    {
        if (!isset(self::$clicks[$name])) return 0;
        $now = microtime(true);
        self::$clicks[$name] = array_values(array_filter(
            self::$clicks[$name],
            static fn(float $t): bool => ($now - $t) <= 1.0
        ));
        return count(self::$clicks[$name]);
    }

    public static function remove(string $name): void
    {
        unset(
            self::$clicks[$name],
            self::$lastTip[$name],
            self::$lastAlertedMax[$name],
            self::$lastAlertTime[$name]
        );
    }
}