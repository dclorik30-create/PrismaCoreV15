<?php
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;

class OfflinePlayerDataManager extends DataHandler
{
 public function init(): void
 {
  $this->loadData("OfflinePlayerData");
 }

 public function savePlayerData(PrismaPlayer $player): void
 {
  $uid = $player->getUniqueId()->toString();
  $this->data[$uid] = [
   "freeze"      => $player->isFreeze(),
   "permissions" => $player->getPermissions()
  ];
 }

 public function loadPlayerData(PrismaPlayer $player): void
 {
  $uid = $player->getUniqueId()->toString();
  if (isset($this->data[$uid])) {
   $player->loadOfflineData($this->data[$uid]);
  }
  $player->setCurrentRegionId(Manager::REGION()->getMainRegionAt($player->getPosition()));
 }

 /**
  * Retourne les données d'un joueur hors-ligne par son nom (clé lowercase).
  * Utilisé par InvseeCommand / EcSeeCommand pour lire/écrire l'inventaire.
  */
 public function getPlayerData(string $player): array
 {
  return (array)($this->data[strtolower($player)] ?? []);
 }

 /**
  * Écrit les données d'un joueur hors-ligne par son nom.
  */
 public function setPlayerData(string $player, array $data): void
 {
  $this->data[strtolower($player)] = $data;
 }

 /** Alias de saveData() pour les appels existants dans les commandes. */
 public function save(): void
 {
  $this->saveData();
 }
}
