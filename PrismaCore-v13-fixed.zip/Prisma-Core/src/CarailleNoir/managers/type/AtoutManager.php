<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class AtoutManager extends DataHandler
{
 // Atouts : speed, force, resis, antiitem
 public function init(): void
 {
 $this->loadData("Atout");
 }

 public function hasAtout(string $player, string $atout): bool
 {
 return in_array($atout, $this->data[strtolower($player)] ?? [], true);
 }

 public function addAtout(string $player, string $atout): void
 {
 $key = strtolower($player);
 if (!isset($this->data[$key])) $this->data[$key] = [];
 if (!in_array($atout, $this->data[$key], true)) {
 $this->data[$key][] = $atout;
 }
 }

 public function removeAtout(string $player, string $atout): void
 {
 $key = strtolower($player);
 $this->data[$key] = array_values(array_filter($this->data[$key] ?? [], fn($a) => $a !== $atout));
 }

 public function getAtouts(string $player): array
 {
 return $this->data[strtolower($player)] ?? [];
 }

 public function hasAntiItemProtection(string $player): bool
 {
 return $this->hasAtout($player, "antiitem");
 }
}
