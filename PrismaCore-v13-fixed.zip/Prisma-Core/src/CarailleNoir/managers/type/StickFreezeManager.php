<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;
/**
 * Stick Freeze PVP — SÉPARÉ du /freeze staff (PrismaPlayer::freeze).
 * Bloque le mouvement via PlayerMoveEvent::cancel().
 * La victime PEUT recevoir des dégâts.
 */
class StickFreezeManager {
 private array $frozen = [];
 public function freeze(string $p, int $d=15): void { $this->frozen[strtolower($p)]=time()+$d; }
 public function isFrozen(string $p): bool {
 $k=strtolower($p);
 if(!isset($this->frozen[$k])) return false;
 if(time()>$this->frozen[$k]){unset($this->frozen[$k]);return false;}
 return true;
 }
 public function getRemaining(string $p): int { return max(0,($this->frozen[strtolower($p)]??0)-time()); }
 public function unfreeze(string $p): void { unset($this->frozen[strtolower($p)]); }
}
