<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;
use CarailleNoir\utils\Utils;

class GradeManager extends DataHandler
{

 public function init(): void
 {
 $this->loadData("Grade");
 }

 public function createGrade(string $identifier, string $name, string $color): void
 {
 $colorCode = Utils::parseColor($color);

 $this->data[$identifier] = [
 "name" => $name,
 "color" => $colorCode,
 "permissions" => [],
 "players" => []
 ];

 $this->saveData();
 }

 public function deleteGrade(string $identifier): void
 {
 if ($this->existGrade($identifier)) {
 unset($this->data[$identifier]);
 $this->saveData();
 }
 }

 public function existGrade(string $identifier): bool
 {
 return isset($this->data[$identifier]);
 }

 public function addGrade(PrismaPlayer $sender, string $identifier, string $player): void
 {
 if (!$this->existGrade($identifier)) {
 $sender->sendMessage("§cLe grade avec l'ID {$identifier} n'existe pas !");
 return;
 }

 $this->removeGrade($sender, $player, false);
 $this->data[$identifier]["players"][] = $player;

  $this->notifyPlayer($player);
 $sender->sendMessage("§aGrade ajouter au joueur");
 }

 public function removeGrade(PrismaPlayer $sender, string $player, bool $resetDefault = true): void
 {
 foreach ($this->data as $id => &$grade) {
 if (in_array($player, $grade["players"], true)) {
 $grade["players"] = array_diff($grade["players"], [$player]);
 $sender->sendMessage("§aGrade {$grade["name"]} retirer à {$player}");
 if ($resetDefault) {
 $this->setDefaultGrade($player);
 }
 }
 }


 }

 public function getPlayerGradeData(string $player): ?array
 {
 foreach ($this->data as $id => $grade) {
 if (in_array($player, $grade["players"], true)) {
 return [
 "color" => $grade["color"],
 "name" => $grade["name"],
 "id" => $id,
 "permissions" => $grade["permissions"]
 ];
 }
 }
 return null;
 }

 public function setDefaultGrade(string $player): void
 {
 $gradeData = $this->getPlayerGradeData($player);

 if ($gradeData === null) {
 if (!$this->existGrade("joueur")){
 $this->createGrade("joueur", "Joueur", "§f");
 }
 $this->data["joueur"]["players"][] = $player;
 }
 }

 /**
 * Retire le grade du joueur sans nécessiter un PrismaPlayer $sender.
 * Remet le grade Joueur par défaut.
 * Utilisé pour l'expiration automatique du grade Vote.
 */
 public function removeGradeOffline(string $player): void
 {
 foreach ($this->data as $id => &$grade) {
 $grade["players"] = array_values(array_filter(
 $grade["players"],
 fn($p) => strtolower($p) !== strtolower($player)
 ));
 }
 unset($grade);
 $this->setDefaultGrade($player);
 $this->saveData();
 $this->notifyPlayer($player);
 }

 public function getGrades(): ?array
 {
 return $this->data ?? null;
 }

 /** Notifie le joueur en ligne pour rafraîchir nametag + scoreboard */
 private function notifyPlayer(string $playerName): void
 {
  $online = Server::getInstance()->getPlayerExact($playerName);
  if ($online instanceof PrismaPlayer) {
   $online->invalidateGradeCache();
  }
 }
}