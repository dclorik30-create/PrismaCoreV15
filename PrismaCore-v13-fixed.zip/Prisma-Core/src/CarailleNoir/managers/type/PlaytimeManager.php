<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\utils\TextFormat;

class PlaytimeManager extends DataHandler
{
    /** @var array<string, int> sessions en mémoire playerName => timestamp start */
    private array $sessions = [];

    public function init(): void
    {
        $this->loadData('Playtime');
        $this->data['milestones'] ??= [];
        $this->data['players']   ??= [];
    }

    // ── Sessions ──────────────────────────────────────────────────────────

    public function startSession(string $player): void
    {
        $key = strtolower($player);
        $this->ensurePlayer($player);
        // Reset journalier si nouveau jour
        $today = date('Y-m-d');
        $state = &$this->data['players'][$key];
        if (($state['last_day'] ?? '') !== $today) {
            $state['daily_seconds']  = 0;
            $state['claimed_daily']  = [];
            $state['last_day']       = $today;
        }
        $this->sessions[$key] = time();
    }

    public function endSession(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->sessions[$key])) return;
        $elapsed = time() - $this->sessions[$key];
        unset($this->sessions[$key]);
        $this->addSeconds($player, $elapsed);
    }

    /** Appelé chaque minute par PlaytimeTask pour sauvegarde intermédiaire */
    public function flushSessions(): void
    {
        $now = time();
        foreach ($this->sessions as $key => $start) {
            $elapsed = $now - $start;
            $this->sessions[$key] = $now; // reset le départ
            $this->addSecondsRaw($key, $elapsed);
        }
        $this->saveData();
    }

    private function addSeconds(string $player, int $seconds): void
    {
        $this->addSecondsRaw(strtolower($player), $seconds);
        $this->saveData();
    }

    private function addSecondsRaw(string $key, int $seconds): void
    {
        $this->ensurePlayerByKey($key);
        $today = date('Y-m-d');
        $state = &$this->data['players'][$key];
        if (($state['last_day'] ?? '') !== $today) {
            $state['daily_seconds'] = 0;
            $state['claimed_daily'] = [];
            $state['last_day']      = $today;
        }
        $state['total_seconds'] = (int)($state['total_seconds'] ?? 0) + $seconds;
        $state['daily_seconds'] = (int)($state['daily_seconds'] ?? 0) + $seconds;
    }

    /** Pour /playtime advance */
    public function addMinutes(string $player, int $minutes): void
    {
        $this->addSeconds($player, $minutes * 60);
    }

    // ── Ensure ────────────────────────────────────────────────────────────

    private function ensurePlayer(string $player): void
    {
        $this->ensurePlayerByKey(strtolower($player));
    }

    private function ensurePlayerByKey(string $key): void
    {
        if (!isset($this->data['players'][$key])) {
            $this->data['players'][$key] = [
                'total_seconds' => 0,
                'daily_seconds' => 0,
                'last_day'      => date('Y-m-d'),
                'claimed'       => [],
                'claimed_daily' => [],
            ];
        }
    }

    // ── Getters ───────────────────────────────────────────────────────────

    public function getPlayerState(string $player): array
    {
        $this->ensurePlayer($player);
        return $this->data['players'][strtolower($player)];
    }

    public function getTotalSeconds(string $player): int
    {
        return (int)($this->getPlayerState($player)['total_seconds'] ?? 0);
    }

    public function getDailySeconds(string $player): int
    {
        $this->startSessionIfNeeded($player);
        return (int)($this->getPlayerState($player)['daily_seconds'] ?? 0);
    }

    private function startSessionIfNeeded(string $player): void
    {
        $key = strtolower($player);
        if (isset($this->sessions[$key])) {
            // flush en mémoire sans sauvegarder pour avoir valeur en temps réel
            $elapsed = time() - $this->sessions[$key];
            $this->sessions[$key] = time();
            $this->addSecondsRaw($key, $elapsed);
        }
    }

    public static function formatSeconds(int $seconds): string
    {
        if ($seconds < 60)  return $seconds . 's';
        if ($seconds < 3600) return floor($seconds / 60) . 'min';
        $h = floor($seconds / 3600);
        $m = floor(($seconds % 3600) / 60);
        return $m > 0 ? "{$h}h{$m}min" : "{$h}h";
    }

    // ── Milestones ────────────────────────────────────────────────────────

    public function setMilestone(int $minutes, Item $item): void
    {
        $this->data['milestones'][(string)$minutes] = $this->serializeItem($item);
        $this->saveData();
    }

    public function removeMilestone(int $minutes): void
    {
        unset($this->data['milestones'][(string)$minutes]);
        $this->saveData();
    }

    public function getMilestones(): array
    {
        $out = [];
        foreach ($this->data['milestones'] as $min => $raw) {
            $out[(int)$min] = $this->deserializeItem($raw);
        }
        ksort($out);
        return $out;
    }

    public function getMilestone(int $minutes): ?Item
    {
        $raw = $this->data['milestones'][(string)$minutes] ?? null;
        return $raw !== null ? $this->deserializeItem($raw) : null;
    }

    public function canClaim(string $player, int $minutes): bool
    {
        $state = $this->getPlayerState($player);
        if (in_array($minutes, $state['claimed'] ?? [], true)) return false;
        return $this->getTotalSeconds($player) >= $minutes * 60
            && $this->getMilestone($minutes) !== null;
    }

    public function hasClaimed(string $player, int $minutes): bool
    {
        return in_array($minutes, $this->getPlayerState($player)['claimed'] ?? [], true);
    }

    public function claim(string $player, int $minutes): ?Item
    {
        if (!$this->canClaim($player, $minutes)) return null;
        $item = $this->getMilestone($minutes);
        if ($item === null) return null;
        $key = strtolower($player);
        $this->data['players'][$key]['claimed'][] = $minutes;
        $this->saveData();
        return $item;
    }

    // ── Serialization ─────────────────────────────────────────────────────

    private function serializeItem(Item $item): array
    {
        $serializer = new BigEndianNbtSerializer();
        return [
            'count'   => $item->getCount(),
            'name'    => $item->getCustomName(),
            'lore'    => $item->getLore(),
            'nbt_b64' => base64_encode($serializer->write(new TreeRoot($item->nbtSerialize()))),
        ];
    }

    private function deserializeItem(array $data): ?Item
    {
        $nbt = $data['nbt_b64'] ?? null;
        if (is_string($nbt) && $nbt !== '') {
            try {
                $serializer = new BigEndianNbtSerializer();
                return Item::nbtDeserialize($serializer->read(base64_decode($nbt))->mustGetCompoundTag());
            } catch (\Throwable) {}
        }
        $item = VanillaItems::PAPER();
        if (($data['name'] ?? '') !== '') $item->setCustomName((string)$data['name']);
        $item->setCount((int)($data['count'] ?? 1));
        $item->setLore($data['lore'] ?? []);
        return $item;
    }
}
