<?php

declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\utils\TextFormat;

class DailyManager extends DataHandler
{
    private const TOTAL_DAYS = 45;

    public function init(): void
    {
        $this->loadData('Daily');
        $this->data['rewards'] ??= [];
        $this->data['players'] ??= [];
    }

    public function getTotalDays(): int { return self::TOTAL_DAYS; }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        $today = date('Y-m-d');

        if (!isset($this->data['players'][$key])) {
            $this->data['players'][$key] = [
                'day'           => 1,
                'lastClaimDate' => '',
                'claimedToday'  => false,
            ];
            return;
        }

        $state = &$this->data['players'][$key];
        $last  = $state['lastClaimDate'] ?? '';

        if ($last === $today) return; // même jour, rien à faire

        if ($last !== '') {
            $diff = (int)round((strtotime($today) - strtotime($last)) / 86400);
            if ($diff > 1) {
                // streak cassée → reset
                $state['day']          = 1;
                $state['claimedToday'] = false;
                $state['lastClaimDate'] = '';
                return;
            }
            // diff == 1 : nouveau jour consécutif
            if ((bool)($state['claimedToday'] ?? false)) {
                // avancer au jour suivant seulement si le joueur avait bien réclamé hier
                $state['day'] = (int)$state['day'] >= self::TOTAL_DAYS ? 1 : (int)$state['day'] + 1;
            }
        }

        $state['claimedToday'] = false;
    }

    public function setReward(int $day, Item $item): void
    {
        if ($day < 1 || $day > self::TOTAL_DAYS) return;
        $this->data['rewards'][(string)$day] = $this->serializeItem($item);
        $this->saveData();
    }

    public function removeReward(int $day): void
    {
        unset($this->data['rewards'][(string)$day]);
        $this->saveData();
    }

    public function advanceDay(string $player, int $amount = 1): array
    {
        $this->ensurePlayer($player);
        $key   = strtolower($player);
        $state = &$this->data['players'][$key];
        $total = self::TOTAL_DAYS;
        for ($i = 0; $i < max(1, $amount); $i++) {
            $state['day'] = (int)$state['day'] >= $total ? 1 : (int)$state['day'] + 1;
        }
        $state['claimedToday']  = false;
        $state['lastClaimDate'] = date('Y-m-d', strtotime('-1 day'));
        $this->saveData();
        return $this->data['players'][$key];
    }

    public function getReward(int $day): ?Item
    {
        $raw = $this->data['rewards'][(string)$day] ?? null;
        if (!is_array($raw)) return null;
        return $this->deserializeItem($raw);
    }

    public function getPlayerState(string $player): array
    {
        $this->ensurePlayer($player);
        return $this->data['players'][strtolower($player)];
    }

    public function canClaimDay(string $player, int $day): bool
    {
        $state = $this->getPlayerState($player);
        return !(bool)$state['claimedToday']
            && (int)$state['day'] === $day
            && $this->getReward($day) !== null;
    }

    public function hasClaimedDay(string $player, int $day): bool
    {
        $state = $this->getPlayerState($player);
        $currentDay    = (int)$state['day'];
        $claimedToday  = (bool)$state['claimedToday'];

        if ($day < $currentDay) return true;
        if ($day === $currentDay && $claimedToday) return true;
        return false;
    }

    public function claim(string $player): ?Item
    {
        $this->ensurePlayer($player);
        $key   = strtolower($player);
        $state = &$this->data['players'][$key];

        if ((bool)$state['claimedToday']) return null;

        $day    = (int)$state['day'];
        $reward = $this->getReward($day);
        if ($reward === null) return null;

        $state['claimedToday']  = true;
        $state['lastClaimDate'] = date('Y-m-d');
        // NE PAS incrémenter day ici — c'est ensurePlayer() qui le fera le lendemain
        $this->saveData();
        return $reward;
    }

    private function serializeItem(Item $item): array
    {
        $nbt        = $item->nbtSerialize();
        $serializer = new BigEndianNbtSerializer();
        return [
            'id'      => $item->getVanillaName(),
            'count'   => $item->getCount(),
            'name'    => $item->getCustomName(),
            'lore'    => $item->getLore(),
            'nbt_b64' => base64_encode($serializer->write(new TreeRoot($nbt))),
        ];
    }

    private function deserializeItem(array $data): ?Item
    {
        $nbt = $data['nbt_b64'] ?? null;
        if (is_string($nbt) && $nbt !== '') {
            try {
                $serializer = new BigEndianNbtSerializer();
                $root       = $serializer->read(base64_decode($nbt));
                return Item::nbtDeserialize($root->mustGetCompoundTag());
            } catch (\Throwable) {}
        }
        $item = VanillaItems::PAPER();
        if (($data['name'] ?? '') !== '') $item->setCustomName((string)$data['name']);
        $item->setCount((int)($data['count'] ?? 1));
        $item->setLore($data['lore'] ?? []);
        return $item;
    }
}
