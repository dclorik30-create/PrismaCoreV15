<?php

declare(strict_types=1);

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\PrismaItems\items\key\DieuKey;
use CarailleNoir\PrismaItems\items\key\HerosKey;
use CarailleNoir\PrismaItems\items\key\NobleKey;
use CarailleNoir\PrismaItems\items\key\VoteKey;
use pocketmine\item\Item;
use pocketmine\player\Player;

class BoxManager
{
    /** @var array<string, array> */
    private array $boxes = [];

    /**
     * Clés en attente pour les joueurs hors-ligne au moment de la victoire.
     * Structure : ['playerNameLower' => ['noble', 'dieu', ...]]
     * @var array<string, list<string>>
     */
    private array $pendingKeys = [];
    private string $pendingKeysFile = '';

    private static array $defaultBoxes = [
        "vote" => ["name" => "§aBoîte Vote", "color" => "§a", "loots" => [
            ["item" => "gold_ingot", "amount" => 16, "chance" => 40, "display" => "§6Lingot d'Or x16"],
            ["item" => "diamond", "amount" => 4, "chance" => 25, "display" => "§bDiamant x4"],
            ["item" => "emerald", "amount" => 8, "chance" => 20, "display" => "§2Emeraude x8"],
            ["item" => "iron_ingot", "amount" => 32, "chance" => 15, "display" => "§7Lingot de Fer x32"]
        ]],
        "noble" => ["name" => "§9Boîte Noble", "color" => "§9", "loots" => [
            ["item" => "diamond", "amount" => 8, "chance" => 35, "display" => "§bDiamant x8"],
            ["item" => "gold_ingot", "amount" => 32, "chance" => 30, "display" => "§6Lingot d'Or x32"],
            ["item" => "emerald", "amount" => 16, "chance" => 25, "display" => "§2Emeraude x16"],
            ["item" => "iron_block", "amount" => 4, "chance" => 10, "display" => "§7Bloc de Fer x4"]
        ]],
        "heros" => ["name" => "§cBoîte Héros", "color" => "§c", "loots" => [
            ["item" => "diamond_block", "amount" => 2, "chance" => 30, "display" => "§bBloc de Diamant x2"],
            ["item" => "diamond", "amount" => 16, "chance" => 30, "display" => "§bDiamant x16"],
            ["item" => "emerald", "amount" => 32, "chance" => 25, "display" => "§2Emeraude x32"],
            ["item" => "gold_block", "amount" => 4, "chance" => 15, "display" => "§6Bloc d'Or x4"]
        ]],
        "dieu" => ["name" => "§6Boîte Dieu", "color" => "§6", "loots" => [
            ["item" => "diamond_block", "amount" => 4, "chance" => 30, "display" => "§bBloc de Diamant x4"],
            ["item" => "netherite_ingot","amount" => 2, "chance" => 25, "display" => "§8Netherite x2"],
            ["item" => "emerald_block", "amount" => 4, "chance" => 25, "display" => "§2Bloc d'Emeraude x4"],
            ["item" => "gold_block", "amount" => 8, "chance" => 20, "display" => "§6Bloc d'Or x8"]
        ]]
    ];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "boxes.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode(self::$defaultBoxes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
        }
        $content = file_get_contents($path);
        $this->boxes = json_decode($content, true) ?? self::$defaultBoxes;

        $this->pendingKeysFile = Core::getInstance()->getDataFolder() . "pending_keys.json";
        if (file_exists($this->pendingKeysFile)) {
            $this->pendingKeys = json_decode(file_get_contents($this->pendingKeysFile), true) ?? [];
        }
    }

    /**
     * Enregistre une clé à donner au joueur lors de sa prochaine connexion.
     * Appelé quand le joueur est hors-ligne au moment de la victoire.
     */
    public function addPendingKey(string $playerName, string $boxId): void
    {
        $key = strtolower($playerName);
        $this->pendingKeys[$key][] = $boxId;
        file_put_contents($this->pendingKeysFile, json_encode($this->pendingKeys, JSON_PRETTY_PRINT));
        Core::getInstance()->getLogger()->info("[BoxManager] Clé '{$boxId}' mise en attente pour '{$playerName}' (hors-ligne au moment de la victoire).");
    }

    /**
     * Distribue les clés en attente au joueur qui vient de se connecter.
     * Appeler depuis PlayerListener::onJoin().
     */
    public function deliverPendingKeys(Player $player): void
    {
        $key = strtolower($player->getName());
        if (empty($this->pendingKeys[$key])) return;

        foreach ($this->pendingKeys[$key] as $boxId) {
            $item = $this->makeKeyItem($boxId);
            if ($item !== null) {
                $player->getInventory()->addItem($item);
                $player->sendMessage("\u00a76[Event] \u00a7fTu avais remporté le TOTEM alors que tu étais hors-ligne. Ta clé \u00a7e" . strtoupper($boxId) . "\u00a7f t'a été remise !");
                Core::getInstance()->getLogger()->info("[BoxManager] Clé '{$boxId}' remise à '{$player->getName()}' au login.");
            }
        }

        unset($this->pendingKeys[$key]);
        file_put_contents($this->pendingKeysFile, json_encode($this->pendingKeys, JSON_PRETTY_PRINT));
    }

    public function save(): void
    {
        $path = Core::getInstance()->getDataFolder() . "boxes.json";
        file_put_contents($path, json_encode($this->boxes, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES));
    }

    public function getBox(string $id): ?array
    {
        return $this->boxes[strtolower($id)] ?? null;
    }

    public function getBoxes(): array
    {
        return $this->boxes;
    }

    public function rollLoot(string $boxId): ?array
    {
        $box = $this->getBox($boxId);
        if ($box === null) return null;

        $rand = mt_rand(1, 100);
        $cumul = 0;
        foreach ($box["loots"] as $loot) {
            $cumul += $loot["chance"];
            if ($rand <= $cumul) return $loot;
        }
        return $box["loots"][array_key_last($box["loots"])] ?? null;
    }

    public function makeKeyItem(string $boxId): ?Item
    {
        $boxId = strtolower($boxId);
        return match ($boxId) {
            'vote' => new VoteKey(),
            'noble' => new NobleKey(),
            'heros' => new HerosKey(),
            'dieu' => new DieuKey(),
            default => null,
        };
    }

    public function isKey(Item $item, string $boxId): bool
    {
        $id = $this->getKeyBoxId($item);
        return $id !== null && strtolower($id) === strtolower($boxId);
    }

    public function getKeyBoxId(Item $item): ?string
    {
        foreach ($item->getLore() as $line) {
            if (str_contains($line, 'item_key_vote')) return 'vote';
            if (str_contains($line, 'item_key_noble')) return 'noble';
            if (str_contains($line, 'item_key_heros')) return 'heros';
            if (str_contains($line, 'item_key_dieu')) return 'dieu';
        }
        return null;
    }
}
