<?php

namespace CarailleNoir\managers\type;

class PearlManager
{
 /** @var array<string, int> player => timestamp */
 private array $pearlCooldowns = [];
 /** @var array<string, int> player => expire_timestamp (Anti-Pearl stick) */
 private array $antiPearlEffects = [];

 private const PEARL_COOLDOWN = 10; // secondes

 public function hasCooldown(string $player): bool
 {
 $key = strtolower($player);
 return isset($this->pearlCooldowns[$key]) && (time() - $this->pearlCooldowns[$key]) < self::PEARL_COOLDOWN;
 }

 public function getCooldownRemaining(string $player): int
 {
 $key = strtolower($player);
 if (!isset($this->pearlCooldowns[$key])) return 0;
 return max(0, self::PEARL_COOLDOWN - (time() - $this->pearlCooldowns[$key]));
 }

 public function setCooldown(string $player): void
 {
 $this->pearlCooldowns[strtolower($player)] = time();
 }

 /** Anti-Pearl stick : empêche de pearl pendant $duration secondes */
 public function applyAntiPearl(string $player, int $duration = 10): void
 {
 $this->antiPearlEffects[strtolower($player)] = time() + $duration;
 }

 public function hasAntiPearl(string $player): bool
 {
 $key = strtolower($player);
 if (!isset($this->antiPearlEffects[$key])) return false;
 if (time() > $this->antiPearlEffects[$key]) {
 unset($this->antiPearlEffects[$key]);
 return false;
 }
 return true;
 }

 public function getAntiPearlRemaining(string $player): int
 {
 $key = strtolower($player);
 return max(0, ($this->antiPearlEffects[$key] ?? 0) - time());
 }
}
