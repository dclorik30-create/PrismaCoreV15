<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\tasks\ScoreboardTask;
use pocketmine\Server;

class CoinsManager extends DataHandler
{
 public function init(): void
 {
  $this->loadData("Coins");
 }

 public function getCoins(string $player): int
 {
  return (int)($this->data[strtolower($player)]["coins"] ?? 0);
 }

 public function setCoins(string $player, int|float $amount): void
 {
  $this->data[strtolower($player)]["coins"] = max(0, (int)$amount);
  $this->triggerRefresh($player);
 }

 public function addCoins(string $player, int|float $amount): void
 {
  $this->setCoins($player, $this->getCoins($player) + (int)$amount);
 }

 public function removeCoins(string $player, int|float $amount): bool
 {
  $current = $this->getCoins($player);
  if ($current < (int)$amount) return false;
  $this->setCoins($player, $current - (int)$amount);
  return true;
 }

 public function hasCoins(string $player, int|float $amount): bool
 {
  return $this->getCoins($player) >= (int)$amount;
 }

 public function ensurePlayer(string $player): void
 {
  $key = strtolower($player);
  if (!isset($this->data[$key])) {
   $this->data[$key] = ["coins" => 0];
  }
 }

 private function triggerRefresh(string $player): void
 {
  $online = Server::getInstance()->getPlayerExact($player);
  if ($online instanceof PrismaPlayer) {
   ScoreboardTask::refresh($online);
  }
 }
}
