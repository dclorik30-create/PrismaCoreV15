<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class AlertWhitelistManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("AlertWhitelist");
        $this->ensure();
    }

    private function ensure(): void
    {
        if (!isset($this->data["players"]) || !is_array($this->data["players"])) {
            $this->data["players"] = [];
        }
    }

    public function add(string $player): void
    {
        $this->ensure();
        $lower = strtolower($player);
        if (!in_array($lower, $this->data["players"], true)) {
            $this->data["players"][] = $lower;
            $this->saveData();
        }
    }

    public function remove(string $player): void
    {
        $this->ensure();
        $lower = strtolower($player);
        $this->data["players"] = array_values(
            array_filter($this->data["players"], static fn(string $n) => $n !== $lower)
        );
        $this->saveData();
    }

    public function isWhitelisted(string $player): bool
    {
        $this->ensure();
        return in_array(strtolower($player), $this->data["players"], true);
    }

    public function getAll(): array
    {
        $this->ensure();
        return $this->data["players"];
    }
}
