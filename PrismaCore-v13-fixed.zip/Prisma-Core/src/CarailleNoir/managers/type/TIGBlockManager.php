<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use pocketmine\block\BlockTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\World;

class TIGBlockManager
{
 private array $coordinates = []; // [["x"=>int,"y"=>int,"z"=>int], ...]
 private array $bedrockPlacedAt = []; // "x,y,z" => int (timestamp pose bedrock)
 private int $moneyReward = 100;
 private int $bedrockDelay = 15; // secondes avant qu'une bedrock → émeraude

 public function init(): void
 {
 $path = \CarailleNoir\Core::getInstance()->getDataFolder() . "TIGBlocks.json";
 if (!file_exists($path)) {
 \CarailleNoir\Core::getInstance()->saveResource("TIGBlocks.json");
 }
 $raw = json_decode(file_get_contents($path), true) ?? [];
 $this->coordinates = $raw["coordinates"] ?? [];
 $this->moneyReward = (int)($raw["money_reward"] ?? 100);
 $this->bedrockDelay = (int)($raw["bedrock_delay"] ?? 15);
 }

 public function getMoneyReward(): int { return $this->moneyReward; }
 public function getCoordinates(): array { return $this->coordinates; }

 private function key(int $x, int $y, int $z): string { return "$x,$y,$z"; }

 /** Appelé par TIGBlockTask chaque seconde */
 public function tick(): void
 {
 $wm = Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded(TIGManager::TIG_WORLD)) return;
 $world = $wm->getWorldByName(TIGManager::TIG_WORLD);
 if ($world === null) return;

 $now = time();

 foreach ($this->coordinates as $coord) {
 $x = (int)$coord["x"]; $y = (int)$coord["y"]; $z = (int)$coord["z"];
 $key = $this->key($x, $y, $z);
 $vec = new Vector3($x, $y, $z);
 $block = $world->getBlock($vec);
 $tid = $block->getTypeId();

 if ($tid === BlockTypeIds::AIR) {
 // Vide → poser une bedrock et noter le timestamp
 if (!isset($this->bedrockPlacedAt[$key])) {
 $world->setBlock($vec, VanillaBlocks::BEDROCK());
 $this->bedrockPlacedAt[$key] = $now;
 }
 } elseif ($tid === BlockTypeIds::BEDROCK) {
 // Bedrock → convertir en émeraude si délai écoulé
 if (isset($this->bedrockPlacedAt[$key]) && ($now - $this->bedrockPlacedAt[$key]) >= $this->bedrockDelay) {
 $world->setBlock($vec, VanillaBlocks::EMERALD_ORE());
 unset($this->bedrockPlacedAt[$key]);
 }
 }
 // Si c'est déjà EMERALD_ORE → on ne fait rien, on attend que le joueur casse
 }
 }

 /** Appelé depuis PlayerListener quand un joueur casse une émeraude */
 public function notifyBroken(int $x, int $y, int $z): void
 {
 // Le bloc est redevenu AIR par PM5, on efface la trace pour relancer le cycle
 $key = $this->key($x, $y, $z);
 unset($this->bedrockPlacedAt[$key]);
 // Le prochain tick() verra AIR → posera bedrock → après $bedrockDelay → émeraude
 }
}
