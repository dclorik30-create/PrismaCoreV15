<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use pocketmine\world\Position;

class AfkKeyManager
{
    public const REQUIRED_TIME = 180;

    private const REWARDS = [
        ['id' => 'vote',  'weight' => 50],
        ['id' => 'noble', 'weight' => 30],
        ['id' => 'heros', 'weight' => 17],
        ['id' => 'dieu',  'weight' => 3],
    ];

    private ?string $capturingPlayer = null;
    private int     $captureTime     = 0;

    public function hasZone(): bool
    {
        return Manager::EVENT()->getZone('afkkey') !== null;
    }

    public function isInZone(Position $pos): bool
    {
        return Manager::EVENT()->isInEventZone('afkkey', $pos);
    }

    public function enterZone(string $playerName): bool
    {
        if ($this->capturingPlayer === $playerName) return true;
        if ($this->capturingPlayer !== null) return false;
        $this->capturingPlayer = $playerName;
        $this->captureTime     = 0;
        return true;
    }

    public function leaveZone(string $playerName): void
    {
        if ($this->capturingPlayer === $playerName) {
            $this->capturingPlayer = null;
            $this->captureTime     = 0;
        }
    }

    public function isPlayerInZone(string $playerName): bool
    {
        return $this->capturingPlayer === $playerName;
    }

    public function getCapturingPlayer(): ?string { return $this->capturingPlayer; }
    public function getCaptureTime(): int         { return $this->captureTime; }

    public function tick(): array
    {
        if ($this->capturingPlayer === null) return [];
        $this->captureTime++;
        if ($this->captureTime >= self::REQUIRED_TIME) {
            $winner            = $this->capturingPlayer;
            $this->captureTime = 0;
            return [$winner];
        }
        return [];
    }

    public function rollReward(): string
    {
        $r = mt_rand(1, 100);
        $cumulative = 0;
        foreach (self::REWARDS as $reward) {
            $cumulative += $reward['weight'];
            if ($r <= $cumulative) return $reward['id'];
        }
        return 'vote';
    }
}
