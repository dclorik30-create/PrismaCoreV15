<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\permission\PermissionAttachment;

class PermissionManager extends DataHandler
{

 public function init(): void
 {
 $this->loadData("Permission");
 }

 /** @var PermissionAttachment[] */
 private array $attachments = [];

 private function getId(PrismaPlayer $player): string
 {
 return $player->getUniqueId()->toString();
 }

 public function register(PrismaPlayer $player): void
 {
 $id = $this->getId($player);

 if (!isset($this->attachments[$id])) {
 $this->attachments[$id] = $player->addAttachment(Core::getInstance());
 $this->updatePermissions($player);
 }


 }

 public function unregister(PrismaPlayer $player): void
 {
 unset($this->attachments[$this->getId($player)]);
 }

 public function getAttachment(PrismaPlayer $player): ?PermissionAttachment
 {
 $id = $this->getId($player);
 if(!isset($this->attachments[$id])){
 $this->register($player);
 }
 return $this->attachments[$id] ?? null;
 }


 public function getPermissions(PrismaPlayer $player): array
 {
 $gradePerm = Manager::GRADE()->getPlayerGradeData($player->getName())["permissions"] ?? [];
 $playerPerm = $player->getPermissions();

 return array_unique(array_merge($gradePerm, $playerPerm));
 }

 public function updatePermissions(PrismaPlayer $player): void
 {
 if (($attachment = $this->getAttachment($player)) !== null) {
 $attachment->clearPermissions();

 foreach ($this->getPermissions($player) as $perm) {
 $attachment->setPermission($perm, true);
 }
 }
 }
}