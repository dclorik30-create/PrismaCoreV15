<?php
namespace CarailleNoir\managers\type;

use pocketmine\item\StringToItemParser;
use pocketmine\player\Player;

class KitHelper
{
 private const LIMITS = [
 "mushroom_stew" => 64,
 "golden_apple" => 6,
 "ender_pearl" => 16,
 ];

 public static function countInInventory(Player $player, string $itemId): int
 {
 $ref = StringToItemParser::getInstance()->parse($itemId);
 if ($ref === null) return 0;
 $count = 0;
 foreach ($player->getInventory()->getContents() as $item) {
 if ($item->getTypeId() === $ref->getTypeId()) $count += $item->getCount();
 }
 return $count;
 }

 public static function canAdd(Player $player, string $itemId, int $amount = 1): bool
 {
 $limit = self::LIMITS[strtolower($itemId)] ?? PHP_INT_MAX;
 return (self::countInInventory($player, $itemId) + $amount) <= $limit;
 }

 public static function enforceInventoryLimits(Player $player, array $kitItems): array
 {
 $refused = [];
 foreach ($kitItems as $entry) {
 $id = strtolower($entry["item"] ?? "");
 if (!isset(self::LIMITS[$id])) continue;
 if (!self::canAdd($player, $id, (int)($entry["amount"] ?? 1))) $refused[] = $entry;
 }
 return $refused;
 }

 public static function getAddable(Player $player, string $itemId, int $requested): int
 {
 $limit = self::LIMITS[strtolower($itemId)] ?? PHP_INT_MAX;
 $current = self::countInInventory($player, $itemId);
 return max(0, min($requested, $limit - $current));
 }
}
