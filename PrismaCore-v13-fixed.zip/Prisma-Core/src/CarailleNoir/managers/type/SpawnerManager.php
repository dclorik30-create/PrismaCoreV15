<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\entities\vanilla\Zombie;
use pocketmine\entity\Living;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\plugin\Plugin;
use pocketmine\world\Position;
use pocketmine\world\World;

class SpawnerManager
{
 private const SAVE_FILE = "spawners.json";
 private const CLUSTER_RADIUS = 12.0;

 private static array $loots = [
 "zombie" => [["item"=>"rotten_flesh","min"=>1,"max"=>2,"chance"=>100]],
 "skeleton" => [["item"=>"bone", "min"=>1,"max"=>2,"chance"=>100]],
 "creeper" => [["item"=>"gunpowder", "min"=>1,"max"=>2,"chance"=>100]],
 ];
 private static array $prices = ["zombie"=>200,"skeleton"=>200,"creeper"=>300];

 /** @var array<string,array{type:string,world:string,x:int,y:int,z:int}> */
 private array $spawners = [];
 /** @var array<int, string> */
 private array $entityTypeIndex = [];

 private static function key(Position $pos): string
 {
  return $pos->getFloorX().":".$pos->getFloorY().":".$pos->getFloorZ().":".$pos->getWorld()->getFolderName();
 }

 public function register(Position $pos, string $type): void
 {
  $this->spawners[self::key($pos)] = [
   "type" => strtolower($type),
   "world" => $pos->getWorld()->getFolderName(),
   "x" => $pos->getFloorX(),
   "y" => $pos->getFloorY(),
   "z" => $pos->getFloorZ()
  ];
 }

 public function unregister(Position $pos): void
 {
  unset($this->spawners[self::key($pos)]);
 }

 public function isSpawner(Position $pos): bool { return isset($this->spawners[self::key($pos)]); }
 public function getType(Position $pos): ?string { return $this->spawners[self::key($pos)]["type"] ?? null; }
 public function getAllSpawners(): array { return $this->spawners; }

 /** @return array<string,array{type:string,world:string,x:int,y:int,z:int}> */
 public function getSpawnersNear(string $type, World $world, Position $center, float $radius = self::CLUSTER_RADIUS): array
 {
  $out = [];
  $r2 = $radius * $radius;
  foreach ($this->spawners as $key => $data) {
   if ($data['world'] !== $world->getFolderName() || $data['type'] !== strtolower($type)) continue;
   $dx = $data['x'] - $center->getFloorX();
   $dy = $data['y'] - $center->getFloorY();
   $dz = $data['z'] - $center->getFloorZ();
   if (($dx * $dx + $dy * $dy + $dz * $dz) <= $r2) $out[$key] = $data;
  }
  return $out;
 }

 public function findStackableEntity(World $world, string $type, Position $center, float $radius = self::CLUSTER_RADIUS): ?Living
 {
  $r2 = $radius * $radius;
  foreach ($world->getEntities() as $entity) {
   if (!$entity instanceof Living || !$entity->isAlive() || $entity->isFlaggedForDespawn()) continue;
   if (!$this->isSpawnerMobOfType($entity, $type)) continue;
   $dx = $entity->getPosition()->getX() - $center->getX();
   $dy = $entity->getPosition()->getY() - $center->getY();
   $dz = $entity->getPosition()->getZ() - $center->getZ();
   if (($dx * $dx + $dy * $dy + $dz * $dz) <= $r2) return $entity;
  }
  return null;
 }

 public function markEntityType(Living $entity, string $type): void
 {
  $this->entityTypeIndex[$entity->getId()] = strtolower($type);
 }

 public function getSpawnerTypeByEntity(int $eid): ?string
 {
  return $this->entityTypeIndex[$eid] ?? null;
 }

 public function onEntityDeath(int $eid): void
 {
  unset($this->entityTypeIndex[$eid]);
 }

 public function isSpawnerMobOfType(Living $entity, string $type): bool
 {
  $type = strtolower($type);
  return match($type) {
   'zombie' => $entity instanceof Zombie,
   'skeleton' => $entity instanceof Skeleton,
   'creeper' => $entity instanceof Creeper,
   default => false,
  };
 }

 public function rollLoots(string $type, int $stack = 1): array
 {
  $r = [];
  foreach ((self::$loots[strtolower($type)] ?? []) as $l) {
   if (mt_rand(1, 100) <= $l["chance"]) $r[] = ["item" => $l["item"], "amount" => min(mt_rand($l["min"], $l["max"]) * $stack, 64)];
  }
  return $r;
 }

 public function getPrice(string $type): int { return self::$prices[strtolower($type)] ?? 200; }
 public function getAvailableTypes(): array { return array_keys(self::$loots); }
 public function getLootsFor(string $type): array { return self::$loots[strtolower($type)] ?? []; }

 public function makeSpawnerItem(string $type): Item
 {
  $item = StringToItemParser::getInstance()->parse("prisma:{$type}_spawner") ?? VanillaItems::BONE_MEAL();
  $item->setCount(1);
  return $item;
 }

 public function getSpawnerTypeFromItem(Item $item): ?string
 {
  foreach ($item->getLore() as $l) {
   if (str_starts_with($l, "§8ID:spawner_")) return mb_substr($l, 13);
  }
  return null;
 }

 public function buildNametag(string $type, int $stack): string
 {
  return match(strtolower($type)) {
   "zombie" => "§2§lZombie §f§lx{$stack}",
   "skeleton" => "§7§lSquelette §f§lx{$stack}",
   "creeper" => "§a§lCreeper §f§lx{$stack}",
   default => "§f§l" . ucfirst($type) . " §f§lx{$stack}",
  };
 }

 public function save(Plugin $plugin): void
 {
  file_put_contents($plugin->getDataFolder() . self::SAVE_FILE, json_encode(array_values($this->spawners), JSON_PRETTY_PRINT));
 }

 public function load(Plugin $plugin): void
 {
  $path = $plugin->getDataFolder() . self::SAVE_FILE;
  if (!file_exists($path)) return;
  foreach (json_decode(file_get_contents($path), true) ?? [] as $e) {
   if (!isset($e['world'], $e['type'], $e['x'], $e['y'], $e['z'])) continue;
   $key = $e['x'] . ':' . $e['y'] . ':' . $e['z'] . ':' . $e['world'];
   $this->spawners[$key] = [
    'type' => strtolower((string)$e['type']),
    'world' => (string)$e['world'],
    'x' => (int)$e['x'],
    'y' => (int)$e['y'],
    'z' => (int)$e['z']
   ];
  }
 }
}
