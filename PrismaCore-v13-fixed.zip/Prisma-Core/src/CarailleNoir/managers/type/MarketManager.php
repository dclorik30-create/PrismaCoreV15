<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use pocketmine\item\Item;
use pocketmine\item\SavedItemStackData;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class MarketManager extends DataHandler
{
 private const MAX_LISTINGS_PER_PLAYER = 10;
 private const TAX_PERCENT = 5;

 public function init(): void
 {
 $this->loadData("Market");
 }

 public function addListing(string $seller, Item $item, float $price, int $amount): ?string
 {
 $playerListings = $this->getPlayerListings($seller);
 if (count($playerListings) >= self::MAX_LISTINGS_PER_PLAYER) return null;

 $id = uniqid("listing_", true);
 $serializer = new LittleEndianNbtSerializer();
 $nbt = $serializer->write(new TreeRoot($item->nbtSerialize()));

 $this->data[$id] = [
 "id" => $id,
 "seller" => $seller,
 "item_nbt"=> base64_encode($nbt),
 "item_name" => $item->getName(),
 "amount" => $amount,
 "price" => $price,
 "created" => time()
 ];
 return $id;
 }

 public function removeListing(string $id): bool
 {
 if (!isset($this->data[$id])) return false;
 unset($this->data[$id]);
 return true;
 }

 public function getListing(string $id): ?array
 {
 return $this->data[$id] ?? null;
 }

 public function getAllListings(): array
 {
 return $this->data;
 }

 public function getPlayerListings(string $player): array
 {
 return array_filter($this->data, fn($l) => strtolower($l["seller"]) === strtolower($player));
 }

 public function getTaxPercent(): int { return self::TAX_PERCENT; }

 public function deserializeItem(string $base64Nbt): ?Item
 {
 try {
 $serializer = new LittleEndianNbtSerializer();
 $nbt = $serializer->read(base64_decode($base64Nbt))->mustGetCompoundTag();
 return Item::nbtDeserialize($nbt);
 } catch (\Throwable) {
 return null;
 }
 }
}
