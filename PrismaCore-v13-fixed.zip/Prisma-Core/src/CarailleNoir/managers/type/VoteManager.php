<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\managers\Manager;
use CarailleNoir\Core;
use CarailleNoir\tasks\VoteCheckTask;
use pocketmine\item\VanillaItems;
use pocketmine\player\Player;
use pocketmine\Server;

class VoteManager
{
    public const API_KEY   = "7Q8zxDPzM69XMmPj7yAQQsww9tGgPjg4lN6";
    public const MAX_VOTES = 50;
    public const GRADE_DURATION = 86400; // 24 heures en secondes

    private static int    $currentVotes = 0;
    private static string $dataFile;
    private static string $gradeFile;

    /**
     * Map playerNameLower => timestamp d'expiration du grade Vote
     * @var array<string, int>
     */
    private static array $gradeExpiry = [];

    public static function init(): void
    {
        self::$dataFile  = Core::getInstance()->getDataFolder() . "vote_data.json";
        self::$gradeFile = Core::getInstance()->getDataFolder() . "vote_grade_expiry.json";

        if (!file_exists(self::$dataFile)) {
            file_put_contents(self::$dataFile, json_encode(["votes" => 0]));
        }
        $data = json_decode(file_get_contents(self::$dataFile), true);
        self::$currentVotes = $data["votes"] ?? 0;

        // Charger les expirations de grade
        if (file_exists(self::$gradeFile)) {
            self::$gradeExpiry = json_decode(file_get_contents(self::$gradeFile), true) ?? [];
        }
    }

    public static function save(): void
    {
        file_put_contents(self::$dataFile, json_encode(["votes" => self::$currentVotes]));
    }

    private static function saveGradeExpiry(): void
    {
        file_put_contents(self::$gradeFile, json_encode(self::$gradeExpiry, JSON_PRETTY_PRINT));
    }

    public static function getCurrentVotes(): int
    {
        return self::$currentVotes;
    }

    public static function checkVote(Player $player): void
    {
        Server::getInstance()->getAsyncPool()->submitTask(
            new VoteCheckTask($player->getName(), self::API_KEY)
        );
    }

    public static function onVoteSuccess(Player $player): void
    {
        $player->sendMessage("§aMerci d'avoir voté ! Voici ta récompense.");
        $player->getInventory()->addItem(VanillaItems::DIAMOND());

        if ($player instanceof \CarailleNoir\player\PrismaPlayer) {
            $gradeId = null;
            if (Manager::GRADE()->existGrade("Vote")) {
                $gradeId = "Vote";
            } elseif (Manager::GRADE()->existGrade("vote")) {
                $gradeId = "vote";
            }

            if ($gradeId !== null) {
                $key = strtolower($player->getName());
                $alreadyHas = isset(self::$gradeExpiry[$key]) && self::$gradeExpiry[$key] > time();

                // Remet le timer à 24h (que ce soit un renouvellement ou un nouveau grade)
                self::$gradeExpiry[$key] = time() + self::GRADE_DURATION;
                self::saveGradeExpiry();

                if (!$alreadyHas) {
                    // Premier vote : donner le grade
                    Manager::GRADE()->addGrade($player, $gradeId, $player->getName());
                } else {
                    // Revote : timer remis à 24h, pas besoin de re-donner le grade
                    $player->sendMessage("§6[Vote] §fTon grade Vote a été renouvelé pour 24 heures !");
                }
            }
        }

        self::$currentVotes++;
        self::save();
        Server::getInstance()->broadcastMessage("§aVoteParty : §f" . self::$currentVotes . "/" . self::MAX_VOTES);

        if (self::$currentVotes >= self::MAX_VOTES) {
            self::triggerVoteParty();
        }
    }

    /**
     * Vérifie et expire les grades Vote périmés.
     * Appelé depuis PlaytimeTask (toutes les 60s).
     */
    public static function tickGradeExpiry(): void
    {
        $now     = time();
        $changed = false;

        foreach (self::$gradeExpiry as $playerName => $expiresAt) {
            if ($now < $expiresAt) continue;

            unset(self::$gradeExpiry[$playerName]);
            $changed = true;

            $gradeManager = Manager::GRADE();
            $online = Server::getInstance()->getPlayerExact($playerName);

            if ($online instanceof \CarailleNoir\player\PrismaPlayer) {
                // Joueur en ligne
                $gradeManager->removeGradeOffline($playerName);
                $online->sendMessage("§c[Vote] §fTon grade Vote a expiré. Tu es redevenu Joueur.");
                $online->invalidateGradeCache();
            } else {
                // Hors-ligne : modifier les données brutes
                $gradeManager->removeGradeOffline($playerName);
            }
        }

        if ($changed) self::saveGradeExpiry();
    }

    public static function triggerVoteParty(): void
    {
        Server::getInstance()->broadcastMessage("§l§aVoteParty atteint ! Récompense pour tous les joueurs !");
        foreach (Server::getInstance()->getOnlinePlayers() as $onlinePlayer) {
            $onlinePlayer->getInventory()->addItem(VanillaItems::EMERALD()->setCount(3));
        }
        self::$currentVotes = 0;
        self::save();
    }
}
