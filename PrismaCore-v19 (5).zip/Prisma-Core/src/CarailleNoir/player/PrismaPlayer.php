<?php

namespace CarailleNoir\player;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\Faction\Faction;
use pocketmine\entity\Location;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\nbt\tag\StringTag;
use pocketmine\network\mcpe\NetworkSession;
use pocketmine\player\Player;
use pocketmine\player\PlayerInfo;
use CarailleNoir\tasks\NameTagTask;
use CarailleNoir\tasks\ScoreboardTask;
use pocketmine\Server;

class PrismaPlayer extends Player
{
 // ----- NBT-persisted -----
 private bool $freeze = false;
 private array $permissions = [];
 private string $factionId = "Aucune";

 // ----- In-memory -----
 private ?string $currentRegion = null;
 /** @var array<int, array> pending money requests [from => name, amount => float, ts => int] */
 private array $pendingMoneyRequests = [];
 private bool $staffMode = false;
 private array $staffInventoryBackup = [];
 private array $staffArmorBackup = [];
 private ?int $lastCpsClick = null;
 private int $cpsCount = 0;
 private int $cpsWindow = 0;
 private string $visualNick = "";
 private bool $regionBypass = false;

 public function __construct(Server $server, NetworkSession $session, PlayerInfo $playerInfo, bool $authenticated, Location $spawnLocation, ?CompoundTag $namedtag)
 {
 parent::__construct($server, $session, $playerInfo, $authenticated, $spawnLocation, $namedtag);
 }

 protected function initEntity(CompoundTag $nbt): void
 {
 parent::initEntity($nbt);
 $this->freeze = (bool)$nbt->getInt("freeze", 0);
 $this->permissions = $nbt->getTag("perm") instanceof StringTag ? unserialize($nbt->getString("perm")) : [];

 $nbtFactionId = $nbt->getString("factionId", "Aucune");

 // ── Reconciliation : le YAML faction est la source de vérité ──────────
 // Évite les factions fantômes après un crash (NBT non sauvé ≠ YAML sauvé)
 if ($nbtFactionId !== "Aucune") {
 $f = Manager::FACTION()->getFaction($nbtFactionId);
 if ($f === null || !$f->hasPlayer($this->getName())) {
 // Faction supprimée ou joueur expulsé sans sauvegarde NBT
 $found = Manager::FACTION()->getFactionByPlayer($this->getName());
 $nbtFactionId = $found?->getId() ?? "Aucune";
 }
 } else {
 // NBT dit "Aucune" mais un YAML a peut-être ce joueur (crash avant save NBT)
 $found = Manager::FACTION()->getFactionByPlayer($this->getName());
 if ($found !== null) $nbtFactionId = $found->getId();
 }

 $this->factionId = $nbtFactionId;
 $this->visualNick = $nbt->getString("visualNick", "");
 }

 public function getSaveData(): CompoundTag
 {
 $nbt = parent::getSaveData();
 $nbt->setInt("freeze", (int)$this->freeze);
 $nbt->setString("perm", serialize($this->permissions));
 $nbt->setString("factionId", $this->factionId);
 $nbt->setString("visualNick", $this->visualNick);
 return $nbt;
 }

 // =================== Freeze ===================
 public function freeze(bool $status = false): void
 {
 $this->setNoClientPredictions($status);
 $this->freeze = $status;
 }

 public function isFreeze(): bool { return $this->freeze; }

 // =================== RegionBypass ===================
 public function hasRegionBypass(): bool { return $this->regionBypass; }
 public function setRegionBypass(bool $value): void { $this->regionBypass = $value; }

 // =================== Permissions ===================
 public function addPermission(string $perm): void
 {
 if (!in_array($perm, $this->permissions, true)) {
 $this->permissions[] = $perm;
 Manager::PERMISSION()->updatePermissions($this);
 }
 }

 public function removePermission(string $perm): void
 {
 $key = array_search($perm, $this->permissions, true);
 if ($key !== false) {
 unset($this->permissions[$key]);
 $this->permissions = array_values($this->permissions);
 Manager::PERMISSION()->updatePermissions($this);
 }
 }

 public function getPermissions(): array { return $this->permissions; }

 public function loadOfflineData(array $data): void
 {
 if (!empty($data["freeze"])) {
 $this->setNoClientPredictions();
 $this->freeze = true;
 }
 foreach ($data["permissions"] ?? [] as $perm) {
 $this->addPermission($perm);
 }
 }

 // =================== Region ===================
 public function getCurrentRegionId(): ?string { return $this->currentRegion; }
 public function setCurrentRegionId(?string $id): void { $this->currentRegion = $id; }

 public function updateRegion(Vector3 $pos): void
 {
 $manager = Manager::REGION();
 $currentRegion = $manager->getMainRegionAt($pos, $this->getWorld()->getFolderName());
 $lastRegion = $this->getCurrentRegionId();
 if (($currentRegion?->getId() ?? null) !== $lastRegion) {
 if ($lastRegion && ($old = $manager->getRegionById($lastRegion))) {
 $this->sendMessage("§cTu viens de leave la region " . $old->getName());
 }
 if ($currentRegion && ($new = $manager->getRegionById($currentRegion->getId()))) {
 $this->sendMessage("§aTu viens de join la region " . $new->getName());
 }
 $this->setCurrentRegionId($currentRegion?->getId());
 }
 }

 // =================== Faction ===================
 public function getFaction(): ?Faction
 {
 $f = Manager::FACTION()->getFaction($this->factionId);
 return $f instanceof Faction ? $f : null;
 }

 public function setFaction(string $id): void {
        $this->factionId = $id;
        ScoreboardTask::refresh($this);
        $this->setNameTag(NameTagTask::buildTag($this));
    }

 // =================== Economy ===================
 public function getMoney(): float { return Manager::ECONOMY()->getMoney($this->getName()); }
 public function addMoney(float $amount): void { Manager::ECONOMY()->addMoney($this->getName(), $amount); ScoreboardTask::refresh($this); }
 public function removeMoney(float $amount): bool { $r = Manager::ECONOMY()->removeMoney($this->getName(), $amount); ScoreboardTask::refresh($this); return $r; }
 public function hasMoney(float $amount): bool { return Manager::ECONOMY()->hasMoney($this->getName(), $amount); }

 // =================== Coins ===================
 public function getCoins(): int { return Manager::COINS()->getCoins($this->getName()); }
 public function addCoins(int $amount): void { Manager::COINS()->addCoins($this->getName(), $amount); ScoreboardTask::refresh($this); }
 public function removeCoins(int $amount): bool { $r = Manager::COINS()->removeCoins($this->getName(), $amount); ScoreboardTask::refresh($this); return $r; }

 // =================== Stats ===================
 public function getKills(): int { return Manager::STATS()->getKills($this->getName()); }
 public function getDeaths(): int { return Manager::STATS()->getDeaths($this->getName()); }
 public function getPower(): int { return Manager::STATS()->getPower($this->getName()); }

 // =================== Money requests ===================
 public function addMoneyRequest(string $fromPlayer, float $amount): void
 {
 $this->pendingMoneyRequests[strtolower($fromPlayer)] = [
 "from" => $fromPlayer,
 "amount" => $amount,
 "ts" => time()
 ];
 }

 public function getMoneyRequest(string $fromPlayer): ?array
 {
 $key = strtolower($fromPlayer);
 if (!isset($this->pendingMoneyRequests[$key])) return null;
 if (time() - $this->pendingMoneyRequests[$key]["ts"] > 60) {
 unset($this->pendingMoneyRequests[$key]);
 return null;
 }
 return $this->pendingMoneyRequests[$key];
 }

 public function getAnyMoneyRequest(): ?array
 {
 foreach ($this->pendingMoneyRequests as $key => $req) {
 if (time() - $req["ts"] > 60) { unset($this->pendingMoneyRequests[$key]); continue; }
 return $req;
 }
 return null;
 }

 public function removeMoneyRequest(string $fromPlayer): void
 {
 unset($this->pendingMoneyRequests[strtolower($fromPlayer)]);
 }

 // =================== Staff mode ===================
 public function isStaffMode(): bool { return $this->staffMode; }
 public function setStaffMode(bool $mode): void { $this->staffMode = $mode; }

 // =================== Staff inventory backup ===================
 public function backupStaffInventory(): void
 {
 $this->staffInventoryBackup = [];
 foreach ($this->getInventory()->getContents() as $slot => $item) {
 $this->staffInventoryBackup[$slot] = clone $item;
 }
 $this->staffArmorBackup = [];
 foreach ($this->getArmorInventory()->getContents() as $slot => $item) {
 $this->staffArmorBackup[$slot] = clone $item;
 }
 }

 public function restoreStaffInventory(): void
 {
 $this->getInventory()->clearAll();
 foreach ($this->staffInventoryBackup as $slot => $item) {
 $this->getInventory()->setItem((int)$slot, clone $item);
 }
 $this->getArmorInventory()->clearAll();
 foreach ($this->staffArmorBackup as $slot => $item) {
 $this->getArmorInventory()->setItem((int)$slot, clone $item);
 }
 $this->staffInventoryBackup = [];
 $this->staffArmorBackup = [];
 }

 // =================== CPS counter ===================
 public function registerClick(): void
 {
 $now = (int)(microtime(true) * 1000);
 if ($this->cpsWindow === 0 || ($now - $this->cpsWindow) > 1000) {
 $this->cpsWindow = $now;
 $this->cpsCount = 0;
 }
 $this->cpsCount++;
 }

 public function getCps(): int
 {
 $now = (int)(microtime(true) * 1000);
 // Réinitialise si la fenêtre de 1s est expirée
 if ($this->cpsWindow > 0 && ($now - $this->cpsWindow) > 1000) {
 $this->cpsCount = 0;
 $this->cpsWindow = 0;
 }
 return $this->cpsCount;
 }

 // =================== Grade ===================
 /** Cache grade pour éviter N appels au GradeManager par tick */
 private ?array $cachedGradeData = null;

 public function getGradeData(): array
 {
 $this->cachedGradeData ??= Manager::GRADE()->getPlayerGradeData($this->getName());
 return $this->cachedGradeData;
 }

 /** Invalide le cache quand le grade change (appelé par GradeCommand) */
 public function invalidateGradeCache(): void {
        $this->cachedGradeData = null;
        ScoreboardTask::refresh($this);
        $this->setNameTag(NameTagTask::buildTag($this));
    }


 public function getVisualNick(): string { return $this->visualNick; }
 public function getVisualName(): string { return $this->visualNick !== "" ? $this->visualNick : $this->getName(); }
 public function setVisualNick(string $nick): void {
        $this->visualNick = trim($nick);
        $this->setNameTag(NameTagTask::buildTag($this));
    }

 public function getGradeId(): string { return $this->getGradeData()["id"] ?? "joueur"; }
 public function getGradeColor(): string { return $this->getGradeData()["color"] ?? "§f"; }
 public function getGradeName(): string { return $this->getGradeData()["name"] ?? "Joueur"; }
}
