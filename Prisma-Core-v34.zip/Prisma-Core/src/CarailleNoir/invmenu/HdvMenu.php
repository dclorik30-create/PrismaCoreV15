<?php
declare(strict_types=1);
namespace CarailleNoir\invmenu;

use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\libs\muqsit\invmenu\type\InvMenuTypeIds;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\HdvManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;

class HdvMenu
{
    // ─── BROWSE ──────────────────────────────────────────────
    public static function openBrowse(PrismaPlayer $player, int $page = 0): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName("§6§lHotel des Ventes");
        self::fillBrowsePage($menu, $player, $page);

        $menu->setListener(function(InvMenuTransaction $t) use (&$page, $menu): InvMenuTransactionResult {
            $item   = $t->getItemClicked();
            $viewer = $t->getPlayer();
            if (!$viewer instanceof PrismaPlayer) return $t->discard();

            $name = $item->getCustomName();

            if ($name === "§aPage suivante") {
                $page++;
                self::fillBrowsePage($menu, $viewer, $page);
                return $t->discard();
            }
            if ($name === "§cPage precedente") {
                if ($page > 0) $page--;
                self::fillBrowsePage($menu, $viewer, $page);
                return $t->discard();
            }
            if ($name === "§eMes annonces") {
                $viewer->removeCurrentWindow();
                self::openMine($viewer);
                return $t->discard();
            }
            if ($name === "§cFermer") {
                $viewer->removeCurrentWindow();
                return $t->discard();
            }

            $id = self::extractId($item->getLore());
            if ($id === null) return $t->discard();

            $listing = Manager::HDV()->getListing($id);
            if ($listing === null) {
                $viewer->sendMessage("§cCette annonce n'existe plus.");
                self::fillBrowsePage($menu, $viewer, $page);
                return $t->discard();
            }
            if (strtolower($listing["seller"]) === strtolower($viewer->getName())) {
                $viewer->sendMessage("§cVous ne pouvez pas acheter votre propre annonce.");
                return $t->discard();
            }

            $viewer->removeCurrentWindow();
            self::openConfirm($viewer, $id, $page);
            return $t->discard();
        });

        $menu->send($player);
    }

    // ─── MES ANNONCES ────────────────────────────────────────
    public static function openMine(PrismaPlayer $player, int $page = 0): void
    {
        $menu = InvMenu::create(InvMenuTypeIds::TYPE_DOUBLE_CHEST);
        $menu->setName("§e§lMes annonces HDV");
        self::fillMinePage($menu, $player, $page);

        $menu->setListener(function(InvMenuTransaction $t) use ($player, &$page, $menu): InvMenuTransactionResult {
            $item   = $t->getItemClicked();
            $viewer = $t->getPlayer();
            if (!$viewer instanceof PrismaPlayer) return $t->discard();

            $name = $item->getCustomName();

            if ($name === "§aPage suivante") {
                $page++;
                self::fillMinePage($menu, $viewer, $page);
                return $t->discard();
            }
            if ($name === "§cPage precedente") {
                if ($page > 0) $page--;
                self::fillMinePage($menu, $viewer, $page);
                return $t->discard();
            }
            if ($name === "§6Retour HDV") {
                $viewer->removeCurrentWindow();
                self::openBrowse($viewer);
                return $t->discard();
            }
            if ($name === "§cFermer") {
                $viewer->removeCurrentWindow();
                return $t->discard();
            }

            $id = self::extractId($item->getLore());
            if ($id === null) return $t->discard();

            if (Manager::HDV()->withdrawListing($viewer, $id)) {
                $viewer->sendMessage("§aAnnonce retiree avec succes.");
                self::fillMinePage($menu, $viewer, $page);
            } else {
                $viewer->sendMessage("§cImpossible de retirer cette annonce.");
            }
            return $t->discard();
        });

        $menu->send($player);
    }

    // ─── CONFIRMATION D'ACHAT ────────────────────────────────
    public static function openConfirm(PrismaPlayer $player, int $listingId, int $returnPage = 0): void
    {
        $listing = Manager::HDV()->getListing($listingId);
        if ($listing === null) {
            $player->sendMessage("§cCette annonce n'existe plus.");
            self::openBrowse($player, $returnPage);
            return;
        }

        $menu = InvMenu::create(InvMenuTypeIds::TYPE_CHEST);
        $menu->setName("§c§lConfirmer l'achat ?");
        $inv   = $menu->getInventory();
        $price = (float)$listing["price"];

        try {
            $preview = HdvManager::decodeItemData($listing["itemData"]);
            if (!$preview instanceof Item) throw new \Exception("invalid");
        } catch (\Throwable) {
            $player->sendMessage("§cErreur avec cet item.");
            self::openBrowse($player, $returnPage);
            return;
        }

        $display = clone $preview;
        $lore    = $display->getLore();
        $lore[]  = "§r§8ID:#" . $listingId;
        $display->setLore($lore);
        $inv->setItem(13, $display);

        $confirm = self::makeItem("lime_concrete", "§a§lACHETER", [
            "§7Prix : §e" . number_format($price, 2) . "§6\$",
            "§7Vendeur : §f" . $listing["seller"],
            "§7Votre solde : §f" . number_format($player->getMoney(), 2) . "§6\$",
        ]);
        $inv->setItem(11, $confirm);

        $cancel = self::makeItem("red_concrete", "§c§lANNULER", ["§7Retour a la liste"]);
        $inv->setItem(15, $cancel);

        $glass = self::makeItem("gray_stained_glass_pane", "§r");
        foreach (range(0, 26) as $slot) {
            if ($inv->getItem($slot)->isNull()) $inv->setItem($slot, $glass);
        }

        $menu->setListener(function(InvMenuTransaction $t) use ($listingId, $returnPage): InvMenuTransactionResult {
            $item   = $t->getItemClicked();
            $viewer = $t->getPlayer();
            if (!$viewer instanceof PrismaPlayer) return $t->discard();

            $name = $item->getCustomName();
            if ($name === "§a§lACHETER") {
                $viewer->removeCurrentWindow();
                if (Manager::HDV()->buyListing($viewer, $listingId)) {
                    $viewer->sendMessage("§aAchat effectue avec succes !");
                } else {
                    $viewer->sendMessage("§cAchat impossible (solde insuffisant ou annonce expiree).");
                }
                self::openBrowse($viewer, $returnPage);
                return $t->discard();
            }
            if ($name === "§c§lANNULER") {
                $viewer->removeCurrentWindow();
                self::openBrowse($viewer, $returnPage);
                return $t->discard();
            }
            return $t->discard();
        });

        $menu->send($player);
    }

    // ─── HELPERS ─────────────────────────────────────────────
    private static function fillBrowsePage(InvMenu $menu, PrismaPlayer $player, int &$page): void
    {
        $inv      = $menu->getInventory();
        $inv->clearAll();
        $listings = Manager::HDV()->getListings();
        $perPage  = 45;
        $total    = count($listings);
        $maxPage  = max(0, (int)ceil($total / $perPage) - 1);
        $page     = max(0, min($page, $maxPage));
        $slice    = array_slice($listings, $page * $perPage, $perPage, true);

        $slotIndex = 0;
        foreach ($slice as $id => $l) {
            try {
                $realItem = HdvManager::decodeItemData($l["itemData"]);
                if (!$realItem instanceof Item) continue;
            } catch (\Throwable) { continue; }
            $display = clone $realItem;
            if (empty($display->getCustomName())) $display->setCustomName("§f" . $display->getName());
            $lore   = $display->getLore();
            $lore[] = "§r";
            $lore[] = "§7Prix : §e" . number_format((float)$l["price"], 2) . "§6\$";
            $lore[] = "§7Vendeur : §f" . $l["seller"];
            $lore[] = "§7Quantite : §f" . $l["itemCount"];
            $lore[] = "§r§8ID:#" . $id;
            $lore[] = "§aCliquez pour acheter";
            $display->setLore($lore);
            $inv->setItem($slotIndex++, $display);
        }

        $glass = self::makeItem("gray_stained_glass_pane", "§r");
        for ($i = 45; $i <= 53; $i++) $inv->setItem($i, $glass);
        $inv->setItem(46, self::makeItem("chest", "§eMes annonces", ["§7Voir et retirer vos annonces"]));
        $inv->setItem(52, self::makeItem("barrier", "§cFermer"));
        $inv->setItem(49, self::makeItem("paper", "§6Page " . ($page + 1) . "/" . ($maxPage + 1), ["§7" . $total . " annonce(s)"]));
        if ($page > 0)        $inv->setItem(45, self::makeItem("arrow", "§cPage precedente"));
        if ($page < $maxPage) $inv->setItem(53, self::makeItem("arrow", "§aPage suivante"));
    }

    private static function fillMinePage(InvMenu $menu, PrismaPlayer $player, int &$page): void
    {
        $inv     = $menu->getInventory();
        $inv->clearAll();
        $all     = Manager::HDV()->getListings();
        $mineKeyed = array_filter($all, fn($l) => strtolower($l["seller"]) === strtolower($player->getName()));
        $perPage = 45;
        $total   = count($mineKeyed);
        $maxPage = max(0, (int)ceil($total / $perPage) - 1);
        $page    = max(0, min($page, $maxPage));
        $slice   = array_slice($mineKeyed, $page * $perPage, $perPage, true);

        $slotIndex = 0;
        foreach ($slice as $id => $l) {
            try {
                $realItem = HdvManager::decodeItemData($l["itemData"]);
                if (!$realItem instanceof Item) continue;
            } catch (\Throwable) { continue; }
            $display = clone $realItem;
            if (empty($display->getCustomName())) $display->setCustomName("§f" . $display->getName());
            $lore   = $display->getLore();
            $lore[] = "§r";
            $lore[] = "§7Prix : §e" . number_format((float)$l["price"], 2) . "§6\$";
            $lore[] = "§7Cliquez pour RETIRER";
            $lore[] = "§r§8ID:#" . $id;
            $display->setLore($lore);
            $inv->setItem($slotIndex++, $display);
        }

        $glass = self::makeItem("gray_stained_glass_pane", "§r");
        for ($i = 45; $i <= 53; $i++) $inv->setItem($i, $glass);
        $inv->setItem(46, self::makeItem("arrow", "§6Retour HDV"));
        $inv->setItem(52, self::makeItem("barrier", "§cFermer"));
        $inv->setItem(49, self::makeItem("paper", "§6Page " . ($page + 1) . "/" . ($maxPage + 1), ["§7" . $total . " annonce(s)"]));
        if ($page > 0)        $inv->setItem(45, self::makeItem("arrow", "§cPage precedente"));
        if ($page < $maxPage) $inv->setItem(53, self::makeItem("arrow", "§aPage suivante"));
    }

    private static function makeItem(string $id, string $name, array $lore = []): Item
    {
        $item = StringToItemParser::getInstance()->parse($id) ?? VanillaItems::AIR();
        if ($name !== "" && $name !== "§r") $item->setCustomName($name);
        if (!empty($lore)) $item->setLore($lore);
        return $item;
    }

    private static function extractId(array $lore): ?int
    {
        foreach (array_reverse($lore) as $line) {
            if (preg_match('/§8ID:#(\d+)/', $line, $m)) return (int)$m[1];
        }
        return null;
    }
}
