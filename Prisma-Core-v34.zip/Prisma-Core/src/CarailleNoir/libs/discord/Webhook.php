<?php

namespace CarailleNoir\libs\discord;

use CarailleNoir\Core;
use CarailleNoir\libs\discord\task\DiscordWebhookSendTask;

class Webhook {
    /** @var string */
    protected string $url;

    public function __construct(string $url) {
        $this->url = $url;
    }

    public function getURL(): string {
        return $this->url;
    }

    public function isValid(): bool {
        return filter_var($this->url, FILTER_VALIDATE_URL) !== false;
    }

    public function send(Message $message): void {
        $messageJson = json_encode($message);

        Core::getInstance()->getServer()->getAsyncPool()->submitTask(new DiscordWebhookSendTask($this->getURL(), $messageJson));
   }
}
