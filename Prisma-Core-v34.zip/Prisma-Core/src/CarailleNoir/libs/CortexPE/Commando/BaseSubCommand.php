<?php

declare(strict_types=1);

namespace CarailleNoir\libs\CortexPE\Commando;

use CarailleNoir\libs\CortexPE\Commando\constraint\BaseConstraint;
use CarailleNoir\libs\CortexPE\Commando\exception\ArgumentOrderException;
use CarailleNoir\libs\CortexPE\Commando\traits\ArgumentableTrait;
use CarailleNoir\libs\CortexPE\Commando\traits\IArgumentable;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\plugin\Plugin;

abstract class BaseSubCommand implements IArgumentable, IRunnable {
    use ArgumentableTrait;
    /** @var string */
    private string $name;
    /** @var string[] */
    private array $aliases;
    /** @var string */
    private string $description;
    /** @var string */
    protected string $usageMessage;
    /** @var string */
    public string $permission = DefaultPermissions::ROOT_USER;
    /** @var array */
    public array $permissions = [];
    /** @var CommandSender */
    protected CommandSender $currentSender;
    /** @var BaseCommand */
    protected BaseCommand $parent;
    /** @var BaseConstraint[] */
    /** @var BaseSubCommand[] */
    private array $subCommands = [];
    private array $constraints = [];

    /**
     * @throws ArgumentOrderException
     */
    public function __construct(string $name, string $description = "", array $aliases = [], ?array $permissions = []) {
        $this->name = $name;
        $this->description = $description;
        $this->aliases = $aliases;
        $this->permissions = $permissions;

        if ($permissions !== null) {
            if (is_array($permissions)) {
                $this->setPermission(implode(";", $permissions));
            } else {
                $this->setPermission($permissions);
            }
        } else {
            $this->setPermission(DefaultPermissions::ROOT_USER);
        }

        foreach ($this->prepare() as $pos => $argument) {
            $this->registerArgument($pos, $argument);
        }


        $this->usageMessage = $this->generateUsageMessage();
    }

    abstract public function onRun(CommandSender $sender, string $aliasUsed, array $args): void;

    /**
     * @return string
     */
    public function getName(): string {
        return $this->name;
    }

    /**
     * @return string[]
     */
    public function getAliases(): array {
        return $this->aliases;
    }

    /**
     * @return string
     */
    public function getDescription(): string {
        return $this->description;
    }

    /**
     * @return string
     */
    public function getUsageMessage(): string {
        return $this->usageMessage;
    }

    /**
     * @return string|null
     */
    public function getPermission(): ?string {
        return $this->permission;
    }

    public function getPermissions(): array
    {
        return $this->permissions;
    }

    /**
     * @param string $permission
     */
    public function setPermission(string $permission): void {
        $this->permission = $permission;
    }

    public function testPermissionSilent(CommandSender $sender): bool {
        if(empty($this->permission)) {
            return true;
        }
        foreach(explode(";", $this->permission) as $permission) {
            if($sender->hasPermission($permission)) {
                return true;
            }
        }

        return false;
    }

    /**
     * @param CommandSender $currentSender
     *
     * @internal Used to pass the current sender from the parent command
     */
    public function setCurrentSender(CommandSender $currentSender): void {
        $this->currentSender = $currentSender;
    }

    /**
     * @param BaseCommand $parent
     *
     * @internal Used to pass the parent context from the parent command
     */
    public function setParent(BaseCommand $parent): void {
        $this->parent = $parent;
    }

    public function sendError(int $errorCode, array $args = []): void {
        $this->parent->sendError($errorCode, $args);
    }

    public function sendUsage():void {
        $this->currentSender->sendMessage("/{$this->parent->getName()} $this->usageMessage");
    }

    public function addConstraint(BaseConstraint $constraint) : void {
        $this->constraints[] = $constraint;
    }

    /**
     * @return BaseConstraint[]
     */
    public function getConstraints(): array {
        return $this->constraints;
    }

    /**
     * @return Plugin
     */
    public function getOwningPlugin(): Plugin {
        return $this->parent->getOwningPlugin();
    }
}