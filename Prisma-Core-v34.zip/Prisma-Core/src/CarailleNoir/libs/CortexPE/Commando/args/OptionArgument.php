<?php

namespace CarailleNoir\libs\CortexPE\Commando\args;

use pocketmine\command\CommandSender;

class OptionArgument extends ArrayEnumArgument
{

    public function getTypeName(): string
    {
        return 'string';
    }

    public function parse(string $argument, CommandSender $sender): string
    {
        return $this->getValues($argument);
    }
}