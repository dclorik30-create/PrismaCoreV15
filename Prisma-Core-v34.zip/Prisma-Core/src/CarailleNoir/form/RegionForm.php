<?php

namespace CarailleNoir\form;

use CarailleNoir\libs\forms\CustomForm;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\Region\Region;
use CarailleNoir\player\PrismaPlayer;

class RegionForm
{
    public static function listMenu(): CustomForm
    {
        $form = new CustomForm(function (PrismaPlayer $player, ?array $data): void {
            if ($data === null || !isset($data[0])) {
                return;
            }

            self::baseMenu($player, $data[0]);
        });

        $regions = Manager::REGION()->getRegions();
        $form->addDropdown("Liste de régions", $regions);

        $form->setTitle("Sélecteur de région");
        return $form;
    }
    public static function baseMenu(PrismaPlayer $player, string $id): void
    {
        $regionInfo = Manager::REGION()->getRegionById($id);
        if ($regionInfo === null) {
            return;
        }

        $form = new CustomForm(function(PrismaPlayer $player, ?array $data) use ($id, $regionInfo): void {
            if ($data === null) {
                return;
            }


            $newName = $data[0] ?? $regionInfo->getName();
            $newPriority = isset($data[1]) && is_numeric($data[1])
                ? (int)$data[1]
                : $regionInfo->getPriority();

            $newParams = [];
            foreach ($regionInfo->getParams() as $perm => $status) {
                $cleanKey = str_replace("region.setting.", "", $perm);
                if (array_key_exists($cleanKey, $data)) {
                    $newParams[$perm] = $data[$cleanKey];
                } else {
                    $newParams[$perm] = $status;
                }
            }

            Manager::REGION()->editRegion($player, $id, new Region($id, $newName, $regionInfo->getZone(), $regionInfo->getWorldName(), $newPriority, $newParams));
        });

        $form->setTitle("Edit {$regionInfo->getName()}");
        $form->addInput("Nom", "Exemple: Spawn", $regionInfo->getName());
        $form->addInput("Priorité", "Exemple: 0 ou 1 ou ... ", $regionInfo->getPriority());

        foreach ($regionInfo->getParams() as $perm => $status) {
            $key = str_replace("region.setting.", "", $perm);

            if (is_bool($status)) {
                $form->addToggle(ucfirst($key), $status, $key);
            } elseif (is_numeric($status)) {
                $form->addToggle(ucfirst($key), (bool)$status, $key);
            } elseif (is_string($status)) {
                $form->addInput(ucfirst($key), "Texte du paramètre", $status, $key);
            }
        }
        $form->sendToPlayer($player);
    }
}