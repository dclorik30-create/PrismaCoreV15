<?php

namespace CarailleNoir\tasks;

use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ClearlagTask extends Task
{
    private int $ticker = 0;
    private const CLEAR_INTERVAL = 600; // 600 secondes = 10 minutes (la tâche tourne à 1 run/s)
    private const WARN_TICKS     = [30, 10, 5]; // avertissements avant le clear

    public function onRun(): void
    {
        $this->ticker++;
        $remaining = self::CLEAR_INTERVAL - $this->ticker;

        if (in_array($remaining, self::WARN_TICKS)) {
            Server::getInstance()->broadcastMessage("§c[ClearLag] §fLes items au sol seront supprimés dans §c{$remaining} §fsecondes !");
        }

        if ($this->ticker >= self::CLEAR_INTERVAL) {
            $this->ticker = 0;
            $this->doClear();
        }
    }

    public function doClear(): void
    {
        $count = 0;
        foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof ItemEntity) {
                    $entity->flagForDespawn();
                    $count++;
                }
            }
        }
        Server::getInstance()->broadcastMessage("§c[ClearLag] §f$count items au sol ont été supprimés !");
    }
}
