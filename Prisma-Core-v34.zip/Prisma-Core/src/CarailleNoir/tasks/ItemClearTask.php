<?php
namespace CarailleNoir\tasks;

use pocketmine\entity\object\ItemEntity;
use pocketmine\scheduler\Task;
use pocketmine\Server;

class ItemClearTask extends Task
{
    private const TTL_SECONDS = 30;
    /** @var array<int, float> entityId => microtime */
    private array $registry = [];

    public function register(ItemEntity $entity): void
    {
        $this->registry[$entity->getId()] = microtime(true);
    }

    public function unregister(int $entityId): void
    {
        unset($this->registry[$entityId]);
    }

    public function onRun(): void
    {
        $now     = microtime(true);
        $expired = array_keys(array_filter($this->registry, fn($t) => ($now - $t) >= self::TTL_SECONDS));
        if (empty($expired)) return;

        foreach (Server::getInstance()->getWorldManager()->getWorlds() as $world) {
            foreach ($world->getEntities() as $entity) {
                if ($entity instanceof ItemEntity && in_array($entity->getId(), $expired, true)) {
                    $entity->flagForDespawn();
                }
            }
        }
        foreach ($expired as $id) $this->unregister($id);
    }
}
