<?php
declare(strict_types=1);
namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class OutpostTask extends Task
{
    public function onRun(): void
    {
        $outpost = Manager::OUTPOST();
        $outpost->tick();

        Manager::FLOATINGTEXT()->updateOutpost(
            $outpost->getState(),
            $outpost->getCapturingFaction(),
            $outpost->getCapturedFaction(),
            $outpost->getDecapturingFaction(),
            $outpost->getCaptureProgress(),
            $outpost->getDecaptureProgress(),
            $outpost->getRewardTimer()
        );
    }
}
