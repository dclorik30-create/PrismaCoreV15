<?php

namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\scheduler\Task;
use pocketmine\Server;

/**
 * Vérifie chaque seconde si un joueur se trouve sur la zone d'un event actif.
 * Appelle EventManager::tickCapture() et déclenche onEventWon() si capture complète.
 */
class EventTickTask extends Task
{
    private const CAPTURE_RADIUS = 5; // blocs

    public function onRun(): void
    {
        $eventMgr = Manager::EVENT();
        if (!$eventMgr->isEventActive()) return;

        $type = $eventMgr->getActiveEvent();
        $cfg  = $eventMgr->getEventConfig($type);
        if ($cfg === null) return;

        $worldName = $cfg["world"] ?? "world";
        $world     = Server::getInstance()->getWorldManager()->getWorldByName($worldName);
        if ($world === null) return;

        $epos = $eventMgr->getEventPosition($type);
        if ($epos === null) return;

        // Chercher un joueur dans le rayon de capture
        $capturingPlayer = null;
        foreach ($world->getPlayers() as $player) {
            if (!$player instanceof PrismaPlayer) continue;
            if ($player->getPosition()->distance($epos) <= self::CAPTURE_RADIUS) {
                $capturingPlayer = $player->getName();
                break;
            }
        }

        $won = $eventMgr->tickCapture($capturingPlayer ?? "");
        if ($won) {
            $eventMgr->onEventWon($capturingPlayer);
        }
    }
}
