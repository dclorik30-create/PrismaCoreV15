<?php

namespace CarailleNoir\tasks;

use CarailleNoir\managers\Manager;
use pocketmine\scheduler\Task;

class VipMineRespawnTask extends Task
{
    public function onRun(): void
    {
        Manager::MINE()->tick();
    }
}
