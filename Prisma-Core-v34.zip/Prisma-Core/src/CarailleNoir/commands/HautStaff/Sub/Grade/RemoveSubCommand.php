<?php

namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\args\OptionArgument;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class RemoveSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("remove", "Retirer le grade au joueur", [], [], DefaultPermissions::ROOT_OPERATOR);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "playerName")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $playerName = $args["playerName"];
        if (!Manager::ALIAS()->hasProfil($playerName)) {
            $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
            return;
        }

        Manager::GRADE()->removeGrade($sender, $playerName);
    }

}