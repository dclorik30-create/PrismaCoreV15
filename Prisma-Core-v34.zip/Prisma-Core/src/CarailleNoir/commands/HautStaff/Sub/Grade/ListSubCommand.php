<?php

namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\utils\TextFormat as TF;

class ListSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("list", "Permet de voir la liste de grade", [], [], DefaultPermissions::ROOT_OPERATOR);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        $grades = Manager::GRADE()->getGrades();

        if ($grades === null || count($grades) === 0) {
            $sender->sendMessage(TF::RED . "Aucun grade trouvé");
            return;
        }

        $sender->sendMessage(TF::YELLOW . "===== List des grades =====");
        foreach ($grades as $id => $grade) {
            $sender->sendMessage(
                TF::GREEN . "- " .
                TF::YELLOW . "Id: " . TF::WHITE . ($id ?? "Inconnu") . " " .
                TF::YELLOW . "Nom: " . TF::WHITE . ($grade["name"] ?? "Inconnu") . " " .
                TF::YELLOW . "Couleur: " . TF::WHITE . ($grade["color"] ?? "Inconnu") . "couleur"
            );
        }
    }
}