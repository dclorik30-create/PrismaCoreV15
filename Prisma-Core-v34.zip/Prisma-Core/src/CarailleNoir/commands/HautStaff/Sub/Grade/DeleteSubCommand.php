<?php

namespace CarailleNoir\commands\HautStaff\Sub\Grade;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class DeleteSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("delete", "Permet de supprimer un grade", [], [], DefaultPermissions::ROOT_OPERATOR);
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("identifier")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;
        $identifier = $args["identifier"];

        if (!Manager::GRADE()->existGrade($identifier)) {
            $sender->sendMessage("LE grade avec l'identifiant {$identifier} n'existe pas");
            return;
        }

        Manager::GRADE()->deleteGrade($identifier);
        $sender->sendMessage("Le grade avec l'identifiant {$identifier} vien d'être supprimé");
    }
}