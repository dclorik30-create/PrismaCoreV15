<?php

namespace CarailleNoir\commands\HautStaff;

use CarailleNoir\commands\HautStaff\Sub\Grade\AddSubCommand;
use CarailleNoir\commands\HautStaff\Sub\Grade\CreateSubCommand;
use CarailleNoir\commands\HautStaff\Sub\Grade\DeleteSubCommand;
use CarailleNoir\commands\HautStaff\Sub\Grade\ListSubCommand;
use CarailleNoir\commands\HautStaff\Sub\Grade\RemoveSubCommand;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class GradeCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("grade", "", [
            new CreateSubCommand(),
            new DeleteSubCommand(),
            new ListSubCommand(),
            new AddSubCommand(),
            new RemoveSubCommand()
        ], [], [DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {

    }
}