<?php

namespace CarailleNoir\commands;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;
use pocketmine\permission\DefaultPermissions;
use SenseiTarzan\SymplyPlugin\Behavior\SymplyItemFactory;

class TestCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("test", "Commande de test", [], ["negro", "noir"], DefaultPermissions::ROOT_OPERATOR);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "zeze")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer)return;
        var_dump($sender->getXuid());
    }
}
