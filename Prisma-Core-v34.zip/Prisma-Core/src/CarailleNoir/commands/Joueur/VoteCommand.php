<?php

namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class VoteCommand extends BaseCommand
{
    private static mixed $cooldowns;

    public function __construct()
    {
        parent::__construct("vote", "Voter pour le serveur");
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;
        $name = strtolower($sender->getName());
        $now = time();

        if (isset(self::$cooldowns[$name]) && ($now - self::$cooldowns[$name]) < 2) {
            $sender->sendMessage("§cPatiente un peu avant de refaire la commande !");
            return;
        }

        self::$cooldowns[$name] = $now;

        Manager::VOTE()::checkVote($sender);

    }
}