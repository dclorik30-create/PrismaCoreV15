<?php
namespace CarailleNoir\commands\Joueur;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\math\Vector3;
use pocketmine\world\Position;
class MineCommand extends BaseCommand {
    public function __construct() { parent::__construct("mine", "Téléporter à la mine", [], [], ["prisma.command.mine"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $cfg  = Manager::MINE()->getMineConfig();
        $worldName = $cfg["world"] ?? "Mine";
        $spawn     = $cfg["spawn"]  ?? ["x" => 0, "y" => 100, "z" => 0];
        $wm = \pocketmine\Server::getInstance()->getWorldManager();
        // Essai insensible à la casse si le nom exact échoue
        if (!$wm->isWorldLoaded($worldName)) $wm->loadWorld($worldName);
        $world = $wm->getWorldByName($worldName);
        if ($world === null) {
            foreach ($wm->getWorlds() as $w) {
                if (strtolower($w->getFolderName()) === strtolower($worldName)) {
                    $world = $w; break;
                }
            }
        }
        if ($world === null) { $sender->sendMessage("§cMine introuvable !"); return; }
        $pos = isset($spawn["x"]) ? new Position($spawn["x"], $spawn["y"], $spawn["z"], $world) : $world->getSpawnLocation();
        $sender->teleport($pos);
        $sender->sendMessage("§aTéléporté à la mine !");
    }
}
