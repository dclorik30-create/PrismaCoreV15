<?php
namespace CarailleNoir\commands\Joueur\PV;

use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction;
use CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\inventory\Inventory;
use pocketmine\player\Player;

class PVCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("pv", "Ouvrir un coffre personnel (PV 1-10)", [], ["pvault"], ["prisma.command.pv"]);
    }

    protected function prepare(): array
    {
        return [new IntegerArgument("slot", false), new TargetPlayerArgument(true, "target")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $slot = (int)($args["slot"] ?? 1);
        $target = $args["target"] ?? $sender->getName();
        $isStaff = ($target !== $sender->getName()) && $sender->hasPermission("prisma.command.pvsee");
        if (!$isStaff) $target = $sender->getName();

        if ($slot < 1 || $slot > 10) {
            $sender->sendMessage("§cSlot invalide (1-10) !");
            return;
        }

        $pvManager = Manager::PV();
        $gradeId = Manager::GRADE()->getPlayerGradeData($target)["id"] ?? "joueur";
        $maxSlots = $pvManager->getMaxVaults($gradeId);

        if ($slot > $maxSlots && !$isStaff) {
            $sender->sendMessage("§cVotre grade §f({$gradeId})§c permet seulement §f{$maxSlots} §cPV.");
            return;
        }

        $menu = InvMenu::create(InvMenu::TYPE_DOUBLE_CHEST);
        $menu->setName("§6PV §e{$target} §6#" . $slot);

        $contents = $pvManager->getVaultContents($target, $slot);
        foreach ($contents as $i => $b64) {
            $item = $pvManager->deserializeItem($b64);
            if ($item !== null) {
                $menu->getInventory()->setItem((int)$i, $item);
            }
        }

        $menu->setListener(function(InvMenuTransaction $transaction) use ($isStaff): InvMenuTransactionResult {
            if ($isStaff) {
                return $transaction->continue();
            }
            return $transaction->continue();
        });

        $playerName = $target;
        $slotRef = $slot;
        $menu->setInventoryCloseListener(function(Player $p, Inventory $inv) use ($playerName, $slotRef, $pvManager): void {
            $serialized = [];
            foreach ($inv->getContents() as $i => $item) {
                $serialized[$i] = $pvManager->serializeItem($item);
            }
            $pvManager->setVaultContents($playerName, $slotRef, $serialized);
            $pvManager->save();
        });

        $menu->send($sender);
    }
}
