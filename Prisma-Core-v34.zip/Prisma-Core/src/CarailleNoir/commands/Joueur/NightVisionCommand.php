<?php

namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\data\bedrock\EffectIds;
use pocketmine\entity\effect\EffectInstance;
use pocketmine\entity\effect\VanillaEffects;
use pocketmine\lang\Translatable;

class NightVisionCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("nightvision", "Permet d'activer/désactiver le night vision", [], ["nv"]);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;
        $effects = $sender->getEffects();

        if (!$effects->has(VanillaEffects::NIGHT_VISION())) {
            $effects->add(new EffectInstance(VanillaEffects::NIGHT_VISION(), null, 255, false));
            $sender->sendMessage("§aEffet de NightVision activé");
        } else {
            $effects->remove(VanillaEffects::NIGHT_VISION());
            $sender->sendMessage("§cEffet de NightVision désactivé");
        }

    }
}