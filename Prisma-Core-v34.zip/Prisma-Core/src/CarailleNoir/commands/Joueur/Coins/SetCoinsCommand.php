<?php
namespace CarailleNoir\commands\Joueur\Coins;
use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
class SetCoinsCommand extends BaseCommand {
    public function __construct() { parent::__construct("setcoins", "Définir les coins d'un joueur", [], [], DefaultPermissions::ROOT_OPERATOR); }
    protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new IntegerArgument("amount")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        Manager::COINS()->setCoins($args["player"], (int)$args["amount"]);
        $sender->sendMessage("§aCoin définis à §f{$args["amount"]} §apour §f{$args["player"]}");
    }
}
