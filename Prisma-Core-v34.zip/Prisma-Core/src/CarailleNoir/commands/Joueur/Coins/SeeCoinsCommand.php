<?php
namespace CarailleNoir\commands\Joueur\Coins;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class SeeCoinsCommand extends BaseCommand {
    public function __construct() { parent::__construct("seecoins", "Voir ses/les coins", [], [], ["prisma.command.seecoins"]); }
    protected function prepare(): array { return [new TargetPlayerArgument(true, "player")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $name = $args["player"] ?? ($sender instanceof PrismaPlayer ? $sender->getName() : null);
        if ($name === null) { $sender->sendMessage("§cUsage: /seecoins [joueur]"); return; }
        $coins = Manager::COINS()->getCoins($name);
        $sender->sendMessage("§6Coins §fde §e{$name}§f : §6{$coins}");
    }
}
