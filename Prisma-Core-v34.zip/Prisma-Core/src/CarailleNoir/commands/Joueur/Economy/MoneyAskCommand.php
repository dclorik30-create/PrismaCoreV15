<?php
namespace CarailleNoir\commands\Joueur\Economy;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class MoneyAskCommand extends BaseCommand {
    public function __construct() { parent::__construct("moneyask", "Demander de l'argent à un joueur", [], [], ["prisma.command.moneyask"]); }
    protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new RawStringArgument("amount")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $target = \pocketmine\Server::getInstance()->getPlayerExact($args["player"]);
        $amount = (float)$args["amount"];
        if ($amount <= 0) { $sender->sendMessage("§cMontant invalide !"); return; }
        if (!$target instanceof PrismaPlayer) { $sender->sendMessage("§cJoueur introuvable !"); return; }
        $target->addMoneyRequest($sender->getName(), $amount);
        $sender->sendMessage("§aDemande envoyée à §f{$target->getName()} §apour §f" . number_format($amount,2) . "§6$");
        $target->sendMessage("§e{$sender->getName()} §fvous demande §a" . number_format($amount,2) . "§6$ §f— faites §a/payaccept {$sender->getName()} §fpour accepter");
    }
}
