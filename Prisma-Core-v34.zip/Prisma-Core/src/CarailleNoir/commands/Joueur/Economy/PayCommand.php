<?php
namespace CarailleNoir\commands\Joueur\Economy;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class PayCommand extends BaseCommand {
    public function __construct() { parent::__construct("pay", "Payer un joueur", [], [], ["prisma.command.pay"]); }
    protected function prepare(): array { return [new TargetPlayerArgument(false, "player"), new RawStringArgument("amount")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $target = \pocketmine\Server::getInstance()->getPlayerExact($args["player"]);
        $amount = (float)$args["amount"];
        if ($amount <= 0) { $sender->sendMessage("§cMontant invalide !"); return; }
        if (!$target instanceof PrismaPlayer) { $sender->sendMessage("§cJoueur introuvable !"); return; }
        if (!$sender->hasMoney($amount)) { $sender->sendMessage("§cVous n'avez pas assez d'argent !"); return; }
        $sender->removeMoney($amount);
        $target->addMoney($amount);
        $sender->sendMessage("§aVous avez envoyé §f" . number_format($amount, 2) . "§6$ §aà §f{$target->getName()}");
        $target->sendMessage("§aVous avez reçu §f" . number_format($amount, 2) . "§6$ §ade §f{$sender->getName()}");
    }
}
