<?php
namespace CarailleNoir\commands\Joueur\Economy;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;
class PayAcceptCommand extends BaseCommand {
    public function __construct() { parent::__construct("payaccept", "Accepter une demande d'argent", [], [], ["prisma.command.payaccept"]); }
    protected function prepare(): array { return [new TargetPlayerArgument(true, "player")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $fromName = $args["player"] ?? null;
        $req = $fromName ? $sender->getMoneyRequest($fromName) : $sender->getAnyMoneyRequest();
        if ($req === null) { $sender->sendMessage("§cAucune demande d'argent en attente !"); return; }
        $amount = $req["amount"];
        if (!$sender->hasMoney($amount)) { $sender->sendMessage("§cVous n'avez pas assez d'argent !"); return; }
        $requester = Server::getInstance()->getPlayerExact($req["from"]);
        $sender->removeMoney($amount);
        if ($requester instanceof PrismaPlayer) $requester->addMoney($amount);
        $sender->removeMoneyRequest($req["from"]);
        $sender->sendMessage("§aVous avez donné §f" . number_format($amount,2) . "§6$ §aà §f{$req["from"]}");
        $requester?->sendMessage("§a{$sender->getName()} §favous donné §f" . number_format($amount,2) . "§6$");
    }
}
