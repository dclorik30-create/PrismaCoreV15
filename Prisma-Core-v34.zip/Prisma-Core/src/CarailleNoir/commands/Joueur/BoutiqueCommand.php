<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\form\Form;
use pocketmine\player\Player;

class BoutiqueCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("boutique", "Ouvrir la boutique", [], [], ["prisma.command.boutique"]);
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;
        $sender->sendForm(new BoutiqueMainForm());
    }
}

// ── Menu principal ────────────────────────────────────────────────────────────
class BoutiqueMainForm implements Form
{
    public function jsonSerialize(): array
    {
        return [
            "type"    => "form",
            "title"   => "§6§lBoutique §r§7(Coins)",
            "content" => "§7Choisissez une catégorie :",
            "buttons" => [
                ["text" => "§2✦ Spawneur\n§7Zombie, Squelette, Creeper"],
                ["text" => "§6✦ Grade\n§7Noble, Héros, Dieu"],
                ["text" => "§5✦ Atout\n§7Protection Anti-Item"],
            ],
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!$player instanceof PrismaPlayer || $data === null) return;
        $player->sendForm(match ((int)$data) {
            0       => new BoutiqueSpawnerForm(),
            1       => new BoutiqueGradeForm(),
            2       => new BoutiqueAtoutForm(),
            default => new BoutiqueMainForm(),
        });
    }
}

// ── Spawneur ──────────────────────────────────────────────────────────────────
class BoutiqueSpawnerForm implements Form
{
    private const ITEMS = [
        "zombie"   => ["§2Zombie",    200],
        "skeleton" => ["§7Squelette", 200],
        "creeper"  => ["§aCreeper",   300],
    ];

    public function jsonSerialize(): array
    {
        $btns = [];
        foreach (self::ITEMS as [$lbl, $price]) {
            $btns[] = ["text" => "$lbl\n§7Prix : §e{$price} §6Coins"];
        }
        return ["type" => "form", "title" => "§2✦ Spawneur", "content" => "", "buttons" => $btns];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!$player instanceof PrismaPlayer || $data === null) return;
        $ids  = array_keys(self::ITEMS);
        $id   = $ids[$data] ?? null;
        if ($id === null) return;
        [$lbl, $price] = self::ITEMS[$id];
        if (!Manager::COINS()->hasCoins($player->getName(), $price)) {
            $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)");
            return;
        }
        Manager::COINS()->removeCoins($player->getName(), $price);
        $player->getInventory()->addItem(Manager::SPAWNER()->makeSpawnerItem($id));
        $player->sendMessage("§aAchat de §f$lbl §apour §e{$price} §6Coins §a!");
    }
}

// ── Grade ─────────────────────────────────────────────────────────────────────
class BoutiqueGradeForm implements Form
{
    private const GRADES = [
        "noble" => ["§7Noble",  "§7", 2000],
        "hero"  => ["§aHéros",  "§a", 5000],
        "dieu"  => ["§6§lDieu", "§6", 10000],
    ];

    public function jsonSerialize(): array
    {
        $btns = [];
        foreach (self::GRADES as [$lbl,, $price]) {
            $btns[] = ["text" => "$lbl\n§7Prix : §e{$price} §6Coins"];
        }
        return [
            "type"    => "form",
            "title"   => "§6✦ Grade",
            "content" => "§7L'achat remplace votre grade actuel.",
            "buttons" => $btns,
        ];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!$player instanceof PrismaPlayer || $data === null) return;
        $ids = array_keys(self::GRADES);
        $id  = $ids[$data] ?? null;
        if ($id === null) return;
        [$lbl, $color, $price] = self::GRADES[$id];
        if (!Manager::COINS()->hasCoins($player->getName(), $price)) {
            $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)");
            return;
        }
        $mgr = Manager::GRADE();
        if (!$mgr->existGrade($id)) {
            $name = preg_replace('/§[0-9a-fk-or]/i', '', $lbl);
            $mgr->createGrade($id, trim($name), $color);
        }
        Manager::COINS()->removeCoins($player->getName(), $price);
        $mgr->addGrade($player, $id, $player->getName());
        $player->sendMessage("§aGrade §r$lbl §aacheté pour §e{$price} §6Coins §a!");
    }
}

// ── Atout ─────────────────────────────────────────────────────────────────────
class BoutiqueAtoutForm implements Form
{
    private const ATOUTS = [
        "antiitem" => ["§dProtection Anti-Item", "§7Seul votre arc est bloqué.", 3000],
    ];

    public function jsonSerialize(): array
    {
        $btns = [];
        foreach (self::ATOUTS as [$lbl, $desc, $price]) {
            $btns[] = ["text" => "$lbl\n$desc\n§7Prix : §e{$price} §6Coins"];
        }
        return ["type" => "form", "title" => "§5✦ Atout", "content" => "", "buttons" => $btns];
    }

    public function handleResponse(Player $player, mixed $data): void
    {
        if (!$player instanceof PrismaPlayer || $data === null) return;
        $ids = array_keys(self::ATOUTS);
        $id  = $ids[$data] ?? null;
        if ($id === null) return;
        [$lbl,, $price] = self::ATOUTS[$id];
        if (Manager::ATOUT()->hasAtout($player->getName(), $id)) {
            $player->sendMessage("§cVous possédez déjà cet atout !");
            return;
        }
        if (!Manager::COINS()->hasCoins($player->getName(), $price)) {
            $player->sendMessage("§cPas assez de Coins ! (§e{$price} §6Coins §crequis)");
            return;
        }
        Manager::COINS()->removeCoins($player->getName(), $price);
        Manager::ATOUT()->addAtout($player->getName(), $id);
        $player->sendMessage("§aAtout §r$lbl §aacheté pour §e{$price} §6Coins §a!");
    }
}
