<?php

namespace CarailleNoir\commands\Joueur;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\Server;

class SpawnCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("spawn", "Ce téléporter au spawn");
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $sender->teleport(Server::getInstance()->getWorldManager()->getDefaultWorld()->getSpawnLocation());
        $sender->sendMessage("§aVous venez d'être téléporter au spawn");
    }
}