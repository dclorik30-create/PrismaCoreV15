<?php
namespace CarailleNoir\commands\Joueur;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\type\EventManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\world\Position;
class APCommand extends BaseCommand {
    public function __construct() { parent::__construct("ap", "Téléporter à l'avant-poste / voir l'event", [], [], ["prisma.command.ap"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $ev = Manager::EVENT();
        if (!$ev->isEventActive()) {
            $sender->sendMessage("§cAucun event en cours ! Revenez plus tard.");
            $sender->sendMessage("§7Events disponibles : §f" . implode(", ", $ev->getAvailableTypes()));
            return;
        }
        $type = $ev->getActiveEvent();
        $pos  = $ev->getEventPosition($type);
        $cfg  = $ev->getEventConfig($type);
        $worldName = $cfg["world"] ?? "world";
        $worldManager = \pocketmine\Server::getInstance()->getWorldManager();
        if (!$worldManager->isWorldLoaded($worldName)) $worldManager->loadWorld($worldName);
        $world = $worldManager->getWorldByName($worldName);
        if ($world === null || $pos === null) { $sender->sendMessage("§cImpossible de téléporter, monde introuvable."); return; }
        $sender->teleport(new Position($pos->x, $pos->y + 1, $pos->z, $world));
        $progress = $ev->getCaptureProgress();
        $required = $ev->getCaptureRequired();
        $pct = $required > 0 ? round($progress / $required * 100) : 0;
        $sender->sendMessage("§6[Event] §eType : §f" . strtoupper($type) . " §7| Capture : §a{$pct}%");
    }
}
