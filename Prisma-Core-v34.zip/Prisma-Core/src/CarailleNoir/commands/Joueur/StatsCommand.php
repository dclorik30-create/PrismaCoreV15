<?php
namespace CarailleNoir\commands\Joueur;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class StatsCommand extends BaseCommand {
    public function __construct() { parent::__construct("stats", "Voir ses statistiques", [], [], ["prisma.command.stats"]); }
    protected function prepare(): array { return [new TargetPlayerArgument(true, "player")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $name = $args["player"] ?? ($sender instanceof PrismaPlayer ? $sender->getName() : null);
        if ($name === null) { $sender->sendMessage("§cUsage: /stats [joueur]"); return; }
        $grade = Manager::GRADE()->getPlayerGradeData($name);
        $faction = Manager::FACTION()->getFactionByPlayer($name);
        $sender->sendMessage(implode("\n", [
            "§6§l--- Stats de §e{$name} §6---",
            "§7Grade : §f" . ($grade["name"] ?? "Joueur"),
            "§7Faction : §f" . ($faction?->getName() ?? "Aucune"),
            "§7Kills : §a" . Manager::STATS()->getKills($name),
            "§7Deaths : §c" . Manager::STATS()->getDeaths($name),
            "§7KDR : §e" . Manager::STATS()->getKDR($name),
            "§7Power : §b" . Manager::STATS()->getPower($name),
            "§7Argent : §6" . number_format(Manager::ECONOMY()->getMoney($name), 2) . "$",
            "§7Coins : §6" . Manager::COINS()->getCoins($name),
        ]));
    }
}
