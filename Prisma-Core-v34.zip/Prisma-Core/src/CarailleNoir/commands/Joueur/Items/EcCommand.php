<?php
namespace CarailleNoir\commands\Joueur\Items;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
class EcCommand extends BaseCommand {
    public function __construct() { parent::__construct("ec", "Ouvrir son ender chest", [], [], ["prisma.command.ec"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $menu = InvMenu::create(InvMenu::TYPE_CHEST);
        $menu->setName("§5Ender Chest");
        foreach ($sender->getEnderInventory()->getContents() as $slot => $item) $menu->getInventory()->setItem($slot, $item);
        $menu->setListener(function(\CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransaction $tx): \CarailleNoir\libs\muqsit\invmenu\transaction\InvMenuTransactionResult {
            return $tx->continue();
        });
        $menu->setInventoryCloseListener(function(\pocketmine\player\Player $p, \pocketmine\inventory\Inventory $inv): void {
            if (!$p instanceof PrismaPlayer) return;
            $p->getEnderInventory()->clearAll();
            foreach ($inv->getContents() as $slot => $item) $p->getEnderInventory()->setItem($slot, $item);
        });
        $menu->send($sender);
    }
}
