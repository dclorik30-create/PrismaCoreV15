<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class SellAllCommand extends BaseCommand
{
    public function __construct() { parent::__construct("sellall", "Vendre tous les items vendables", [], [], ["prisma.command.sellall"]); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;
        $total = 0.0;
        $inv   = $sender->getInventory();
        foreach ($inv->getContents() as $slot => $item) {
            $entry = Manager::SHOP()->getEntryForItem($item);
            if ($entry === null || ($entry["sell_price"] ?? 0) <= 0) continue;
            $total += (float)$entry["sell_price"] * $item->getCount();
            $inv->clear($slot);
        }
        if ($total <= 0) { $sender->sendMessage("§cAucun item vendable dans votre inventaire !"); return; }
        $sender->addMoney($total);
        $sender->sendMessage("§aVente totale : §f" . number_format($total, 2) . "§6$");
    }
}
