<?php
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\VanillaItems;

class SellHandCommand extends BaseCommand
{
    public function __construct() { parent::__construct("sellhand", "Vendre l'item en main", [], [], ["prisma.command.sellhand"]); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;
        $item  = $sender->getInventory()->getItemInHand();
        if ($item->isNull()) { $sender->sendMessage("§cVous ne tenez rien en main !"); return; }
        $entry = Manager::SHOP()->getEntryForItem($item);
        if ($entry === null || ($entry["sell_price"] ?? 0) <= 0) { $sender->sendMessage("§cCet item ne peut pas être vendu !"); return; }
        $total = (float)$entry["sell_price"] * $item->getCount();
        $sender->addMoney($total);
        $sender->getInventory()->setItemInHand(VanillaItems::AIR());
        $sender->sendMessage("§aVendu §f{$item->getCount()}x {$item->getName()} §apour §f" . number_format($total, 2) . "§6$");
    }
}
