<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Items;

use CarailleNoir\invmenu\CraftingTableInvMenuType;
use CarailleNoir\libs\muqsit\invmenu\InvMenu;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use pocketmine\command\CommandSender;
use pocketmine\player\Player;

class CraftCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("craft", "Ouvrir une table de craft", [], [], ["prisma.command.craft"]);
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof Player) {
            $sender->sendMessage("§cCette commande est réservée aux joueurs.");
            return;
        }
        InvMenu::create(CraftingTableInvMenuType::TYPE_ID)->send($sender);
    }
}
