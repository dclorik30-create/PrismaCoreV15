<?php
namespace CarailleNoir\commands\Joueur\Items;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\item\Durable;
class RepairCommand extends BaseCommand {
    private const REPAIR_COST = 500;
    public function __construct() { parent::__construct("repair", "Réparer l'item en main", [], [], ["prisma.command.repair"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $item = $sender->getInventory()->getItemInHand();
        if (!$item instanceof Durable) { $sender->sendMessage("§cCet item n'est pas réparable !"); return; }
        if ($item->getDamage() === 0) { $sender->sendMessage("§cVotre item n'est pas endommagé !"); return; }
        if (!$sender->hasMoney(self::REPAIR_COST)) { $sender->sendMessage("§cVous n'avez pas assez d'argent ! (§f" . number_format(self::REPAIR_COST,2) . "§6$§c requis)"); return; }
        $sender->removeMoney(self::REPAIR_COST);
        $item->setDamage(0);
        $sender->getInventory()->setItemInHand($item);
        $sender->sendMessage("§aItem réparé pour §f" . number_format(self::REPAIR_COST,2) . "§6$");
    }
}
