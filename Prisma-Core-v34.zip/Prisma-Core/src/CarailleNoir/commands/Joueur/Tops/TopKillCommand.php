<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopKillCommand extends BaseCommand {
    public function __construct() { parent::__construct("topkill", "Top kills", [], [], ["prisma.command.topkill"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $sender->sendMessage("§6§l--- TOP KILLS ---");
        $i = 1;
        foreach (Manager::STATS()->getTopKills(10) as $name => $data) {
            $sender->sendMessage("§e#{$i} §f{$name} §7— §a{$data["kills"]} kills"); $i++;
        }
    }
}
