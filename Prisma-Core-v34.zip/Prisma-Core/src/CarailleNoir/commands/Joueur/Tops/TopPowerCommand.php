<?php
namespace CarailleNoir\commands\Joueur\Tops;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
class TopPowerCommand extends BaseCommand {
    public function __construct() { parent::__construct("toppower", "Top power", [], [], ["prisma.command.toppower"]); }
    protected function prepare(): array { return []; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $sender->sendMessage("§6§l--- TOP POWER ---");
        $i = 1;
        foreach (Manager::STATS()->getTopPower(10) as $name => $data) {
            $sender->sendMessage("§e#{$i} §f{$name} §7— §b{$data["power"]} pts"); $i++;
        }
    }
}
