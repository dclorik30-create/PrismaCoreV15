<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class DescSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("desc", "Definir la description de la faction (max 100 caracteres)");
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("description", false)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

        $faction = $sender->getFaction();
        if (!$faction instanceof Faction) {
            FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []);
            return;
        }

        $name = $sender->getName();
        $isLeader = $faction->getOwner() === $name
            || in_array($name, $faction->get(FactionRoleEnum::SUB_OWNER), true);

        if (!$isLeader) {
            $sender->sendMessage("§cSeul le chef ou un sous-chef peut modifier la description.");
            return;
        }

        $desc = trim($args["description"] ?? "");
        if ($desc === "") {
            $sender->sendMessage("§eUsage : §f/f desc <description> §7(max 100 caracteres)");
            return;
        }
        if (mb_strlen($desc) > 100) {
            $sender->sendMessage("§cDescription trop longue (§e" . mb_strlen($desc) . "§c/100 caracteres max).");
            return;
        }

        $faction->setDescription($desc);
        $sender->sendMessage("§aDescription mise a jour : §f{$desc}");
    }
}
