<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub\Manage;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use pocketmine\command\CommandSender;

class LeaderSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("leader", "Permet de set le lead à une autre personne de sa faction");
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("playerName")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $fManager = Manager::FACTION();
        $faction = $sender->getFaction();

        if (!$faction instanceof Faction) {
            FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []);
            return;
        }

        if ($faction->getOwner() !== $sender->getName()) {
            FactionMessageEnum::NOT_OWNER->sendToPlayer($sender,[]);
            return;
        }

        $target = $args["playerName"];
        if (!Manager::ALIAS()->hasProfil($target)) {
            $sender->sendMessage(TextUtils::ALIAS_NO_EXIST);
            return;
        }

        if ($faction->getOwner() === $target) {
            FactionMessageEnum::ALREADY_OWNER->sendToPlayer($sender,[]);
            return;
        }

        if (!$faction->hasPlayer($target)) {
            FactionMessageEnum::TARGET_NOT_IN_FACTION->sendToPlayer($sender,[]);
            return;
        }

        FactionMessageEnum::NEW_OWNER->sendToFaction($faction, ["{OwnerName}" => $target]);

        $faction->add($sender->getName(), FactionRoleEnum::SUB_OWNER);
        $faction->remove($target);
        $faction->setOwner($target);
    }
}