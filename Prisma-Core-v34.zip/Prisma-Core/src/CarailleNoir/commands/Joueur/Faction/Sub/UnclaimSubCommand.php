<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class UnclaimSubCommand extends BaseSubCommand {
    public function __construct() { parent::__construct("unclaim", "Supprimer le claim du chunk actuel"); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $faction = $sender->getFaction();
        if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
        if ($faction->getOwner() !== $sender->getName()) {
            $sender->sendMessage("§cSeul le chef peut supprimer un claim !"); return;
        }
        $pos    = $sender->getPosition();
        $world  = $pos->getWorld()->getFolderName();
        $chunkX = $pos->getFloorX() >> 4;
        $chunkZ = $pos->getFloorZ() >> 4;

        $claimOwner = Manager::FACTION()->getClaimOwner($world, $chunkX, $chunkZ);
        if ($claimOwner === null || $claimOwner->getId() !== $faction->getId()) {
            $sender->sendMessage("§cCe chunk n'est pas claim par votre faction !"); return;
        }
        Manager::FACTION()->removeClaim($faction->getId(), $world, $chunkX, $chunkZ);
        $sender->sendMessage("§aChunk §f({$chunkX}, {$chunkZ}) §adéclaim !");
    }
}
