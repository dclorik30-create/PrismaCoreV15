<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class DelHomeSubCommand extends BaseSubCommand {
    public function __construct() { parent::__construct("delhome", "Supprimer le home de faction"); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $faction = $sender->getFaction();
        if ($faction === null) { $sender->sendMessage("§cVous n'avez pas de faction !"); return; }
        if (!$faction->hasHome()) { $sender->sendMessage("§cVotre faction n'a pas de home."); return; }
        $faction->deleteHome();
        Manager::FACTION()->save();
        $sender->sendMessage("§aHome de faction supprimé.");
    }
}
