<?php

namespace CarailleNoir\commands\Joueur\Faction\Sub;

use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class AcceptSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("accept", "Permet d'accepter une invitation dans une faction");
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $fManager = Manager::FACTION();
        $faction = $sender->getFaction();

        if ($faction instanceof Faction) {
            FactionMessageEnum::ALREADY_IN_FACTION->sendToPlayer($sender, []);
            return;
        }

        if (!$fManager->hasInvite($sender->getName())) {
            FactionMessageEnum::INVITE_NOT_FOUND->sendToPlayer($sender, []);
            return;
        }

        $factionI = $fManager->getLastInvite($sender->getName());
        if ($factionI === null) {
            FactionMessageEnum::INVITE_EXPIRE->sendToPlayer($sender, []);
            return;
        }

        FactionMessageEnum::FACTION_JOIN->sendToPlayer($sender, ["{faction}" => $factionI->getName()]);
        FactionMessageEnum::NEW_FACTION_JOIN->sendToFaction($factionI, ["{playername}" => $sender->getName()]);

        $factionI->add($sender->getName(), FactionRoleEnum::RECRUITS);
        $fManager->removeInvite($sender->getName());
        $sender->setFaction($factionI->getId());
    }
}