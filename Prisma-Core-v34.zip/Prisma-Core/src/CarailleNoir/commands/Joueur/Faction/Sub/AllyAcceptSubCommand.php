<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\Faction\FactionMessageEnum;
use CarailleNoir\managers\option\Faction\FactionRoleEnum;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class AllyAcceptSubCommand extends BaseSubCommand {
    public function __construct() { parent::__construct("allyaccept", "Accepter une demande d'alliance", [], []); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        $faction = $sender->getFaction();
        if ($faction === null) { FactionMessageEnum::NOT_IN_FACTION->sendToPlayer($sender, []); return; }

        $role = $faction->getPlayerRole($sender->getName());
        if ($role === null || $role->getPriority() < FactionRoleEnum::SUB_OWNER->getPriority()) {
            FactionMessageEnum::NOT_OWNER_OR_SUB->sendToPlayer($sender, []); return;
        }

        if (!Manager::FACTION()->hasAllyRequest($faction->getId())) {
            FactionMessageEnum::ALLY_NO_REQUEST->sendToPlayer($sender, []); return;
        }

        $senderFactionId = Manager::FACTION()->acceptAllyRequest($faction->getId());
        $senderFaction   = Manager::FACTION()->getFaction($senderFactionId);
        if ($senderFaction === null) { $sender->sendMessage("§cLa faction demandeuse n'existe plus."); return; }

        // Ally bidirectionnel
        $faction->addAlly($senderFactionId);
        $senderFaction->addAlly($faction->getId());
        Manager::FACTION()->save();

        FactionMessageEnum::ALLY_ACCEPTED->sendToPlayer($sender, ["{faction}" => $senderFaction->getName()]);
        foreach ($senderFaction->getOnlinePlayers() as $p) {
            FactionMessageEnum::ALLY_ACCEPTED->sendToPlayer($p, ["{faction}" => $faction->getName()]);
        }
    }
}
