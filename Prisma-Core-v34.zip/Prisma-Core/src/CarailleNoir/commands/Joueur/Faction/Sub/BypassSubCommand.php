<?php
namespace CarailleNoir\commands\Joueur\Faction\Sub;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class BypassSubCommand extends BaseSubCommand {
    public function __construct() { parent::__construct("bypass", "Bypass la protection des islands (OP)", [], []); }
    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        if (!$sender instanceof PrismaPlayer) return;
        if (!\pocketmine\Server::getInstance()->isOp($sender->getName())) {
            $sender->sendMessage("§cVous n'avez pas la permission d'utiliser cette commande !");
            return;
        }
        $active = Manager::FACTION()->toggleBypass($sender->getName());
        if ($active) {
            $sender->sendMessage("§6[Island Bypass] §aActivé — vous pouvez interagir avec toutes les islands.");
        } else {
            $sender->sendMessage("§6[Island Bypass] §cDésactivé.");
        }
    }
}
