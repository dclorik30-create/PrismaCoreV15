<?php

namespace CarailleNoir\commands\Admin;

use CarailleNoir\commands\Admin\Sub\Region\CreateSubCommand;
use CarailleNoir\commands\Admin\Sub\Region\DeleteSubCommand;
use CarailleNoir\commands\Admin\Sub\Region\EditSubCommand;
use CarailleNoir\commands\Admin\Sub\Region\ListSubCommand;
use CarailleNoir\commands\Admin\Sub\Region\TpSubCommand;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class RegionCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("region", "Gerer les régions", [
            new CreateSubCommand(),
            new DeleteSubCommand(),
            new EditSubCommand(),
            new ListSubCommand(),
            new TpSubCommand()
        ]);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;

    }

}
