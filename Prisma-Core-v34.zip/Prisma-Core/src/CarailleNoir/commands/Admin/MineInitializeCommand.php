<?php
namespace CarailleNoir\commands\Admin;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;

class MineInitializeCommand extends BaseCommand {
    public function __construct() { parent::__construct("mineinitialize", "Initialiser les positions bedrock d'une mine", [], [], ["prisma.command.staff", "prisma.command.mineinitialize"]); }
    protected function prepare(): array { return [new RawStringArgument("type")]; }
    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void {
        $type = strtolower((string)($args["type"] ?? ""));
        if (!in_array($type, ["mine", "minevip"], true)) {
            $sender->sendMessage("§cUsage : /mineinitialize <mine|minevip>");
            return;
        }
        $count = Manager::MINE()->initializeMine($type);
        $sender->sendMessage("§aInitialisation terminée pour §f{$type}§a : §e{$count} §abedrocks enregistrées.");
        $sender->sendMessage("§7Logique: bedrock -> 30s -> minerai, minerai cassé -> air -> bedrock -> 30s -> minerai.");
    }
}
