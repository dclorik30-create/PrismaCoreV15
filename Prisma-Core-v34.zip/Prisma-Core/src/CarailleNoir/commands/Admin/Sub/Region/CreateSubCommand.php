<?php

namespace CarailleNoir\commands\Admin\Sub\Region;

use CarailleNoir\libs\CortexPE\Commando\args\IntegerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Utils;
use pocketmine\command\CommandSender;

class CreateSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("create", "Créer une regions");
    }

    protected function prepare(): array
    {
        return [new RawStringArgument("id"), new RawStringArgument("name"), new IntegerArgument("priority", true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $id = $args["id"];
        $name = $args["name"];
        $priority = $args["priority"] ?? null;

        $positions = Manager::REGION()->getPositions($sender->getName());
        if (!$positions || !isset($positions["pos1"], $positions["pos2"])) {
            $sender->sendMessage("§cTu dois définir Pos1 et Pos2 avec le Region Wand avant de créer la région !");
            return;
        }

        $zone = Utils::getZone($positions["pos1"], $positions["pos2"]);

        Manager::REGION()->createRegion($sender, $id, $name, $zone, $sender->getWorld()->getDisplayName(), $priority);
    }
}