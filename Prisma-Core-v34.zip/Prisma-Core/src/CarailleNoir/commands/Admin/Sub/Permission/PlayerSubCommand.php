<?php

namespace CarailleNoir\commands\Admin\Sub\Permission;

use CarailleNoir\libs\CortexPE\Commando\args\OptionArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseSubCommand;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;
use pocketmine\permission\PermissionManager;
use pocketmine\Server;

class PlayerSubCommand extends BaseSubCommand
{
    public function __construct()
    {
        parent::__construct("player");
    }

    protected function prepare(): array
    {
        $allPermissions = array_filter(
            array_keys(PermissionManager::getInstance()->getPermissions()),
            fn($perm) => str_starts_with($perm, "prisma.")
        );

        return [new OptionArgument("type", "choix", ["list", "add", "remove"]), new TargetPlayerArgument(false, "playername"), new OptionArgument("name","permission", $allPermissions, true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        $type = $args["type"];
        $playerName = $args["playername"];
        $permission = $args["name"] ?? null;

        $target = Server::getInstance()->getPlayerExact($playerName);
        if (!$target instanceof PrismaPlayer) {
            $sender->sendMessage("Joueur introuvable ou hors ligne");
            return;
        }

        if ($type === "list") {
            $perms = $target->getPermissions();
            $sender->sendMessage("Permissions de {$target->getName()} : " . implode(", ", $perms));
            return;
        }

        if ($type === "add" || $type === "remove") {
            if (!$permission) {
                $sender->sendMessage("Paramètre 'permission' requis");
                return;
            }

            $allPermissions = array_filter(array_keys(PermissionManager::getInstance()->getPermissions()), fn($perm) => str_starts_with($perm, "prisma."));
            if (!in_array($permission, $allPermissions)) {
                $sender->sendMessage("La permission '$permission' n'existe pas.");
                return;
            }

            $sender->sendMessage("Action : $type");
            $sender->sendMessage("Joueur : " . $target->getName());
            $sender->sendMessage("Permission : $permission");

            if ($type === "add") {
                $target->addPermission($permission);
            } else {
                $target->removePermission($permission);
            }

            return;
        }

        $sender->sendMessage("Erreur : type invalide (list, add, remove)");
    }

}