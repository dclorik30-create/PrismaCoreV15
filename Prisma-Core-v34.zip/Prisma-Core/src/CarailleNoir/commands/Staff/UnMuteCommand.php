<?php
declare(strict_types=1);
namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\args\TextArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\command\CommandSender;

class UnMuteCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("unmute", "Commande pour unmute un joueur", [], [], ["prisma.command.unmute", "prisma.command.staff"]);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "name"), new TextArgument("reason", true)];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) return;
        $targetName = $args["name"] ?? null;
        if ($targetName === null) { $sender->sendMessage("§cUsage: /unmute <joueur> [raison]"); return; }
        $reason = $args["reason"] ?? "Aucune";

        if (!Manager::ALIAS()->hasProfil($targetName)) {
            $sender->sendMessage("§cCe joueur n'est jamais connecté au serveur.");
            return;
        }
        if (!Manager::MUTE()->isMuted($targetName)) {
            $sender->sendMessage("§a$targetName §fn'est pas mute.");
            return;
        }
        Manager::MUTE()->removeMute($targetName, $reason, $sender->getName());
    }
}
