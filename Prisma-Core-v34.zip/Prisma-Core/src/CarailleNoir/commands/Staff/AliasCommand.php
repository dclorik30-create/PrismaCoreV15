<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\exception\ArgumentOrderException;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\plugin\Plugin;

class AliasCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("alias", "Alias des joueurs", [], [], ["prisma.command.staff", "prisma.command.alias", DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "playername")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer) {
            $sender->sendMessage("§cCette commande ne peut être utilisée que par un joueur.");
            return;
        }
        var_dump($args);
        $targetName = $args["playername"];

        if (!Manager::ALIAS()->hasProfil($args["playername"])) {
            $sender->sendMessage("§cAucun profile trouver pour §f{$targetName}");
            return;
        }

        $alts = Manager::ALIAS()->getAccounts($targetName);

        $formatted = "§eAlias de §f{$targetName}§e:\n";
        if (empty($alts)) {
            $formatted .= "§7- §6Comptes liés§f: §cAucun trouvé";
        } else {
            $formatted .= "§7- §6Comptes liés§f: §a" . implode(", ", $alts);
        }

        $sender->sendMessage($formatted);
    }
}
