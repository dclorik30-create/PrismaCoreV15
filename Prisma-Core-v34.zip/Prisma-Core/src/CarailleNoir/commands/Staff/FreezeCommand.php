<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\TargetPlayerArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\Text\TextUtils;
use CarailleNoir\utils\Utils;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;
use pocketmine\plugin\Plugin;
use pocketmine\Server;

class FreezeCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("freeze", "Permet de freeze un joueur", [], [], ["prisma.command.staff", "prisma.command.freeze", DefaultPermissions::ROOT_OPERATOR]);
    }

    protected function prepare(): array
    {
        return [new TargetPlayerArgument(false, "playername")];
    }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;

        $targetName = $args["playername"];
        $target = Server::getInstance()->getPlayerExact($targetName);
        if ($target instanceof PrismaPlayer) {
            $target->freeze(!$target->isFreeze());
            $sender->sendMessage(str_replace(["{targetname}", "{freeze_status}"], ["$targetName", $target->isFreeze() ? "freeze" : "unfreeze"], TextUtils::SENDER_FREEZE));
            $target->sendMessage(str_replace("{freeze_status}", $target->isFreeze() ? "freeze" : "unfreeze", TextUtils::TARGET_FREEZE));

        }else {
            $sender->sendMessage("Le joueur $targetName n'est pas connecté");
        }
    }
}