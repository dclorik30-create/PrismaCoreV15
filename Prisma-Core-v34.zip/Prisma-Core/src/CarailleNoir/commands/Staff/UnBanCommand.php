<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\args\RawStringArgument;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\managers\Manager;
use pocketmine\command\CommandSender;
use pocketmine\permission\DefaultPermissions;

class UnBanCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("unban", "Commande pour unban un joueur");
        $this->setPermission(DefaultPermissions::ROOT_OPERATOR);

    }

    protected function prepare(): array
    {
        return [new RawStringArgument("name"), new RawStringArgument("reason")];
    }


    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $targetName = $args["name"];
        $reason = $args["reason"] ?? "Aucune";

        if (Manager::ALIAS()->hasProfil($targetName)) {
            if (Manager::BAN()->isBanned($targetName)) {
                Manager::BAN()->removeBan($targetName, $reason);

                $alts = Manager::ALIAS()->getAccounts($targetName);
                foreach ($alts as $alt) {
                    Manager::BAN()->removeBan($alt, "Double compte de : $targetName");
                }
                $sender->sendMessage("§eLe joueur §f$targetName §evient d'être unban");
            }else {
                $sender->sendMessage("§aLe joueur §f$targetName §an'est pas ban");
            }

        }else {
            $sender->sendMessage("§aLe joueur §f$targetName §ane c'est jamais connecté au serveur");
        }
    }
}