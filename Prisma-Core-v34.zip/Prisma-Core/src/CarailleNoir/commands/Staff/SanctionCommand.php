<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\invmenu\SanctionMenu;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\player\PrismaPlayer;
use CarailleNoir\utils\trait\Time;
use pocketmine\command\CommandSender;

class SanctionCommand extends BaseCommand
{
    use Time;
    public function __construct()
    {
        parent::__construct("sanction", "Fait apparaitre le menu de sanction", [], [], ["prisma.command.sanction", "prisma.command.staff"]);
    }

    protected function prepare(): array
    {
        return [];
    }

    public function onRun(CommandSender $sender, string $aliasUsed,array $args): void
    {
        if (!$sender instanceof PrismaPlayer)return;
        SanctionMenu::getSanctionMenu()->send($sender);
    }
}