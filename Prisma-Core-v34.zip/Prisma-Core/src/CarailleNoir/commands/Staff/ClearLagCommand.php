<?php

namespace CarailleNoir\commands\Staff;

use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\utils\Loader;
use pocketmine\command\CommandSender;

class ClearLagCommand extends BaseCommand
{
    public function __construct()
    {
        parent::__construct("clearlag", "Forcer un clearlag", [], [], ["prisma.command.clearlag"]);
    }

    protected function prepare(): array { return []; }

    public function onRun(CommandSender $sender, string $aliasUsed, array $args): void
    {
        $task = Loader::getClearlagTask();
        if ($task === null) {
            $sender->sendMessage("§cErreur : ClearlagTask non initialisée !");
            return;
        }
        $task->doClear();
        $sender->sendMessage("§aClearlag forcé !");
    }
}
