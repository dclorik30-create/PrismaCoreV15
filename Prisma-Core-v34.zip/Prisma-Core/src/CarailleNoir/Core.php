<?php

namespace CarailleNoir;

use CarailleNoir\handlers\ManagerHandler;
use CarailleNoir\libs\CortexPE\Commando\PacketHooker;
use CarailleNoir\libs\muqsit\invmenu\InvMenuHandler;
use CarailleNoir\utils\Loader;
use pocketmine\plugin\PluginBase;
use pocketmine\utils\Config;

class Core extends PluginBase
{
    private static self $self;


    public function onLoad(): void
    {
        self::$self = $this;
    }

    public static function getInstance(): self
    {
        return self::$self;
    }


    public function onEnable(): void
    {
        @mkdir($this->getDataFolder(), 0777, true);
        date_default_timezone_set("Europe/Paris");

        if(!PacketHooker::isRegistered()){
            PacketHooker::register($this);
        }

        if (!InvMenuHandler::isRegistered()) {
            InvMenuHandler::register($this);
        }

        ManagerHandler::Load();
        $this->getLogger()->info("§ePrisma Core§f activé avec §asuccès§f.");

        new Loader($this);
    }


    public function onDisable(): void
    {
        $this->getLogger()->info("§cSAUVEGARDE des données du serveur... Merci de ne pas kill le process !");
        ManagerHandler::UnLoad();
        $this->getLogger()->info("§aSAUVEGARDE des données du serveur terminée !");
    }

    public function getConfigFile(string $file): Config
    {
        return new Config($this->getDataFolder() . $file . ".yml", Config::YAML);
    }
}