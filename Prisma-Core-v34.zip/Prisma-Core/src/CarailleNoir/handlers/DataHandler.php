<?php

namespace CarailleNoir\handlers;

use CarailleNoir\Core;
use Symfony\Component\Filesystem\Path;

class DataHandler
{
    protected array $data = [];
    protected string $folderName = "";
    protected string $fileName = "Data.json";

    protected function getFilePath(): string
    {
        return Path::join(Core::getInstance()->getDataFolder(), $this->folderName, $this->fileName);
    }

    public function loadData(string $folderName, string $fileName = "Data.json"): void
    {
        $this->folderName = $folderName;
        $this->fileName = $fileName;

        $file = $this->getFilePath();
        if (file_exists($file)) {
            $json = file_get_contents($file);
            $this->data = json_decode($json, true) ?? [];
        } else {
            $this->data = [];
        }
    }

    public function saveData(): void
    {
        $folder = dirname($this->getFilePath());
        if (!is_dir($folder)) {
            mkdir($folder, 0777, true);
        }
        file_put_contents($this->getFilePath(), json_encode($this->data, JSON_PRETTY_PRINT));
    }

    public function getData(): array
    {
        return $this->data;
    }

    public function setData(array $data): void
    {
        $this->data = $data;
    }
}