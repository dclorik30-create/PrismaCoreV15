<?php

namespace CarailleNoir\utils\trait;

trait Time
{
    public function parseTime(string $time): ?int
    {
        $unit = strtolower(substr($time, -1));
        $amount = (int) substr($time, 0, -1);

        return match($unit) {
            's' => $amount,
            'm' => $amount * 60,
            'h' => $amount * 3600,
            'd' => $amount * 86400,
            'w' => $amount * 604800,
            "y" => $amount * 31536000,
            default => null
        };
    }

}