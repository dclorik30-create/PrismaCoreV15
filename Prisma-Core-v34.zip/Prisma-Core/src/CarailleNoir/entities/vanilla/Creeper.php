<?php
declare(strict_types=1);
namespace CarailleNoir\entities\vanilla;

use pocketmine\entity\EntitySizeInfo;
use pocketmine\entity\Living;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\item\StringToItemParser;
use pocketmine\math\Vector3;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;
use pocketmine\player\Player;

class Creeper extends Living
{
    public int $stack = 1;

    protected function initEntity(CompoundTag $nbt): void
    {
        $this->setNameTagAlwaysVisible(true);
        parent::initEntity($nbt);
        $splitted = explode("§f§lx", $this->getNameTag());
        if (isset($splitted[1])) {
            $this->stack = (int)$splitted[1];
        }
    }

    public static function getNetworkTypeId(): string { return EntityIds::CREEPER; }
    protected function getInitialSizeInfo(): EntitySizeInfo { return new EntitySizeInfo(1.8, 0.6); }
    public function getName(): string { return "Creeper"; }
    public function getXpHunter(): int { return 25; }
    public function getDrops(): array { return []; }
    public function getXpDropAmount(): int { return 2; }

    public function knockBack(float $x, float $z, float $force = 0, ?float $verticalLimit = 0.4): void
    {
        $this->setMotion(new Vector3($this->motion->x, $this->motion->y, $this->motion->z));
    }

    public function attack(EntityDamageEvent $source): void
    {
        if (!$this->isAlive()) return;
        $this->doHitAnimation();

        if ($source instanceof EntityDamageByEntityEvent) {
            $player = $source->getDamager();
            if ($player instanceof Player) {
                $this->giveRandomDrop($player);
            }
        }

        $this->stack--;

        if ($this->stack <= 0) {
            $source->cancel();
            $this->kill();
            return;
        }

        $this->setHealth($this->getMaxHealth());
        $this->setNameTag("§a§lCreeper §f§lx" . $this->stack);
        $source->cancel();
        parent::attack($source);
    }

    private function giveRandomDrop(Player $player): void
    {
        $item = StringToItemParser::getInstance()->parse("gunpowder");
        if ($item !== null) {
            $item->setCount(1);
            if ($player->getInventory()->canAddItem($item)) {
                $player->getInventory()->addItem($item);
            } else {
                $player->getWorld()->dropItem($player->getPosition(), $item);
            }
        }
    }
    // onUpdate() supprimé : stacking géré par SpawnerTask.
}
