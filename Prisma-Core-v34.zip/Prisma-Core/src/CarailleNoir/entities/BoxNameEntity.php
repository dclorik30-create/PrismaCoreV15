<?php

namespace CarailleNoir\entities;

use CarailleNoir\Core;
use pocketmine\entity\Entity;
use pocketmine\entity\EntitySizeInfo;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\network\mcpe\protocol\types\entity\EntityIds;

class BoxNameEntity extends Entity
{
    private ?string $BoxName = null;

    protected function initEntity(CompoundTag $nbt): void
    {
        $core = Core::getInstance();
        if (!is_null($nbt->getTag("BoxName")))
        {
            $this->BoxName = $nbt->getString("BoxName");
        }

        $this->setNameTagAlwaysVisible();
        $this->setNameTag(is_null($this->BoxName) ? "§cERREUR" : $this->BoxName);

        $this->setCanSaveWithChunk(true);
        $this->setScale(0.001);

        parent::initEntity($nbt);
    }

    public function saveNBT(): CompoundTag
    {
        $nbt = parent::saveNBT();
        $nbt->setString("BoxName", $this->BoxName);
        return $nbt;
    }

    public function attack(EntityDamageEvent $source): void
    {
        if ($source instanceof EntityDamageByEntityEvent) $source->cancel();
    }

    protected function getInitialSizeInfo(): EntitySizeInfo
    {
        return new EntitySizeInfo(0.7, 0.4);
    }

    protected function getInitialDragMultiplier(): float
    {
        return 0;
    }

    protected function getInitialGravity(): float
    {
        return 0;
    }

    public static function getNetworkTypeId(): string
    {
        return EntityIds::ARMOR_STAND;
    }

}