<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\Core;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\Block;
use pocketmine\event\block\BlockBreakEvent;
use pocketmine\event\block\BlockPlaceEvent;
use pocketmine\event\entity\EntityDeathEvent;
use pocketmine\event\Listener;
use pocketmine\item\StringToItemParser;

class SpawnerListener implements Listener
{
    private function getTypeFromBlock(Block $block): ?string
    {
        $name = preg_replace('/§[0-9a-fk-or]/i', '', $block->getName());
        return match(true) {
            str_contains($name, 'Zombie')    => 'zombie',
            str_contains($name, 'Squelette') => 'skeleton',
            str_contains($name, 'Skeleton')  => 'skeleton',
            str_contains($name, 'Creeper')   => 'creeper',
            default                          => null,
        };
    }

    public function onPlace(BlockPlaceEvent $event): void
    {
        foreach ($event->getTransaction()->getBlocks() as [$x, $y, $z, $block]) {
            $type = $this->getTypeFromBlock($block);
            if ($type === null) {
                $item = $event->getPlayer()->getInventory()->getItemInHand();
                $type = Manager::SPAWNER()->getSpawnerTypeFromItem($item);
            }
            if ($type === null) continue;
            Manager::SPAWNER()->register($block->getPosition(), $type);
            Manager::SPAWNER()->save(Core::getInstance());
            $event->getPlayer()->sendMessage("§a\u2713 Spawner §f" . ucfirst($type) . " §aplacé !");
        }
    }

    public function onBreak(BlockBreakEvent $event): void
    {
        $pos   = $event->getBlock()->getPosition();
        $block = $event->getBlock();
        if (!Manager::SPAWNER()->isSpawner($pos)) {
            $type = $this->getTypeFromBlock($block);
            if ($type === null) return;
            Manager::SPAWNER()->register($pos, $type);
        }
        $type = Manager::SPAWNER()->getType($pos);
        $eid  = Manager::SPAWNER()->getEntityId($pos);
        if ($eid !== null) $pos->getWorld()->getEntity($eid)?->kill();
        $event->setDrops([]);
        $pos->getWorld()->dropItem($pos->add(0.5, 0.5, 0.5), Manager::SPAWNER()->makeSpawnerItem($type));
        Manager::SPAWNER()->unregister($pos);
        Manager::SPAWNER()->save(Core::getInstance());
    }

    public function onEntityDeath(EntityDeathEvent $event): void
    {
        $entity = $event->getEntity();
        $data   = Manager::SPAWNER()->getSpawnerByEntity($entity->getId());
        if ($data === null) return;

        $type = $data["type"];

        $event->setDrops([]);
        // FIX loot : rollLoots avec stack=1 (pas de multiplication par nb de spawners)
        // Les drops par stack sont déjà distribués via giveRandomDrop() à chaque hit.
        foreach (Manager::SPAWNER()->rollLoots($type, 1) as $loot) {
            $item = StringToItemParser::getInstance()->parse($loot["item"]);
            if ($item !== null) {
                $item->setCount($loot["amount"]);
                $entity->getWorld()->dropItem($entity->getPosition(), $item);
            }
        }

        $cause   = $entity->getLastDamageCause();
        $damager = method_exists($cause ?? new \stdClass, 'getDamager') ? $cause->getDamager() : null;
        if ($damager instanceof PrismaPlayer) {
            Manager::STATS()->addKill($damager->getName());
            $damager->sendMessage("§a+1 kill §8(Spawner §f{$type}§8)");
        }
        Manager::SPAWNER()->onEntityDeath($entity->getId());
    }
}
