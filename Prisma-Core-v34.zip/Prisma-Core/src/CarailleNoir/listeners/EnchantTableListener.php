<?php
namespace CarailleNoir\listeners;

use CarailleNoir\managers\type\CustomEnchantManager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\block\BlockTypeIds;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerInteractEvent;
use pocketmine\form\Form;

class EnchantTableListener implements Listener
{
    public function onInteract(PlayerInteractEvent $event): void
    {
        $player = $event->getPlayer();
        if (!$player instanceof PrismaPlayer) return;
        if ($event->getAction() !== PlayerInteractEvent::RIGHT_CLICK_BLOCK) return;
        if ($event->getBlock()->getTypeId() !== BlockTypeIds::ENCHANTING_TABLE) return;

        $event->cancel();
        $item = $player->getInventory()->getItemInHand();

        if ($item->isNull()) {
            $player->sendMessage("§cTenez un item en main pour l'enchanter !");
            return;
        }

        $manager = new CustomEnchantManager();
        $buttons = $manager->buildFormButtons($item);

        $player->sendForm(new class($item, $buttons, $manager) implements Form {
            public function __construct(
                private \pocketmine\item\Item $item,
                private array $buttons,
                private CustomEnchantManager $mgr
            ) {}

            public function jsonSerialize(): array
            {
                $btns = array_map(fn($b) => ["text" => $b["text"]], $this->buttons);
                $btns[] = ["text" => "§7Fermer"];
                return [
                    "type"    => "form",
                    "title"   => "§5§lTable d'Enchantement",
                    "content" => "§7Item§8: §f{$this->item->getName()}\n§7Choisissez un enchantement :",
                    "buttons" => $btns,
                ];
            }

            public function handleResponse(\pocketmine\player\Player $player, mixed $data): void
            {
                if (!$player instanceof PrismaPlayer || $data === null) return;
                if ($data >= count($this->buttons)) return;

                $sel     = $this->buttons[$data];
                $id      = $sel["id"];
                $current = $sel["current"];
                $max     = $sel["max"];
                $price   = $sel["price"];

                if ($current >= $max) { $player->sendMessage("§cNiveau maximum atteint !"); return; }
                if (!$player->hasMoney((float)$price)) {
                    $player->sendMessage("§cPas assez d'argent ! (§f{$price}§6\$§c requis)");
                    return;
                }
                $hand = $player->getInventory()->getItemInHand();
                if ($hand->isNull() || $hand->getTypeId() !== $this->item->getTypeId()) {
                    $player->sendMessage("§cTenez toujours le même item en main !");
                    return;
                }
                $newLevel  = $current + 1;
                $enchanted = $this->mgr->setItemEnchant($hand, $id, $newLevel);
                $player->removeMoney((float)$price);
                $player->getInventory()->setItemInHand($enchanted);
                $label = $this->mgr->getEnchant($id)["label"] ?? $id;
                $player->sendMessage("§a{$label} §fNiv.{$newLevel} §aappliqué ! (§f-{$price}§6\$§a)");
            }
        });
    }
}
