<?php

namespace CarailleNoir\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\RegionOption;
use pocketmine\block\BlockTypeIds;
use pocketmine\event\block\BlockBurnEvent;
use pocketmine\event\block\BlockExplodeEvent;
use pocketmine\event\block\BlockGrowEvent;
use pocketmine\event\block\BlockMeltEvent;
use pocketmine\event\block\BlockUpdateEvent;
use pocketmine\event\block\LeavesDecayEvent;
use pocketmine\event\Listener;
use pocketmine\event\server\DataPacketReceiveEvent;
use pocketmine\event\server\DataPacketSendEvent;
use pocketmine\network\mcpe\protocol\ProtocolInfo;
use pocketmine\network\mcpe\protocol\SetTimePacket;

class ServerListener implements Listener
{
    public function onBlockGrow(BlockGrowEvent $event): void
    {
        $bloc = $event->getBlock();
        $region = Manager::REGION()->getMainRegionAt($bloc->getPosition()->asVector3());
        if ($region !== null) {
            if (!$region->isSettingsEnabled(RegionOption::PARAM_GROW->getType())) {
                $event->cancel();
                return;
            }
        }
    }

    public function onBlockExplode(BlockExplodeEvent $event): void
    {
        $bloc = $event->getBlock();
        $region = Manager::REGION()->getMainRegionAt($bloc->getPosition()->asVector3());
        if ($region !== null) {
            if (!$region->isSettingsEnabled(RegionOption::PARAM_EXPLOSION->getType())) {
                $event->cancel();
                return;
            }
        }
    }

    public function onLeavesDecay(LeavesDecayEvent $event): void {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null) {
            if (!$region->isSettingsEnabled(RegionOption::PARAM_DECAY->getType())) {
                $event->cancel();
                return;
            }
        }
    }

    public function onBlockMelt(BlockMeltEvent $event): void {
        $region = Manager::REGION()->getMainRegionAt($event->getBlock()->getPosition()->asVector3());
        if ($region !== null) {
            if (!$region->isSettingsEnabled(RegionOption::PARAM_DECAY->getType())) {
                $event->cancel();
                return;
            }
        }
    }

    public function onPacketSend(DataPacketSendEvent $event): void {
        foreach ($event->getPackets() as $packet) {
            if ($packet instanceof SetTimePacket) {
                $packet->time = 1000;
            }
        }
    }
}