<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\Core;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageByEntityEvent;
use pocketmine\event\Listener;
use pocketmine\math\Vector3;
use pocketmine\scheduler\ClosureTask;

class KnockbackListener implements Listener
{
    private float $kbX;
    private float $kbY;
    private float $kbZ;
    private int   $hitDelay;

    public function __construct()
    {
        $path = Core::getInstance()->getDataFolder() . "knockback.yml";
        if (!file_exists($path)) {
            file_put_contents($path,
                "# Knockback custom\n# Augmenté vers l'avant (x/z), réduit vers le haut (y)\nhorizontal_x: 0.48\nvertical_y: 0.28\nhorizontal_z: 0.48\nhit_delay: 8\n"
            );
        }
        $cfg = yaml_parse_file($path) ?? [];
        $this->kbX      = (float)($cfg["horizontal_x"] ?? 0.48);
        $this->kbY      = (float)($cfg["vertical_y"]   ?? 0.28);
        $this->kbZ      = (float)($cfg["horizontal_z"] ?? 0.48);
        $this->hitDelay = (int)  ($cfg["hit_delay"]    ?? 8);
    }

    /** @priority HIGHEST */
    public function onDamage(EntityDamageByEntityEvent $event): void
    {
        $damager = $event->getDamager();
        $victim  = $event->getEntity();
        if (!$damager instanceof PrismaPlayer || !$victim instanceof PrismaPlayer) return;
        if ($event->isCancelled()) return;

        $event->setKnockBack(0.0);
        $event->setAttackCooldown($this->hitDelay);

        $dx  = $victim->getPosition()->x - $damager->getPosition()->x;
        $dz  = $victim->getPosition()->z - $damager->getPosition()->z;
        $len = sqrt($dx * $dx + $dz * $dz);
        if ($len < 0.001) { $dx = 1.0; $dz = 0.0; $len = 1.0; }
        $dx /= $len; $dz /= $len;

        $kbX = $this->kbX; $kbY = $this->kbY; $kbZ = $this->kbZ;
        Core::getInstance()->getScheduler()->scheduleDelayedTask(
            new ClosureTask(static function() use ($victim, $dx, $dz, $kbX, $kbY, $kbZ): void {
                if (!$victim->isClosed()) {
                    $victim->setMotion(new Vector3($dx * $kbX, $kbY, $dz * $kbZ));
                }
            }), 1
        );
    }
}
