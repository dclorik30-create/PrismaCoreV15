<?php
namespace CarailleNoir\listeners;

use CarailleNoir\tasks\ItemClearTask;
use pocketmine\entity\object\ItemEntity;
use pocketmine\event\entity\EntitySpawnEvent;
use pocketmine\event\entity\ItemDespawnEvent;
use pocketmine\event\Listener;

class ItemClearListener implements Listener
{
    public function __construct(private ?ItemClearTask $task) {}

    public function onEntitySpawn(EntitySpawnEvent $event): void
    {
        if ($this->task === null) return;
        $entity = $event->getEntity();
        if ($entity instanceof ItemEntity) $this->task->register($entity);
    }

    public function onItemDespawn(ItemDespawnEvent $event): void
    {
        if ($this->task !== null) $this->task->unregister($event->getEntity()->getId());
    }
}
