<?php
declare(strict_types=1);
namespace CarailleNoir\listeners;

use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\event\entity\EntityDamageEvent;
use pocketmine\event\Listener;
use pocketmine\event\player\PlayerMoveEvent;
use pocketmine\event\player\PlayerQuitEvent;
use pocketmine\math\Vector3;

/**
 * Detecte entrees/sorties de zone Outpost via PlayerMoveEvent.
 * Uniquement les changements de bloc sont traites (optimisation).
 */
class OutpostListener implements Listener
{
    /** @var array<string, bool> playerName => estDansZone */
    private array $inZone = [];

    public function onMove(PlayerMoveEvent $event): void
    {
        $player = $event->getPlayer();
        if (!($player instanceof PrismaPlayer)) return;

        $from = $event->getFrom();
        $to   = $event->getTo();

        // Ignorer si le joueur n'a pas change de bloc
        if ((int)floor($from->getX()) === (int)floor($to->getX())
            && (int)floor($from->getY()) === (int)floor($to->getY())
            && (int)floor($from->getZ()) === (int)floor($to->getZ())) {
            return;
        }

        $outpost = Manager::OUTPOST();
        $name    = $player->getName();
        $wasIn   = $this->inZone[$name] ?? false;
        $isIn    = $outpost->isInZone($to);

        if (!$wasIn && $isIn) {
            // Entree dans la zone
            $faction = $player->getFaction();
            if ($faction === null) {
                $player->sendTip("§c[Outpost] Vous devez etre dans une faction pour capturer !");
                return;
            }
            $this->inZone[$name] = true;
            $outpost->enterZone($name, $faction->getId());
            $player->sendTip("§e[Outpost] §fVous etes entré dans la zone de capture !");
        } elseif ($wasIn && !$isIn) {
            // Sortie de la zone
            $this->inZone[$name] = false;
            $outpost->leaveZone($name);
            $player->sendTip("§e[Outpost] §fVous avez quitté la zone de capture.");
        }
    }

    public function onQuit(PlayerQuitEvent $event): void
    {
        $name = $event->getPlayer()->getName();
        if ($this->inZone[$name] ?? false) {
            Manager::OUTPOST()->leaveZone($name);
            unset($this->inZone[$name]);
        }
    }

    public function onDamage(EntityDamageEvent $event): void
    {
        // Si le joueur meurt dans la zone, on le retire
        $entity = $event->getEntity();
        if (!($entity instanceof PrismaPlayer)) return;
        if ($event->getFinalDamage() < $entity->getHealth()) return;

        $name = $entity->getName();
        if ($this->inZone[$name] ?? false) {
            Manager::OUTPOST()->leaveZone($name);
            unset($this->inZone[$name]);
        }
    }
}
