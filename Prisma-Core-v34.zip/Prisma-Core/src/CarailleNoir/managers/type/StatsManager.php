<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class StatsManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("Stats");
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = ["kills" => 0, "deaths" => 0, "power" => 0];
        }
    }

    public function addKill(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["kills"]++;
        $this->addPower($player, 10);
    }

    public function addDeath(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["deaths"]++;
    }

    public function addPower(string $player, int $amount): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["power"] += $amount;
    }

    public function getKills(string $player): int
    {
        return (int)($this->data[strtolower($player)]["kills"] ?? 0);
    }

    public function getDeaths(string $player): int
    {
        return (int)($this->data[strtolower($player)]["deaths"] ?? 0);
    }

    public function getPower(string $player): int
    {
        return (int)($this->data[strtolower($player)]["power"] ?? 0);
    }

    public function getKDR(string $player): string
    {
        $k = $this->getKills($player);
        $d = $this->getDeaths($player);
        return $d === 0 ? (string)$k : number_format($k / $d, 2);
    }

    public function getTopKills(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["kills"] ?? 0) <=> ($a["kills"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopDeaths(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["deaths"] ?? 0) <=> ($a["deaths"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopPower(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["power"] ?? 0) <=> ($a["power"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }
}
