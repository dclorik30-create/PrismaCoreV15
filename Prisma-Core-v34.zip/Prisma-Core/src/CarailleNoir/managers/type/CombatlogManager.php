<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;
class CombatlogManager {
    private array $combatTags=[], $lastAttacker=[];
    private const DUR=15;
    public function tag(string $p): void { $this->combatTags[strtolower($p)]=time()+self::DUR; }
    public function isTagged(string $p): bool {
        $k=strtolower($p);
        if(!isset($this->combatTags[$k])) return false;
        if(time()>$this->combatTags[$k]){unset($this->combatTags[$k],$this->lastAttacker[$k]);return false;}
        return true;
    }
    public function getRemainingTime(string $p): int { return max(0,($this->combatTags[strtolower($p)]??0)-time()); }
    public function untag(string $p): void { $k=strtolower($p); unset($this->combatTags[$k],$this->lastAttacker[$k]); }
    public function setLastAttacker(string $v, string $a): void { $this->lastAttacker[strtolower($v)]=$a; }
    public function getLastAttacker(string $v): ?string { return $this->lastAttacker[strtolower($v)]??null; }
    public function getDuration(): int { return self::DUR; }
    public function getTagRemaining(string $p): int { return $this->getRemainingTime($p); }
}
