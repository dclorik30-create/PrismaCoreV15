<?php

namespace CarailleNoir\managers\type\Region;

use pocketmine\math\AxisAlignedBB;

class Region
{
    public function __construct(
        private string $id,
        private string $name,
        private AxisAlignedBB $zone,
        private string $worldName,
        private int $priority = 0,
        private array $params
    ) {}

    public function getId(): string {
        return $this->id;
    }

    public function getName(): string {
        return $this->name;
    }

    public function getWorldName(): string
    {
        return $this->worldName;
    }

    public function getZone(): AxisAlignedBB{
        return $this->zone;
    }

    public function getPriority(): int {
        return $this->priority;
    }

    public function getParams(): array
    {
        return $this->params;
    }

    public static function serialize(self $region): array {
        return [
            "id" => $region->id,
            "name" => $region->name,
            "zone" => serialize($region->zone),
            "world" => $region->worldName,
            "priority" => $region->priority,
            "params" => $region->params
        ];
    }

    public static function unserialize(array $data): self {
        return new self(
            $data["id"],
            $data["name"],
            unserialize($data["zone"]),
            $data["world"],
            $data["priority"],
            $data["params"],
        );
    }

    public function isSettingsEnabled(string $parametre): bool {
        return $this->params[$parametre] ?? false;
    }
}