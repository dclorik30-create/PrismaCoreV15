<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;
use pocketmine\Server;

class MuteManager extends DataHandler
{

    public function init(): void
    {
        $this->loadData("Mute");
    }

    public function addMute(string $playerName, string $reason, string $staff = "Console", ?int $duration = null): void
    {
        $expire = is_null($duration) ? null : (time() + $duration);
        $this->data[strtolower($playerName)] = [
            "reason" => $reason,
            "staff"  => $staff,
            "expire" => $expire
        ];
        $exp = $duration ? date("d/m/Y H:i:s", time() + $duration) : "Permanent";
        Server::getInstance()->broadcastMessage("§c[MUTE] §f$playerName §7— §e$reason §7| Staff: $staff §7| Expire: $exp");
        Manager::WARN()->incrementMute($playerName);
    }

    public function removeMute(string $playerName, string $reason, string $staff): void
    {
        if (isset($this->data[strtolower($playerName)])) {
            unset($this->data[strtolower($playerName)]);
            Server::getInstance()->broadcastMessage("Le joueur $playerName vient d'être unmute\nraison : $reason\nStaff : $staff");
        }
    }

    public function isMuted(PrismaPlayer|string $player): bool
    {
        if ($player instanceof PrismaPlayer) {
            $name = strtolower($player->getName());
        }else {
            $name = strtolower($player);
        }

        if ($this->checkActiveMute($name)) {
            return true;
        }

        return false;
    }

    private function checkActiveMute(string $name): bool
    {
        if (!isset($this->data[strtolower($name)])) {
            return false;
        }

        $mute = $this->data[strtolower($name)];

        if ($mute["expire"] === null) {
            return true;
        }


        if ($mute["expire"] < time()) {
            unset($this->data[strtolower($name)]);
            return false;
        }
        return true;
    }

    public function getMuteInfo(PrismaPlayer $player): array
    {
        $name = strtolower($player->getName());

        if ($this->checkActiveMute($name)) {
            return $this->data[$name];
        }

        return [
            "reason" => "Aucune raison trouvée",
            "staff" => "Console",
            "expire" => null
        ];
    }
}