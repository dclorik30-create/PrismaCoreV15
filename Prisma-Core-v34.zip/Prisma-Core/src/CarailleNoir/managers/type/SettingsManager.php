<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class SettingsManager extends DataHandler
{
    public const SETTING_SCOREBOARD    = "scoreboard";
    public const SETTING_NIGHTVISION   = "nightvision";
    public const SETTING_PARTICLES     = "particles";
    public const SETTING_CPS           = "cps";

    private static array $defaults = [
        self::SETTING_SCOREBOARD  => true,
        self::SETTING_NIGHTVISION => true,
        self::SETTING_PARTICLES   => false,
        self::SETTING_CPS         => false,
    ];

    public function init(): void
    {
        $this->loadData("Settings");
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = self::$defaults;
        }
    }

    public function getSetting(string $player, string $setting): bool
    {
        $this->ensurePlayer($player);
        return (bool)($this->data[strtolower($player)][$setting] ?? self::$defaults[$setting] ?? false);
    }

    public function toggleSetting(string $player, string $setting): bool
    {
        $this->ensurePlayer($player);
        $key = strtolower($player);
        $this->data[$key][$setting] = !($this->data[$key][$setting] ?? true);
        return $this->data[$key][$setting];
    }

    public function getAll(string $player): array
    {
        $this->ensurePlayer($player);
        return $this->data[strtolower($player)];
    }
}
