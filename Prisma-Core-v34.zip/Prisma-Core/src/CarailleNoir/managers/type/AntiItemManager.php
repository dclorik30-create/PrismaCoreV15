<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;
class AntiItemManager {
    private array $effects = [];
    public function apply(string $p, int $d=20): void { $this->effects[strtolower($p)]=time()+$d; }
    public function hasEffect(string $p): bool {
        $k=strtolower($p);
        if(!isset($this->effects[$k])) return false;
        if(time()>$this->effects[$k]){unset($this->effects[$k]);return false;}
        return true;
    }
    public function getRemaining(string $p): int { return max(0,($this->effects[strtolower($p)]??0)-time()); }
    public function remove(string $p): void { unset($this->effects[strtolower($p)]); }
}
