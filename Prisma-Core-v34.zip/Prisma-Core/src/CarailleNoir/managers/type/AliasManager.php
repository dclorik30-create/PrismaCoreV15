<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use CarailleNoir\managers\Manager;
use CarailleNoir\player\PrismaPlayer;

class AliasManager extends DataHandler
{

    public function init(): void
    {
        $this->loadData("Alias");
    }


    public function getProfileData(PrismaPlayer|string $player): ?array
    {
        if ($player instanceof PrismaPlayer) {
            return [
                "username" => $player->getName(),
                "ip" => $player->getNetworkSession()->getIp(),
                "did" => $player->getPlayerInfo()->getExtraData()["DeviceId"]
            ];
        }

        return $this->data[$player] ?? null;
    }

    public function createProfil(PrismaPlayer $player): void
    {
        $this->data[$player->getName()] = $this->getProfileData($player);
        Manager::GRADE()->setDefaultGrade($player->getName(), );
    }

    public function hasProfil(string $playerName): bool
    {
        return isset($this->data[$playerName]);
    }

    public function getAccounts(PrismaPlayer|string $player): array
    {
        $profile = $this->getProfileData($player);
        if ($profile === null) {
            return [];

        }
        $currentName = $profile["username"];
        $currentIp = $profile["ip"];
        $currentDid = $profile["did"];

        $alts = [];

        foreach ($this->data as $name => $info) {
            if (strtolower($name) === strtolower($currentName)) {
                continue;
            }

            $sameIp = $info["ip"] === $currentIp;
            $sameDid = $info["did"] === $currentDid;

            if ($sameIp || $sameDid) {
                $alts[] = $name;
            }
        }

        return $alts;
    }

}