<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use pocketmine\item\Item;
use pocketmine\nbt\LittleEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class PlayerVaultManager
{
    private array $vaults = [];

    private static array $maxVaultsByGrade = [
        "joueur" => 2,
        "noble"  => 4,
        "heros"  => 7,
        "dieu"   => 10
    ];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "PlayerVaults/";
        if (!is_dir($path)) mkdir($path, 0777, true);

        foreach (glob($path . "*.json") as $file) {
            $player = strtolower(basename($file, ".json"));
            $this->vaults[$player] = json_decode(file_get_contents($file), true) ?? [];
        }
    }

    public function save(): void
    {
        $path = Core::getInstance()->getDataFolder() . "PlayerVaults/";
        foreach ($this->vaults as $player => $vaults) {
            file_put_contents($path . $player . ".json", json_encode($vaults, JSON_PRETTY_PRINT));
        }
    }

    public function getMaxVaults(string $gradeId): int
    {
        return self::$maxVaultsByGrade[strtolower($gradeId)] ?? 2;
    }

    public function hasVault(string $player, int $slot): bool
    {
        return isset($this->vaults[strtolower($player)][$slot]);
    }

    public function getVaultContents(string $player, int $slot): array
    {
        return $this->vaults[strtolower($player)][$slot] ?? [];
    }

    public function setVaultContents(string $player, int $slot, array $serializedItems): void
    {
        $this->vaults[strtolower($player)][$slot] = $serializedItems;
    }

    public function serializeItem(Item $item): string
    {
        $serializer = new LittleEndianNbtSerializer();
        return base64_encode($serializer->write(new TreeRoot($item->nbtSerialize())));
    }

    public function deserializeItem(string $data): ?Item
    {
        try {
            $serializer = new LittleEndianNbtSerializer();
            $nbt = $serializer->read(base64_decode($data))->mustGetCompoundTag();
            return Item::nbtDeserialize($nbt);
        } catch (\Throwable) {
            return null;
        }
    }
}
