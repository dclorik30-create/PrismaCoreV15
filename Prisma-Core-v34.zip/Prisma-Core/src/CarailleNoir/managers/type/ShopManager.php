<?php
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\items\SpecialItems;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;

class ShopManager
{
    private array $shops = [];

    private static array $defaultShops = [
        'pvp' => ['name' => '§cPVP', 'items' => []],
        'farm' => ['name' => '§aFARM', 'items' => []],
        'block' => ['name' => '§6BLOCK', 'items' => []],
        'mob' => ['name' => '§5MOB', 'items' => []],
        'minage' => ['name' => '§bMINAGE', 'items' => []],
    ];

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "shop.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode(self::$defaultShops, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        $loaded = json_decode(file_get_contents($path), true);
        if (!is_array($loaded) || isset($loaded["resources"]) || isset($loaded["food"]) || isset($loaded["combat"])) {
            $loaded = self::$defaultShops;
            file_put_contents($path, json_encode($loaded, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }
        $this->shops = $loaded;
    }

    public function addItemToCategory(string $catId, Item $item, ?float $buy = null, ?float $sell = null): bool
    {
        $catId = strtolower($catId);
        if (!isset($this->shops[$catId])) {
            return false;
        }

        $this->shops[$catId]["items"][] = [
            "item" => method_exists($item, "getTypeId") ? (string) ($this->detectItemStringId($item) ?? strtolower(str_replace(' ', '_', $item->getVanillaName()))) : strtolower(str_replace(' ', '_', $item->getVanillaName())),
            "itemData" => $this->itemToNbt($item),
            "buy" => $buy ?? 0,
            "sell" => $sell ?? 0,
            "name" => $item->getName(),
            "amount" => $item->getCount()
        ];
        $this->save();
        return true;
    }

    private function detectItemStringId(Item $item): ?string
    {
        foreach ([
            'prisma:freeze_stick' => SpecialItems::makeFreezeStick(),
            'prisma:anti_pearl_stick' => SpecialItems::makeAntiPearlStick(),
            'prisma:anti_item_stick' => SpecialItems::makeAntiItemStick(),
            'prisma:bump' => SpecialItems::makeBump(),
        ] as $id => $ref) {
            if ($ref->getTypeId() === $item->getTypeId()) {
                if ($ref->getCustomName() !== '' && $item->getCustomName() !== '' && $ref->getCustomName() !== $item->getCustomName()) {
                    continue;
                }
                return $id;
            }
        }
        return null;
    }

    public function save(): void
    {
        file_put_contents(Core::getInstance()->getDataFolder() . "shop.json", json_encode($this->shops, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
    }

    public function getCategories(): array { return $this->shops; }
    public function getCategory(string $id): ?array { return $this->shops[strtolower($id)] ?? null; }

    public function getItemsByCategory(string $catId): array
    {
        $cat = $this->getCategory($catId);
        if ($cat === null) return [];
        $result = [];
        foreach (($cat["items"] ?? []) as $index => $entry) {
            $key = strtolower((string)($entry["item"] ?? 'item')) . '#' . $index;
            $result[$key] = [
                "name" => $entry["name"] ?? ($entry["item"] ?? 'Item'),
                "item_id" => (string)($entry["item"] ?? ''),
                "item_data" => (string)($entry["itemData"] ?? ''),
                "buy_price" => (float)($entry["buy"] ?? 0),
                "sell_price" => (float)($entry["sell"] ?? 0),
                "amount" => (int)($entry["amount"] ?? 1),
            ];
        }
        return $result;
    }

    public function getEntryForItem(Item|string $item): ?array
    {
        if ($item instanceof Item) {
            foreach ($this->shops as $cat) {
                foreach (($cat["items"] ?? []) as $entry) {
                    $ref = $this->makeShopItem((string)($entry["item"] ?? ''), (string)($entry["name"] ?? ''), 1);
                    if ($ref !== null && $ref->getTypeId() === $item->getTypeId()) {
                        if ($ref->getCustomName() !== '' && $item->getCustomName() !== '' && $ref->getCustomName() !== $item->getCustomName()) {
                            continue;
                        }
                        return [
                            "name" => $entry["name"] ?? $entry["item"],
                            "item_id" => (string)($entry["item"] ?? ''),
                            "buy_price" => (float)($entry["buy"] ?? 0),
                            "sell_price" => (float)($entry["sell"] ?? 0),
                            "amount" => (int)($entry["amount"] ?? 1)
                        ];
                    }
                }
            }
            return null;
        }

        $search = strtolower((string)$item);
        foreach ($this->shops as $cat) {
            foreach (($cat["items"] ?? []) as $entry) {
                if (strtolower((string)($entry["item"] ?? '')) === $search) {
                    return [
                        "name" => $entry["name"] ?? $entry["item"],
                        "item_id" => (string)($entry["item"] ?? ''),
                        "buy_price" => (float)($entry["buy"] ?? 0),
                        "sell_price" => (float)($entry["sell"] ?? 0),
                        "amount" => (int)($entry["amount"] ?? 1)
                    ];
                }
            }
        }
        return null;
    }

    public function countItemInInventory($player, string $itemId): int
    {
        $entry = $this->getEntryForItem($itemId);
        if ($entry === null) return 0;
        $probe = $this->makeShopItem($entry["item_id"], $entry["name"], 1);
        if ($probe === null) return 0;
        $count = 0;
        foreach ($player->getInventory()->getContents() as $invItem) {
            if ($invItem->getTypeId() === $probe->getTypeId()) {
                if ($probe->getCustomName() !== '' && $invItem->getCustomName() !== $probe->getCustomName()) {
                    continue;
                }
                $count += $invItem->getCount();
            }
        }
        return $count;
    }

    public function removeItemFromInventory($player, string $itemId, int $amount): bool
    {
        $entry = $this->getEntryForItem($itemId);
        if ($entry === null) return false;
        $probe = $this->makeShopItem($entry["item_id"], $entry["name"], 1);
        if ($probe === null) return false;

        $remaining = $amount;
        $inv = $player->getInventory();
        $contents = $inv->getContents();
        foreach ($contents as $slot => $invItem) {
            if ($invItem->getTypeId() !== $probe->getTypeId()) continue;
            if ($probe->getCustomName() !== '' && $invItem->getCustomName() !== $probe->getCustomName()) continue;
            $take = min($remaining, $invItem->getCount());
            $invItem->setCount($invItem->getCount() - $take);
            if ($invItem->getCount() <= 0) {
                $inv->clear($slot);
            } else {
                $inv->setItem($slot, $invItem);
            }
            $remaining -= $take;
            if ($remaining <= 0) return true;
        }
        return false;
    }

    public function makeShopItem(string $itemId, ?string $displayName = null, int $amount = 1, ?string $itemData = null): ?Item
    {
        if ($itemData !== null && $itemData !== '') {
            $decoded = $this->itemFromNbt($itemData);
            if ($decoded !== null) {
                $decoded->setCount(max(1, $amount));
                return $decoded;
            }
        }

        $id = strtolower($itemId);
        $item = match ($id) {
            'prisma:freeze_stick', 'special:freeze_stick' => SpecialItems::makeFreezeStick(),
            'prisma:anti_pearl_stick', 'special:anti_pearl', 'prisma:anti_pearl' => SpecialItems::makeAntiPearlStick(),
            'prisma:anti_item_stick', 'special:anti_item', 'prisma:anti_item' => SpecialItems::makeAntiItemStick(),
            'prisma:bump', 'special:bump' => SpecialItems::makeBump(),
            'snowball' => VanillaItems::SNOWBALL(),
            default => StringToItemParser::getInstance()->parse($itemId)
        };
        if ($item === null) return null;
        if ($displayName !== null && $id === 'snowball') {
            $item->setCustomName($displayName);
        }
        $item->setCount(max(1, $amount));
        return $item;
    }

    public function itemToNbt(Item $item): string
    {
        try {
            return base64_encode((new BigEndianNbtSerializer())->write(new TreeRoot($item->nbtSerialize())));
        } catch (\Throwable) {
            return '';
        }
    }

    public function itemFromNbt(string $data): ?Item
    {
        try {
            $raw = base64_decode($data, true);
            if ($raw === false || $raw === '') return null;
            $tag = (new BigEndianNbtSerializer())->read($raw)->mustGetCompoundTag();
            return Item::nbtDeserialize($tag);
        } catch (\Throwable) {
            return null;
        }
    }
}
