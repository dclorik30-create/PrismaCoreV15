<?php

namespace CarailleNoir\managers\option\Faction;

use CarailleNoir\managers\type\Faction\Faction;
use CarailleNoir\player\PrismaPlayer;

enum FactionMessageEnum: string {

    case ALREADY_IN_FACTION = "§cVous êtes déjà dans une faction !";
    case NOT_IN_FACTION = "§cVous ne faites pas parti d'une faction !";
    case TARGET_NOT_IN_FACTION = "§cCe joueur ne fait pas parti de votre faction !";
    case TARGET_ALREADY_IN_FACTION = "§cCe joueur fait déjà parti d'une faction !";
    case NOT_OWNER = "§cVous n'êtes pas le chef de la faction !";
    case KICK_FACTION = "§cVous venez d'être kick de votre faction !";
    case ALREADY_OWNER = "§cVous ne pouvez pas remettre le même chef !";
    case FACTION_NOT_FOUND = "§cFaction introuvable !";
    case NOT_PERMISSION_INVITE = "§cTu n'as pas la permission d'inviter des joueurs !";
    case NOT_PERMISSION_KICK = "§cTu n'as pas la permission de kick des joueurs !";
    case NOT_PERMISSION_PROMOTE = "§cTu n'as pas la permission d'uprank des joueurs!";
    case NOT_PERMISSION_DEMOTE = "§cTu n'as pas la permission d'unrank des joueurs!";
    case NOT_PERMISSION_PROMOTE_PLAYER = "§cTu n'as pas la permission d'uprank ce joueur!";
    case NOT_PERMISSION_DEMOTE_PLAYER = "§cTu n'as pas la permission d'unrank ce joueur!";
    case INVITE_NOT_FOUND = "§cVous n'avez pas d'invitation en attente !";
    case INVITE_EXPIRE = "§cL'invitation à expiré !";
    case IS_OWNER = "§cVous ne pouvez pas faire cela tant que vous êtes chef de votre faction !";
    case NOT_SAME_FACTION = "§cVous ce joueur ne fait pas partie de votre faction !";
    case ALLY_REQUEST_SENT     = "§aVous avez envoyé une demande d'alliance à §f{faction} §a!";
    case ALLY_REQUEST_RECEIVED = "§aLa faction §f{faction} §aveut former une alliance ! §f/f allyaccept";
    case ALLY_ACCEPTED         = "§aL'alliance avec §f{faction} §aest maintenant active !";
    case ALLY_NO_REQUEST       = "§cAucune demande d'alliance en attente !";
    case ALLY_ALREADY          = "§cVous êtes déjà alliés avec cette faction !";
    case NOT_OWNER_OR_SUB      = "§cSeuls le chef et le sous-chef peuvent gérer les alliances !";
    case ISLAND_BUILD_ALLOWED  = "§aLes alliés peuvent maintenant builder sur votre île !";
    case ISLAND_BUILD_DENIED   = "§cLes alliés ne peuvent plus builder sur votre île.";



    case CREATE_FACTION = "§aFaction crée avec succès !";
    case DISBAND_FACTION = "§aVotre Faction à été supprimée avec succès !";
    case NEW_OWNER = "§aVotre nouveau chef de faction est {OwnerName} !";
    case TARGET_NEW_INVITE = "§aVous avez été invite dans la faction {faction}\n§r§u/f accept §r§a pour rejoindre la faction !";
    case SENDER_NEW_INVITE = "§aVous avez invité §r§u{playername}§r§a dans votre faction !";
    case FACTION_INFO = "§l§u--------------- Infos Faction ---------------\n§r§dNom: §f{NAME}\n§dDescription: §f{DESCRIPTION}\n§dChef: §f{OWNER}\n§dSous chefs: §f{SUBOWNER}\n§dOfficiers: §f{OFFICERS}\n§dMembres: §f{MEMBERS}\n§dRecrues: §f{RECRUITS}\n§dAlliances: §f{ALLIES}\n§dPower total: §a{POWER}\n§l§u-------------------------------------------------";
    case FACTION_JOIN = "§aVous avez rejoins la faction §r§u{faction}§r§a !";
    case NEW_FACTION_JOIN = "§u{playername}§r§a vien de rejoindre la faction !";
    case FACTION_LEAVE = "§aVous avez quitté la faction avec succès !";
    case PLAYER_LEAVE = "§aLe joueur §r{playername}§a à quitté la faction !";
    case PROMOTE_PLAYER = "§aLe joueur §r{playername}§a vient de ce faire uprank {rankname}";
    case DEMOTE_PLAYER = "§aLe joueur §r{playername}§a vient de ce faire unrank {rankname}";


    public function sendToPlayer(PrismaPlayer $player, array $replace): void {
        $player->sendMessage(str_ireplace(array_keys($replace), array_values($replace), $this->value));
    }

    public function sendToFaction(Faction $faction, array $replace): void {
        $faction->sendFactionMessage(str_ireplace(array_keys($replace), array_values($replace), $this->value));
    }
}
