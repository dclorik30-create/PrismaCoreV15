<?php

namespace CarailleNoir\managers\option\Faction;

use CarailleNoir\managers\type\Faction\Faction;

enum FactionPermissionEnum:string {
    case INVITE = "faction.invite.permission";
    case KICK = "faction.kick.permission";
    case CLAIM = "faction.claim.permission";
    case PROMOTE     = "faction.promote.permission";
    case BUILD_ISLAND = "faction.build.island";

    public function has(Faction $faction, string $player): bool {
        return $faction->hasPermission($this, $player);
    }
}
