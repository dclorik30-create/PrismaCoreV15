<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;
use pocketmine\item\Item;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\BigEndianNbtSerializer;
use pocketmine\nbt\TreeRoot;
use pocketmine\player\Player;
use pocketmine\Server;

class TIGManager extends DataHandler
{
 public const TIG_WORLD = "TIG";

 public function init(): void { $this->loadData("TIG"); }

 public function addTIG(string $playerName, int $durationSeconds, string $reason, string $staff): void
 {
 $player = Server::getInstance()->getPlayerExact($playerName);
 $invData = null;

 if ($player instanceof Player) {
 // Joueur connecté : on sauvegarde et efface son inventaire maintenant
 $invData = $this->serializeInventory($player);
 $player->getInventory()->clearAll();
 $player->getArmorInventory()->clearAll();
 }
 // Joueur hors-ligne : invData = null, on sauvegarde au login (checkOnLogin)

 $this->data[strtolower($playerName)] = [
 "reason" => $reason,
 "staff" => $staff,
 "expire" => time() + $durationSeconds,
 "blocks_mined" => 0,
 "prev_world" => $player?->getWorld()->getFolderName() ?? "world",
 "inventory" => $invData,
 ];
 $this->saveData();

 if ($player instanceof Player) $this->teleportToTIG($player, $reason);
 }

 public function removeTIG(string $playerName): void
 {
 $key = strtolower($playerName);
 $data = $this->data[$key] ?? null;
 $player = Server::getInstance()->getPlayerExact($playerName);
 unset($this->data[$key]);
 $this->saveData();

 if ($player instanceof Player) {
 // Vider l'inventaire TIG (pioche, etc.) avant de restaurer
 $player->getInventory()->clearAll();
 $player->getArmorInventory()->clearAll();

 if ($data !== null && !empty($data["inventory"])) {
 $this->restoreInventory($player, $data["inventory"]);
 }

 $wm = Server::getInstance()->getWorldManager();
 $prevWorld = $data["prev_world"] ?? "world";
 if (!$wm->isWorldLoaded($prevWorld)) $wm->loadWorld($prevWorld);
 $world = $wm->getWorldByName($prevWorld) ?? $wm->getDefaultWorld();
 if ($world !== null) $player->teleport($world->getSpawnLocation());
 $player->sendMessage("§aVotre TIG est terminé, vous êtes libre !");
 }
 // Joueur hors-ligne : données effacées, checkOnLogin gérera la restauration au prochain login
 }

 public function isTIG(string $playerName): bool
 {
 $key = strtolower($playerName);
 if (!isset($this->data[$key])) return false;
 if (time() > $this->data[$key]["expire"]) { $this->removeTIG($playerName); return false; }
 return true;
 }

 public function getTIGInfo(string $playerName): ?array
 {
 return isset($this->data[strtolower($playerName)]) ? $this->data[strtolower($playerName)] : null;
 }

 public function getRemainingTime(string $playerName): int
 {
 $key = strtolower($playerName);
 $info = $this->data[$key] ?? null;
 return $info ? max(0, $info["expire"] - time()) : 0;
 }

 public function addMinedBlock(string $playerName): void
 {
 $key = strtolower($playerName);
 if (isset($this->data[$key])) $this->data[$key]["blocks_mined"]++;
 }

 public function teleportToTIG(Player $player, string $reason = ""): void
 {
 $wm = Server::getInstance()->getWorldManager();
 if (!$wm->isWorldLoaded(self::TIG_WORLD)) $wm->loadWorld(self::TIG_WORLD);
 $world = $wm->getWorldByName(self::TIG_WORLD);
 if ($world === null) {
 $player->sendMessage("§cErreur : le monde TIG n'existe pas sur ce serveur !");
 return;
 }
 $player->teleport($world->getSpawnLocation());
 $player->getInventory()->clearAll();
 $player->getArmorInventory()->clearAll();

 // Pioche diamant Efficacité III
 // PickaxeOfGod niveau 1 (PrismaItems)
        $pickaxe = \CarailleNoir\items\PickaxeOfGodManager::makeLevel(1, 0);
        if ($pickaxe !== null) { $player->getInventory()->addItem($pickaxe); }

 $remaining = $this->getRemainingTime($player->getName());
 $h = intdiv($remaining, 3600); $m = intdiv($remaining % 3600, 60);
 $s = $remaining % 60;
 $player->sendMessage("§c━━━━━━━━━━━━━━━━━━━━━━━━");
 $player->sendMessage("§cVous avez été placé en TIG.");
 $player->sendMessage("§fRaison : §e" . ($reason ?: "Non précisée"));
 $player->sendMessage("§fDurée restante : §e{$h}h {$m}min {$s}s");
 $player->sendMessage("§c━━━━━━━━━━━━━━━━━━━━━━━━");
 }

 public function checkOnLogin(Player $player): void
 {
 $key = strtolower($player->getName());
 if (!isset($this->data[$key])) return;

 // TIG expiré pendant que le joueur était hors-ligne
 if (time() > $this->data[$key]["expire"]) {
 $data = $this->data[$key];
 unset($this->data[$key]);
 $this->saveData();

 $player->getInventory()->clearAll();
 $player->getArmorInventory()->clearAll();
 if (!empty($data["inventory"])) {
 $this->restoreInventory($player, $data["inventory"]);
 }
 $wm = Server::getInstance()->getWorldManager();
 $prevWorld = $data["prev_world"] ?? "world";
 if (!$wm->isWorldLoaded($prevWorld)) $wm->loadWorld($prevWorld);
 $world = $wm->getWorldByName($prevWorld) ?? $wm->getDefaultWorld();
 if ($world !== null) $player->teleport($world->getSpawnLocation());
 $player->sendMessage("§aVotre TIG est terminé, vous êtes libre !");
 return;
 }

 // TIG actif — si inventaire pas encore sauvegardé (TIG appliqué hors-ligne)
 if (empty($this->data[$key]["inventory"])) {
 $this->data[$key]["inventory"] = $this->serializeInventory($player);
 $this->saveData();
 }

 $this->teleportToTIG($player, $this->data[$key]["reason"] ?? "");
 }

 public function serializeInventory(Player $player): string
 {
 $nbt = new BigEndianNbtSerializer();
 $items = [];
 foreach ($player->getInventory()->getContents() as $slot => $item) {
 $items[] = ["slot" => $slot, "type" => "main", "data" => base64_encode($nbt->write(new TreeRoot($item->nbtSerialize())))];
 }
 foreach ($player->getArmorInventory()->getContents() as $slot => $item) {
 $items[] = ["slot" => $slot, "type" => "armor", "data" => base64_encode($nbt->write(new TreeRoot($item->nbtSerialize())))];
 }
 return base64_encode(json_encode($items));
 }

 private function restoreInventory(Player $player, string $encoded): void
 {
 try {
 $nbt = new BigEndianNbtSerializer();
 $items = json_decode(base64_decode($encoded), true);
 foreach ($items as $entry) {
 $tag = $nbt->read(base64_decode($entry["data"]))->mustGetCompoundTag();
 $item = Item::nbtDeserialize($tag);
 if ($entry["type"] === "armor") $player->getArmorInventory()->setItem((int)$entry["slot"], $item);
 else $player->getInventory()->setItem((int)$entry["slot"], $item);
 }
 } catch (\Throwable) {}
 }
}
