<?php
declare(strict_types=1);
namespace CarailleNoir\managers\type;

use CarailleNoir\Core;
use CarailleNoir\PrismaItems\blocks\DiamondOre;
use CarailleNoir\PrismaItems\blocks\EmeraldOre;
use CarailleNoir\PrismaItems\blocks\RubyOre;
use CarailleNoir\PrismaItems\blocks\PrismOre;
use pocketmine\block\Block;
use pocketmine\scheduler\ClosureTask;
use pocketmine\block\VanillaBlocks;
use pocketmine\math\Vector3;
use pocketmine\Server;
use pocketmine\world\World;

class MineManager
{
    private const MINE_WORLD     = "Mine";
    private const VIP_MINE_WORLD = "MineVIP";

    /**
     * VipMineRespawnTask appelle tick() toutes les 20 ticks serveur.
     * 1 appel = ~1 seconde.
     */
    private const AIR_TO_BEDROCK_CALLS = 1;
    private const BEDROCK_TO_ORE_CALLS = 20;

    private array $data = [];
    /** @var array<string, true> */
    private array $trackedPositions = [];
    /** @var array<string, int> */
    private array $pendingBedrocks = [];
    /** @var array<string, int> */
    private array $pendingRespawns = [];

    private int $callCount = 0;

    public function register(): void
    {
        $path = Core::getInstance()->getDataFolder() . "mine.json";
        if (!file_exists($path)) {
            file_put_contents($path, json_encode([
                "mine"    => ["world" => self::MINE_WORLD,     "spawn" => ["x" => -1, "y" => 119, "z" => 16], "bedrock_positions" => []],
                "minevip" => ["world" => self::VIP_MINE_WORLD, "spawn" => ["x" => -1, "y" => 119, "z" => 16], "bedrock_positions" => []],
            ], JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE));
        }

        $decoded = json_decode(file_get_contents($path), true) ?? [];
        if (isset($decoded['vipmime']) && !isset($decoded['minevip'])) {
            $decoded['minevip'] = $decoded['vipmime'];
            unset($decoded['vipmime']);
        }
        $decoded['mine']    ??= ["world" => self::MINE_WORLD,     "spawn" => ["x" => -1, "y" => 119, "z" => 16], "bedrock_positions" => []];
        $decoded['minevip'] ??= ["world" => self::VIP_MINE_WORLD, "spawn" => ["x" => -1, "y" => 119, "z" => 16], "bedrock_positions" => []];

        $this->data = $decoded;
        $this->rebuildTrackedPositions();
        $this->save();
    }

    public function save(): void
    {
        file_put_contents(
            Core::getInstance()->getDataFolder() . "mine.json",
            json_encode($this->data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE)
        );
    }

    public function getMineConfig(): array    { return $this->data['mine']    ?? []; }
    public function getVipMineConfig(): array { return $this->data['minevip'] ?? []; }

    public function rollBlock(string $type = 'mine'): ?array
    {
        return ['block' => $this->rollOre(strtolower($type))];
    }

    public function initializeMine(string $type): int
    {
        $type = strtolower($type);
        if (!isset($this->data[$type])) return 0;

        $worldName = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($worldName)) $wm->loadWorld($worldName);

        $world = $this->findWorld($worldName);
        if ($world === null) return 0;

        $positions = [];
        $count = 0;
        $world->loadChunk(0, 0);
        foreach ($world->getLoadedChunks() as $chunkHash => $chunk) {
            World::getXZ($chunkHash, $cx, $cz);
            for ($x = $cx << 4; $x < ($cx << 4) + 16; $x++) {
                for ($z = $cz << 4; $z < ($cz << 4) + 16; $z++) {
                    for ($y = World::Y_MIN; $y <= World::Y_MAX; $y++) {
                        $block = $world->getBlockAt($x, $y, $z);
                        if ($block->getTypeId() === VanillaBlocks::BEDROCK()->getTypeId()) {
                            $positions[] = ['x' => $x, 'y' => $y, 'z' => $z];
                            $count++;
                        }
                    }
                }
            }
        }

        $this->data[$type]['bedrock_positions'] = $positions;
        $this->rebuildTrackedPositions();
        $this->pendingBedrocks = [];
        $this->pendingRespawns = [];
        $this->save();
        return $count;
    }

    public function tick(): void
    {
        $this->callCount++;

        foreach ($this->pendingBedrocks as $key => $readyAtCall) {
            if ($this->callCount < $readyAtCall) continue;

            [$type, $x, $y, $z] = explode(':', $key, 4);
            $ix = (int)$x; $iy = (int)$y; $iz = (int)$z;

            $worldName = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
            $world = $this->findWorld($worldName);
            if ($world === null) continue;

            if (!$this->isTrackedPosition($type, $ix, $iy, $iz)) {
                unset($this->pendingBedrocks[$key]);
                continue;
            }

            $world->setBlockAt($ix, $iy, $iz, VanillaBlocks::BEDROCK());
            $this->pendingRespawns[$key] = $this->callCount + self::BEDROCK_TO_ORE_CALLS;
            unset($this->pendingBedrocks[$key]);
        }

        foreach ($this->pendingRespawns as $key => $readyAtCall) {
            if ($this->callCount < $readyAtCall) continue;

            [$type, $x, $y, $z] = explode(':', $key, 4);
            $ix = (int)$x; $iy = (int)$y; $iz = (int)$z;

            $worldName = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
            $world = $this->findWorld($worldName);
            if ($world === null) continue;

            if (!$this->isTrackedPosition($type, $ix, $iy, $iz)) {
                unset($this->pendingRespawns[$key]);
                continue;
            }

            $world->setBlockAt($ix, $iy, $iz, $this->rollOre($type));
            unset($this->pendingRespawns[$key]);
        }
    }

    public function handleOreBreak(World $world, Vector3 $pos): void
    {
        $worldName = $world->getFolderName();
        $type = $this->getMineTypeByWorld($worldName);
        if ($type === null) return;

        $x = (int)$pos->x; $y = (int)$pos->y; $z = (int)$pos->z;
        if (!$this->isTrackedPosition($type, $x, $y, $z)) return;

        $key = $this->getKey($type, $x, $y, $z);
        unset($this->pendingRespawns[$key]);

        // Bedrock instantanee au tick suivant (meme systeme que la TIG)
        $callCount = &$this->callCount;
        $pending   = &$this->pendingRespawns;
        Core::getInstance()->getScheduler()->scheduleDelayedTask(
            new ClosureTask(function() use ($world, $x, $y, $z, $key, &$callCount, &$pending): void {
                $world->setBlockAt($x, $y, $z, VanillaBlocks::BEDROCK());
                $pending[$key] = $callCount + self::BEDROCK_TO_ORE_CALLS;
            }),
            1
        );
    }

    public function isMineWorld(string $worldName): bool
    {
        return $this->getMineTypeByWorld($worldName) !== null;
    }

    public function canBreakAt(string $worldName, int $x, int $y, int $z): bool
    {
        $type = $this->getMineTypeByWorld($worldName);
        if ($type === null) return false;
        return isset($this->trackedPositions[$this->getKey($type, $x, $y, $z)]);
    }

    public function isVipOreBlock(int $x, int $y, int $z): bool          { return false; }
    public function markVipBlockMined(int $x, int $y, int $z, int $d): void {}
    public function checkVipRespawns(World $world): void                  {}

    private function findWorld(string $worldName): ?World
    {
        $wm = Server::getInstance()->getWorldManager();
        if (!$wm->isWorldLoaded($worldName)) {
            $wm->loadWorld($worldName);
        }
        $world = $wm->getWorldByName($worldName);
        if ($world !== null) return $world;
        foreach ($wm->getWorlds() as $w) {
            if (strtolower($w->getFolderName()) === strtolower($worldName)) return $w;
        }
        return null;
    }

    private function getMineTypeByWorld(string $worldName): ?string
    {
        foreach (['mine', 'minevip'] as $type) {
            $configured = $this->data[$type]['world'] ?? ($type === 'minevip' ? self::VIP_MINE_WORLD : self::MINE_WORLD);
            if (strtolower($worldName) === strtolower($configured)) return $type;
        }
        return null;
    }

    private function isTrackedPosition(string $type, int $x, int $y, int $z): bool
    {
        return isset($this->trackedPositions[$this->getKey($type, $x, $y, $z)]);
    }

    private function rebuildTrackedPositions(): void
    {
        $this->trackedPositions = [];
        foreach (['mine', 'minevip'] as $type) {
            foreach (($this->data[$type]['bedrock_positions'] ?? []) as $pos) {
                $this->trackedPositions[$this->getKey($type, (int)$pos['x'], (int)$pos['y'], (int)$pos['z'])] = true;
            }
        }
    }

    private function getKey(string $type, int $x, int $y, int $z): string
    {
        return $type . ':' . $x . ':' . $y . ':' . $z;
    }

    private function rollOre(string $type): Block
    {
        return match (strtolower($type)) {
            'mine' => $this->weighted([
                [new DiamondOre(), 50],
                [new EmeraldOre(), 35],
                [new RubyOre(),    15],
            ]),
            'minevip' => $this->weighted([
                [new EmeraldOre(), 30],
                [new RubyOre(),    60],
                [new PrismOre(),   10],
            ]),
            'emeraude', 'emerald' => new EmeraldOre(),
            'rubis'               => new RubyOre(),
            'prisme'              => new PrismOre(),
            default               => new DiamondOre(),
        };
    }

    private function weighted(array $entries): Block
    {
        $total = array_sum(array_column($entries, 1));
        $rand  = mt_rand(1, $total);
        $cur   = 0;
        foreach ($entries as [$block, $weight]) {
            $cur += $weight;
            if ($rand <= $cur) return $block;
        }
        return $entries[0][0];
    }
}
