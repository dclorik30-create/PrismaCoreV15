<?php

namespace CarailleNoir\managers\type;

use CarailleNoir\handlers\DataHandler;

class StatsManager extends DataHandler
{
    public function init(): void
    {
        $this->loadData("Stats");
    }

    public function ensurePlayer(string $player): void
    {
        $key = strtolower($player);
        if (!isset($this->data[$key])) {
            $this->data[$key] = [
                "kills"          => 0,
                "deaths"         => 0,
                "power"          => 0,
                "assists"        => 0,
                "killstreak"     => 0,
                "bestkillstreak" => 0,
            ];
        } else {
            $this->data[$key] += [
                "assists"        => 0,
                "killstreak"     => 0,
                "bestkillstreak" => 0,
            ];
        }
    }

    // ── Kills ──────────────────────────────────────────────────────────────

    /**
     * Incrémente le compteur de kills du joueur.
     * NB : le power est géré séparément dans PlayerListener (addPower),
     *      afin de prendre en compte l'atout "powerkill" côté joueur.
     */
    public function addKill(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["kills"]++;
    }

    public function getKills(string $player): int
    {
        return (int)($this->data[strtolower($player)]["kills"] ?? 0);
    }

    // ── Deaths ─────────────────────────────────────────────────────────────

    public function addDeath(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["deaths"]++;
    }

    public function getDeaths(string $player): int
    {
        return (int)($this->data[strtolower($player)]["deaths"] ?? 0);
    }

    // ── Power (stocké par joueur — le power faction = somme des membres) ──

    public function addPower(string $player, int $amount): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["power"] += $amount;
    }

    public function removePower(string $player, int $amount): void
    {
        $this->ensurePlayer($player);
        $key = strtolower($player);
        $this->data[$key]["power"] = max(0, ($this->data[$key]["power"] ?? 0) - $amount);
    }

    public function getPower(string $player): int
    {
        return (int)($this->data[strtolower($player)]["power"] ?? 0);
    }

    // ── Assists ────────────────────────────────────────────────────────────

    public function addAssist(string $player): void
    {
        $this->ensurePlayer($player);
        $this->data[strtolower($player)]["assists"]++;
    }

    public function getAssists(string $player): int
    {
        return (int)($this->data[strtolower($player)]["assists"] ?? 0);
    }

    // ── KillStreak ─────────────────────────────────────────────────────────

    public function incrementKillStreak(string $player): int
    {
        $this->ensurePlayer($player);
        $key    = strtolower($player);
        $streak = ++$this->data[$key]["killstreak"];
        if ($streak > (int)$this->data[$key]["bestkillstreak"]) {
            $this->data[$key]["bestkillstreak"] = $streak;
        }
        return $streak;
    }

    public function resetKillStreak(string $player): void
    {
        $key = strtolower($player);
        if (isset($this->data[$key])) {
            $this->data[$key]["killstreak"] = 0;
        }
    }

    public function getKillStreak(string $player): int
    {
        return (int)($this->data[strtolower($player)]["killstreak"] ?? 0);
    }

    public function getBestKillStreak(string $player): int
    {
        return (int)($this->data[strtolower($player)]["bestkillstreak"] ?? 0);
    }

    // ── KDR ────────────────────────────────────────────────────────────────

    public function getKDR(string $player): string
    {
        $k = $this->getKills($player);
        $d = $this->getDeaths($player);
        return $d === 0 ? (string)$k : number_format($k / $d, 2);
    }

    // ── Tops ───────────────────────────────────────────────────────────────

    public function getTopKills(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["kills"] ?? 0) <=> ($a["kills"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopDeaths(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["deaths"] ?? 0) <=> ($a["deaths"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopPower(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["power"] ?? 0) <=> ($a["power"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopAssists(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["assists"] ?? 0) <=> ($a["assists"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }

    public function getTopKillStreak(int $limit = 10): array
    {
        $sorted = $this->data;
        uasort($sorted, fn($a, $b) => ($b["bestkillstreak"] ?? 0) <=> ($a["bestkillstreak"] ?? 0));
        return array_slice($sorted, 0, $limit, true);
    }
}
