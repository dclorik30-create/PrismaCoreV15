<?php
namespace CarailleNoir\utils;

use CarailleNoir\Core;
use CarailleNoir\invmenu\CraftingTableInvMenuType;
use CarailleNoir\libs\muqsit\invmenu\InvMenuHandler;
use CarailleNoir\entities\BoxNameEntity;
use CarailleNoir\entities\FloatingTextEntity;
use CarailleNoir\entities\vanilla\Creeper;
use CarailleNoir\entities\vanilla\Piglin;
use CarailleNoir\entities\vanilla\Zombie;
use CarailleNoir\entities\vanilla\Skeleton;
use CarailleNoir\libs\CortexPE\Commando\BaseCommand;
use CarailleNoir\libs\CortexPE\Commando\PacketHooker;
use CarailleNoir\listeners\CraftListener;
use CarailleNoir\listeners\EnchantTableListener;
use CarailleNoir\listeners\ItemClearListener;
use CarailleNoir\listeners\KnockbackListener;
use CarailleNoir\listeners\PlayerListener;
use CarailleNoir\listeners\OutpostListener;
use CarailleNoir\listeners\KothListener;
use CarailleNoir\listeners\AfkKeyListener;
use CarailleNoir\listeners\TotemListener;
use CarailleNoir\listeners\ServerListener;
use CarailleNoir\listeners\SpawnerListener;
use CarailleNoir\listeners\StickListener;
use CarailleNoir\listeners\LevelXpListener;
use CarailleNoir\listeners\OreDropListener;
use CarailleNoir\listeners\AutoPickupListener;
use CarailleNoir\listeners\AnvilListener;
use CarailleNoir\managers\Manager;
use CarailleNoir\tasks\ArmorEffectTask;
use CarailleNoir\tasks\AutoSaveTask;
use CarailleNoir\tasks\ClearlagTask;
use CarailleNoir\tasks\PlaytimeTask;
use CarailleNoir\tasks\FlyTask;
use CarailleNoir\tasks\EventTickTask;
use CarailleNoir\tasks\OutpostTask;
use CarailleNoir\tasks\AfkKeyTask;
use CarailleNoir\tasks\TotemTask;
use CarailleNoir\tasks\FloatingTextTask;
use CarailleNoir\tasks\ItemClearTask;
use CarailleNoir\tasks\ScoreboardTask;
use CarailleNoir\tasks\TIGBlockTask;
use CarailleNoir\tasks\TipTask;
use CarailleNoir\tasks\VipMineRespawnTask;
use CarailleNoir\tasks\NameTagTask;
use CarailleNoir\tasks\SpawnMobTask;
use CarailleNoir\tasks\SpawnerTask;
use Exception;
use pocketmine\command\Command;
use pocketmine\crafting\ShapedRecipe;
use pocketmine\crafting\ShapelessRecipe;
use pocketmine\entity\EntityDataHelper;
use pocketmine\entity\Entity;
use pocketmine\entity\EntityFactory;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;
use pocketmine\Server;
use pocketmine\world\World;
use ReflectionClass;
use RecursiveIteratorIterator;
use RecursiveDirectoryIterator;
use SplFileInfo;

class Loader
{
 private static ?ClearlagTask $clearlagTask = null;
 private static ?ItemClearTask $itemClearTask = null;

 /** @throws Exception */
 public function __construct(Core $instance)
 {
 // Enregistrer le type InvMenu workbench pour /craft
 InvMenuHandler::getTypeRegistry()->register(CraftingTableInvMenuType::TYPE_ID, new CraftingTableInvMenuType());
 $this->unloadCommands();
 $this->initCommands($instance);
 $this->clearCustomMobs();
 $this->initTasks();
 $this->initEvents();
 Manager::FACTION()->loadIslands();
 $this->initEntities();
 $this->loadWorlds();
 $this->RemoveCraft();
 }

 private function unloadCommands(): void
 {
 $core = Core::getInstance();
 $commands = ["kick","me","ban","unban","ban-ip","unban-ip","banlist","about"];
 foreach ($commands as $cmd) {
 $c = $core->getServer()->getCommandMap()->getCommand($cmd);
 if ($c !== null) $core->getServer()->getCommandMap()->unregister($c);
 }
 $core->getLogger()->info("Il y a eu un total de §e" . count($commands) . " §fcommandes déchargées !");
 }

 private static function initCommands(Core $instance): void
 {
 $path = __DIR__ . "/../commands";
 $namespace = "CarailleNoir\\commands";
 $counter = 0;
 $map = $instance->getServer()->getCommandMap();
 $iterator = new RecursiveIteratorIterator(new RecursiveDirectoryIterator($path));
 /** @var SplFileInfo $file */
 foreach ($iterator as $file) {
 if ($file->getExtension() !== "php") continue;
 $custompath = str_replace($path . DIRECTORY_SEPARATOR, "", $file->getPathname());
 $class = $namespace . "\\" . str_replace([DIRECTORY_SEPARATOR, ".php"], ["\\", ""], $custompath);
 if (!class_exists($class)) continue;
 $r = new ReflectionClass($class);
 if (($r->isSubclassOf(Command::class) || $r->isSubclassOf(BaseCommand::class)) && !$r->isAbstract()) {
 /** @var Command $command */
 $command = $r->newInstance($instance);
 $old = $map->getCommand($command->getName());
 if ($old !== null) $map->unregister($old);
 $map->register($command->getName(), $command);
 $counter++;
 }
 }
 $instance->getLogger()->notice("§e- §fUn total de §e$counter commandes §fviennent d'être chargés");
 }

 /**
  * Supprime toutes les entités custom (Zombie/Skeleton/Creeper/Piglin) des mondes
  * chargés au démarrage pour éviter le stacking lors d'un redémarrage.
  */
 private function clearCustomMobs(): void
 {
  $wm = Server::getInstance()->getWorldManager();
  $count = 0;
  foreach ($wm->getWorlds() as $world) {
   foreach ($world->getEntities() as $entity) {
    if ($entity instanceof Zombie || $entity instanceof Skeleton
     || $entity instanceof Creeper || $entity instanceof Piglin
    ) {
     $entity->flagForDespawn();
     $count++;
    }
   }
  }
  Core::getInstance()->getLogger()->info("§aClearCustomMobs : §e{$count} §aentites custom supprimees au demarrage.");
 }

 private function initTasks(): void
 {
  $scheduler = Core::getInstance()->getScheduler();

  self::$itemClearTask = new ItemClearTask();
  $scheduler->scheduleRepeatingTask(self::$itemClearTask, 100);

  self::$clearlagTask = new ClearlagTask();

  $scheduler->scheduleRepeatingTask(new ArmorEffectTask(), 20);
  $scheduler->scheduleRepeatingTask(new VipMineRespawnTask(), 20);
  // VipMineRespawnTask supprimée — MineVIP géré par plugin externe
  // ScoreboardTask : intervalle 100 ticks (5s) pour re-sync si un joueur
  // perd son scoreboard (chunk reload, reconnexion partielle, etc.)
  $scheduler->scheduleRepeatingTask(new ScoreboardTask(), 100);
  $scheduler->scheduleRepeatingTask(new FloatingTextTask(), 1200);
  $scheduler->scheduleRepeatingTask(new TIGBlockTask(), 20);
  $scheduler->scheduleRepeatingTask(new TipTask(), 40);
  $scheduler->scheduleRepeatingTask(new SpawnMobTask(), 20);
  $scheduler->scheduleRepeatingTask(new SpawnerTask(), 600);
  $scheduler->scheduleRepeatingTask(new EventTickTask(), 20);
  $scheduler->scheduleRepeatingTask(new OutpostTask(), 20);
  $scheduler->scheduleRepeatingTask(new AfkKeyTask(), 20);
  $scheduler->scheduleRepeatingTask(new TotemTask(), 20);

  $scheduler->scheduleRepeatingTask(new \pocketmine\scheduler\ClosureTask(
   static function(): void { Manager::FACTION()->save(); }
  ), 6000);

  $scheduler->scheduleRepeatingTask(new AutoSaveTask(), 6000);
  $scheduler->scheduleRepeatingTask(new PlaytimeTask(), 20 * 60);
  $scheduler->scheduleRepeatingTask(new FlyTask(), 20);

  Core::getInstance()->getLogger()->info("§aTasks chargees !");
 }

 private function initEvents(): void
 {
 $core = Core::getInstance();
 $events = [
 new PlayerListener(),
 new KnockbackListener(),
 new ServerListener(),
 new StickListener(),
 new SpawnerListener(),
 new EnchantTableListener(),
 new ItemClearListener(self::$itemClearTask),
 new PacketHooker(),
 new OutpostListener(),
            new KothListener(),
            new AfkKeyListener(),
            new TotemListener(),
            new LevelXpListener(Core::getInstance()->getDataFolder()),
            new OreDropListener(),
            new AutoPickupListener(),
            new AnvilListener(),
 ];
 foreach ($events as $event) {
 $core->getServer()->getPluginManager()->registerEvents($event, Core::getInstance());
 }
 $core->getLogger()->info("Il y a eu un total de §e" . count($events) . " §fevents chargés !");
 }

 public static function getClearlagTask(): ?ClearlagTask { return self::$clearlagTask; }
 public static function getItemClearTask(): ?ItemClearTask { return self::$itemClearTask; }

 private function initEntities(): void
 {
 EntityFactory::getInstance()->register(FloatingTextEntity::class, static fn(World $world, CompoundTag $nbt): Entity => new FloatingTextEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["FloatingText"]);
 EntityFactory::getInstance()->register(BoxNameEntity::class, static fn(World $world, CompoundTag $nbt): Entity => new BoxNameEntity(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["BoxName"]);
 EntityFactory::getInstance()->register(Creeper::class, static fn(World $world, CompoundTag $nbt): Entity => new Creeper(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["Creeper"]);
 EntityFactory::getInstance()->register(Zombie::class, static fn(World $world, CompoundTag $nbt): Entity => new Zombie(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["PrismaZombie"]);
 EntityFactory::getInstance()->register(Piglin::class, static fn(World $world, CompoundTag $nbt): Entity => new Piglin(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["PrismaPiglin"]);
 EntityFactory::getInstance()->register(Skeleton::class, static fn(World $world, CompoundTag $nbt): Entity => new Skeleton(EntityDataHelper::parseLocation($nbt, $world), $nbt), ["Skeleton"]);
 }

 private function loadWorlds(): void
 {
 $core = Core::getInstance();
 $wm = $core->getServer()->getWorldManager();
 $dir = $core->getServer()->getDataPath() . "worlds/";
 if (!is_dir($dir)) { $core->getLogger()->info("Le dossier de mondes n'existe pas"); return; }
 $loaded = 0;
 foreach (array_filter(glob($dir . "*"), 'is_dir') as $d) {
 $name = basename($d);
 if (!$wm->isWorldLoaded($name)) { $wm->loadWorld($name, true); $loaded++; }
 }
 // Tuer tous les mobs de spawners résiduels (avant que SpawnerTask en respawn)
 $killed = 0;
 foreach ($wm->getWorlds() as $world) {
 foreach ($world->getEntities() as $entity) {
 if ($entity instanceof \CarailleNoir\entities\vanilla\Zombie
 || $entity instanceof \CarailleNoir\entities\vanilla\Skeleton
 || $entity instanceof \CarailleNoir\entities\vanilla\Creeper) {
 $entity->kill();
 $killed++;
 }
 }
 }
 if ($killed > 0) $core->getLogger()->info("§e{$killed} §fmob(s) de spawner tués au démarrage.");
 $core->getLogger()->info("Il y a eu un total de §e{$loaded} §fmondes chargés !");
 }

 /** @throws \ReflectionException */
 public function RemoveCraft(): void
 {
 $removed = [];
 $targets = [
 VanillaItems::DIAMOND_BOOTS(), VanillaItems::DIAMOND_LEGGINGS(),
 VanillaItems::DIAMOND_CHESTPLATE(), VanillaItems::DIAMOND_HELMET(),
 VanillaItems::DIAMOND_SWORD(), VanillaItems::IRON_BOOTS(),
 VanillaItems::IRON_LEGGINGS(), VanillaItems::IRON_CHESTPLATE(),
 VanillaItems::IRON_HELMET(), VanillaItems::IRON_SWORD(),
 ];
 foreach ($targets as $i) $removed[] = $i->getTypeId();

 $cm = Server::getInstance()->getCraftingManager();
 $rc = new \ReflectionClass($cm);
 $newRecipes = [];
 foreach ($cm->getCraftingRecipeIndex() as $recipe) {
 $valid = true;
 if ($recipe instanceof ShapedRecipe || $recipe instanceof ShapelessRecipe) {
 foreach ($recipe->getResults() as $item) if (in_array($item->getTypeId(), $removed)) $valid = false;
 }
 if ($valid) $newRecipes[] = $recipe;
 }
 $p = $rc->getProperty("craftingRecipeIndex");
 $p->setAccessible(true);
 $p->setValue($cm, $newRecipes);
 $p->setAccessible(false);
 }
}