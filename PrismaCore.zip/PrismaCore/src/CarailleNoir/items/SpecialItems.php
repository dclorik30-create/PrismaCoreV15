<?php
declare(strict_types=1);
namespace CarailleNoir\items;

use CarailleNoir\PrismaItems\items\staff\AntiItemStick;
use CarailleNoir\PrismaItems\items\staff\AntiPearlStick;
use CarailleNoir\PrismaItems\items\staff\ArcPunchItem;
use CarailleNoir\PrismaItems\items\staff\BumpItem;
use CarailleNoir\PrismaItems\items\staff\FreezeStick;
use CarailleNoir\PrismaItems\items\staff\PumpkinStick;
use CarailleNoir\PrismaItems\items\staff\TeleportStick;
use CarailleNoir\PrismaItems\items\consumable\SoupItem;
use pocketmine\item\Item;
use pocketmine\item\StringToItemParser;
use pocketmine\item\ItemTypeIds;
use pocketmine\block\VanillaBlocks;
use pocketmine\item\VanillaItems;
use pocketmine\nbt\tag\CompoundTag;

class SpecialItems
{
 private const LORE_FREEZE = "§8ID:stick_freeze";
 private const LORE_ANTIPEARL = "§8ID:stick_antipearl";
 private const LORE_ANTIITEM = "§8ID:stick_antiitem";
 private const LORE_ARCPUNCH = "§8ID:item_arcpunch";
 private const LORE_SWITCH = "§8ID:item_switchball";
 private const LORE_BUMP = "§8ID:item_bump";
 private const LORE_EGGTRAP = "§8ID:item_eggtrap";
 private const LORE_PUMPKIN = "§8ID:stick_pumpkin";
 private const LORE_TELEPORT = "§8ID:stick_teleport";
 public const LORE_TEMP_PUMPKIN = "§8ID:temp_pumpkin";
 private const LORE_SANCTION = "§8ID:staff_sanction";

 
 public static function makeSanctionStick(): Item
 {
 $item = VanillaItems::BLAZE_ROD()->setCount(1);
 $item->setCustomName("§cSanction");
 $item->setLore([self::LORE_SANCTION]);
 return $item;
 }

 public static function isSanctionStick(Item $item): bool
 {
 return in_array(self::LORE_SANCTION, $item->getLore(), true);
 }

public static function makeFreezeStick(): Item
 {
 // FreezeStick (custom, texture RP correcte)
 $item = (new FreezeStick())->setCount(1);
 return $item;
 }

 public static function makeAntiPearlStick(): Item
 {
 return (new AntiPearlStick())->setCount(1);
 }

 public static function makeAntiItemStick(): Item
 {
 return (new AntiItemStick())->setCount(1);
 }

 public static function makeArcPunch(): Item
 {
 return (new ArcPunchItem())->setCount(1);
 }

 public static function makeSwitchBall(): Item
 {
 $item = VanillaItems::SNOWBALL()->setCount(1);
 $item->setCustomName("§5 SwitchBall");
 $item->setLore([self::LORE_SWITCH, "§7Lance et échange ta position !", "§eCooldown : §f180s"]);
 return $item;
 }

 private const LORE_SOUP = "§8ID:item_soup";

 /**
 * Soupe custom — utilise prisma:soup (stackable x64, enregistré dans PrismaItems).
 * Fallback sur MUSHROOM_STEW si PrismaItems n'est pas chargé.
 */
 public static function makeSoup(int $count = 1): Item
 {
 $item = StringToItemParser::getInstance()->parse("prisma:soup");
 if ($item === null) {
 // Fallback si PrismaItems pas encore chargé
 $item = VanillaItems::MUSHROOM_STEW();
 $item->setCustomName("§c§lSoupe§r §7(+4 PV)");
 $item->setLore([self::LORE_SOUP, "§7Clic droit pour se soigner."]);
 }
 return $item->setCount(max(1, min($count, 64)));
 }

 public static function isSoup(Item $item): bool { return in_array(self::LORE_SOUP, $item->getLore(), true); }

 public static function makeBump(): Item
 {
 return (new BumpItem())->setCount(1);
 }

 public static function isFreezeStick(Item $item): bool { return in_array(self::LORE_FREEZE, $item->getLore(), true); }
 public static function isAntiPearlStick(Item $item): bool { return in_array(self::LORE_ANTIPEARL, $item->getLore(), true); }
 public static function isAntiItemStick(Item $item): bool { return in_array(self::LORE_ANTIITEM, $item->getLore(), true); }
 public static function isArcPunch(Item $item): bool { return in_array(self::LORE_ARCPUNCH, $item->getLore(), true); }
 public static function isSwitchBall(Item $item): bool { return in_array(self::LORE_SWITCH, $item->getLore(), true); }
 public static function isBump(Item $item): bool { return in_array(self::LORE_BUMP, $item->getLore(), true); }
 public static function makeEggTrap(): Item
 {
 $item = VanillaItems::EGG()->setCount(1);
 $item->setCustomName("§2EggTrap");
 $item->setLore([self::LORE_EGGTRAP, "§7Bloque les ennemis en toiles !", "§eCD : §f180s"]);
 return $item;
 }

 public static function isEggTrap(Item $item): bool { return in_array(self::LORE_EGGTRAP, $item->getLore(), true); }

 public static function isPumpkinStick(Item $item): bool { return in_array(self::LORE_PUMPKIN, $item->getLore(), true); }
 public static function isTeleportStick(Item $item): bool { return in_array(self::LORE_TELEPORT, $item->getLore(), true); }

 public static function makePumpkinStick(): Item
 {
 return (new PumpkinStick())->setCount(1);
 }

 public static function makeTeleportStick(): Item
 {
 return (new TeleportStick())->setCount(1);
 }

 public static function makeTempPumpkin(): Item
 {
 // VanillaItems::CARVED_PUMPKIN() n'existe pas en PM5 — utiliser VanillaBlocks
 $item = VanillaBlocks::CARVED_PUMPKIN()->asItem()->setCount(1);
 $item->setCustomName("§6Citrouille");
 $item->setLore([self::LORE_TEMP_PUMPKIN]);
 return $item;
 }

 public static function isAntiItemBlockedItem(Item $item): bool
 {
 return self::isBump($item) || self::isSwitchBall($item) || self::isFreezeStick($item)
 || self::isAntiPearlStick($item) || self::isAntiItemStick($item) || self::isArcPunch($item)
 || self::isPumpkinStick($item) || self::isTeleportStick($item) || self::isEggTrap($item);
 }
 // ── Cash custom items ───────────────────────────────────────────────────
 private const LORE_CASH_MONEY = "§8ID:cash_money_";
 private const LORE_CASH_COINS = "§8ID:cash_coins_";
 private const TAG_CASH_TYPE = "prisma_cash_type";
 private const TAG_CASH_AMOUNT = "prisma_cash_amount";

 public static function makeCashMoney(float $amount): Item
 {
 $item = StringToItemParser::getInstance()->parse("prisma:cash_money") ?? VanillaItems::PAPER();
 $item->setCount(1);
 $item->setCustomName("§6Cash Money §e" . number_format($amount, 0, ",", " ") . "§6$");
 $item->setLore([
 self::LORE_CASH_MONEY . (string)$amount,
 "§7Valeur : §e" . number_format($amount, 0, ",", " ") . "§6$",
 "§7Fais un clic droit pour encaisser."
 ]);
 $tag = $item->getNamedTag();
 $tag->setString(self::TAG_CASH_TYPE, "money");
 $tag->setFloat(self::TAG_CASH_AMOUNT, (float)$amount);
 $item->setNamedTag($tag);
 return $item;
 }

 public static function makeCashCoins(int $amount): Item
 {
 $item = StringToItemParser::getInstance()->parse("prisma:cash_coins") ?? VanillaItems::PAPER();
 $item->setCount(1);
 $item->setCustomName("§5Cash Coins §b" . number_format($amount, 0, ",", " ") . "§5 Coins");
 $item->setLore([
 self::LORE_CASH_COINS . (string)$amount,
 "§7Valeur : §b" . number_format($amount, 0, ",", " ") . "§5 Coins",
 "§7Fais un clic droit pour encaisser."
 ]);
 $tag = $item->getNamedTag();
 $tag->setString(self::TAG_CASH_TYPE, "coins");
 $tag->setInt(self::TAG_CASH_AMOUNT, (int)$amount);
 $item->setNamedTag($tag);
 return $item;
 }

 public static function isCashMoney(Item $item): bool
 {
 $tag = $item->getNamedTag();
 if($tag->getTag(self::TAG_CASH_TYPE) !== null && $tag->getString(self::TAG_CASH_TYPE, "") === "money") return true;
 foreach ($item->getLore() as $line) {
 if (str_starts_with($line, self::LORE_CASH_MONEY)) return true;
 }
 return false;
 }

 public static function isCashCoins(Item $item): bool
 {
 $tag = $item->getNamedTag();
 if($tag->getTag(self::TAG_CASH_TYPE) !== null && $tag->getString(self::TAG_CASH_TYPE, "") === "coins") return true;
 foreach ($item->getLore() as $line) {
 if (str_starts_with($line, self::LORE_CASH_COINS)) return true;
 }
 return false;
 }

 public static function getCashMoneyAmount(Item $item): float
 {
 $tag = $item->getNamedTag();
 if($tag->getTag(self::TAG_CASH_AMOUNT) !== null){ return (float)$tag->getFloat(self::TAG_CASH_AMOUNT, 0.0); }
 foreach ($item->getLore() as $line) {
 if (str_starts_with($line, self::LORE_CASH_MONEY)) return (float) mb_substr($line, mb_strlen(self::LORE_CASH_MONEY));
 }
 return 0.0;
 }

 public static function getCashCoinsAmount(Item $item): int
 {
 $tag = $item->getNamedTag();
 if($tag->getTag(self::TAG_CASH_AMOUNT) !== null){ return (int)$tag->getInt(self::TAG_CASH_AMOUNT, 0); }
 foreach ($item->getLore() as $line) {
 if (str_starts_with($line, self::LORE_CASH_COINS)) return (int) mb_substr($line, mb_strlen(self::LORE_CASH_COINS));
 }
 return 0;
 }


}