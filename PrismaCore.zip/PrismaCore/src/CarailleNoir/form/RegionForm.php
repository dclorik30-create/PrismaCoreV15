<?php

namespace CarailleNoir\form;

use CarailleNoir\libs\forms\CustomForm;
use CarailleNoir\managers\Manager;
use CarailleNoir\managers\option\RegionOption;
use CarailleNoir\managers\type\Region\Region;
use CarailleNoir\player\PrismaPlayer;

class RegionForm
{
 /** Params par défaut utilisés pour le merge (régions créées avant l'ajout de PARAM_USE) */
 private static function defaultParams(): array
 {
 return [
 RegionOption::PARAM_PVP->getType()        => true,
 RegionOption::PARAM_BUILD->getType()       => false,
 RegionOption::PARAM_INTERACT->getType()    => false,
 RegionOption::PARAM_GROW->getType()        => false,
 RegionOption::PARAM_DECAY->getType()       => false,
 RegionOption::PARAM_DROP->getType()        => true,
 RegionOption::PARAM_PICKUP->getType()      => true,
 RegionOption::PARAM_EXPLOSION->getType()   => false,
 RegionOption::PARAM_HUNGER->getType()      => false,
 RegionOption::PARAM_ENDERPEARL->getType()  => true,
 RegionOption::PARAM_CHAT->getType()        => true,
 RegionOption::PARAM_FIRE_DAMAGE->getType() => false,
 RegionOption::PARAM_FALL_DAMAGE->getType() => false,
 RegionOption::PARAM_USE->getType()         => true,
 ];
 }

 public static function listMenu(): CustomForm
 {
 $form = new CustomForm(function (PrismaPlayer $player, ?array $data): void {
 if ($data === null || !isset($data[0])) {
 return;
 }

 self::baseMenu($player, $data[0]);
 });

 $regions = Manager::REGION()->getRegions();
 $form->addDropdown("Liste de régions", $regions);

 $form->setTitle("Sélecteur de région");
 return $form;
 }

 public static function baseMenu(PrismaPlayer $player, string $id): void
 {
 $regionInfo = Manager::REGION()->getRegionById($id);
 if ($regionInfo === null) {
 return;
 }

 // Merge : les régions existantes sans PARAM_USE récupèrent la valeur par défaut
 $mergedParams = array_merge(self::defaultParams(), $regionInfo->getParams());

 $form = new CustomForm(function(PrismaPlayer $player, ?array $data) use ($id, $regionInfo, $mergedParams): void {
 if ($data === null) {
 return;
 }

 $newName = $data[0] ?? $regionInfo->getName();
 $newPriority = isset($data[1]) && is_numeric($data[1])
 ? (int)$data[1]
 : $regionInfo->getPriority();

 $newParams = [];
 foreach ($mergedParams as $perm => $status) {
 $cleanKey = str_replace("region.setting.", "", $perm);
 if (array_key_exists($cleanKey, $data)) {
 $newParams[$perm] = $data[$cleanKey];
 } else {
 $newParams[$perm] = $status;
 }
 }

 Manager::REGION()->editRegion($player, $id, new Region($id, $newName, $regionInfo->getZone(), $regionInfo->getWorldName(), $newPriority, $newParams));
 });

 $form->setTitle("Edit {$regionInfo->getName()}");
 $form->addInput("Nom", "Exemple: Spawn", $regionInfo->getName());
 $form->addInput("Priorité", "Exemple: 0 ou 1 ou ... ", $regionInfo->getPriority());

 // Rendu des toggles avec merge pour afficher PARAM_USE même sur les anciennes régions
 foreach ($mergedParams as $perm => $status) {
 $key = str_replace("region.setting.", "", $perm);

 if (is_bool($status)) {
 $form->addToggle(ucfirst($key), $status, $key);
 } elseif (is_numeric($status)) {
 $form->addToggle(ucfirst($key), (bool)$status, $key);
 } elseif (is_string($status)) {
 $form->addInput(ucfirst($key), "Texte du paramètre", $status, $key);
 }
 }
 $form->sendToPlayer($player);
 }
}
